package com.udharhisab.reminder

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.udharhisab.MainActivity
import com.udharhisab.domain.UnitConverter
import kotlinx.coroutines.flow.first
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * ⭐ প্রতিদিন একবার চেক — reminderDays-এর বেশি দিন ধরে বাকি থাকা দোকানে নোটিফিকেশন
 */
class ReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repo = ReminderDeps.repo(applicationContext)
        val store = ReminderDeps.store(applicationContext)

        val settings = store.settings.first()
        if (!settings.remindersEnabled) return Result.success()

        val due = repo.dueForReminder(settings.reminderDays)
        if (due.isEmpty()) return Result.success()

        if (hasNotificationPermission()) {
            due.forEach { (shop, balance) ->
                if (balance > 0) showNotification(shop.id, shop.name, balance, settings.language)
            }
        }
        return Result.success()
    }

    private fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        return ContextCompat.checkSelfPermission(
            applicationContext, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun showNotification(shopId: Long, shopName: String, balance: Double, language: String) {
        val ctx = applicationContext
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, "বাকি রিমাইন্ডার", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "দোকানের বাকি মনে করিয়ে দেয়" }
        )

        // ⭐ ট্যাপ → MainActivity → সরাসরি ওই দোকান
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("navigate_to_shop", shopId)
        }
        val pi = PendingIntent.getActivity(
            ctx, shopId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // ⭐ ফিক্স: আগে এখানে ভাঙা string template ছিল ("shopName—shopName..." literally),
        // দোকানের নাম/টাকার অঙ্ক আসলে কখনো নোটিফিকেশনে দেখাতোই না।
        val dueText = if (language == "en") "$shopName — ${UnitConverter.rupees(balance)} due"
                      else "$shopName — ${UnitConverter.rupees(balance)} বাকি আছে"
        val bigText = if (language == "en")
            "$shopName owes ${UnitConverter.rupees(balance)}.\nDon't forget to record payment in the app once settled."
        else
            "$shopName দোকানে ${UnitConverter.rupees(balance)} বাকি আছে।\nপরিশোধ হলে অ্যাপে জমা দিতে ভুলবেন না।"

        val notification = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(ctx.applicationInfo.icon)
            .setContentTitle(if (language == "en") "Due reminder" else "বাকি মনে করিয়ে দিলাম")
            .setContentText(dueText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        try {
            nm.notify(shopId.toInt(), notification)
        } catch (_: SecurityException) { /* পারমিশন নেই */ }
    }

    companion object {
        const val CHANNEL_ID = "reminders"
        const val WORK_NAME = "daily_reminder"

        /** প্রতিদিন সকাল ৯টায় */
        fun schedule(context: Context) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 9)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val delay = target.timeInMillis - System.currentTimeMillis()

            val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setConstraints(
                    Constraints.Builder().setRequiresBatteryNotLow(true).build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
