package com.udharhisab.domain

import java.security.MessageDigest

/**
 * ⭐ পিন কখনো প্লেইন টেক্সটে রাখা হয় না — SHA-256 হ্যাশ
 */
object PinHasher {

    private const val SALT = "dhar_hisab_v1_salt"   // প্রজেক্ট-স্পেসিফিক ফিক্সড সল্ট

    fun hash(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest((SALT + pin).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verify(input: String, storedHash: String): Boolean =
        hash(input) == storedHash
}
