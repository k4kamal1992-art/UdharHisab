package com.udharhisab.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate as rotateDraw
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ হাতে-আঁকা ধাঁচের রঙিন ইলাস্ট্রেশন — কোনো ছবির ফাইল ছাড়া, সরাসরি Compose Canvas-এ আঁকা।
 * তাই যেকোনো স্ক্রিনে ধারালো থাকে, ডার্ক থিমেও মানায়, আর অ্যাপের সাইজ বাড়ায় না।
 * সবগুলো আস্তে আস্তে ওঠানামা করে (floating), যাতে খালি পেজও প্রাণবন্ত লাগে।
 */
object Friendly {
    val Coral = Color(0xFFFF8A65)
    val Sun = Color(0xFFFFC857)
    val Mint = Color(0xFF7DDAB9)
    val Teal = Color(0xFF14B8A6)
    val Deep = Color(0xFF087F5B)
    val Sky = Color(0xFF8EC5FF)
    val Cream = Color(0xFFFFF4DB)
    val Rose = Color(0xFFFF9EB5)
    val Violet = Color(0xFFB39DFF)
}

/** ⭐ আইকন-টাইল ও অবতারের রঙ — (নরম জমি, গাঢ় আইকন); একই নাম সবসময় একই রং পায় */
object FriendlyTiles {
    val list = listOf(
        Color(0xFFD9F5EA) to Color(0xFF087F5B),
        Color(0xFFFFE3D9) to Color(0xFFE2562B),
        Color(0xFFFFF0C9) to Color(0xFFB77F00),
        Color(0xFFDCEEFF) to Color(0xFF2B6FD1),
        Color(0xFFECE4FF) to Color(0xFF6A47D6),
        Color(0xFFFFE0E8) to Color(0xFFD1355F)
    )
    fun forKey(key: String): Pair<Color, Color> = list[kotlin.math.abs(key.hashCode()) % list.size]
}

@Composable
private fun rememberFloat(durationMs: Int = 2600): Float {
    val t = rememberInfiniteTransition(label = "illustration")
    val v by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "float"
    )
    return v
}

/** ৪-কোণা ঝিলিক (sparkle) */
private fun DrawScope.sparkle(center: Offset, r: Float, color: Color) {
    val p = Path().apply {
        moveTo(center.x, center.y - r)
        quadraticBezierTo(center.x, center.y, center.x + r, center.y)
        quadraticBezierTo(center.x, center.y, center.x, center.y + r)
        quadraticBezierTo(center.x, center.y, center.x - r, center.y)
        quadraticBezierTo(center.x, center.y, center.x, center.y - r)
        close()
    }
    drawPath(p, color)
}

/** টাকার কয়েন */
private fun DrawScope.coin(center: Offset, r: Float) {
    drawCircle(Friendly.Sun, r, center)
    drawCircle(Color(0xFFE5A92B), r, center, style = Stroke(width = r * 0.14f))
    drawCircle(Color(0xFFFFE08A), r * 0.55f, center)
}

/**
 * 🏪 ছোট্ট দোকান — "কোনো দোকান/কাস্টমার নেই" ও প্রথমবারের পেজে।
 */
@Composable
fun ShopIllustration(modifier: Modifier = Modifier.size(210.dp, 180.dp)) {
    val f = rememberFloat()
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val bob = (f - 0.5f) * 8.dp.toPx()

        // নরম ব্যাকগ্রাউন্ড বৃত্ত + মাটির ছায়া
        drawCircle(Friendly.Mint.copy(alpha = 0.28f), w * 0.44f, Offset(w * 0.5f, h * 0.5f))
        drawOval(Color(0x22000000), Offset(w * 0.2f, h * 0.9f), Size(w * 0.6f, h * 0.07f))

        translate(top = bob) {
            // দোকানের দেয়াল
            drawRoundRect(Color.White, Offset(w * 0.2f, h * 0.38f), Size(w * 0.6f, h * 0.5f), CornerRadius(14f))
            drawRoundRect(Friendly.Mint.copy(alpha = 0.6f), Offset(w * 0.2f, h * 0.38f), Size(w * 0.6f, h * 0.5f),
                CornerRadius(14f), style = Stroke(3f))

            // ছাদ
            drawRoundRect(Friendly.Deep, Offset(w * 0.13f, h * 0.17f), Size(w * 0.74f, h * 0.08f), CornerRadius(12f))

            // ডোরাকাটা চাঁদোয়া (awning) — গোল ঝালর সহ
            val stripes = 6
            val sw = (w * 0.74f) / stripes
            for (i in 0 until stripes) {
                val x = w * 0.13f + i * sw
                val col = if (i % 2 == 0) Friendly.Coral else Friendly.Cream
                drawRect(col, Offset(x, h * 0.24f), Size(sw, h * 0.12f))
                drawCircle(col, sw / 2f, Offset(x + sw / 2f, h * 0.36f))
            }

            // দরজা
            drawRoundRect(Friendly.Teal, Offset(w * 0.3f, h * 0.56f), Size(w * 0.17f, h * 0.32f), CornerRadius(10f))
            drawCircle(Friendly.Sun, w * 0.012f, Offset(w * 0.445f, h * 0.73f))

            // জানালা
            drawRoundRect(Friendly.Sky, Offset(w * 0.55f, h * 0.53f), Size(w * 0.19f, h * 0.17f), CornerRadius(8f))
            drawLine(Color.White, Offset(w * 0.645f, h * 0.53f), Offset(w * 0.645f, h * 0.70f), 4f)
            drawLine(Color.White, Offset(w * 0.55f, h * 0.615f), Offset(w * 0.74f, h * 0.615f), 4f)

            // ফুলের টব
            drawRoundRect(Friendly.Coral, Offset(w * 0.08f, h * 0.78f), Size(w * 0.08f, h * 0.1f), CornerRadius(6f))
            drawOval(Friendly.Mint, Offset(w * 0.055f, h * 0.66f), Size(w * 0.07f, h * 0.14f))
            drawOval(Friendly.Deep.copy(alpha = 0.8f), Offset(w * 0.11f, h * 0.68f), Size(w * 0.06f, h * 0.12f))
        }

        // ভাসমান কয়েন ও ঝিলিক (উল্টো দিকে ওঠানামা)
        val bob2 = (0.5f - f) * 10.dp.toPx()
        coin(Offset(w * 0.86f, h * 0.2f + bob2), w * 0.07f)
        coin(Offset(w * 0.12f, h * 0.36f - bob2 * 0.6f), w * 0.045f)
        sparkle(Offset(w * 0.9f, h * 0.5f), w * 0.04f, Friendly.Sun)
        sparkle(Offset(w * 0.08f, h * 0.18f), w * 0.035f, Friendly.Rose)
        sparkle(Offset(w * 0.72f, h * 0.08f + bob2 * 0.4f), w * 0.028f, Friendly.Violet)
    }
}

/**
 * 📒 খাতা + পেনসিল — "এখনো কোনো লেনদেন নেই" পেজে।
 */
@Composable
fun LedgerIllustration(modifier: Modifier = Modifier.size(200.dp, 160.dp)) {
    val f = rememberFloat(2200)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val bob = (f - 0.5f) * 8.dp.toPx()

        drawCircle(Friendly.Sun.copy(alpha = 0.22f), w * 0.42f, Offset(w * 0.5f, h * 0.5f))
        drawOval(Color(0x22000000), Offset(w * 0.22f, h * 0.88f), Size(w * 0.56f, h * 0.07f))

        translate(top = bob) {
            // খাতার পাতা
            drawRoundRect(Color.White, Offset(w * 0.24f, h * 0.14f), Size(w * 0.5f, h * 0.7f), CornerRadius(16f))
            drawRoundRect(Friendly.Mint, Offset(w * 0.24f, h * 0.14f), Size(w * 0.5f, h * 0.7f), CornerRadius(16f), style = Stroke(3f))
            // বাঁধাই (spine)
            drawRoundRect(Friendly.Teal, Offset(w * 0.2f, h * 0.14f), Size(w * 0.09f, h * 0.7f), CornerRadius(12f))
            for (i in 0 until 5) {
                drawCircle(Color.White, w * 0.012f, Offset(w * 0.245f, h * (0.22f + i * 0.13f)))
            }
            // লাইন টানা (ruled)
            for (i in 0 until 5) {
                val y = h * (0.28f + i * 0.11f)
                drawLine(Friendly.Mint.copy(alpha = 0.7f), Offset(w * 0.34f, y), Offset(w * 0.68f, y), 4f)
            }
            // শিরোনামের রঙিন দাগ + টিক
            drawRoundRect(Friendly.Coral, Offset(w * 0.34f, h * 0.2f), Size(w * 0.18f, h * 0.035f), CornerRadius(8f))
            drawCircle(Friendly.Mint, w * 0.035f, Offset(w * 0.64f, h * 0.2f + h * 0.0175f))
        }

        // পেনসিল (হেলানো)
        val bob2 = (0.5f - f) * 6.dp.toPx()
        translate(top = bob2) {
            val pivot = Offset(w * 0.74f, h * 0.55f)
            rotateDraw(35f, pivot) {
                drawRoundRect(Friendly.Sun, Offset(w * 0.71f, h * 0.28f), Size(w * 0.06f, h * 0.38f), CornerRadius(6f))
                drawRect(Friendly.Rose, Offset(w * 0.71f, h * 0.24f), Size(w * 0.06f, h * 0.05f))
                val tip = Path().apply {
                    moveTo(w * 0.71f, h * 0.66f); lineTo(w * 0.77f, h * 0.66f); lineTo(w * 0.74f, h * 0.74f); close()
                }
                drawPath(tip, Friendly.Cream)
                val lead = Path().apply {
                    moveTo(w * 0.73f, h * 0.71f); lineTo(w * 0.75f, h * 0.71f); lineTo(w * 0.74f, h * 0.74f); close()
                }
                drawPath(lead, Color(0xFF455A64))
            }
        }

        coin(Offset(w * 0.12f, h * 0.7f - bob * 0.5f), w * 0.06f)
        sparkle(Offset(w * 0.86f, h * 0.2f), w * 0.04f, Friendly.Coral)
        sparkle(Offset(w * 0.1f, h * 0.2f), w * 0.03f, Friendly.Violet)
    }
}

/**
 * 👤 মানুষ (গ্রাহক) — "আমি কে" পেজে।
 */
@Composable
fun PersonIllustration(modifier: Modifier = Modifier.size(150.dp, 150.dp)) {
    val f = rememberFloat(2400)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val bob = (f - 0.5f) * 6.dp.toPx()
        drawCircle(Friendly.Sky.copy(alpha = 0.3f), w * 0.46f, Offset(w * 0.5f, h * 0.5f))
        translate(top = bob) {
            // শরীর
            drawRoundRect(Friendly.Violet, Offset(w * 0.28f, h * 0.55f), Size(w * 0.44f, h * 0.32f), CornerRadius(40f))
            // মাথা
            drawCircle(Color(0xFFFFD1A9), w * 0.15f, Offset(w * 0.5f, h * 0.38f))
            // চুল
            drawArc(Color(0xFF5D4037), 180f, 180f, true, Offset(w * 0.35f, h * 0.23f), Size(w * 0.3f, h * 0.26f))
            // চোখ ও হাসি
            drawCircle(Color(0xFF3E2723), w * 0.012f, Offset(w * 0.455f, h * 0.395f))
            drawCircle(Color(0xFF3E2723), w * 0.012f, Offset(w * 0.545f, h * 0.395f))
            drawArc(Color(0xFF3E2723), 20f, 140f, false, Offset(w * 0.46f, h * 0.4f), Size(w * 0.08f, h * 0.06f), style = Stroke(3f))
            // গালের লালচে ভাব
            drawCircle(Friendly.Rose.copy(alpha = 0.6f), w * 0.02f, Offset(w * 0.425f, h * 0.43f))
            drawCircle(Friendly.Rose.copy(alpha = 0.6f), w * 0.02f, Offset(w * 0.575f, h * 0.43f))
        }
        coin(Offset(w * 0.82f, h * 0.24f), w * 0.06f)
        sparkle(Offset(w * 0.14f, h * 0.3f), w * 0.04f, Friendly.Sun)
    }
}

/**
 * 🧑‍🍳 দোকানদার — চাঁদোয়ার নিচে হাসিমুখ, "আমি কে" পেজে।
 */
@Composable
fun ShopkeeperIllustration(modifier: Modifier = Modifier.size(150.dp, 150.dp)) {
    val f = rememberFloat(2800)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val bob = (f - 0.5f) * 6.dp.toPx()
        drawCircle(Friendly.Mint.copy(alpha = 0.3f), w * 0.46f, Offset(w * 0.5f, h * 0.5f))
        translate(top = bob) {
            // কাউন্টার
            drawRoundRect(Friendly.Deep, Offset(w * 0.16f, h * 0.68f), Size(w * 0.68f, h * 0.2f), CornerRadius(16f))
            // শরীর (এপ্রন)
            drawRoundRect(Friendly.Coral, Offset(w * 0.33f, h * 0.5f), Size(w * 0.34f, h * 0.24f), CornerRadius(30f))
            // মাথা
            drawCircle(Color(0xFFFFD1A9), w * 0.14f, Offset(w * 0.5f, h * 0.36f))
            // টুপি
            drawRoundRect(Color.White, Offset(w * 0.36f, h * 0.17f), Size(w * 0.28f, h * 0.1f), CornerRadius(24f))
            drawRect(Color.White, Offset(w * 0.38f, h * 0.24f), Size(w * 0.24f, h * 0.05f))
            // মুখ
            drawCircle(Color(0xFF3E2723), w * 0.012f, Offset(w * 0.46f, h * 0.37f))
            drawCircle(Color(0xFF3E2723), w * 0.012f, Offset(w * 0.54f, h * 0.37f))
            drawArc(Color(0xFF3E2723), 20f, 140f, false, Offset(w * 0.465f, h * 0.38f), Size(w * 0.07f, h * 0.055f), style = Stroke(3f))
            // কাউন্টারে কয়েন
            coin(Offset(w * 0.7f, h * 0.65f), w * 0.045f)
        }
        sparkle(Offset(w * 0.86f, h * 0.22f), w * 0.04f, Friendly.Sun)
        sparkle(Offset(w * 0.12f, h * 0.3f), w * 0.03f, Friendly.Violet)
    }
}

/**
 * ছোট এম্পটি-স্টেট আইকন (ইতিহাস, আর্কাইভ, নোট, নোটিফিকেশন...) — রঙিন ঝাপসা বৃত্তের ওপর গ্রেডিয়েন্ট বাবল।
 */
/**
 * 😊 রেটিং অনুযায়ী বদলানো মুখ — ১-২ তারায় মন খারাপ (কমলা), ৩-এ নিরপেক্ষ (হলুদ), ৪-৫-এ হাসিখুশি (সবুজ)।
 * রং ও হাসির বাঁক নরমভাবে বদলায়।
 */
@Composable
fun RatingFaceIllustration(rating: Int, modifier: Modifier = Modifier.size(150.dp)) {
    val face by animateColorAsState(
        when {
            rating <= 0 -> Friendly.Sun
            rating <= 2 -> Friendly.Coral
            rating == 3 -> Friendly.Sun
            else -> Friendly.Mint
        }, label = "face"
    )
    val smile by animateFloatAsState(
        when (rating) { 0 -> 0.35f; 1 -> -1f; 2 -> -0.5f; 3 -> 0f; 4 -> 0.75f; else -> 1.1f },
        animationSpec = spring(dampingRatio = 0.5f), label = "smile"
    )
    val f = rememberFloat(2000)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val bob = (f - 0.5f) * 7.dp.toPx()
        drawCircle(face.copy(alpha = 0.22f), w * 0.5f, Offset(w * 0.5f, h * 0.5f))
        translate(top = bob) {
            drawCircle(face, w * 0.34f, Offset(w * 0.5f, h * 0.5f))
            drawCircle(Color.White.copy(alpha = 0.25f), w * 0.12f, Offset(w * 0.4f, h * 0.38f))
            val eye = Color(0xFF3E2723)
            drawCircle(eye, w * 0.035f, Offset(w * 0.4f, h * 0.46f))
            drawCircle(eye, w * 0.035f, Offset(w * 0.6f, h * 0.46f))
            val mouth = Path().apply {
                moveTo(w * 0.37f, h * 0.62f)
                quadraticBezierTo(w * 0.5f, h * (0.62f + 0.085f * smile * 2f), w * 0.63f, h * 0.62f)
            }
            drawPath(mouth, eye, style = Stroke(width = 5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
            if (smile > 0.6f) {
                drawCircle(Friendly.Rose.copy(alpha = 0.55f), w * 0.04f, Offset(w * 0.33f, h * 0.58f))
                drawCircle(Friendly.Rose.copy(alpha = 0.55f), w * 0.04f, Offset(w * 0.67f, h * 0.58f))
            }
        }
        sparkle(Offset(w * 0.9f, h * 0.2f), w * 0.045f, Friendly.Sun)
        sparkle(Offset(w * 0.08f, h * 0.25f), w * 0.035f, Friendly.Violet)
        coin(Offset(w * 0.88f, h * 0.78f), w * 0.05f)
    }
}

@Composable
fun FriendlyEmptyIcon(icon: ImageVector, accent: Color = Friendly.Teal) {
    val f = rememberFloat(2600)
    val c = LocalKhataColors.current
    Box(Modifier.size(128.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(128.dp)) {
            val w = size.width
            drawCircle(accent.copy(alpha = 0.16f), w * 0.48f, center)
            drawCircle(Friendly.Sun.copy(alpha = 0.9f), w * 0.05f, Offset(w * 0.86f, w * (0.2f + (f - 0.5f) * 0.05f)))
            drawCircle(Friendly.Coral.copy(alpha = 0.85f), w * 0.035f, Offset(w * 0.12f, w * (0.74f - (f - 0.5f) * 0.05f)))
            sparkle(Offset(w * 0.18f, w * 0.22f), w * 0.05f, Friendly.Violet)
        }
        Box(
            Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(accent, c.Primary))),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
        }
    }
}
