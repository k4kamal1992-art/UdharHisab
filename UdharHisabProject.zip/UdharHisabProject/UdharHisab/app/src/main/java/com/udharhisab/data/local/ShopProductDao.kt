package com.udharhisab.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopProductDao {

    @Query("SELECT * FROM shop_products WHERE shopId = :shopId ORDER BY name COLLATE NOCASE")
    fun forShop(shopId: Long): Flow<List<ShopProductEntity>>

    /** shopId+name ইউনিক ইনডেক্সের জোরে এটা কার্যত upsert — নতুন দাম দিলে পুরনোটা বদলে যায় */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ShopProductEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIfAbsent(products: List<ShopProductEntity>)

    @Query("SELECT * FROM shop_products WHERE shopId = :shopId AND name = :name LIMIT 1")
    suspend fun findByName(shopId: Long, name: String): ShopProductEntity?
}
