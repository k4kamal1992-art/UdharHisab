package com.udharhisab.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** ⭐ সব লেনদেনের হিস্ট্রি — দোকান আর ধার/পরিশোধ অনুযায়ী ফিল্টার করা যায় */
class TransactionHistoryViewModel(repo: HisabRepository) : ViewModel() {

    /** null = সব দোকান */
    val shopFilter = MutableStateFlow<Long?>(null)

    /** null = সব, CREDIT = শুধু ধার, PAYMENT = শুধু পরিশোধ */
    val typeFilter = MutableStateFlow<String?>(null)

    private val allTxns: StateFlow<List<TransactionWithShop>> =
        repo.allTxnsWithShop().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** প্রথম ডাটাবেজ emission না আসা পর্যন্ত true */
    val isLoading: StateFlow<Boolean> =
        repo.allTxnsWithShop().map { false }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val filtered: StateFlow<List<TransactionWithShop>> =
        combine(allTxns, shopFilter, typeFilter) { txns, shopId, type ->
            txns.filter { tws ->
                (shopId == null || tws.txn.shopId == shopId) &&
                    (type == null || tws.txn.type == type)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** ফিল্টার ড্রপডাউনে দেখানোর জন্য — যেসব দোকানের অন্তত একটা লেনদেন আছে */
    val availableShops: StateFlow<List<Pair<Long, String>>> = allTxns
        .map { txns -> txns.map { it.txn.shopId to it.shopName }.distinct().sortedBy { it.second } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setShopFilter(shopId: Long?) { shopFilter.value = shopId }
    fun setTypeFilter(type: String?) { typeFilter.value = type }
}
