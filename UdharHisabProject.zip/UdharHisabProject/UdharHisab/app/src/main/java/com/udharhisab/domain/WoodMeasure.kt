package com.udharhisab.domain

import org.json.JSONObject

/**
 * ⭐ কাঠের হিসাবের পুরো মাপ — PDF-এ সম্পূর্ণ বিবরণ ছাপার জন্য লেনদেনের সাথে সেভ হয়।
 * (আগে শুধু মোট CFT আর দাম সেভ হতো, দৈর্ঘ্য/প্রস্থ/পুরুত্ব/পিস হারিয়ে যেত।)
 */
data class WoodMeasure(
    val round: Boolean,          // false = চেরাই কাঠ, true = গোল কাঠ
    val lengthFt: Double,
    val widthIn: Double,
    val thicknessIn: Double,
    val girthIn: Double,
    val pieces: Int,
    val perPieceCft: Double
) {
    val totalCft: Double get() = perPieceCft * pieces

    fun toJson(): String = JSONObject().apply {
        put("r", round); put("l", lengthFt); put("w", widthIn); put("t", thicknessIn)
        put("g", girthIn); put("n", pieces); put("p", perPieceCft)
    }.toString()

    companion object {
        fun fromJson(json: String?): WoodMeasure? {
            if (json.isNullOrBlank()) return null
            return try {
                val o = JSONObject(json)
                WoodMeasure(
                    round = o.getBoolean("r"),
                    lengthFt = o.getDouble("l"),
                    widthIn = o.optDouble("w", 0.0),
                    thicknessIn = o.optDouble("t", 0.0),
                    girthIn = o.optDouble("g", 0.0),
                    pieces = o.getInt("n"),
                    perPieceCft = o.getDouble("p")
                )
            } catch (_: Exception) { null }
        }
    }
}
