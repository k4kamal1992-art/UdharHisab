package com.udharhisab.ui.security

import androidx.biometric.BiometricManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings

/**
 * ⭐ নিরাপত্তা ও প্রাইভেসি — More পেজের "পূর্ণ পেজ" আইটেম।
 * PIN সেট/বদল, ফিঙ্গারপ্রিন্ট লক, আর "সাথে সাথে লক করুন" টগল — একসাথে।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityPrivacyScreen(container: AppContainer, onBack: () -> Unit) {
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val s = LocalStrings.current
    val context = LocalContext.current

    val settings by viewModel.settings.collectAsState()
    val pinEnabled = settings.pinEnabled
    val fingerprintEnabled = settings.fingerprintEnabled
    val lockImmediately = settings.lockImmediately

    val biometricAvailable = remember {
        BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }

    var showPinDialog by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(s.securityPrivacyTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // PIN লক
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(s.pinSectionTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (pinEnabled) s.pinLockOn else s.pinSectionDesc,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = pinEnabled,
                            onCheckedChange = { checked ->
                                if (checked) showPinDialog = true else showRemoveDialog = true
                            }
                        )
                    }
                    if (pinEnabled) {
                        TextButton(onClick = { showPinDialog = true }) {
                            Text(s.changePin)
                        }
                    }
                }
            }

            // ফিঙ্গারপ্রিন্ট লক
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(s.fingerprintTitle, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (biometricAvailable) s.fingerprintDesc else s.fingerprintUnavailable,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = fingerprintEnabled && biometricAvailable,
                            enabled = biometricAvailable && pinEnabled,
                            onCheckedChange = { viewModel.setFingerprint(it) }
                        )
                    }
                }
            }

            // সাথে সাথে লক করুন
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.lockImmediatelyTitle, style = MaterialTheme.typography.titleMedium)
                        Text(s.lockImmediatelyDesc, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = lockImmediately,
                        enabled = pinEnabled,
                        onCheckedChange = { viewModel.setLockImmediately(it) }
                    )
                }
            }
        }
    }

    // PIN সেট করার ডায়ালগ
    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text(s.setPinTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.take(6) },
                        label = { Text(s.newPinLabel) },
                        isError = error
                    )
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it.take(6) },
                        label = { Text(s.confirmPinLabel) },
                        isError = error
                    )
                    if (error) {
                        Text(
                            s.pinSetupError,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pin.length >= 4 && pin == confirm) {
                            viewModel.savePin(pin)
                            showPinDialog = false
                        } else {
                            error = true
                        }
                    }
                ) { Text(s.save) }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text(s.cancel) }
            }
        )
    }

    // PIN মুছার ডায়ালগ
    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            title = { Text(s.removePinTitle) },
            text = { Text(s.removePinText) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.removePin()
                    viewModel.setFingerprint(false)
                    viewModel.setLockImmediately(false)
                    showRemoveDialog = false
                }) { Text(s.yesTurnOff) }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveDialog = false }) { Text(s.no) }
            }
        )
    }
}
