package com.udharhisab.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val KhataTypography = Typography(
    // হিরো ব্যালেন্স (মোট বাকি)
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        letterSpacing = (-0.5).sp
    ),
    // হিরো লেবেল
    displaySmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp
    ),
    // স্ক্রিন টাইটেল — Heading 18-22sp Bold
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    // কার্ড টাইটেল / দোকানের নাম — Sub heading 14-16sp SemiBold
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp
    ),
    // বডি — 12-14sp Regular
    bodyLarge = TextStyle(
        fontSize = 14.sp
    ),
    bodyMedium = TextStyle(
        fontSize = 13.sp
    ),
    // ক্যাপশন / টাইমস্ট্যাম্প — 10-11sp Regular
    bodySmall = TextStyle(
        fontSize = 11.sp,
        lineHeight = 15.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        letterSpacing = 0.3.sp
    )
)
