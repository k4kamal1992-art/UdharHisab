package com.udharhisab.ui.more

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** ব্যাকআপ ও রিস্টোর — লোকাল JSON ফাইলে; আগে "শীঘ্রই আসছে" প্লেসহোল্ডার ছিল, এখন কার্যকর */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()

    var pendingRestoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var working by remember { mutableStateOf(false) }

    val fileNameStamp = remember { SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) }

    val createDocLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        working = true
        scope.launch {
            try {
                val json = container.repo.exportBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                container.store.setLastBackupAt(System.currentTimeMillis())
                snackbar.showSnackbar(s.backupSuccessMessage)
            } catch (e: Exception) {
                snackbar.showSnackbar("${s.backupFailPrefix}${e.message}")
            } finally {
                working = false
            }
        }
    }

    val openDocLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingRestoreUri = uri }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.moreBackupRestore) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BackupActionCard(
                icon = Icons.Default.CloudUpload,
                title = s.backupNowButton,
                hint = s.backupNowHint,
                enabled = !working,
                onClick = { createDocLauncher.launch("udharhisab_backup_$fileNameStamp.json") }
            )
            BackupActionCard(
                icon = Icons.Default.Restore,
                title = s.restoreButton,
                hint = s.restoreHint,
                enabled = !working,
                onClick = { openDocLauncher.launch(arrayOf("application/json")) }
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = c.Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = c.Success)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(s.lastBackupLabel, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                        val lastBackup = settings.lastBackupAt
                        Text(
                            if (lastBackup != null)
                                SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.US).format(Date(lastBackup))
                            else s.noBackupYetLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = c.TextPrimary
                        )
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = c.Muted, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(s.dataSafeNote, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
        }
    }

    val restoreUri = pendingRestoreUri
    if (restoreUri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text(s.restoreConfirmTitle) },
            text = { Text(s.restoreConfirmMessage) },
            confirmButton = {
                TextButton(onClick = {
                    pendingRestoreUri = null
                    working = true
                    scope.launch {
                        try {
                            val json = context.contentResolver.openInputStream(restoreUri)
                                ?.bufferedReader()?.use { it.readText() }
                                ?: throw IllegalStateException("empty file")
                            container.repo.restoreFromBackupJson(json)
                            snackbar.showSnackbar(s.restoreSuccessMessage)
                        } catch (e: Exception) {
                            snackbar.showSnackbar("${s.restoreFailPrefix}${e.message}")
                        } finally {
                            working = false
                        }
                    }
                }) { Text(s.restoreButton, color = c.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreUri = null }) { Text(s.back) }
            }
        )
    }
}

@Composable
private fun BackupActionCard(
    icon: ImageVector,
    title: String,
    hint: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val c = LocalKhataColors.current
    Card(
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(c.ChipBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary)
                Text(hint, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
        }
    }
}
