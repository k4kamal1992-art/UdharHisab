package com.udharhisab.ui.about

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ গোপনীয়তা নীতি — উপরে গ্রেডিয়েন্ট ব্যানার, প্রতিটা ধারা আলাদা গোল কার্ডে (নম্বর-ব্যাজ সহ)।
 * লেখাটা আগের মতো একটাই স্ট্রিং; "1. শিরোনাম" দিয়ে শুরু হওয়া অনুচ্ছেদ আলাদা কার্ড হয়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val sections = s.privacyPolicyBody.trim().split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }
    val numbered = Regex("^(\\d+)\\.\\s*(.*)$")

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.aboutPrivacyPolicy, fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Background,
                    scrolledContainerColor = c.Background,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ── ব্যানার ──
            Row(
                Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(26.dp), ambientColor = c.Primary, spotColor = c.Primary)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(52.dp).background(Color.White.copy(alpha = 0.22f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(s.aboutPrivacyPolicy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text(s.privacyPolicyEffectiveDate, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.88f))
                }
            }

            // ── ধারা-কার্ড ──
            sections.forEach { block ->
                val lines = block.trim().lines()
                val m = numbered.find(lines.first().trim())
                Row(
                    Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(22.dp))
                        .clip(RoundedCornerShape(22.dp))
                        .background(c.Surface)
                        .padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    if (m != null) {
                        Box(
                            Modifier.size(32.dp).background(Brush.linearGradient(listOf(c.Primary, c.Accent)), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(m.groupValues[1], color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelLarge) }
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        if (m != null) {
                            Text(m.groupValues[2], style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = c.TextPrimary)
                            val rest = lines.drop(1).joinToString("\n").trim()
                            if (rest.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Text(rest, style = MaterialTheme.typography.bodyMedium, color = c.TextSecondary)
                            }
                        } else {
                            Text(block.trim(), style = MaterialTheme.typography.bodyMedium, color = c.TextPrimary)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
