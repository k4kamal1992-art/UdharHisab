package com.udharhisab.ui.notifications

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.EmptyStateIcon
import com.udharhisab.ui.components.SkeletonList
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * নোটিফিকেশন/কার্যকলাপ ফিড — আলাদা কোনো নোটিফিকেশন-লগ টেবিল বানানো হয়নি,
 * বরং বাস্তব লেনদেন হিস্ট্রি থেকেই সময়ানুক্রমিক ফিড তৈরি হয় (একই ডেটা, দুইভাবে দেখানো)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationInboxScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current

    val txns by container.repo.allTxnsWithShop().collectAsState(initial = null)

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.notificationInboxTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            val list = txns
            when {
                list == null -> SkeletonList()
                list.isEmpty() -> Column(
                    Modifier.fillMaxWidth().padding(top = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    EmptyStateIcon(Icons.Default.Notifications)
                    Spacer(Modifier.height(12.dp))
                    Text(s.noNotificationsYetTitle, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(4.dp))
                    Text(s.noNotificationsYetSubtitle, style = MaterialTheme.typography.bodyMedium, color = c.Muted)
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list.filter { !it.txn.isDeleted }.take(50), key = { it.txn.id }) { row ->
                        NotificationRow(row)
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(row: TransactionWithShop) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val isCredit = row.txn.type == TransactionEntity.TYPE_CREDIT
    val amountStr = UnitConverter.rupees(row.txn.amount)
    val message = if (isCredit) {
        s.notifCreditMessage.format(row.shopName, amountStr)
    } else {
        s.notifPaymentMessage.format(row.shopName, amountStr)
    }
    val iconColor = if (isCredit) c.Danger else c.Success

    Card(
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isCredit) Icons.Default.TrendingUp else Icons.Default.Payments,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(message, style = MaterialTheme.typography.bodyMedium, color = c.TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(
                    SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.US).format(Date(row.txn.date)),
                    style = MaterialTheme.typography.bodySmall,
                    color = c.Muted
                )
            }
        }
    }
}
