package com.yourname.udharhisab.data.repository

import androidx.lifecycle.LiveData
import com.yourname.udharhisab.data.local.TransactionDao
import com.yourname.udharhisab.data.local.ShopTotals
import com.yourname.udharhisab.data.model.Transaction

class TransactionRepository(private val transactionDao: TransactionDao) {

    fun getTransactionsByShop(shopId: Long): LiveData<List<Transaction>> {
        return transactionDao.getTransactionsByShop(shopId)
    }

    fun getTransactionsByType(shopId: Long, type: String): LiveData<List<Transaction>> {
        return transactionDao.getTransactionsByType(shopId, type)
    }

    fun getShopTotals(shopId: Long): LiveData<ShopTotals> {
        return transactionDao.getShopTotals(shopId)
    }

    fun getShopBalance(shopId: Long): LiveData<Double> {
        return transactionDao.getShopBalance(shopId)
    }

    suspend fun insert(transaction: Transaction): Long {
        return transactionDao.insertTransaction(transaction)
    }

    suspend fun update(transaction: Transaction) {
        transactionDao.updateTransaction(transaction)
    }

    suspend fun delete(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    fun getRecentTransactions(): LiveData<List<Transaction>> {
        return transactionDao.getRecentTransactions()
    }

    fun getAllTransactions(): LiveData<List<Transaction>> {
        return transactionDao.getAllTransactions()
    }

    fun getTransactionsByDateRange(startDate: Long, endDate: Long): LiveData<List<Transaction>> {
        return transactionDao.getTransactionsByDateRange(startDate, endDate)
    }
}
