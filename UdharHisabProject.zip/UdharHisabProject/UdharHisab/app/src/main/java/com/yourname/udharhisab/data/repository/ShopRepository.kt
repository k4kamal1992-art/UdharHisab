package com.yourname.udharhisab.data.repository

import androidx.lifecycle.LiveData
import com.yourname.udharhisab.data.local.ShopDao
import com.yourname.udharhisab.data.model.Shop

class ShopRepository(private val shopDao: ShopDao) {

    val allShops: LiveData<List<Shop>> = shopDao.getAllShops()

    suspend fun insert(shop: Shop): Long {
        return shopDao.insertShop(shop)
    }

    suspend fun update(shop: Shop) {
        shopDao.updateShop(shop)
    }

    suspend fun delete(shop: Shop) {
        shopDao.deleteShop(shop)
    }

    suspend fun getShopById(id: Long): Shop? {
        return shopDao.getShopById(id)
    }

    fun searchShops(query: String): LiveData<List<Shop>> {
        return shopDao.searchShops(query)
    }
}
