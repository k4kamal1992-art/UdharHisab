package com.udharhisab.ads

import android.view.ViewGroup
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

/**
 * ছোট ব্যানার বিজ্ঞাপন — bottom nav-এর ঠিক ওপরে বসানো, স্থির ও অ-বিরক্তিকর।
 *
 * ⭐ ওভারল্যাপ ঠিক করা: আগে AdView নিজের উচ্চতা নিজে ঠিক করত (wrap_content), বিজ্ঞাপন লোড হলে বড় হয়ে
 * Scaffold-এর পাওয়া জায়গার ওপর চেপে বসত — তাই "নতুন কাস্টমার" বাটন ঢাকা পড়ত।
 * এখন উচ্চতা Compose নিজে ঠিক করে: বিজ্ঞাপন না এলে 0, লোড হলে অ্যাডাপটিভ ব্যানারের ঠিক যতটা উচ্চতা (সাধারণত ৫০–৯০dp)।
 * তাই Scaffold বাকি সব কন্টেন্ট (বাটন সহ) এই উচ্চতার ওপরেই বসায়, কিছুই ঢাকে না।
 */
@Composable
fun BannerAdView(modifier: Modifier = Modifier) {
    var loaded by remember { mutableStateOf(false) }
    // ⭐ ফোনের পর্দার চওড়ায় খাপ খাওয়া "অ্যাডাপটিভ" ব্যানার — সাইজ/উচ্চতা SDK-ই হিসাব করে দেয়
    val context = LocalContext.current
    val widthDp = LocalConfiguration.current.screenWidthDp
    val adSize = remember(widthDp) {
        AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp)
    }
    val slotHeight = adSize.height.dp

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(if (loaded) slotHeight else 0.dp)
            .clipToBounds()
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(slotHeight),
            factory = { context ->
                AdView(context).apply {
                    setAdSize(adSize)
                    adUnitId = AdIds.BANNER
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    adListener = object : AdListener() {
                        override fun onAdLoaded() { loaded = true }
                        override fun onAdFailedToLoad(error: LoadAdError) { loaded = false }
                    }
                    loadAd(AdRequest.Builder().build())
                }
            }
        )
    }
}
