package com.yourname.udharhisab.data.model

/**
 * Data class combining shop info with calculated balance
 */
data class ShopWithBalance(
    val shop: Shop,
    val balance: Double,
    val totalCredit: Double,
    val totalPayment: Double
)
