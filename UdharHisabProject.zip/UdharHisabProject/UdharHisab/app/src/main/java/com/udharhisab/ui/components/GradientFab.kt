package com.udharhisab.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ অ্যাপের সব "নতুন যোগ করুন" ভাসমান বাটন এটাই — গ্রেডিয়েন্ট, নরম রঙিন ছায়া, চাপলে বাউন্স।
 * (আগে প্রতি পেজে আলাদা সাদামাটা ExtendedFloatingActionButton ছিল।)
 */
@Composable
fun GradientFab(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalKhataColors.current
    Row(
        modifier
            .shadow(12.dp, RoundedCornerShape(28.dp), ambientColor = c.Primary, spotColor = c.Primary)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
            .bouncyClick(onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
    }
}
