package com.udharhisab.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * ⭐ আরও গোল কোণা — রঙিন ও বন্ধুত্বপূর্ণ নতুন ডিজাইনের সাথে মিল রেখে।
 * এখানে বদলালে অ্যাপের সব কার্ড, ইনপুট ঘর, চিপ, ডায়ালগ একসাথে নরম হয়ে যায়।
 */
val KhataShapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp),  // ইনপুট ঘর, ছোট ট্যাগ
    small = RoundedCornerShape(16.dp),       // চিপ
    medium = RoundedCornerShape(22.dp),      // কার্ড
    large = RoundedCornerShape(28.dp),       // হিরো কার্ড
    extraLarge = RoundedCornerShape(32.dp)   // বটম শিট, ডায়ালগ
)
