package com.udharhisab.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val KhataShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),      // কার্ড
    large = RoundedCornerShape(18.dp),       // হিরো কার্ড
    extraLarge = RoundedCornerShape(26.dp)   // বটম শিট
)
