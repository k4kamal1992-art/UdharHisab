package com.udharhisab.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlin.math.roundToLong

/**
 * কুইক ক্যালকুলেটর — স্বাধীন ইউটিলিটি, কোনো ডেটাবেজ লাগে না
 * "সাধারণ" ট্যাব কার্যকর; "শতকরা"/"রূপান্তর" পরে যোগ হবে
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickCalculatorScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf(s.calcGeneralTab, s.calcPercentTab, s.calcConversionTab)

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.moreQuickCalculator) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(
                selectedTabIndex = tab,
                containerColor = c.Surface,
                contentColor = c.Primary
            ) {
                tabs.forEachIndexed { i, label ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
                }
            }

            when (tab) {
                0 -> GeneralCalculator()
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(s.calcComingSoonInTab, color = c.Muted)
                }
            }
        }
    }
}

private enum class Op(val symbol: String) { ADD("+"), SUB("−"), MUL("×"), DIV("÷") }

private fun compute(a: Double, b: Double, op: Op): Double = when (op) {
    Op.ADD -> a + b
    Op.SUB -> a - b
    Op.MUL -> a * b
    Op.DIV -> if (b == 0.0) Double.NaN else a / b
}

private fun formatNum(v: Double): String {
    if (v.isNaN()) return "Error"
    return if (v == v.roundToLong().toDouble() && kotlin.math.abs(v) < 1e15) {
        v.roundToLong().toString()
    } else {
        // সর্বোচ্চ ৮ ঘর, শেষের শূন্য ছেঁটে
        var str = "%.8f".format(v)
        str = str.trimEnd('0').trimEnd('.')
        str
    }
}

@Composable
private fun GeneralCalculator() {
    val c = LocalKhataColors.current

    var display by remember { mutableStateOf("0") }
    var operand1 by remember { mutableStateOf<Double?>(null) }
    var pendingOp by remember { mutableStateOf<Op?>(null) }
    var freshInput by remember { mutableStateOf(true) }

    fun clearAll() {
        display = "0"; operand1 = null; pendingOp = null; freshInput = true
    }

    fun onDigit(d: String) {
        if (display == "Error" || freshInput) {
            display = d
            freshInput = false
        } else {
            display = if (display == "0") d else display + d
        }
    }

    fun onDot() {
        if (display == "Error") { display = "0."; freshInput = false; return }
        if (freshInput) { display = "0."; freshInput = false; return }
        if (!display.contains(".")) display += "."
    }

    fun onOperator(op: Op) {
        val current = display.toDoubleOrNull() ?: 0.0
        if (operand1 != null && pendingOp != null && !freshInput) {
            operand1 = compute(operand1!!, current, pendingOp!!)
            display = formatNum(operand1!!)
        } else {
            operand1 = current
        }
        pendingOp = op
        freshInput = true
    }

    fun onEquals() {
        val current = display.toDoubleOrNull() ?: 0.0
        if (operand1 != null && pendingOp != null) {
            val result = compute(operand1!!, current, pendingOp!!)
            display = formatNum(result)
            operand1 = null
            pendingOp = null
            freshInput = true
        }
    }

    fun onBackspace() {
        if (display == "Error" || freshInput) return
        display = if (display.length <= 1) "0" else display.dropLast(1)
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // ── ডিসপ্লে ──
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .clip(RoundedCornerShape(16.dp))
                .background(c.ChipBg)
                .padding(20.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Column(horizontalAlignment = Alignment.End) {
                if (pendingOp != null && operand1 != null) {
                    Text(
                        "${formatNum(operand1!!)} ${pendingOp!!.symbol}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.Muted
                    )
                }
                Text(
                    display,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = c.TextPrimary,
                    textAlign = TextAlign.End
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── AC / ব্যাকস্পেস ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CalcKey("AC", Modifier.weight(1f), bg = c.Danger.copy(alpha = 0.12f), fg = c.Danger, onClick = ::clearAll)
            CalcKey(null, Modifier.weight(1f), bg = c.ChipBg, fg = c.TextPrimary, icon = Icons.AutoMirrored.Filled.Backspace, onClick = ::onBackspace)
            CalcKey("÷", Modifier.weight(1f), bg = c.Primary, fg = Color.White) { onOperator(Op.DIV) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CalcKey("7", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("7") }
            CalcKey("8", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("8") }
            CalcKey("9", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("9") }
            CalcKey("×", Modifier.weight(1f), bg = c.Primary, fg = Color.White) { onOperator(Op.MUL) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CalcKey("4", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("4") }
            CalcKey("5", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("5") }
            CalcKey("6", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("6") }
            CalcKey("−", Modifier.weight(1f), bg = c.Primary, fg = Color.White) { onOperator(Op.SUB) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CalcKey("1", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("1") }
            CalcKey("2", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("2") }
            CalcKey("3", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary) { onDigit("3") }
            CalcKey("+", Modifier.weight(1f), bg = c.Primary, fg = Color.White) { onOperator(Op.ADD) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CalcKey("0", Modifier.weight(2.15f), bg = c.Surface, fg = c.TextPrimary, alignStart = true) { onDigit("0") }
            CalcKey(".", Modifier.weight(1f), bg = c.Surface, fg = c.TextPrimary, onClick = ::onDot)
            CalcKey("=", Modifier.weight(1f), bg = c.Accent, fg = Color.White, onClick = ::onEquals)
        }
    }
}

@Composable
private fun CalcKey(
    label: String?,
    modifier: Modifier = Modifier,
    bg: Color,
    fg: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    alignStart: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(60.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = if (alignStart) 24.dp else 0.dp),
        contentAlignment = if (alignStart) Alignment.CenterStart else Alignment.Center
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
        } else if (label != null) {
            Text(label, style = MaterialTheme.typography.titleLarge, color = fg, fontWeight = FontWeight.Medium)
        }
    }
}
