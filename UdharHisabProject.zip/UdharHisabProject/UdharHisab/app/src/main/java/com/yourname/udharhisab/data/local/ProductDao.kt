package com.yourname.udharhisab.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.yourname.udharhisab.data.model.Product

@Dao
interface ProductDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Query("SELECT * FROM products WHERE nameBn = :name OR nameHi = :name OR nameEn = :name")
    suspend fun findProduct(name: String): Product?

    @Query("SELECT * FROM products WHERE nameBn LIKE '%' || :keyword || '%' OR nameHi LIKE '%' || :keyword || '%' OR nameEn LIKE '%' || :keyword || '%'")
    suspend fun searchProducts(keyword: String): List<Product>

    @Query("SELECT * FROM products")
    suspend fun getAllProducts(): List<Product>

    @Query("SELECT * FROM products WHERE category = :category")
    suspend fun getProductsByCategory(category: String): List<Product>
}
