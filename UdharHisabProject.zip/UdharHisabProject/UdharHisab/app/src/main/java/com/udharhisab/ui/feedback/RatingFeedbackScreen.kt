package com.udharhisab.ui.feedback

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * ⭐ রেটিং ও ফিডব্যাক — ৫ তারা দিলে Play Store-এ পাঠায়,
 * কম তারা দিলে অ্যাপের ভেতরেই ফিডব্যাক লেখার জায়গা দেখায়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RatingFeedbackScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var rating by remember { mutableIntStateOf(0) }
    var feedbackText by remember { mutableStateOf("") }
    var feedbackSent by remember { mutableStateOf(false) }

    fun openPlayStore() {
        try {
            val uri = Uri.parse("market://details?id=${context.packageName}")
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            val uri = Uri.parse("https://play.google.com/store/apps/details?id=${context.packageName}")
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.rateTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                s.rateSubtitle,
                style = MaterialTheme.typography.titleMedium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            androidx.compose.foundation.layout.Spacer(Modifier.height(6.dp))
            Text(
                s.rateStarsPrompt,
                style = MaterialTheme.typography.bodySmall,
                color = c.Muted
            )
            androidx.compose.foundation.layout.Spacer(Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 1..5) {
                    IconButton(onClick = {
                        rating = i
                        feedbackSent = false
                        if (i >= 4) {
                            scope.launch { snackbar.showSnackbar(s.rateThanksMessage) }
                            openPlayStore()
                        }
                    }) {
                        Icon(
                            imageVector = if (i <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = null,
                            tint = c.Primary,
                            modifier = Modifier.height(36.dp)
                        )
                    }
                }
            }

            if (rating in 1..3) {
                androidx.compose.foundation.layout.Spacer(Modifier.height(24.dp))
                Text(s.feedbackPromptLow, style = MaterialTheme.typography.bodyMedium)
                androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = feedbackText,
                    onValueChange = { feedbackText = it },
                    placeholder = { Text(s.feedbackPlaceholder) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
                androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        feedbackSent = true
                        feedbackText = ""
                        scope.launch { snackbar.showSnackbar(s.feedbackThanks) }
                    },
                    enabled = feedbackText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(s.feedbackSubmit)
                }
            }
        }
    }
}
