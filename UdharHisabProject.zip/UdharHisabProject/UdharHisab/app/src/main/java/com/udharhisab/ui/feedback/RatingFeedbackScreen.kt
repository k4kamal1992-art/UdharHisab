package com.udharhisab.ui.feedback

import androidx.compose.foundation.layout.*
import com.udharhisab.ui.components.RatingFaceIllustration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Spring
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * ⭐ রেটিং ও ফিডব্যাক — ৫ তারা দিলে Play Store-এ পাঠায়,
 * কম তারা দিলে অ্যাপের ভেতরেই ফিডব্যাক লেখার জায়গা দেখায়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RatingFeedbackScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var rating by remember { mutableIntStateOf(0) }
    var feedbackText by remember { mutableStateOf("") }
    var feedbackSent by remember { mutableStateOf(false) }

    fun openPlayStore() {
        try {
            val uri = Uri.parse("market://details?id=${context.packageName}")
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            val uri = Uri.parse("https://play.google.com/store/apps/details?id=${context.packageName}")
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.rateTitle, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Background,
                    scrolledContainerColor = c.Background,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ⭐ রেটিং অনুযায়ী মুখ বদলায়, তারাগুলো লাফিয়ে ওঠে
            Column(
                Modifier
                    .fillMaxWidth()
                    .shadow(8.dp, RoundedCornerShape(28.dp), ambientColor = c.Primary, spotColor = c.Primary)
                    .clip(RoundedCornerShape(28.dp))
                    .background(c.Surface)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                RatingFaceIllustration(rating)
                Spacer(Modifier.height(8.dp))
                Text(
                    s.rateSubtitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
                Text(s.rateStarsPrompt, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (i in 1..5) {
                        val picked = i <= rating
                        val starScale by animateFloatAsState(
                            targetValue = if (picked) 1.2f else 1f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                            label = "star$i"
                        )
                        IconButton(onClick = {
                            rating = i
                            feedbackSent = false
                            if (i >= 4) {
                                scope.launch { snackbar.showSnackbar(s.rateThanksMessage) }
                                openPlayStore()
                            }
                        }, modifier = Modifier.size(52.dp)) {
                            Icon(
                                imageVector = if (picked) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = null,
                                tint = if (picked) Color(0xFFFFB800) else c.Divider,
                                modifier = Modifier.size(42.dp).graphicsLayer { scaleX = starScale; scaleY = starScale }
                            )
                        }
                    }
                }
            }

            if (rating in 1..3) {
                Spacer(Modifier.height(20.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(c.Surface)
                        .padding(18.dp)
                ) {
                    Text(s.feedbackPromptLow, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        placeholder = { Text(s.feedbackPlaceholder) },
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            feedbackSent = true
                            feedbackText = ""
                            scope.launch { snackbar.showSnackbar(s.feedbackThanks) }
                        },
                        enabled = feedbackText.isNotBlank(),
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Text(s.feedbackSubmit, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}
