package com.udharhisab.ui.entry

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.udharhisab.data.local.TransactionEntity

/**
 * ⭐ ধার/জমা এন্ট্রি VM — CFT/ইউনিট সাপোর্টসহ
 *
 * ⭐ এই VM ডাটাবেস জানে না! সেভ করার সময় onInsert কলব্যাক দিয়ে
 *    txn তৈরি করে পাঠিয়ে দেয় — আসল সেভ করে ShopDetailViewModel।
 */
class EntryViewModel : ViewModel() {

    /** ⭐ সেভ-করার কলব্যাক — ShopDetailScreen সেট করবে */
    var onInsert: ((TransactionEntity) -> Unit)? = null

    var type = mutableStateOf(TransactionEntity.TYPE_CREDIT)   // CREDIT/PAYMENT
        private set
    var productName = mutableStateOf("")
        private set
    var amount = mutableStateOf("")            // হাতে লেখা টাকা
        private set
    var quantity = mutableStateOf("")          // পরিমাণ (ঐচ্ছিক)
        private set
    var unit = mutableStateOf("")              // cft/কেজি/টোকা (ঐচ্ছিক)
        private set
    var unitPrice = mutableStateOf("")         // ইউনিট দাম (ঐচ্ছিক)
        private set
    var paymentMethod = mutableStateOf("নগদ")  // শুধু জমায়
        private set
    var note = mutableStateOf("")
        private set
    var error = mutableStateOf<String?>(null)
        private set

    /** ⭐ গণনা-প্রিভিউ: পরিমাণ × দাম দিলে টাকা অটো */
    fun computedAmount(): Double? {
        val q = quantity.value.toDoubleOrNull()
        val up = unitPrice.value.toDoubleOrNull()
        if (q != null && up != null) return q * up
        return amount.value.toDoubleOrNull()
    }

    fun setType(t: String) { type.value = t }
    fun setProductName(v: String) { productName.value = v; error.value = null }
    fun setAmount(v: String) { amount.value = v }
    fun setQuantity(v: String) { quantity.value = v }
    fun setUnit(v: String) { unit.value = v }
    fun setUnitPrice(v: String) { unitPrice.value = v }
    fun setPaymentMethod(v: String) { paymentMethod.value = v }
    fun setNote(v: String) { note.value = v }

    fun save(shopId: Long, onDone: () -> Unit) {
        val finalAmount = computedAmount()
        when {
            finalAmount == null || finalAmount <= 0 -> {
                error.value = "সঠিক টাকার পরিমাণ দিন"
                return
            }
            else -> {
                val txn = TransactionEntity(
                    shopId = shopId,
                    amount = finalAmount,
                    type = type.value,
                    productName = productName.value.ifBlank { null },
                    quantity = quantity.value.toDoubleOrNull(),
                    unit = unit.value.ifBlank { null },
                    unitPrice = unitPrice.value.toDoubleOrNull(),
                    paymentMethod = if (type.value == TransactionEntity.TYPE_PAYMENT)
                        paymentMethod.value else null,
                    note = note.value.ifBlank { null }
                )
                // ⭐ repo-র বদলে কলব্যাক — সেভ করবে DetailViewModel
                onInsert?.invoke(txn)
                onDone()
            }
        }
    }
}
