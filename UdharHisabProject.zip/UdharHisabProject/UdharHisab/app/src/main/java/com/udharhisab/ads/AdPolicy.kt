package com.udharhisab.ads

import android.content.Context
import android.content.SharedPreferences
import android.telephony.TelephonyManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ⭐ বিজ্ঞাপনের সব নিয়মের একটাই জায়গা — কোথায়, কখন, কতবার, কাকে দেখানো হবে।
 *
 * নিয়মগুলো:
 *  1. নতুন ব্যবহারকারীকে ধাপে ধাপে বিজ্ঞাপন (যেটা আগে হয় সেটাই ধরা হয় — দিন "অথবা" এন্ট্রি):
 *       • ব্যানার (সবচেয়ে কম বিরক্তিকর): ১ দিন অথবা ১টা এন্ট্রির পর
 *       • নেটিভ ও অ্যাপ-ওপেন: ১ দিন অথবা ৩টা এন্ট্রির পর
 *       • ফুল-স্ক্রিন: ২ দিন অথবা ৫টা এন্ট্রির পর
 *  2. "বিজ্ঞাপনমুক্ত" কিনলে সব বিজ্ঞাপন বন্ধ।
 *  3. সম্মতি (UMP) না পেলে বিজ্ঞাপন নয়।
 *  4. ফুল-স্ক্রিন বিজ্ঞাপন: দিনে সীমিত (দোকানদার ১, গ্রাহক ২), দুটোর মাঝে ন্যূনতম ফাঁক, অ্যাপ খোলার প্রথম ১ মিনিট নয়।
 *  5. অ্যাপ-ওপেন বিজ্ঞাপন: দিনে ১ বার, অন্তত ৫ মিনিট বাইরে থেকে ফিরলে।
 *  6. বেশি আয়ের দেশে (যেমন USA, UK) ফুল-স্ক্রিন কম — দিনে ১, ফাঁক দ্বিগুণ।
 *  7. ব্যানার শুধু নিচের ট্যাব-পেজে (হোম/ইতিহাস/রিপোর্ট/আরও); ধার, জমা, PIN, ডায়ালগে কখনো নয় (নেভিগেশন কাঠামোই তা নিশ্চিত করে)।
 */
object AdPolicy {
    // ── নতুন ব্যবহারকারীর ধাপ (পরীক্ষার সময় সব 0 করে দেখুন; প্রকাশের আগে আবার এই মানে ফেরান) ──
    const val BANNER_DAYS = 1
    const val BANNER_ENTRIES = 1
    const val NATIVE_DAYS = 1
    const val NATIVE_ENTRIES = 3
    const val FULLSCREEN_DAYS = 2
    const val FULLSCREEN_ENTRIES = 5

    private const val MIN = 60 * 1000L
    private const val DAY_MS = 24 * 60 * MIN
    private const val BASE_GAP_MS = 10 * MIN
    private const val SESSION_QUIET_MS = 1 * MIN
    private const val APP_OPEN_AWAY_MS = 5 * MIN
    private const val AFTER_INTERSTITIAL_QUIET_MS = 2 * MIN

    /** বেশি আয়ের দেশ — এখানে ব্যবহারকারীকে কম বিরক্ত করেও ভালো আয় হয় */
    private val HIGH_VALUE_COUNTRIES = setOf(
        "US", "GB", "CA", "AU", "NZ", "DE", "FR", "NL", "SE", "NO", "DK", "FI", "CH", "AT", "IE", "JP", "SG", "AE"
    )

    private var prefs: SharedPreferences? = null
    private var userMode: String = ""
    private var consentOk: Boolean = false
    private var country: String = ""
    private val sessionStart = System.currentTimeMillis()

    private val _adFree = MutableStateFlow(false)
    /** কেনা হয়ে থাকলে true */
    val adFree: StateFlow<Boolean> = _adFree.asStateFlow()

    private val _bannerEligible = MutableStateFlow(false)
    /** ব্যানার দেখানো যাবে কি না */
    val bannerEligible: StateFlow<Boolean> = _bannerEligible.asStateFlow()

    private val _eligible = MutableStateFlow(false)
    /** নেটিভ বিজ্ঞাপন ও অ্যাপ-ওপেনের জন্য */
    val eligible: StateFlow<Boolean> = _eligible.asStateFlow()

    private var fullscreenOk = false

    fun init(context: Context) {
        val app = context.applicationContext
        val p = app.getSharedPreferences("ad_policy", Context.MODE_PRIVATE)
        prefs = p
        if (p.getLong("first_seen", 0L) == 0L) {
            p.edit().putLong("first_seen", firstInstallTime(app)).apply()
        }
        country = detectCountry(app)
        _adFree.value = p.getBoolean("ad_free", false)
        refresh()
    }

    fun setMode(mode: String) { userMode = mode }

    fun setConsent(ok: Boolean) {
        consentOk = ok
        refresh()
    }

    fun setAdFree(value: Boolean) {
        prefs?.edit()?.putBoolean("ad_free", value)?.apply()
        _adFree.value = value
        refresh()
    }

    /** প্রতিটা সেভ হওয়া ধার/জমা এন্ট্রির পরে একবার কল হয় */
    fun onEntryAdded() {
        val p = prefs ?: return
        p.edit().putInt("entries", p.getInt("entries", 0) + 1).apply()
        refresh()
    }

    fun refresh() {
        val p = prefs ?: return
        val now = System.currentTimeMillis()
        val daysOld = (now - p.getLong("first_seen", now)) / DAY_MS
        val entries = p.getInt("entries", 0)
        val base = !_adFree.value && consentOk
        _bannerEligible.value = base && (daysOld >= BANNER_DAYS || entries >= BANNER_ENTRIES)
        _eligible.value = base && (daysOld >= NATIVE_DAYS || entries >= NATIVE_ENTRIES)
        fullscreenOk = base && (daysOld >= FULLSCREEN_DAYS || entries >= FULLSCREEN_ENTRIES)
    }

    // ── ফুল-স্ক্রিন (interstitial) ──
    private fun isHighValue() = country in HIGH_VALUE_COUNTRIES
    private fun dailyCap(): Int = if (isHighValue() || userMode == "shopkeeper") 1 else 2
    private fun gapMs(): Long = if (isHighValue()) BASE_GAP_MS * 2 else BASE_GAP_MS

    fun canShowInterstitial(now: Long): Boolean {
        val p = prefs ?: return false
        if (!fullscreenOk) return false
        if (now - sessionStart < SESSION_QUIET_MS) return false
        if (now - p.getLong("last_interstitial", 0L) < gapMs()) return false
        val today = dayKey(now)
        val count = if (p.getString("interstitial_day", "") == today) p.getInt("interstitial_count", 0) else 0
        return count < dailyCap()
    }

    fun recordInterstitialShown(now: Long) {
        val p = prefs ?: return
        val today = dayKey(now)
        val count = if (p.getString("interstitial_day", "") == today) p.getInt("interstitial_count", 0) else 0
        p.edit()
            .putLong("last_interstitial", now)
            .putString("interstitial_day", today)
            .putInt("interstitial_count", count + 1)
            .apply()
    }

    // ── অ্যাপ-ওপেন ──
    fun canShowAppOpen(now: Long, awayMs: Long): Boolean {
        val p = prefs ?: return false
        if (!_eligible.value) return false
        if (awayMs < APP_OPEN_AWAY_MS) return false
        if (p.getString("app_open_day", "") == dayKey(now)) return false
        if (now - p.getLong("last_interstitial", 0L) < AFTER_INTERSTITIAL_QUIET_MS) return false
        return true
    }

    fun recordAppOpenShown(now: Long) {
        prefs?.edit()?.putString("app_open_day", dayKey(now))?.apply()
    }

    // ── সহায়ক ──
    private fun dayKey(now: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(now))

    private fun firstInstallTime(context: Context): Long = try {
        context.packageManager.getPackageInfo(context.packageName, 0).firstInstallTime
    } catch (e: Exception) {
        System.currentTimeMillis()
    }

    private fun detectCountry(context: Context): String {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val iso = tm?.networkCountryIso?.takeIf { it.isNotBlank() }
            ?: tm?.simCountryIso?.takeIf { it.isNotBlank() }
            ?: Locale.getDefault().country
        return iso.uppercase(Locale.US)
    }
}
