package com.udharhisab.navigation

/**
 * সব রাউট এক জায়গায়
 */
sealed class Route(val route: String) {
    object Home : Route("home")
    object AddShop : Route("add_shop")
    object History : Route("history")
    object Reports : Route("reports")
    object More : Route("more")
    object ArchivedShops : Route("archived_shops")
    object Settings : Route("settings")
    object Lock : Route("lock")

    object ShopDetail {
        const val BASE = "shop_detail"
        const val pattern = "$BASE/{shopId}"
        fun create(id: Long) = "$BASE/$id"
    }
}
