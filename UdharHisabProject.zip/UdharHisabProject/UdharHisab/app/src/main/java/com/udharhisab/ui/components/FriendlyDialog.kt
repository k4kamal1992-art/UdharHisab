package com.udharhisab.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ অ্যাপের সব বড় ডায়ালগের একই কাঠামো — রঙিন গ্রেডিয়েন্ট হেডার, স্ক্রল হওয়া মাঝের অংশ,
 * আর নিচে স্থির বাটন-সারি (লম্বা হলেও "বাতিল/তৈরি করো" বাটন কখনো কেটে যায় না)।
 */
@Composable
fun FriendlyDialog(
    title: String,
    icon: ImageVector,
    onDismiss: () -> Unit,
    subtitle: String? = null,
    footer: @Composable RowScope.() -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalKhataColors.current
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.9f).dp
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = c.Surface,
            modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = maxHeight)
        ) {
            Column {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(40.dp).background(Color.White.copy(alpha = 0.22f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            if (subtitle != null) {
                                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.88f))
                            }
                        }
                    }
                }
                Column(
                    Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    content = content
                )
                Box(Modifier.fillMaxWidth().height(1.dp).background(c.Divider))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    content = footer
                )
            }
        }
    }
}

/** ডায়ালগের ভেতরের ছোট সেকশন-শিরোনাম */
@Composable
fun DialogSectionLabel(text: String) {
    val c = LocalKhataColors.current
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.ExtraBold,
        color = c.Primary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

/** সাধারণ AlertDialog-এর `icon` স্লটের রঙিন গোল আইকন (সতর্কতা হলে লাল) */
@Composable
fun FriendlyDialogIcon(icon: ImageVector, danger: Boolean = false) {
    val c = LocalKhataColors.current
    val tone = if (danger) c.Danger else c.Primary
    Box(
        Modifier.size(56.dp).background(tone.copy(alpha = 0.14f), CircleShape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = null, tint = tone, modifier = Modifier.size(28.dp)) }
}

/**
 * ⭐ হ্যাঁ/না ধরনের নিশ্চিতকরণ ডায়ালগ (মুছে ফেলা, আর্কাইভ, PIN বন্ধ...) —
 * মাঝখানে জ্বলজ্বলে বড় আইকন, মাঝ-বরাবর লেখা, নিচে দুটো গোল বাটন। সতর্কতার কাজে লাল।
 */
@Composable
fun FriendlyConfirmDialog(
    title: String,
    message: String,
    icon: ImageVector,
    confirmLabel: String,
    dismissLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    danger: Boolean = false
) {
    val c = LocalKhataColors.current
    val tone = if (danger) c.Danger else c.Primary
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = c.Surface,
            modifier = Modifier.fillMaxWidth(0.88f)
        ) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(88.dp).background(tone.copy(alpha = 0.12f), CircleShape))
                    Box(
                        Modifier
                            .size(64.dp)
                            .shadow(12.dp, CircleShape, ambientColor = tone, spotColor = tone)
                            .background(Brush.linearGradient(listOf(tone.copy(alpha = 0.8f), tone)), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp)) }
                }
                Spacer(Modifier.height(16.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold,
                    color = c.TextPrimary, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(message, style = MaterialTheme.typography.bodyMedium, color = c.Muted, textAlign = TextAlign.Center)
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(26.dp),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(dismissLabel, fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = onConfirm,
                        shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = tone),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(confirmLabel, fontWeight = FontWeight.ExtraBold) }
                }
            }
        }
    }
}
