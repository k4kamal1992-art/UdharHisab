package com.udharhisab.ui.pdf

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.udharhisab.data.pdf.KhataPdfGenerator
import com.udharhisab.data.pdf.PdfContentScope
import com.udharhisab.data.pdf.PdfFormat
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.strings.AppStrings
import com.udharhisab.ui.strings.shopkeeperLabelsFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** PDF তৈরি হওয়ার পর কী করা হবে */
enum class PdfAction { SHARE, SAVE, PRINT }

/** PDF অপশন ডায়ালগ থেকে আসা সব বাছাই */
data class PdfRequest(
    val shopId: Long?,
    val fromTime: Long,
    val toTime: Long,
    val scope: PdfContentScope,
    val format: PdfFormat,
    val useBranding: Boolean,
    val action: PdfAction
)

/** ⭐ দুই জায়গা (ShopDetail ও More) থেকেই একই কোডে PDF বানায় */
suspend fun buildPdf(context: Context, container: AppContainer, strings: AppStrings, req: PdfRequest): File =
    withContext(Dispatchers.IO) {
        val reportNumber = container.store.nextReportNumber()
        val settings = container.store.settings.first()
        val branding = if (req.useBranding) settings.toBranding() else null
        // ⭐ দোকানদার মোডে PDF-এও দোকানদারের শব্দ (বাকি দিয়েছি / পরিশোধ পেয়েছি / পাওনা)
        val labels = if (settings.isShopkeeper) shopkeeperLabelsFor(strings.code) else null
        val generator = KhataPdfGenerator(context, strings, branding, labels)
        if (req.shopId != null) {
            val shop = container.repo.shopOnce(req.shopId) ?: error("shop not found")
            val txns = container.repo.txnsWithItemsInRange(req.shopId, req.fromTime, req.toTime)
            generator.generateShopReport(shop, txns, reportNumber, req.fromTime, req.toTime, req.format, req.scope)
        } else {
            val rows = container.repo.shopReportRowsInRange(req.fromTime, req.toTime)
            generator.generateAllShopsReport(rows, reportNumber, req.fromTime, req.toTime)
        }
    }

class PdfOutput internal constructor(
    private val context: Context,
    private val pending: MutableState<File?>,
    private val launchSave: (String) -> Unit
) {
    fun deliver(file: File, action: PdfAction, shareTitle: String) {
        when (action) {
            PdfAction.SHARE -> {
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, shareTitle))
            }
            // ডিভাইসে ডাউনলোড/সেভ — সিস্টেমের "সেভ করুন" পিকার, কোনো স্টোরেজ পারমিশন লাগে না
            PdfAction.SAVE -> {
                pending.value = file
                launchSave(file.name)
            }
            PdfAction.PRINT -> {
                val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print(file.nameWithoutExtension, FilePrintAdapter(file), null)
            }
        }
    }
}

/** [onSaveResult]: সেভ সফল হলে true, ব্যর্থ হলে false (ইউজার বাতিল করলে কিছুই ডাকা হয় না) */
@Composable
fun rememberPdfOutput(onSaveResult: (Boolean) -> Unit): PdfOutput {
    val context = LocalContext.current
    val pending = remember { mutableStateOf<File?>(null) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val file = pending.value
        pending.value = null
        if (uri != null && file != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { it.copyTo(out) }
                } != null
            }.getOrDefault(false)
            onSaveResult(ok)
        }
    }
    return remember(context, launcher) { PdfOutput(context, pending) { name -> launcher.launch(name) } }
}

private class FilePrintAdapter(private val file: File) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) { callback.onLayoutCancelled(); return }
        callback.onLayoutFinished(
            PrintDocumentInfo.Builder(file.name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                .build(),
            true
        )
    }

    override fun onWrite(
        pages: Array<out PageRange>?, destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?, callback: WriteResultCallback
    ) {
        try {
            FileInputStream(file).use { input ->
                FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) }
            }
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message)
        }
    }
}
