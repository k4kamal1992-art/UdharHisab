package com.udharhisab.ui.entry

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings

/**
 * ⭐ কাঠের দোকানের জন্য CFT ক্যালকুলেটর —
 * দৈর্ঘ্য×প্রস্থ×উচ্চতা (ইঞ্চি) → ঘনফুট → রেট দিলে টাকা
 * রেজাল্ট quantity/unit/unitPrice ফিল্ডে বসে যায়
 */
@Composable
fun CftCalculator(
    onApply: (cft: Double, rate: Double) -> Unit
) {
    val s = LocalStrings.current
    var len by remember { mutableStateOf("") }
    var wid by remember { mutableStateOf("") }
    var hgt by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }

    val l = len.toDoubleOrNull() ?: 0.0
    val w = wid.toDoubleOrNull() ?: 0.0
    val h = hgt.toDoubleOrNull() ?: 0.0
    val r = rate.toDoubleOrNull() ?: 0.0
    val cft = UnitConverter.cft(l, w, h)

    Column(Modifier.fillMaxWidth()) {
        Text(s.cftCalculatorTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = len, onValueChange = { len = it },
                label = { Text(s.lengthLabel) }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = wid, onValueChange = { wid = it },
                label = { Text(s.widthLabel) }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hgt, onValueChange = { hgt = it },
                label = { Text(s.heightLabel) }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            OutlinedTextField(
                value = rate, onValueChange = { rate = it },
                label = { Text(s.rateLabel) }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                "= ${UnitConverter.formatIndian(cft)} cft\n= ${UnitConverter.rupees(UnitConverter.cftToAmount(cft, r))}",
                style = MaterialTheme.typography.labelLarge
            )
        }
        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = { onApply(cft, r) },
            enabled = cft > 0 && r > 0,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(s.applyToEntryButton)
        }
    }
}
