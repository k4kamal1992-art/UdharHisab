package com.udharhisab.ui.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(onOpenSettings: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun comingSoon() {
        scope.launch { snackbar.showSnackbar(s.comingSoonMessage) }
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(s.moreTitle) }) }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(vertical = 8.dp)
        ) {
            MoreGroup {
                MoreRow(Icons.Default.CloudUpload, s.moreBackupRestore, onClick = ::comingSoon)
                MoreRow(Icons.Default.IosShare, s.moreExportShare, onClick = ::comingSoon)
                MoreRow(Icons.Default.Notifications, s.moreNotifications, onClick = onOpenSettings)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(Icons.Default.Language, s.moreLanguage, onClick = onOpenSettings)
                MoreRow(Icons.Default.Lock, s.moreSecurityPrivacy, onClick = onOpenSettings)
                MoreRow(Icons.Default.Palette, s.moreAppearance, onClick = onOpenSettings)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(Icons.Default.Star, s.moreRateFeedback, onClick = ::comingSoon)
                MoreRow(Icons.Default.Info, s.moreAbout, onClick = onOpenSettings)
            }
        }
    }
}

@Composable
private fun MoreGroup(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalKhataColors.current
    Card(
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(content = content)
    }
}

@Composable
private fun MoreRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = c.Primary)
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = c.Muted)
    }
}
