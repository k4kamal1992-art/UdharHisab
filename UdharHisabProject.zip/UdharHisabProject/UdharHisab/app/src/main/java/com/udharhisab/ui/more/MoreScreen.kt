package com.udharhisab.ui.more

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.pdf.KhataPdfGenerator
import com.udharhisab.di.AppContainer
import com.udharhisab.reminder.ReminderWorker
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * ⭐ "পথ ৪ (মিশ্র পদ্ধতি)" — More পেজ
 * ৩টা ছোট বাছাই (নোটিফিকেশন/ভাষা/থিম) → Bottom Sheet
 * ৫টা বড় কাজ (ব্যাকআপ/এক্সপোর্ট/নিরাপত্তা/রেটিং/সম্পর্কে) → আলাদা পেজ
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    container: AppContainer,
    onOpenSecurityPrivacy: () -> Unit,
    onOpenRatingFeedback: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())

    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()

    var activeSheet by remember { mutableStateOf<MoreSheet?>(null) }

    fun comingSoon() {
        scope.launch { snackbar.showSnackbar(s.comingSoonMessage) }
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(s.moreTitle) }) }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(vertical = 8.dp)
        ) {
            MoreGroup {
                MoreRow(Icons.Default.CloudUpload, s.moreBackupRestore, s.moreHintPage, onClick = ::comingSoon)
                MoreRow(Icons.Default.IosShare, s.moreExportShare, s.moreHintPage, onClick = { showPdfDialog = true })
                MoreRow(Icons.Default.Notifications, s.moreNotifications, s.moreHintSheet, onClick = { activeSheet = MoreSheet.Notifications })
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(Icons.Default.Language, s.moreLanguage, s.moreHintSheet, onClick = { activeSheet = MoreSheet.Language })
                MoreRow(Icons.Default.Security, s.moreSecurityPrivacy, s.moreHintPage, onClick = onOpenSecurityPrivacy)
                MoreRow(Icons.Default.Palette, s.moreAppearance, s.moreHintSheet, onClick = { activeSheet = MoreSheet.Theme })
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(Icons.Default.Star, s.moreRateFeedback, s.moreHintPage, onClick = onOpenRatingFeedback)
                MoreRow(Icons.Default.Info, s.moreAbout, s.moreHintPage, onClick = onOpenAbout)
            }
        }
    }

    when (activeSheet) {
        MoreSheet.Notifications -> NotificationSheet(
            dueReminder = settings.remindersEnabled,
            weeklySummary = settings.weeklySummaryEnabled,
            appNews = settings.appNewsEnabled,
            onDueReminderChange = {
                viewModel.setReminder(it)
                if (it) ReminderWorker.schedule(context) else ReminderWorker.cancel(context)
            },
            onWeeklySummaryChange = viewModel::setWeeklySummary,
            onAppNewsChange = viewModel::setAppNews,
            onDismiss = { activeSheet = null }
        )
        MoreSheet.Language -> LanguageSheet(
            selected = settings.language,
            onSelect = { viewModel.setLanguage(it); activeSheet = null },
            onDismiss = { activeSheet = null }
        )
        MoreSheet.Theme -> ThemeSheet(
            selected = settings.theme,
            onSelect = { viewModel.setTheme(it); activeSheet = null },
            onDismiss = { activeSheet = null }
        )
        null -> Unit
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = null,
            onDismiss = { showPdfDialog = false },
            onGenerate = { pdfShopId, fromTime, toTime, pdfScope, pdfFormat ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val reportNumber = container.store.nextReportNumber()
                        val file = if (pdfShopId != null) {
                            val targetShop = container.repo.shopOnce(pdfShopId)
                            if (targetShop == null) {
                                snackbar.showSnackbar("${s.pdfFailPrefix}shop not found")
                                return@launch
                            }
                            val rangeTxns = container.repo.txnsWithItemsInRange(pdfShopId, fromTime, toTime)
                            KhataPdfGenerator(context, s).generateShopReport(
                                targetShop, rangeTxns, reportNumber, fromTime, toTime, pdfFormat, pdfScope
                            )
                        } else {
                            val rows = container.repo.shopReportRowsInRange(fromTime, toTime)
                            KhataPdfGenerator(context, s).generateAllShopsReport(
                                rows, reportNumber, fromTime, toTime
                            )
                        }
                        val uri = FileProvider.getUriForFile(
                            context, "${context.packageName}.fileprovider", file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, s.shareKhata))
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }
}

private enum class MoreSheet { Notifications, Language, Theme }

// ────────────────────────── Bottom sheets ──────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationSheet(
    dueReminder: Boolean,
    weeklySummary: Boolean,
    appNews: Boolean,
    onDueReminderChange: (Boolean) -> Unit,
    onWeeklySummaryChange: (Boolean) -> Unit,
    onAppNewsChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalStrings.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        SheetHeader(title = "\uD83D\uDD14 ${s.notifSheetTitle}", subtitle = s.notifSheetSubtitle)
        ToggleOptionRow("\u23F0", s.notifDueReminderOption, dueReminder, onDueReminderChange)
        ToggleOptionRow("\uD83D\uDCCA", s.notifWeeklySummaryOption, weeklySummary, onWeeklySummaryChange)
        ToggleOptionRow("\uD83C\uDF89", s.notifAppNewsOption, appNews, onAppNewsChange)
        Spacer(Modifier.height(12.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageSheet(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    val s = LocalStrings.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        SheetHeader(title = "\uD83C\uDF10 ${s.moreLanguage}", subtitle = s.langSheetSubtitle)
        SingleChoiceOptionRow("\uD83C\uDDE7\uD83C\uDDE9", s.languageBengaliOption, selected == "bn") { onSelect("bn") }
        SingleChoiceOptionRow("\uD83C\uDDEC\uD83C\uDDE7", s.languageEnglishOption, selected == "en") { onSelect("en") }
        Spacer(Modifier.height(12.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ThemeSheet(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    val s = LocalStrings.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        SheetHeader(title = "\uD83C\uDFA8 ${s.moreAppearance}", subtitle = s.themeSheetSubtitle)
        SingleChoiceOptionRow("\u2600\uFE0F", s.themeLight, selected == "light") { onSelect("light") }
        SingleChoiceOptionRow("\uD83C\uDF19", s.themeDark, selected == "dark") { onSelect("dark") }
        SingleChoiceOptionRow("\u2699\uFE0F", s.themeSystem, selected == "system") { onSelect("system") }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SheetHeader(title: String, subtitle: String) {
    val c = LocalKhataColors.current
    Column(Modifier.padding(horizontal = 20.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun SingleChoiceOptionRow(emoji: String, label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 8.dp)
            .background(if (selected) c.ChipBg else c.Surface, MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = c.TextPrimary, modifier = Modifier.weight(1f))
        if (selected) {
            Box(
                Modifier
                    .size(20.dp)
                    .background(c.Primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("\u2713", color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ToggleOptionRow(emoji: String, label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 8.dp)
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = c.TextPrimary, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

// ────────────────────────── Row / group building blocks ──────────────────────────

@Composable
private fun MoreGroup(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalKhataColors.current
    Card(
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(content = content)
    }
}

@Composable
private fun MoreRow(icon: ImageVector, label: String, hint: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = c.Primary)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = c.Muted)
    }
}
