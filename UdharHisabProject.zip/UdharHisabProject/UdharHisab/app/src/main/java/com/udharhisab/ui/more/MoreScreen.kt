package com.udharhisab.ui.more

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.udharhisab.R
import com.udharhisab.data.pdf.KhataPdfGenerator
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * More পেজ — সব সাব-সেকশন এখন আলাদা পূর্ণ পেজ (আগে ৩টা Bottom Sheet ছিল)
 * সব আইকন নিজেদের বানানো SVG লাইন-আর্ট — একই সবুজে, সব ফোনে হুবহু একরকম
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    container: AppContainer,
    onOpenSecurityPrivacy: () -> Unit,
    onOpenRatingFeedback: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenLanguage: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenTheme: () -> Unit,
    onOpenBackupRestore: () -> Unit,
    onOpenCalculator: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenHelpCenter: () -> Unit,
    onOpenNotificationInbox: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.moreTitle) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(vertical = 8.dp)
        ) {
            MoreGroup {
                MoreRow(R.drawable.ic_more_backup, s.moreBackupRestore, s.moreHintBackupRestore, onClick = onOpenBackupRestore)
                MoreRow(R.drawable.ic_more_export, s.moreExportShare, s.moreHintExportShare, onClick = { showPdfDialog = true })
                MoreRow(R.drawable.ic_more_notification, s.moreNotifications, s.moreHintNotifications, onClick = onOpenNotifications)
                MoreRowVector(androidx.compose.material.icons.Icons.Default.Notifications, s.moreNotificationHistory, s.moreHintNotificationHistory, onClick = onOpenNotificationInbox)
                MoreRowVector(androidx.compose.material.icons.Icons.Default.Calculate, s.moreQuickCalculator, s.moreHintQuickCalculator, onClick = onOpenCalculator)
                MoreRowVector(androidx.compose.material.icons.Icons.Default.Description, s.notesTitle, s.noNotesYetSubtitle, onClick = onOpenNotes)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(R.drawable.ic_more_language, s.moreLanguage, s.moreHintLanguage, onClick = onOpenLanguage)
                MoreRow(R.drawable.ic_more_security, s.moreSecurityPrivacy, s.moreHintSecurityPrivacy, onClick = onOpenSecurityPrivacy)
                MoreRow(R.drawable.ic_more_theme, s.moreAppearance, s.moreHintAppearance, onClick = onOpenTheme)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(R.drawable.ic_more_rating, s.moreRateFeedback, s.moreHintRateFeedback, onClick = onOpenRatingFeedback)
                MoreRowVector(androidx.compose.material.icons.Icons.Default.HelpOutline, s.helpCenterTitle, s.helpSearchPlaceholder, onClick = onOpenHelpCenter)
                MoreRow(R.drawable.ic_more_about, s.moreAbout, s.moreHintAbout, onClick = onOpenAbout)
            }
        }
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = null,
            onDismiss = { showPdfDialog = false },
            onGenerate = { pdfShopId, fromTime, toTime, pdfScope, pdfFormat ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val reportNumber = container.store.nextReportNumber()
                        val file = if (pdfShopId != null) {
                            val targetShop = container.repo.shopOnce(pdfShopId)
                            if (targetShop == null) {
                                snackbar.showSnackbar("${s.pdfFailPrefix}shop not found")
                                return@launch
                            }
                            val rangeTxns = container.repo.txnsWithItemsInRange(pdfShopId, fromTime, toTime)
                            KhataPdfGenerator(context, s).generateShopReport(
                                targetShop, rangeTxns, reportNumber, fromTime, toTime, pdfFormat, pdfScope
                            )
                        } else {
                            val rows = container.repo.shopReportRowsInRange(fromTime, toTime)
                            KhataPdfGenerator(context, s).generateAllShopsReport(
                                rows, reportNumber, fromTime, toTime
                            )
                        }
                        val uri = FileProvider.getUriForFile(
                            context, "${context.packageName}.fileprovider", file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, s.shareKhata))
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }
}

// ────────────────────────── Row / group building blocks ──────────────────────────

@Composable
private fun MoreGroup(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalKhataColors.current
    Card(
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(content = content)
    }
}

@Composable
private fun MoreRowVector(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, hint: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .background(c.ChipBg, RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        }
        Icon(
            androidx.compose.material.icons.Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = c.Muted
        )
    }
}

@Composable
private fun MoreRow(iconRes: Int, label: String, hint: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .background(c.ChipBg, RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(id = iconRes),
                contentDescription = null,
                tint = c.Primary,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        }
        Icon(
            androidx.compose.material.icons.Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = c.Muted
        )
    }
}
