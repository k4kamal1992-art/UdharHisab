package com.udharhisab.ui.more

import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.udharhisab.ui.components.FriendlyTiles
import com.udharhisab.ui.components.PersonIllustration
import com.udharhisab.ui.components.ShopkeeperIllustration
import com.udharhisab.ui.strings.shopkeeperLabelsFor
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.udharhisab.R
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.pdf.buildPdf
import com.udharhisab.ui.pdf.rememberPdfOutput
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * More পেজ — সব সাব-সেকশন এখন আলাদা পূর্ণ পেজ (আগে ৩টা Bottom Sheet ছিল)
 * সব আইকন নিজেদের বানানো SVG লাইন-আর্ট — একই সবুজে, সব ফোনে হুবহু একরকম
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    container: AppContainer,
    onOpenSecurityPrivacy: () -> Unit,
    onOpenRatingFeedback: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenLanguage: () -> Unit,
    onOpenUserMode: () -> Unit,
    onOpenShopProfile: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenTheme: () -> Unit,
    onOpenBackupRestore: () -> Unit,
    onOpenCalculator: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenHelpCenter: () -> Unit,
    onOpenNotificationInbox: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())
    // ⭐ দোকানদার হলে (আমি কে → দোকানদার) দোকানের প্রোফাইল অপশন আসে
    val settings by container.store.settings.collectAsState(initial = null)
    val pdfOutput = rememberPdfOutput { ok ->
        scope.launch { snackbar.showSnackbar(if (ok) s.pdfSavedMessage else s.pdfSaveFailed) }
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.moreTitle, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp)
        ) {
            // ⭐ প্রোফাইল-কার্ড: কে ব্যবহার করছে (গ্রাহক/দোকানদার) — চরিত্রসহ, ট্যাপ করলে "আমি কে" পেজ
            val shopkeeper = settings?.isShopkeeper == true
            val modeLabels = shopkeeperLabelsFor(s.code)
            val displayName = if (shopkeeper && !settings?.businessName.isNullOrBlank()) settings!!.businessName else s.homeHeadline
            Box(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .shadow(8.dp, RoundedCornerShape(26.dp), ambientColor = c.Primary, spotColor = c.Primary)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
                    .clickable(onClick = onOpenUserMode)
            ) {
                Row(Modifier.padding(start = 20.dp, top = 14.dp, bottom = 14.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(displayName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold,
                            color = Color.White, maxLines = 1)
                        Spacer(Modifier.height(6.dp))
                        Box(
                            Modifier.background(Color.White.copy(alpha = 0.22f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (shopkeeper) modeLabels.userModeShopkeeperOption else modeLabels.userModeCustomerOption,
                                style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.White,
                                maxLines = 1
                            )
                        }
                    }
                    if (shopkeeper) ShopkeeperIllustration(Modifier.size(96.dp))
                    else PersonIllustration(Modifier.size(96.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            MoreGroup {
                MoreRow(R.drawable.ic_more_backup, s.moreBackupRestore, s.moreHintBackupRestore, onClick = onOpenBackupRestore)
                MoreRow(R.drawable.ic_more_export, s.moreExportShare, s.moreHintExportShare, onClick = { showPdfDialog = true })
                MoreRow(R.drawable.ic_more_notification, s.moreNotifications, s.moreHintNotifications, onClick = onOpenNotifications)
                MoreRowVector(Icons.Default.Notifications, s.moreNotificationHistory, s.moreHintNotificationHistory, onClick = onOpenNotificationInbox)
                MoreRowVector(Icons.Default.Calculate, s.moreQuickCalculator, s.moreHintQuickCalculator, onClick = onOpenCalculator)
                MoreRowVector(Icons.Default.Description, s.notesTitle, s.noNotesYetSubtitle, onClick = onOpenNotes)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(R.drawable.ic_more_language, s.moreLanguage, s.moreHintLanguage, onClick = onOpenLanguage)
                MoreRowVector(Icons.Default.SwitchAccount, s.moreUserMode, s.moreHintUserMode, onClick = onOpenUserMode)
                if (settings?.isShopkeeper == true) {
                    MoreRowVector(Icons.Default.Storefront, s.moreShopProfile, s.moreHintShopProfile, onClick = onOpenShopProfile)
                }
                MoreRow(R.drawable.ic_more_security, s.moreSecurityPrivacy, s.moreHintSecurityPrivacy, onClick = onOpenSecurityPrivacy)
                MoreRow(R.drawable.ic_more_theme, s.moreAppearance, s.moreHintAppearance, onClick = onOpenTheme)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(R.drawable.ic_more_rating, s.moreRateFeedback, s.moreHintRateFeedback, onClick = onOpenRatingFeedback)
                MoreRowVector(Icons.Default.HelpOutline, s.helpCenterTitle, s.helpSearchPlaceholder, onClick = onOpenHelpCenter)
                MoreRow(R.drawable.ic_more_about, s.moreAbout, s.moreHintAbout, onClick = onOpenAbout)
            }
        }
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = null,
            shopkeeperMode = settings?.isShopkeeper == true,
            brandingAvailable = settings?.toBranding() != null,
            onDismiss = { showPdfDialog = false },
            onGenerate = { req ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val file = buildPdf(context, container, s, req)
                        pdfOutput.deliver(file, req.action, s.shareKhata)
                        (context as? android.app.Activity)?.let { com.udharhisab.ads.AdManager.maybeShowInterstitialAfterExport(it) }
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }
}

// ────────────────────────── Row / group building blocks ──────────────────────────

@Composable
private fun MoreGroup(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalKhataColors.current
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(Modifier.padding(vertical = 6.dp), content = content)
    }
}

/** ⭐ প্রতিটা সারির নিজস্ব রঙের আইকন-টাইল */
@Composable
private fun MoreTile(label: String, content: @Composable () -> Unit) {
    val (bg, _) = FriendlyTiles.forKey(label)
    Box(
        Modifier.size(46.dp).background(bg, RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun MoreRowVector(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, hint: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val (_, fg) = FriendlyTiles.forKey(label)
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MoreTile(label) { Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary, fontWeight = FontWeight.Bold)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = c.Muted)
    }
}

@Composable
private fun MoreRow(iconRes: Int, label: String, hint: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val (_, fg) = FriendlyTiles.forKey(label)
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MoreTile(label) {
            Icon(painter = painterResource(id = iconRes), contentDescription = null, tint = fg, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary, fontWeight = FontWeight.Bold)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = c.Muted)
    }
}
