package com.udharhisab.ui.addshop

import androidx.compose.runtime.mutableLongStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.launch

/** ⭐ ViewModel ভাষা জানে না — এরর একটা enum হিসেবে রাখা হয়, UI-লেয়ারে অনুবাদ হয় */
enum class AddShopError { NAME_REQUIRED, TYPE_REQUIRED }

class AddShopViewModel(private val repo: HisabRepository) : ViewModel() {

    var name = androidx.compose.runtime.mutableStateOf("")
        private set
    var phone = androidx.compose.runtime.mutableStateOf("")
        private set
    var selectedType = androidx.compose.runtime.mutableStateOf<ShopType?>(null)
        private set
    var error = androidx.compose.runtime.mutableStateOf<AddShopError?>(null)
        private set
    var saved = androidx.compose.runtime.mutableStateOf(false)
        private set

    /** ⭐ সেভ হওয়া দোকানের নতুন id — নেভিগেশনের জন্য */
    val savedShopId = mutableLongStateOf(0L)

    fun setName(v: String) { name.value = v; error.value = null }
    fun setPhone(v: String) { phone.value = v }
    fun setType(t: ShopType) { selectedType.value = t }

    fun save(language: String = "bn") {
        viewModelScope.launch {
            when {
                name.value.isBlank() -> error.value = AddShopError.NAME_REQUIRED
                selectedType.value == null -> error.value = AddShopError.TYPE_REQUIRED
                else -> {
                    val id = repo.insertShop(name.value, phone.value, selectedType.value!!, language)
                    savedShopId.longValue = id
                    saved.value = true
                }
            }
        }
    }
}
