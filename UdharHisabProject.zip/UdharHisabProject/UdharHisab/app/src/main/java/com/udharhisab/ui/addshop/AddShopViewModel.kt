package com.udharhisab.ui.addshop

import androidx.compose.runtime.mutableLongStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.launch

class AddShopViewModel(private val repo: HisabRepository) : ViewModel() {

    var name = androidx.compose.runtime.mutableStateOf("")
        private set
    var phone = androidx.compose.runtime.mutableStateOf("")
        private set
    var selectedType = androidx.compose.runtime.mutableStateOf<ShopType?>(null)
        private set
    var error = androidx.compose.runtime.mutableStateOf<String?>(null)
        private set
    var saved = androidx.compose.runtime.mutableStateOf(false)
        private set

    /** ⭐ সেভ হওয়া দোকানের নতুন id — নেভিগেশনের জন্য */
    val savedShopId = mutableLongStateOf(0L)

    fun setName(v: String) { name.value = v; error.value = null }
    fun setPhone(v: String) { phone.value = v }
    fun setType(t: ShopType) { selectedType.value = t }

    fun save() {
        viewModelScope.launch {
            when {
                name.value.isBlank() -> error.value = "দোকানের নাম লিখুন"
                selectedType.value == null -> error.value = "দোকানের ধরন বেছে নিন"
                else -> {
                    val id = repo.insertShop(name.value, phone.value, selectedType.value!!)
                    savedShopId.longValue = id
                    saved.value = true
                }
            }
        }
    }

    // রেফারেন্স পাবলিক করুন
   // val savedShopId = mutableLongStateOf(0L)
}
