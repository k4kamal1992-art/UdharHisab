package com.yourname.udharhisab.utils

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.model.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter

/**
 * Handles JSON export/import for backup
 */
object JsonBackupManager {

    private val gson = Gson()

    data class BackupData(
        val shops: List<Shop>,
        val transactions: List<Transaction>,
        val exportDate: Long = System.currentTimeMillis()
    )

    suspend fun exportToJson(context: Context): File = withContext(Dispatchers.IO) {
        val app = context.applicationContext as UdharHisabApp
        val shops = app.shopRepository.allShops.value ?: emptyList()
        val transactions = app.transactionRepository.getAllTransactions().value ?: emptyList()

        val backupData = BackupData(shops, transactions)
        val json = gson.toJson(backupData)

        val downloadsDir = context.getExternalFilesDir(null)
            ?: context.filesDir
        val file = File(downloadsDir, Constants.BACKUP_FILE_NAME)

        FileWriter(file).use { writer ->
            writer.write(json)
        }
        file
    }

    suspend fun importFromJson(context: Context, jsonString: String) = withContext(Dispatchers.IO) {
        val app = context.applicationContext as UdharHisabApp
        val type = object : TypeToken<BackupData>() {}.type
        val backupData = gson.fromJson<BackupData>(jsonString, type)

        backupData.shops.forEach { shop ->
            app.shopRepository.insert(shop)
        }
        backupData.transactions.forEach { transaction ->
            app.transactionRepository.insert(transaction)
        }
    }
}
