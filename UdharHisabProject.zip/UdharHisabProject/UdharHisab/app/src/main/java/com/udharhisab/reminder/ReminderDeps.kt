package com.udharhisab.reminder

import android.content.Context
import com.udharhisab.data.local.AppDatabase
import com.udharhisab.data.repository.HisabRepository
import com.udharhisab.data.settings.SettingsDataStore

/**
 * ⭐ Worker-এর জন্য সিম্পল DI — অ্যাপের AppContainer-এর সাথে একই সিঙ্গলটন শেয়ার
 */
object ReminderDeps {

    @Volatile private var database: AppDatabase? = null

    fun db(context: Context): AppDatabase =
        database ?: synchronized(this) {
            database ?: AppDatabase.getInstance(context.applicationContext)
        }.also { database = it }

    fun repo(context: Context): HisabRepository = HisabRepository(db(context))

    fun store(context: Context): SettingsDataStore =
        SettingsDataStore(context.applicationContext)
}
