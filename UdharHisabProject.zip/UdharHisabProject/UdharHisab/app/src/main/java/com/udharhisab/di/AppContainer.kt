package com.udharhisab.di

import android.content.Context
import com.udharhisab.data.local.AppDatabase
import com.udharhisab.data.repository.HisabRepository
import com.udharhisab.data.settings.SettingsDataStore

/**
 * সিম্পল DI কন্টেইনার — সব ViewModel এখান থেকে ডিপেন্ডেন্সি পাবে
 */
class AppContainer(context: Context) {
    val db: AppDatabase = AppDatabase.getInstance(context.applicationContext)
    val repo: HisabRepository = HisabRepository(db)
    val store: SettingsDataStore = SettingsDataStore(context.applicationContext)
}
