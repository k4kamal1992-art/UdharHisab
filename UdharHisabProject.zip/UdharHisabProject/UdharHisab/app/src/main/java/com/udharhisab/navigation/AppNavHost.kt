package com.udharhisab.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.addshop.AddShopScreen
import com.udharhisab.ui.detail.ShopDetailScreen
import com.udharhisab.ui.history.HistoryScreen
import com.udharhisab.ui.home.HomeScreen
import com.udharhisab.ui.settings.SettingsScreen

@Composable
fun AppNavHost(container: AppContainer) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Route.Home.route
    ) {
        composable(Route.Home.route) {
            HomeScreen(
                container = container,
                onAddShop = { navController.navigate(Route.AddShop.route) },
                onOpenShop = { id ->
                    navController.navigate(Route.ShopDetail.create(id))
                },
                onOpenHistory = { navController.navigate(Route.History.route) },
                onOpenSettings = { navController.navigate(Route.Settings.route) }
            )
        }

        composable(Route.AddShop.route) {
            AddShopScreen(
                container = container,
                onBack = { navController.popBackStack() },
                onSaved = { shopId ->
                    navController.navigate(Route.ShopDetail.create(shopId)) {
                        popUpTo(Route.AddShop.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            Route.ShopDetail.pattern,
            arguments = listOf(navArgument("shopId") { type = NavType.LongType })
        ) { backStackEntry ->
            val shopId = backStackEntry.arguments?.getLong("shopId") ?: 0L
            ShopDetailScreen(
                container = container,
                shopId = shopId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Route.History.route) {
            HistoryScreen(
                container = container,
                onBack = { navController.popBackStack() },
                onOpenShop = { id ->
                    navController.navigate(Route.ShopDetail.create(id))
                }
            )
        }

        composable(Route.Settings.route) {
            SettingsScreen(
                container = container,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
