package com.udharhisab.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.addshop.AddShopScreen
import com.udharhisab.ui.about.AboutScreen
import com.udharhisab.ui.detail.ShopDetailScreen
import com.udharhisab.ui.entry.CreditEntryScreen
import com.udharhisab.ui.entry.PaymentEntryScreen
import com.udharhisab.ui.feedback.RatingFeedbackScreen
import com.udharhisab.ui.history.ArchivedShopsScreen
import com.udharhisab.ui.history.HistoryScreen
import com.udharhisab.ui.home.HomeScreen
import com.udharhisab.ui.more.MoreScreen
import com.udharhisab.ui.nav.BottomNavBar
import com.udharhisab.ui.reports.ReportsScreen
import com.udharhisab.ui.security.SecurityPrivacyScreen
import com.udharhisab.ui.settings.SettingsScreen
import com.udharhisab.ui.shopprofile.ShopProfileScreen
import androidx.compose.runtime.collectAsState

/** ⭐ বটম-ন্যাভে দেখানোর মতো টপ-লেভেল রাউট — এগুলোতেই শুধু নিচের বার দেখাবে */
private val bottomNavRoutes = setOf(
    Route.Home.route, Route.History.route, Route.Reports.route, Route.More.route
)

@Composable
fun AppNavHost(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute in bottomNavRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                BottomNavBar(currentRoute = currentRoute) { route ->
                    navController.navigate(route.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Route.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Route.Home.route) {
                HomeScreen(
                    container = container,
                    onAddShop = { navController.navigate(Route.AddShop.route) },
                    onOpenShop = { id ->
                        navController.navigate(Route.ShopDetail.create(id))
                    }
                )
            }

            composable(Route.AddShop.route) {
                AddShopScreen(
                    container = container,
                    onBack = { navController.popBackStack() },
                    onSaved = { shopId ->
                        navController.navigate(Route.ShopDetail.create(shopId)) {
                            popUpTo(Route.AddShop.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(
                Route.ShopDetail.pattern,
                arguments = listOf(navArgument("shopId") { type = NavType.LongType })
            ) { backStackEntry2 ->
                val shopId = backStackEntry2.arguments?.getLong("shopId") ?: 0L
                // ⭐ ধার/জমা সেভ হয়ে ফিরলে এখানে "credit"/"payment" আসে → দোকানদারকে রিমাইন্ডার অপশন দেখাই
                val savedKind by backStackEntry2.savedStateHandle
                    .getStateFlow<String?>("entry_saved", null).collectAsState()
                ShopDetailScreen(
                    container = container,
                    shopId = shopId,
                    justSavedKind = savedKind,
                    onSavedPromptHandled = { backStackEntry2.savedStateHandle["entry_saved"] = null },
                    onBack = { navController.popBackStack() },
                    onOpenCredit = { navController.navigate(Route.CreditEntry.create(shopId)) },
                    onOpenPayment = { navController.navigate(Route.PaymentEntry.create(shopId)) }
                )
            }

            composable(
                Route.CreditEntry.pattern,
                arguments = listOf(navArgument("shopId") { type = NavType.LongType })
            ) { backStackEntry2 ->
                val shopId = backStackEntry2.arguments?.getLong("shopId") ?: 0L
                CreditEntryScreen(
                    container = container,
                    shopId = shopId,
                    onBack = { navController.popBackStack() },
                    onSaved = {
                        navController.previousBackStackEntry?.savedStateHandle?.set("entry_saved", "credit")
                        navController.popBackStack()
                    }
                )
            }

            composable(
                Route.PaymentEntry.pattern,
                arguments = listOf(navArgument("shopId") { type = NavType.LongType })
            ) { backStackEntry2 ->
                val shopId = backStackEntry2.arguments?.getLong("shopId") ?: 0L
                PaymentEntryScreen(
                    container = container,
                    shopId = shopId,
                    onBack = { navController.popBackStack() },
                    onSaved = {
                        navController.previousBackStackEntry?.savedStateHandle?.set("entry_saved", "payment")
                        navController.popBackStack()
                    }
                )
            }

            composable(Route.History.route) {
                HistoryScreen(
                    container = container,
                    onOpenShop = { id -> navController.navigate(Route.ShopDetail.create(id)) },
                    onOpenArchived = { navController.navigate(Route.ArchivedShops.route) }
                )
            }

            composable(Route.ArchivedShops.route) {
                ArchivedShopsScreen(
                    container = container,
                    onBack = { navController.popBackStack() },
                    onOpenShop = { id -> navController.navigate(Route.ShopDetail.create(id)) }
                )
            }

            composable(Route.Reports.route) {
                ReportsScreen(
                    container = container,
                    onOpenShop = { id -> navController.navigate(Route.ShopDetail.create(id)) }
                )
            }

            composable(Route.More.route) {
                MoreScreen(
                    container = container,
                    onOpenSecurityPrivacy = { navController.navigate(Route.SecurityPrivacy.route) },
                    onOpenRatingFeedback = { navController.navigate(Route.RatingFeedback.route) },
                    onOpenAbout = { navController.navigate(Route.About.route) },
                    onOpenShopProfile = { navController.navigate(Route.ShopProfile.route) }
                )
            }

            composable(Route.SecurityPrivacy.route) {
                SecurityPrivacyScreen(
                    container = container,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Route.ShopProfile.route) {
                ShopProfileScreen(
                    container = container,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Route.RatingFeedback.route) {
                RatingFeedbackScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Route.About.route) {
                AboutScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Route.Settings.route) {
                SettingsScreen(
                    container = container,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
