package com.udharhisab.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(private val repo: HisabRepository) : ViewModel() {

    // ── UI ফিল্টার স্টেট ──
    val search = MutableStateFlow("")
    val typeFilter = MutableStateFlow<ShopType?>(null)   // null = সব
    val sortBy = MutableStateFlow(SortBy.RECENT)

    enum class SortBy { RECENT, NAME, DUE_HIGH }

    private val allShops = repo.shopsWithBalance()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    /** ⭐ সার্চ + ফিল্টার + সর্ট — সব একসাথে */
    val visibleShops: StateFlow<List<ShopWithBalance>> =
        combine(allShops, search, typeFilter, sortBy) { shops, q, type, sort ->
            var list = shops

            if (type != null) list = list.filter { it.shop.shopType == type.key }

            if (q.isNotBlank()) {
                val needle = q.trim()
                list = list.filter {
                    it.shop.name.contains(needle, ignoreCase = true) ||
                        (it.shop.phone?.contains(needle) == true)
                }
            }

            when (sort) {
                SortBy.RECENT -> list.sortedByDescending { it.shop.lastUsedAt }
                SortBy.NAME -> list.sortedBy { it.shop.name }
                SortBy.DUE_HIGH -> list.sortedByDescending { it.balance }
            }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    /** হিরো কার্ড: মোট বাকি */
    val totalDue: StateFlow<Double> =
        combine(allShops) { shops -> shops.sumOf { it.balance.coerceAtLeast(0.0) } }
            .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), 0.0)

    /** পরিশোধিত (ব্যালেন্স ≤ 0) সংখ্যা — হোমে "🎉" ব্যাজ */
   // val settledCount: StateFlow<Int> =
       // combine(allShops) { shops -> shops.count { it.balance <= 0 && it.balance != 0.0 || it.balance == 0.0 && false } }
      //      .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), 0)
  
    val settledCount: StateFlow<Int> =
        combine(allShops) { shops -> shops.count { it.balance <= 0.0 } }
            .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), 0)

    fun setSearch(q: String) { search.value = q }
    fun setTypeFilter(t: ShopType?) { typeFilter.value = t }
    fun setSort(s: SortBy) { sortBy.value = s }
}
