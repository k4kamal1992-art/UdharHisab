package com.udharhisab.ui.entry

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.ShopProductEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreditEntryScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val products by container.repo.shopProducts(shopId).collectAsState(initial = emptyList())
    val shop by container.repo.shopByIdFlow(shopId).collectAsState(initial = null)
    var currentDue by remember { mutableStateOf(0.0) }
    LaunchedEffect(shopId) { currentDue = container.repo.balanceOnce(shopId) }

    val shopVal = shop
    if (shopVal == null) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Spacer(Modifier.height(40.dp))
            com.udharhisab.ui.components.SkeletonHeroCard()
            Spacer(Modifier.height(16.dp))
            com.udharhisab.ui.components.ShimmerBlock(Modifier.fillMaxWidth(), height = 52.dp, corner = 14.dp)
        }
        return
    }
    val shopName = shopVal.name
    val isWoodShop = ShopType.fromKey(shopVal.shopType) == ShopType.WOOD

    val vm: CreditEntryViewModel = viewModel { CreditEntryViewModel(container.repo, shopId, isWoodShop) }

    LaunchedEffect(vm.saved) { if (vm.saved) onSaved() }

    val total = vm.totalAmount()
    val newTotalDue = currentDue + total

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(shopName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${s.currentDueLabel}: ${UnitConverter.rupees(currentDue)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Primary,
                    scrolledContainerColor = c.Primary,
                    titleContentColor = androidx.compose.ui.graphics.Color.White,
                    navigationIconContentColor = androidx.compose.ui.graphics.Color.White,
                    actionIconContentColor = androidx.compose.ui.graphics.Color.White
                )
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Column(Modifier.padding(16.dp)) {
                    if (vm.error) {
                        Text(s.invalidAmountError, color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Button(
                        onClick = { vm.save(onSaved) },
                        colors = ButtonDefaults.buttonColors(containerColor = c.Danger),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Text("${s.addCreditButton} — ${UnitConverter.rupees(total)}")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            // ── হিসাবের ধরন ──
            Text(s.accountingTypeLabel, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = vm.mode == CreditMode.DIRECT,
                    onClick = { vm.selectMode(CreditMode.DIRECT) },
                    label = { Text(s.directMoneyMode) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = vm.mode == CreditMode.PRODUCT,
                    onClick = { vm.selectMode(CreditMode.PRODUCT) },
                    label = { Text(s.productMode) },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(16.dp))

            if (vm.mode == CreditMode.DIRECT) {
                OutlinedTextField(
                    value = vm.directAmount,
                    onValueChange = vm::updateDirectAmount,
                    label = { Text(s.directMoneyAmountLabel) },
                    singleLine = true,
                    isError = vm.error,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                DueCalcBox(s.previousDueLabel, currentDue, s.newCreditLabel, total, s.newTotalDueLabel, newTotalDue, c)
                Spacer(Modifier.height(16.dp))
                NoteField(vm.note, vm::updateNote, s.noteLabel)
                Spacer(Modifier.height(24.dp))
            } else {
                if (isWoodShop) {
                    TimberCalculator { productName, totalCft, ratePerCft ->
                        vm.addProductRowFromTimber(productName, totalCft, ratePerCft)
                    }
                    Spacer(Modifier.height(16.dp))
                    if (vm.productRows.isNotEmpty()) {
                        Text(s.addedItemsHeader, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                    }
                }

                vm.productRows.forEachIndexed { index, row ->
                    ProductRowCard(
                        row = row,
                        suggestions = products,
                        canDelete = true,
                        onDelete = { vm.removeProductRow(row) }
                    )
                    Spacer(Modifier.height(10.dp))
                }

                OutlinedButton(
                    onClick = { vm.addProductRow() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (isWoodShop) s.addMoreWoodProductButton else s.addMoreProductButton) }

                Spacer(Modifier.height(16.dp))

                // ⭐ সবসময় দৃশ্যমান টোটাল
                Card(colors = CardDefaults.cardColors(containerColor = c.ChipBg)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(s.totalNewCreditLabel, style = MaterialTheme.typography.titleMedium)
                            Text(UnitConverter.rupees(total), style = MaterialTheme.typography.titleMedium, color = c.Danger)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                DueCalcBox(s.previousDueLabel, currentDue, s.newCreditLabel, total, s.newTotalDueLabel, newTotalDue, c)
                Spacer(Modifier.height(16.dp))
                NoteField(vm.note, vm::updateNote, s.noteLabel)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun DueCalcBox(
    prevLabel: String, prev: Double,
    newLabel: String, added: Double,
    totalLabel: String, total: Double,
    c: com.udharhisab.ui.theme.KhataColors
) {
    Card(colors = CardDefaults.cardColors(containerColor = c.Surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(prevLabel, color = c.Muted)
                Text(UnitConverter.rupees(prev))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(newLabel, color = c.Muted)
                Text(UnitConverter.rupees(added), color = c.Danger)
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(totalLabel, style = MaterialTheme.typography.titleMedium)
                Text(UnitConverter.rupees(total), style = MaterialTheme.typography.titleMedium, color = c.Danger)
            }
        }
    }
}

@Composable
private fun NoteField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth()
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductRowCard(
    row: ProductRow,
    suggestions: List<ShopProductEntity>,
    canDelete: Boolean,
    onDelete: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    var expanded by remember { mutableStateOf(false) }
    val filtered = remember(suggestions, row.productName, s.code) {
        val q = row.productName.trim()
        val list = if (q.isEmpty()) suggestions
            else suggestions.filter {
                DefaultProducts.translateIfDefault(it.name, s.code).contains(q, ignoreCase = true)
            }
        list.map { it to DefaultProducts.translateIfDefault(it.name, s.code) }
    }

    Card(colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ExposedDropdownMenuBox(
                    expanded = expanded && filtered.isNotEmpty(),
                    onExpandedChange = { expanded = it },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = row.productName,
                        onValueChange = { row.productName = it; expanded = true },
                        label = { Text(s.productNameLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded && filtered.isNotEmpty(),
                        onDismissRequest = { expanded = false }
                    ) {
                        filtered.forEach { (p, displayName) ->
                            DropdownMenuItem(
                                text = {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(displayName, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                        p.lastUnitPrice?.let {
                                            Text(UnitConverter.rupees(it), color = c.Muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                },
                                onClick = {
                                    row.productName = displayName
                                    p.lastUnit?.let { row.unit = it }
                                    p.lastUnitPrice?.let { row.unitPrice = UnitConverter.amountInput(it) }
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                if (canDelete) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, s.deleteTxnAction, tint = c.Muted)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = row.quantity, onValueChange = { row.quantity = it },
                    label = { Text(s.quantityLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = row.unit, onValueChange = { row.unit = it },
                    label = { Text(s.unitLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = row.unitPrice, onValueChange = { row.unitPrice = it },
                    label = { Text(s.pricePerUnitLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }
            row.amount?.let {
                Spacer(Modifier.height(6.dp))
                Text(
                    "${row.productName.ifBlank { s.creditFallback }} — ${UnitConverter.rupees(it)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.Danger
                )
            }
        }
    }
}
