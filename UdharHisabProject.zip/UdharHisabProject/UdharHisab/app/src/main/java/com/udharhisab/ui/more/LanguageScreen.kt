package com.udharhisab.ui.more

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** ভাষা নির্বাচন — আগে Bottom Sheet ছিল, এখন পূর্ণ পেজ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()

    var selected by remember(settings.language) { mutableStateOf(settings.language) }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.moreLanguage) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(s.langSheetSubtitle, color = c.Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))

            ChoiceRow(Icons.Default.Language, s.languageBengaliOption, selected == "bn") { selected = "bn" }
            Spacer(Modifier.height(10.dp))
            ChoiceRow(Icons.Default.Language, s.languageEnglishOption, selected == "en") { selected = "en" }

            Spacer(Modifier.weight(1f))
            Button(
                onClick = { viewModel.setLanguage(selected); onBack() },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(s.save)
            }
        }
    }
}

/** একটা বাছাইযোগ্য অপশন — Language/Theme পেজে ব্যবহৃত */
@Composable
internal fun ChoiceRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(if (selected) c.ChipBg else c.Surface)
            .then(
                if (selected) Modifier.border(BorderStroke(2.dp, c.Primary), MaterialTheme.shapes.medium)
                else Modifier.border(BorderStroke(1.dp, c.Divider), MaterialTheme.shapes.medium)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary, modifier = Modifier.weight(1f))
        if (selected) {
            Box(
                Modifier.size(22.dp).background(c.Primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
