package com.udharhisab.ui.more

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** ভাষা নির্বাচন — ২-কলাম গ্রিড, রঙিন অ্যাভাটার, অ্যাপের নিজস্ব সবুজ প্যালেটে */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()

    var selected by remember(settings.language) { mutableStateOf(settings.language) }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.moreLanguage) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(s.langSheetSubtitle, color = c.Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))

            LanguageGrid(selected = selected, onSelect = { selected = it })

            Spacer(Modifier.weight(1f))
            Button(
                onClick = { viewModel.setLanguage(selected); onBack() },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(s.save)
            }
        }
    }
}

/** তিনটা ভাষার ২-কলাম গ্রিড — Language পেজ আর প্রথমবার-অনবোর্ডিং দুটোতেই ব্যবহৃত */
@Composable
internal fun LanguageGrid(selected: String?, onSelect: (String) -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LanguageGridCard(
            letter = "বা", label = s.languageBengaliOption, avatarColor = c.Primary,
            selected = selected == "bn", modifier = Modifier.weight(1f)
        ) { onSelect("bn") }
        LanguageGridCard(
            letter = "E", label = s.languageEnglishOption, avatarColor = c.Accent,
            selected = selected == "en", modifier = Modifier.weight(1f)
        ) { onSelect("en") }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LanguageGridCard(
            letter = "हि", label = "हिंदी", avatarColor = c.PrimaryDark,
            selected = selected == "hi", modifier = Modifier.weight(1f)
        ) { onSelect("hi") }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun LanguageGridCard(
    letter: String,
    label: String,
    avatarColor: Color,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val c = LocalKhataColors.current
    Box(
        modifier
            .clip(MaterialTheme.shapes.medium)
            .background(if (selected) c.ChipBg else c.Surface)
            .then(
                if (selected) Modifier.border(BorderStroke(2.dp, c.Primary), MaterialTheme.shapes.medium)
                else Modifier.border(BorderStroke(1.dp, c.Divider), MaterialTheme.shapes.medium)
            )
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Column {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(avatarColor),
                contentAlignment = Alignment.Center
            ) {
                Text(letter, color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(10.dp))
            Text(label, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary, fontWeight = FontWeight.Medium)
        }
        if (selected) {
            Box(
                Modifier.align(Alignment.TopEnd).size(20.dp).background(c.Primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
            }
        }
    }
}

/** একটা বাছাইযোগ্য অপশন — Theme পেজে ব্যবহৃত */
@Composable
internal fun ChoiceRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(if (selected) c.ChipBg else c.Surface)
            .then(
                if (selected) Modifier.border(BorderStroke(2.dp, c.Primary), MaterialTheme.shapes.medium)
                else Modifier.border(BorderStroke(1.dp, c.Divider), MaterialTheme.shapes.medium)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary, modifier = Modifier.weight(1f))
        if (selected) {
            Box(
                Modifier.size(22.dp).background(c.Primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
