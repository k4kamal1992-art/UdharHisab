package com.udharhisab.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer

/**
 * ⭐ ছোট ছোট অ্যানিমেশন — অ্যাপ যেন "জীবন্ত" লাগে।
 */

/** চাপলে কার্ড/বাটন একটু ছোট হয়ে ফিরে আসে (বাউন্সি টাচ) */
fun Modifier.bouncyClick(onClick: () -> Unit): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = interaction, indication = LocalIndication.current, onClick = onClick)
}

/**
 * টাকার অঙ্ক আগের মান থেকে নতুন মানে গুনে গুনে বাড়ে/কমে।
 * শেষ মুহূর্তে অঙ্কটা হুবহু আসল মান (Double) — তাই কোনো পয়সা-টাকার গোলমাল হয় না।
 */
@Composable
fun rememberCountUp(target: Double, durationMs: Int = 700): Double {
    val progress = remember { Animatable(1f) }
    val from = remember { mutableStateOf(target) }
    val to = remember { mutableStateOf(target) }
    LaunchedEffect(target) {
        if (target == to.value) return@LaunchedEffect
        // চলতি দেখানো মান থেকেই নতুনটার দিকে যাই
        from.value = from.value + (to.value - from.value) * progress.value
        to.value = target
        progress.snapTo(0f)
        progress.animateTo(1f, tween(durationMs))
    }
    return from.value + (to.value - from.value) * progress.value
}
