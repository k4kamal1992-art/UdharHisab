package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** ব্যবহারকারীর ব্যক্তিগত নোট — বাজারের তালিকা, রিমাইন্ডার, যেকোনো টুকিটাকি লেখা রাখার জন্য */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
