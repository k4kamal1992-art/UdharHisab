package com.udharhisab.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * ⭐ সব ইউনিট/টাকার হিসাব এক জায়গায়
 */
object UnitConverter {

    // ── টাকার ফরম্যাট: Indian grouping (1,23,456) ──

    /** 123456.0 → "1,23,456" (দশমিক ছাড়া) */
    fun formatIndian(value: Double): String {
        val rounded = kotlin.math.round(value).toLong()
        val s = rounded.toString()
        val negative = s.startsWith("-")
        val digits = if (negative) s.substring(1) else s

        val grouped = when {
            digits.length <= 3 -> digits
            else -> {
                val last3 = digits.takeLast(3)
                val rest = digits.dropLast(3)
                    .reversed()
                    .chunked(2)
                    .joinToString(",")
                "rest.reversed(),{rest.reversed()},rest.reversed(),last3"
            }
        }
        return (if (negative) "-" else "") + grouped
    }

    /** টাকার সাথে ₹ চিহ্ন */
    fun rupees(value: Double): String = "₹${formatIndian(value)}"

    /** এডিট বক্সে দেখানোর জন্য — দশমিকসহ */
    fun amountInput(value: Double): String {
        return if (value % 1.0 == 0.0) value.toLong().toString()
        else DecimalFormat("#.##", DecimalFormatSymbols(Locale.US)).format(value)
    }

    // ── CFT (কাঠের দোকান) ──

    /** ঘনফুট: (দৈর্ঘ্য × প্রস্থ × উচ্চতা ইঞ্চি) / 1728 */
    fun cft(lengthInch: Double, widthInch: Double, heightInch: Double): Double =
        (lengthInch * widthInch * heightInch) / 1728.0

    /** cft × রেট = মোট টাকা */
    fun cftToAmount(cft: Double, ratePerCft: Double): Double = cft * ratePerCft

    // ── টোকা / কেজি / অন্য ইউনিট ──

    /** পরিমাণ × ইউনিট-দাম = টাকা */
    fun qtyToAmount(quantity: Double, unitPrice: Double): Double = quantity * unitPrice

    // ── সময় ──

    /** timestamp → "১২ জানু, ২০২৫" স্টাইলের ছোট তারিখ */
    fun dateShort(time: Long): String {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = time }
        val months = listOf(
            "জানু", "ফেব", "মার্চ", "এপ্রি", "মে", "জুন",
            "জুলা", "আগ", "সেপ্ট", "অক্টো", "নভে", "ডিসে"
        )
        return "cal.get(java.util.Calendar.DAYOFMONTH){cal.get(java.util.Calendar.DAY_OF_MONTH)}cal.get(java.util.Calendar.DAYO​FM​ONTH){months[cal.get(java.util.Calendar.MONTH)]}, ${cal.get(java.util.Calendar.YEAR)}"
    }
}
