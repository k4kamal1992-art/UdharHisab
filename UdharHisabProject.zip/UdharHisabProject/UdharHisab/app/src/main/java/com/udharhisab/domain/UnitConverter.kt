package com.udharhisab.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * ⭐ সব ইউনিট/টাকার হিসাব এক জায়গায়
 */
object UnitConverter {

    // ── টাকার ফরম্যাট: Indian grouping (1,23,456) ──

    /** 123456.0 → "1,23,456" (দশমিক ছাড়া) */
    fun formatIndian(value: Double): String {
        val rounded = kotlin.math.round(value).toLong()
        val s = rounded.toString()
        val negative = s.startsWith("-")
        val digits = if (negative) s.substring(1) else s

        val grouped = when {
            digits.length <= 3 -> digits
            else -> {
                val last3 = digits.takeLast(3)
                val rest = digits.dropLast(3)
                    .reversed()
                    .chunked(2)
                    .joinToString(",")
                "${rest.reversed()},$last3"
            }
        }
        return (if (negative) "-" else "") + grouped
    }

    /** টাকার সাথে ₹ চিহ্ন */
    fun rupees(value: Double): String = "₹${formatIndian(value)}"

    /** এডিট বক্সে দেখানোর জন্য — দশমিকসহ */
    fun amountInput(value: Double): String {
        return if (value % 1.0 == 0.0) value.toLong().toString()
        else DecimalFormat("#.##", DecimalFormatSymbols(Locale.US)).format(value)
    }

    // ── কাঠের হিসাব (Timber Calculator) ──

    /** চেরাই কাঠ: (দৈর্ঘ্য ফুট × প্রস্থ ইঞ্চি × পুরত্ব ইঞ্চি) ÷ 144 */
    fun sawnTimberCft(lengthFt: Double, widthIn: Double, thicknessIn: Double): Double =
        (lengthFt * widthIn * thicknessIn) / 144.0

    /** গোল কাঠ: (দৈর্ঘ্য ফুট × গোলবেড়ি ইঞ্চি × গোলবেড়ি ইঞ্চি) ÷ 2304 — গোলবেড়ি মানে circumference/girth, diameter নয় */
    fun roundTimberCft(lengthFt: Double, girthIn: Double): Double =
        (lengthFt * girthIn * girthIn) / 2304.0

    // ── টোকা / কেজি / অন্য ইউনিট ──

    /** পরিমাণ × ইউনিট-দাম = টাকা */
    fun qtyToAmount(quantity: Double, unitPrice: Double): Double = quantity * unitPrice

    // ── সময় ──

    /** timestamp → "১২ জানু, ২০২৫" (bn) / "12 Jan, 2025" (en) স্টাইলের ছোট তারিখ */
    fun dateShort(time: Long, language: String = "bn"): String {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = time }
        val months = if (language == "en") listOf(
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ) else listOf(
            "জানু", "ফেব", "মার্চ", "এপ্রি", "মে", "জুন",
            "জুলা", "আগ", "সেপ্ট", "অক্টো", "নভে", "ডিসে"
        )
        return "${cal.get(java.util.Calendar.DAY_OF_MONTH)} ${months[cal.get(java.util.Calendar.MONTH)]}, ${cal.get(java.util.Calendar.YEAR)}"
    }
}
