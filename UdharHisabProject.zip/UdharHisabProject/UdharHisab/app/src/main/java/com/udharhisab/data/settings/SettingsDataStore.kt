package com.udharhisab.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "khata_settings")

data class Settings(
    val pinHash: String? = null,
    val pinEnabled: Boolean = false,
    val remindersEnabled: Boolean = false,
    val reminderDays: Int = 7,
    val theme: String = "system",     // "system" | "light" | "dark"
    val language: String = "bn"
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val REMINDERS = booleanPreferencesKey("reminders_enabled")
        val REMINDER_DAYS = intPreferencesKey("reminder_days")
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
    }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            pinHash = p[Keys.PIN_HASH],
            pinEnabled = p[Keys.PIN_ENABLED] ?: false,
            remindersEnabled = p[Keys.REMINDERS] ?: false,
            reminderDays = p[Keys.REMINDER_DAYS] ?: 7,
            theme = p[Keys.THEME] ?: "system",
            language = p[Keys.LANGUAGE] ?: "bn"
        )
    }

    suspend fun setPin(hash: String) = context.dataStore.edit {
        it[Keys.PIN_HASH] = hash
        it[Keys.PIN_ENABLED] = true
    }

    suspend fun clearPin() = context.dataStore.edit {
        it.remove(Keys.PIN_HASH)
        it[Keys.PIN_ENABLED] = false
    }

    suspend fun setPinEnabled(enabled: Boolean) = context.dataStore.edit {
        it[Keys.PIN_ENABLED] = enabled
    }

    suspend fun setReminders(enabled: Boolean) = context.dataStore.edit {
        it[Keys.REMINDERS] = enabled
    }

    suspend fun setReminderDays(days: Int) = context.dataStore.edit {
        it[Keys.REMINDER_DAYS] = days
    }

    suspend fun setTheme(mode: String) = context.dataStore.edit {
        it[Keys.THEME] = mode
    }

    suspend fun setLanguage(lang: String) = context.dataStore.edit {
        it[Keys.LANGUAGE] = lang
    }
}
