package com.udharhisab.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "khata_settings")

/**
 * অ্যাপ প্রথমবার ইনস্টল হওয়ার পর — ফোনের সিস্টেম ভাষা অনুযায়ী ডিফল্ট ঠিক করে
 * (ফোনের ভাষা বাংলা হলে বাংলা, নাহলে ইংরেজি)। ইউজার একবার ভাষা বেছে নিলে
 * সেটা DataStore-এ সেভ হয়ে যায়, তখন এই ফাংশন আর ব্যবহার হয় না।
 */
private fun systemDefaultLanguage(): String =
    if (java.util.Locale.getDefault().language == "bn") "bn" else "en"

data class Settings(
    val pinHash: String? = null,
    val pinEnabled: Boolean = false,
    val remindersEnabled: Boolean = false,
    val reminderDays: Int = 7,
    val theme: String = "system",     // "system" | "light" | "dark"
    val language: String = systemDefaultLanguage(),
    // ⭐ নোটিফিকেশন সাব-অপশন (More পেজ → নোটিফিকেশন Sheet)
    val weeklySummaryEnabled: Boolean = false,
    val appNewsEnabled: Boolean = false,
    // ⭐ নিরাপত্তা ও প্রাইভেসি পেজ
    val fingerprintEnabled: Boolean = false,
    val lockImmediately: Boolean = false,
    // ⭐ ব্যাকআপ ও রিস্টোর পেজ — শেষ ব্যাকআপের সময়
    val lastBackupAt: Long? = null
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val REMINDERS = booleanPreferencesKey("reminders_enabled")
        val REMINDER_DAYS = intPreferencesKey("reminder_days")
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
        val REPORT_NUMBER = intPreferencesKey("pdf_report_number")
        val WEEKLY_SUMMARY = booleanPreferencesKey("weekly_summary_enabled")
        val APP_NEWS = booleanPreferencesKey("app_news_enabled")
        val FINGERPRINT = booleanPreferencesKey("fingerprint_enabled")
        val LOCK_IMMEDIATELY = booleanPreferencesKey("lock_immediately")
        val LAST_BACKUP_AT = androidx.datastore.preferences.core.longPreferencesKey("last_backup_at")
    }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            pinHash = p[Keys.PIN_HASH],
            pinEnabled = p[Keys.PIN_ENABLED] ?: false,
            remindersEnabled = p[Keys.REMINDERS] ?: false,
            reminderDays = p[Keys.REMINDER_DAYS] ?: 7,
            theme = p[Keys.THEME] ?: "system",
            language = p[Keys.LANGUAGE] ?: systemDefaultLanguage(),
            weeklySummaryEnabled = p[Keys.WEEKLY_SUMMARY] ?: false,
            appNewsEnabled = p[Keys.APP_NEWS] ?: false,
            fingerprintEnabled = p[Keys.FINGERPRINT] ?: false,
            lockImmediately = p[Keys.LOCK_IMMEDIATELY] ?: false,
            lastBackupAt = p[Keys.LAST_BACKUP_AT]
        )
    }

    /** ⭐ PDF রিপোর্ট নম্বর — প্রতিবার PDF বানানোর সময় ১ বাড়ে, নতুন নম্বরটা রিটার্ন করে */
    suspend fun nextReportNumber(): Int {
        var result = 1
        context.dataStore.edit {
            val current = it[Keys.REPORT_NUMBER] ?: 0
            result = current + 1
            it[Keys.REPORT_NUMBER] = result
        }
        return result
    }

    suspend fun setPin(hash: String) = context.dataStore.edit {
        it[Keys.PIN_HASH] = hash
        it[Keys.PIN_ENABLED] = true
    }

    suspend fun clearPin() = context.dataStore.edit {
        it.remove(Keys.PIN_HASH)
        it[Keys.PIN_ENABLED] = false
    }

    suspend fun setPinEnabled(enabled: Boolean) = context.dataStore.edit {
        it[Keys.PIN_ENABLED] = enabled
    }

    suspend fun setReminders(enabled: Boolean) = context.dataStore.edit {
        it[Keys.REMINDERS] = enabled
    }

    suspend fun setReminderDays(days: Int) = context.dataStore.edit {
        it[Keys.REMINDER_DAYS] = days
    }

    suspend fun setTheme(mode: String) = context.dataStore.edit {
        it[Keys.THEME] = mode
    }

    suspend fun setLanguage(lang: String) = context.dataStore.edit {
        it[Keys.LANGUAGE] = lang
    }

    suspend fun setWeeklySummary(enabled: Boolean) = context.dataStore.edit {
        it[Keys.WEEKLY_SUMMARY] = enabled
    }

    suspend fun setAppNews(enabled: Boolean) = context.dataStore.edit {
        it[Keys.APP_NEWS] = enabled
    }

    suspend fun setFingerprint(enabled: Boolean) = context.dataStore.edit {
        it[Keys.FINGERPRINT] = enabled
    }

    suspend fun setLockImmediately(enabled: Boolean) = context.dataStore.edit {
        it[Keys.LOCK_IMMEDIATELY] = enabled
    }

    suspend fun setLastBackupAt(time: Long) = context.dataStore.edit {
        it[Keys.LAST_BACKUP_AT] = time
    }
}
