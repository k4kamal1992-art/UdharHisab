package com.udharhisab.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.udharhisab.data.pdf.ShopBranding
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "khata_settings")

data class Settings(
    val pinHash: String? = null,
    val pinEnabled: Boolean = false,
    val remindersEnabled: Boolean = false,
    val reminderDays: Int = 7,
    val theme: String = "system",     // "system" | "light" | "dark"
    val language: String = "bn",
    // ⭐ নোটিফিকেশন সাব-অপশন (More পেজ → নোটিফিকেশন Sheet)
    val weeklySummaryEnabled: Boolean = false,
    val appNewsEnabled: Boolean = false,
    // ⭐ নিরাপত্তা ও প্রাইভেসি পেজ
    val fingerprintEnabled: Boolean = false,
    val lockImmediately: Boolean = false,
    // ⭐ দোকানদার মোড — চালু থাকলেই রিমাইন্ডার পাঠানো ও PDF-এ দোকানের নাম/লোগো/ঠিকানার অপশন আসে
    val shopkeeperMode: Boolean = false,
    val businessName: String = "",
    val businessAddress: String = "",
    val businessPhone: String = "",
    val businessLogoPath: String? = null,
    val countryCode: String = "91",
    val customerReminderPrompt: Boolean = true
) {
    /** দোকানদার মোড চালু আর দোকানের নাম দেওয়া থাকলে PDF-এর ব্র্যান্ডিং; নয়তো null */
    fun toBranding(): ShopBranding? =
        if (shopkeeperMode && businessName.isNotBlank())
            ShopBranding(businessName.trim(), businessAddress.trim(), businessPhone.trim(), businessLogoPath)
        else null
}

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val REMINDERS = booleanPreferencesKey("reminders_enabled")
        val REMINDER_DAYS = intPreferencesKey("reminder_days")
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
        val REPORT_NUMBER = intPreferencesKey("pdf_report_number")
        val WEEKLY_SUMMARY = booleanPreferencesKey("weekly_summary_enabled")
        val APP_NEWS = booleanPreferencesKey("app_news_enabled")
        val FINGERPRINT = booleanPreferencesKey("fingerprint_enabled")
        val LOCK_IMMEDIATELY = booleanPreferencesKey("lock_immediately")
        val SHOPKEEPER_MODE = booleanPreferencesKey("shopkeeper_mode")
        val BUSINESS_NAME = stringPreferencesKey("business_name")
        val BUSINESS_ADDRESS = stringPreferencesKey("business_address")
        val BUSINESS_PHONE = stringPreferencesKey("business_phone")
        val BUSINESS_LOGO = stringPreferencesKey("business_logo_path")
        val COUNTRY_CODE = stringPreferencesKey("country_code")
        val CUSTOMER_REMINDER_PROMPT = booleanPreferencesKey("customer_reminder_prompt")
    }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            pinHash = p[Keys.PIN_HASH],
            pinEnabled = p[Keys.PIN_ENABLED] ?: false,
            remindersEnabled = p[Keys.REMINDERS] ?: false,
            reminderDays = p[Keys.REMINDER_DAYS] ?: 7,
            theme = p[Keys.THEME] ?: "system",
            language = p[Keys.LANGUAGE] ?: "bn",
            weeklySummaryEnabled = p[Keys.WEEKLY_SUMMARY] ?: false,
            appNewsEnabled = p[Keys.APP_NEWS] ?: false,
            fingerprintEnabled = p[Keys.FINGERPRINT] ?: false,
            lockImmediately = p[Keys.LOCK_IMMEDIATELY] ?: false,
            shopkeeperMode = p[Keys.SHOPKEEPER_MODE] ?: false,
            businessName = p[Keys.BUSINESS_NAME] ?: "",
            businessAddress = p[Keys.BUSINESS_ADDRESS] ?: "",
            businessPhone = p[Keys.BUSINESS_PHONE] ?: "",
            businessLogoPath = p[Keys.BUSINESS_LOGO],
            countryCode = p[Keys.COUNTRY_CODE] ?: "91",
            customerReminderPrompt = p[Keys.CUSTOMER_REMINDER_PROMPT] ?: true
        )
    }

    /** ⭐ PDF রিপোর্ট নম্বর — প্রতিবার PDF বানানোর সময় ১ বাড়ে, নতুন নম্বরটা রিটার্ন করে */
    suspend fun nextReportNumber(): Int {
        var result = 1
        context.dataStore.edit {
            val current = it[Keys.REPORT_NUMBER] ?: 0
            result = current + 1
            it[Keys.REPORT_NUMBER] = result
        }
        return result
    }

    suspend fun setPin(hash: String) = context.dataStore.edit {
        it[Keys.PIN_HASH] = hash
        it[Keys.PIN_ENABLED] = true
    }

    suspend fun clearPin() = context.dataStore.edit {
        it.remove(Keys.PIN_HASH)
        it[Keys.PIN_ENABLED] = false
    }

    suspend fun setPinEnabled(enabled: Boolean) = context.dataStore.edit {
        it[Keys.PIN_ENABLED] = enabled
    }

    suspend fun setReminders(enabled: Boolean) = context.dataStore.edit {
        it[Keys.REMINDERS] = enabled
    }

    suspend fun setReminderDays(days: Int) = context.dataStore.edit {
        it[Keys.REMINDER_DAYS] = days
    }

    suspend fun setTheme(mode: String) = context.dataStore.edit {
        it[Keys.THEME] = mode
    }

    suspend fun setLanguage(lang: String) = context.dataStore.edit {
        it[Keys.LANGUAGE] = lang
    }

    suspend fun setWeeklySummary(enabled: Boolean) = context.dataStore.edit {
        it[Keys.WEEKLY_SUMMARY] = enabled
    }

    suspend fun setAppNews(enabled: Boolean) = context.dataStore.edit {
        it[Keys.APP_NEWS] = enabled
    }

    suspend fun setFingerprint(enabled: Boolean) = context.dataStore.edit {
        it[Keys.FINGERPRINT] = enabled
    }

    suspend fun setLockImmediately(enabled: Boolean) = context.dataStore.edit {
        it[Keys.LOCK_IMMEDIATELY] = enabled
    }

    // ── ⭐ দোকানদার মোড ও দোকানের প্রোফাইল ──

    suspend fun setShopkeeperMode(enabled: Boolean) = context.dataStore.edit {
        it[Keys.SHOPKEEPER_MODE] = enabled
    }

    suspend fun saveBusinessProfile(name: String, address: String, phone: String, countryCode: String) =
        context.dataStore.edit {
            it[Keys.BUSINESS_NAME] = name.trim()
            it[Keys.BUSINESS_ADDRESS] = address.trim()
            it[Keys.BUSINESS_PHONE] = phone.trim()
            it[Keys.COUNTRY_CODE] = countryCode.filter { c -> c.isDigit() }.ifEmpty { "91" }
        }

    suspend fun setBusinessLogo(path: String?) = context.dataStore.edit {
        if (path == null) it.remove(Keys.BUSINESS_LOGO) else it[Keys.BUSINESS_LOGO] = path
    }

    suspend fun setCustomerReminderPrompt(enabled: Boolean) = context.dataStore.edit {
        it[Keys.CUSTOMER_REMINDER_PROMPT] = enabled
    }
}
