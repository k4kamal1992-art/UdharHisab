package com.udharhisab.ui.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.NoteEntity
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotesViewModel(private val repo: HisabRepository) : ViewModel() {

    val search = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    private val rawNotes = search
        .flatMapLatest { q ->
            if (q.isBlank()) repo.observeNotes() else repo.searchNotes(q)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = rawNotes

    /** প্রথম DB emission না আসা পর্যন্ত true */
    @OptIn(ExperimentalCoroutinesApi::class)
    val isLoading: StateFlow<Boolean> =
        repo.observeNotes().map { false }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun setSearch(q: String) { search.value = q }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch { repo.deleteNote(note) }
    }
}
