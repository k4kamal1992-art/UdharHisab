package com.udharhisab.ui.strings

/**
 * "শপকিপার মোড" চালু থাকলে যে কয়েকটা মূল শব্দ বদলে যায় — "দোকান" এর বদলে "কাস্টমার",
 * "ধার নিলাম" এর বদলে "বাকিতে দিলাম" ইত্যাদি। ডেটা মডেল একই থাকে (এখনো "shops" টেবিলই),
 * শুধু ইউজার-ফেসিং লেখা বদলায়। AppStrings-কে আরও বড় না করে আলাদা রাখা হয়েছে।
 */
data class ShopkeeperLabels(
    val userModeSettingLabel: String,
    val userModeCustomerOption: String,
    val userModeShopkeeperOption: String,
    val userModeHint: String,
    val totalDueLabel: String,
    val thisMonthCreditLabel: String,
    val thisMonthPaymentLabel: String,
    val newShopButton: String,
    val shopNameLabel: String,
    val shopNamePlaceholder: String,
    val creditPageTitle: String,
    val paymentPageTitle: String,
    val dueLabel: String,
    val currentDueLabel: String,
    val noShopsYetTitle: String,
    val noShopsYetSubtitle: String,
    val addFirstShopButton: String,
    val searchPlaceholder: String,
    val historyFilterAllShops: String,
    val reportShopWiseTitle: String,
    val pdfShopLabel: String
)

private val bn = ShopkeeperLabels(
    userModeSettingLabel = "আমি কে",
    userModeCustomerOption = "আমি গ্রাহক (দোকানে ধার রাখি)",
    userModeShopkeeperOption = "আমি দোকানদার (কাস্টমারকে বাকি দিই)",
    userModeHint = "এটা বদলালে অ্যাপের কিছু শব্দ বদলে যাবে, ডেটা একই থাকবে",
    totalDueLabel = "মোট পাওনা আছে",
    thisMonthCreditLabel = "এ মাসে বাকি দিয়েছি",
    thisMonthPaymentLabel = "এ মাসে পেয়েছি",
    newShopButton = "নতুন কাস্টমার",
    shopNameLabel = "কাস্টমারের নাম *",
    shopNamePlaceholder = "যেমন: রহিম মিয়া",
    creditPageTitle = "বাকিতে দিন",
    paymentPageTitle = "পরিশোধ নিন",
    dueLabel = "পাওনা",
    currentDueLabel = "বর্তমান পাওনা",
    noShopsYetTitle = "এখনো কোনো কাস্টমার নেই",
    noShopsYetSubtitle = "প্রথম কাস্টমার যোগ করে খাতা শুরু করুন",
    addFirstShopButton = "প্রথম কাস্টমার যোগ করুন",
    searchPlaceholder = "কাস্টমার/ফোন খুঁজুন...",
    historyFilterAllShops = "সব কাস্টমার",
    reportShopWiseTitle = "কাস্টমারভিত্তিক পাওনা",
    pdfShopLabel = "কাস্টমার: "
)

private val en = ShopkeeperLabels(
    userModeSettingLabel = "Who am I",
    userModeCustomerOption = "I'm a customer (I owe shops)",
    userModeShopkeeperOption = "I'm a shopkeeper (customers owe me)",
    userModeHint = "Changing this swaps some wording in the app — your data stays the same",
    totalDueLabel = "Total receivable",
    thisMonthCreditLabel = "Given this month",
    thisMonthPaymentLabel = "Received this month",
    newShopButton = "New customer",
    shopNameLabel = "Customer's name *",
    shopNamePlaceholder = "e.g. Rahim Mia",
    creditPageTitle = "Give credit",
    paymentPageTitle = "Receive payment",
    dueLabel = "Receivable",
    currentDueLabel = "Current receivable",
    noShopsYetTitle = "No customers yet",
    noShopsYetSubtitle = "Add your first customer to start your ledger",
    addFirstShopButton = "Add first customer",
    searchPlaceholder = "Search customer/phone...",
    historyFilterAllShops = "All customers",
    reportShopWiseTitle = "Customer-wise receivable",
    pdfShopLabel = "Customer: "
)

private val hi = ShopkeeperLabels(
    userModeSettingLabel = "मैं कौन हूं",
    userModeCustomerOption = "मैं ग्राहक हूं (दुकानों का उधार देता हूं)",
    userModeShopkeeperOption = "मैं दुकानदार हूं (ग्राहक मुझे उधार देते हैं)",
    userModeHint = "यह बदलने पर ऐप के कुछ शब्द बदल जाएंगे, डेटा वही रहेगा",
    totalDueLabel = "कुल पावना",
    thisMonthCreditLabel = "इस महीने दिया गया उधार",
    thisMonthPaymentLabel = "इस महीने मिला",
    newShopButton = "नया ग्राहक",
    shopNameLabel = "ग्राहक का नाम *",
    shopNamePlaceholder = "जैसे: रहीम मिया",
    creditPageTitle = "उधार दें",
    paymentPageTitle = "भुगतान प्राप्त करें",
    dueLabel = "पावना",
    currentDueLabel = "मौजूदा पावना",
    noShopsYetTitle = "अभी कोई ग्राहक नहीं",
    noShopsYetSubtitle = "अपना खाता शुरू करने के लिए पहला ग्राहक जोड़ें",
    addFirstShopButton = "पहला ग्राहक जोड़ें",
    searchPlaceholder = "ग्राहक/फ़ोन खोजें...",
    historyFilterAllShops = "सभी ग्राहक",
    reportShopWiseTitle = "ग्राहक अनुसार पावना",
    pdfShopLabel = "ग्राहक: "
)

fun shopkeeperLabelsFor(languageCode: String): ShopkeeperLabels = when (languageCode) {
    "en" -> en
    "hi" -> hi
    else -> bn
}
