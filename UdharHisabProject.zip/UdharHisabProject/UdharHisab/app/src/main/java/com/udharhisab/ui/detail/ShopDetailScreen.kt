package com.udharhisab.ui.detail

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.pdf.KhataPdfGenerator
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.entry.EntryBottomSheet
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopDetailScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit
) {
    val vm: ShopDetailViewModel = viewModel {
        ShopDetailViewModel(container.repo, shopId)
    }
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val shop by vm.shop.collectAsState()
    val txns by vm.txns.collectAsState()
    val balance by vm.balance.collectAsState()
    val lastDeleted by vm.lastDeletedTxnId.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var showSheet by remember { mutableStateOf(false) }
    var sheetType by remember { mutableStateOf(TransactionEntity.TYPE_CREDIT) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val s = shop
    if (s == null) {
        // লোড হচ্ছে
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val isWood = ShopType.fromKey(s.shopType) == ShopType.WOOD

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "ফিরে যান")
                    }
                },
                actions = {
                    // PDF এক্সপোর্ট
                    IconButton(onClick = {
                        scope.launch {
                            try {
                                val file = KhataPdfGenerator(context)
                                    .generate(s, vm.txns.value)
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    file
                                )
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(
                                    Intent.createChooser(intent, "খাতা শেয়ার করুন")
                                )
                            } catch (e: Exception) {
                                snackbar.showSnackbar("PDF তৈরি ব্যর্থ: ${e.message}")
                            }
                        }
                    }) {
                        Icon(Icons.Default.PictureAsPdf, "PDF এক্সপোর্ট")
                    }
                    // আর্কাইভ
                    IconButton(onClick = { vm.archiveShop { onBack() } }) {
                        Icon(Icons.Default.Archive, "আর্কাইভ")
                    }
                }
            )
        },
        bottomBar = {
            // ⭐ নিচে দুই বড় বাটন
            Surface(shadowElevation = 8.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            sheetType = TransactionEntity.TYPE_CREDIT
                            showSheet = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = c.Danger),
                        modifier = Modifier.weight(1f)
                    ) { Text("🔴 ধার নিলাম") }

                    Button(
                        onClick = {
                            sheetType = TransactionEntity.TYPE_PAYMENT
                            showSheet = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                        modifier = Modifier.weight(1f)
                    ) { Text("🟢 জমা দিলাম") }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // ── হিরো: বর্তমান বাকি ──
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (balance > 0) c.Danger else c.Success
                    ),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            if (balance > 0) "বাকি আছে" else "🎉 পরিশোধিত",
                            style = MaterialTheme.typography.displaySmall,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                        )
                        Text(
                            UnitConverter.rupees(if (balance > 0) balance else 0.0),
                            style = MaterialTheme.typography.displayLarge,
                            color = androidx.compose.ui.graphics.Color.White
                        )
                        s.phone?.let {
                            Text("📞 $it", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f))
                        }
                    }
                }
            }

            // ── লেনদেন লিস্ট ──
            if (txns.isEmpty()) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("📝", style = MaterialTheme.typography.displayLarge)
                        Text("এখনো কোনো লেনদেন নেই",
                            style = MaterialTheme.typography.bodyLarge, color = c.Muted)
                    }
                }
            } else {
                items(txns, key = { it.id }) { t ->
                    TxnRow(
                        txn = t,
                        onDelete = { vm.deleteTxn(t.id) }
                    )
                }
            }
        }
    }

    // ── আনডু Snackbar ──
    LaunchedEffect(lastDeleted) {
        if (lastDeleted != null) {
            val result = snackbar.showSnackbar(
                message = "লেনদেন মুছে ফেলা হয়েছে",
                actionLabel = "আনডু",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) vm.undoDelete()
            else vm.lastDeletedTxnId.value = null
        }
    }

    // ── এন্ট্রি শিট ──
    if (showSheet) {
        EntryBottomSheet(
            initialType = sheetType,
            isWoodShop = isWood,
            onDismiss = { showSheet = false }
        ) { entryVm, onDone ->
            entryVm.onInsert = { txn -> vm.addTxn(txn) { } }
            entryVm.save(shopId, onDone)
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("দোকান আর্কাইভ করবেন?") },
            text = { Text("আর্কাইভ করলে হোম লিস্ট থেকে সরে যাবে — হিস্ট্রিতে পাবেন।") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    vm.archiveShop { onBack() }
                }) { Text("আর্কাইভ") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
private fun TxnRow(txn: TransactionEntity, onDelete: () -> Unit) {
    val c = LocalKhataColors.current
    val isCredit = txn.type == TransactionEntity.TYPE_CREDIT

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    txn.productName ?: if (isCredit) "ধার" else "জমা",
                    style = MaterialTheme.typography.titleMedium
                )
                val details = buildString {
                    append(UnitConverter.dateShort(txn.date))
                    if (txn.quantity != null && txn.unit != null) {
                        append(" • ${UnitConverter.amountInput(txn.quantity!!)} ${txn.unit}")
                        txn.unitPrice?.let { append(" × ${UnitConverter.amountInput(it)}") }
                    }
                    txn.paymentMethod?.let { append(" • $it") }
                    txn.note?.let { append(" • $it") }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(txn.amount),
                style = MaterialTheme.typography.titleMedium,
                color = if (isCredit) c.Danger else c.Success
            )
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete, "মুছুন",
                    tint = c.Muted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
