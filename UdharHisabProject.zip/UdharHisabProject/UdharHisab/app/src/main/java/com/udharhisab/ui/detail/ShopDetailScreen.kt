package com.udharhisab.ui.detail

import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import com.udharhisab.ui.components.LedgerIllustration
import com.udharhisab.ui.components.rememberCountUp
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithItems
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.pdf.buildPdf
import com.udharhisab.ui.pdf.rememberPdfOutput
import com.udharhisab.ui.reminder.ReminderDialog
import com.udharhisab.domain.PaymentReminder
import com.udharhisab.domain.ReminderKind
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.automirrored.filled.Send
import com.udharhisab.ui.theme.LocalShopkeeperLabels
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ShopDetailScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onOpenCredit: () -> Unit,
    onOpenPayment: () -> Unit,
    /** ⭐ ধার/জমা সেভ করে ফিরলে "credit"/"payment"; নাহলে null */
    justSavedKind: String? = null,
    onSavedPromptHandled: () -> Unit = {}
) {
    val vm: ShopDetailViewModel = viewModel {
        ShopDetailViewModel(container.repo, shopId)
    }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val shop by vm.shop.collectAsState()
    val txns by vm.txns.collectAsState()
    val balance by vm.balance.collectAsState()
    val shownBalance = rememberCountUp(if (balance > 0) balance else 0.0)
    val lastDeleted by vm.lastDeletedTxnId.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var showPermanentDeleteDialog by remember { mutableStateOf(false) }
    var showMoveDialog by remember { mutableStateOf(false) }
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())

    // ⭐ দোকানদার (আমি কে → দোকানদার) হলে রিমাইন্ডার অপশন
    val settingsState by container.store.settings.collectAsState(initial = null)
    val shopkeeper = settingsState?.isShopkeeper == true
    var reminderDraft by remember { mutableStateOf<String?>(null) }

    val pdfOutput = rememberPdfOutput { ok ->
        scope.launch { snackbar.showSnackbar(if (ok) s.pdfSavedMessage else s.pdfSaveFailed) }
    }

    fun openReminder(kind: ReminderKind) {
        val cfg = settingsState ?: return
        val sh = shop ?: return
        scope.launch {
            val due = container.repo.balanceOnce(shopId)
            reminderDraft = PaymentReminder.buildMessage(s, cfg.businessName, sh.name, due, kind)
        }
    }

    // ধার/জমা সেভ হয়ে ফিরলে — ব্যালেন্স রিফ্রেশ, আর দোকানদার হলে (ফোন নম্বর থাকলে) রিমাইন্ডার অপশন
    LaunchedEffect(justSavedKind, settingsState, shop) {
        val kind = justSavedKind ?: return@LaunchedEffect
        val cfg = settingsState ?: return@LaunchedEffect
        val sh = shop ?: return@LaunchedEffect
        vm.refreshBalance()
        if (cfg.isShopkeeper && cfg.customerReminderPrompt && !sh.phone.isNullOrBlank()) {
            val due = container.repo.balanceOnce(shopId)
            reminderDraft = PaymentReminder.buildMessage(
                s, cfg.businessName, sh.name, due,
                if (kind == "payment") ReminderKind.PAYMENT_RECEIVED else ReminderKind.CREDIT_ADDED
            )
        }
        onSavedPromptHandled()
    }

    val shopVal = shop
    if (shopVal == null) {
        // লোড হচ্ছে — হিরো কার্ড + কয়েকটা সারির স্কেলেটন
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Spacer(Modifier.height(40.dp))
            com.udharhisab.ui.components.SkeletonHeroCard()
            Spacer(Modifier.height(16.dp))
            com.udharhisab.ui.components.SkeletonList(count = 3)
        }
        return
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(shopVal.name) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                actions = {
                    // PDF এক্সপোর্ট
                    IconButton(onClick = { showPdfDialog = true }) {
                        Icon(Icons.Default.PictureAsPdf, s.pdfExport)
                    }
                    // ⭐ অন্য তালিকায় সরান (গ্রাহক ↔ দোকানদার)
                    IconButton(onClick = { showMoveDialog = true }) {
                        Icon(Icons.Default.SwapHoriz, s.moveShopAction)
                    }
                    // আর্কাইভ
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Archive, s.archive)
                    }
                    // ⭐ পার্মানেন্ট ডিলিট
                    IconButton(onClick = { showPermanentDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, s.deleteShopAction)
                    }
                }
            )
        },
        bottomBar = {
            // ⭐ এখন দুটো বাটনই আলাদা পূর্ণ-স্ক্রিন পেজ খোলে (আগের মতো এক শিটে দুটো অপশন না)
            Surface(
                shadowElevation = 12.dp,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenCredit,
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Danger),
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Default.ArrowUpward, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(sk?.creditButton ?: s.creditButton, fontWeight = FontWeight.ExtraBold)
                    }

                    Button(
                        onClick = onOpenPayment,
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) {
                        Icon(Icons.Default.ArrowDownward, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(sk?.paymentButton ?: s.paymentButton, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // ── হিরো: বর্তমান বাকি ──
            item {
                // ⭐ বাকি থাকলে উষ্ণ কমলা-লাল গ্রেডিয়েন্ট, শোধ হলে সবুজ — এক নজরে অবস্থা বোঝা যায়
                val heroBrush = if (balance > 0)
                    Brush.linearGradient(listOf(androidx.compose.ui.graphics.Color(0xFFFF8A65), c.Danger))
                else Brush.linearGradient(listOf(c.Primary, c.Accent))
                val heroGlow = if (balance > 0) c.Danger else c.Primary
                Box(
                    Modifier
                        .fillMaxWidth()
                        .shadow(10.dp, RoundedCornerShape(28.dp), ambientColor = heroGlow, spotColor = heroGlow)
                        .clip(RoundedCornerShape(28.dp))
                        .background(heroBrush)
                ) {
                    Canvas(Modifier.matchParentSize()) {
                        drawCircle(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.12f), size.height * 0.8f, Offset(size.width * 0.95f, size.height * 0.0f))
                        drawCircle(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.08f), size.height * 0.45f, Offset(size.width * 0.75f, size.height * 1.05f))
                        drawCircle(androidx.compose.ui.graphics.Color(0xFFFFC857), size.height * 0.03f, Offset(size.width * 0.88f, size.height * 0.34f))
                    }
                    Column(Modifier.padding(20.dp)) {
                        if (balance > 0) {
                            Text(
                                s.dueLabel,
                                style = MaterialTheme.typography.displaySmall,
                                color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    s.settledLabel,
                                    style = MaterialTheme.typography.displaySmall,
                                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }
                        Text(
                            UnitConverter.rupees(shownBalance),
                            style = MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = androidx.compose.ui.graphics.Color.White
                        )
                        shopVal.phone?.let {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(it, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f))
                            }
                        }
                        // ⭐ শুধু দোকানদারের জন্য: গ্রাহককে বাকির রিমাইন্ডার
                        if (shopkeeper && balance > 0) {
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = { openReminder(ReminderKind.DUE) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = androidx.compose.ui.graphics.Color.White
                                ),
                                border = BorderStroke(1.dp, androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f))
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(s.reminderSendAction)
                            }
                        }
                    }
                }
            }

            // ── লেনদেন লিস্ট ──
            if (txns.isEmpty()) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LedgerIllustration()
                        Spacer(Modifier.height(8.dp))
                        Text(s.noTransactionsYet,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold, color = c.Muted)
                    }
                }
            } else {
                items(txns, key = { it.txn.id }) { tw ->
                    TxnRow(
                        tw = tw,
                        onDelete = { vm.deleteTxn(tw.txn.id) },
                        modifier = Modifier.animateItemPlacement()
                    )
                }
            }
        }
    }

    // ── আনডু Snackbar ──
    LaunchedEffect(lastDeleted) {
        if (lastDeleted != null) {
            val result = snackbar.showSnackbar(
                message = s.txnDeletedSnackbar,
                actionLabel = s.undo,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) vm.undoDelete()
            else vm.lastDeletedTxnId.value = null
        }
    }

    if (showDeleteDialog) {
        com.udharhisab.ui.components.FriendlyConfirmDialog(
            title = s.archiveConfirmTitle,
            message = s.archiveConfirmText,
            icon = androidx.compose.material.icons.Icons.Default.Archive,
            confirmLabel = s.yesArchive,
            dismissLabel = s.cancel,
            onConfirm = {
                showDeleteDialog = false
                vm.archiveShop { onBack() }
            },
            onDismiss = { showDeleteDialog = false }
        )
    }

    if (showPermanentDeleteDialog) {
        com.udharhisab.ui.components.FriendlyConfirmDialog(
            title = s.deleteConfirmTitle,
            message = s.deleteConfirmText,
            icon = androidx.compose.material.icons.Icons.Default.Delete,
            danger = true,
            confirmLabel = s.yesDelete,
            dismissLabel = s.cancel,
            onConfirm = {
                showPermanentDeleteDialog = false
                vm.deleteShop { onBack() }
            },
            onDismiss = { showPermanentDeleteDialog = false }
        )
    }

    if (showMoveDialog) {
        val toShopkeeper = !shopkeeper
        com.udharhisab.ui.components.FriendlyConfirmDialog(
            title = s.moveShopTitle,
            message = if (toShopkeeper) s.moveToShopkeeperMsg else s.moveToCustomerMsg,
            icon = Icons.Default.SwapHoriz,
            confirmLabel = s.moveShopConfirm,
            dismissLabel = s.cancel,
            onConfirm = {
                showMoveDialog = false
                scope.launch {
                    container.repo.moveShopToOtherMode(shopId)
                    onBack()
                }
            },
            onDismiss = { showMoveDialog = false }
        )
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = shopId,
            shopkeeperMode = shopkeeper,
            brandingAvailable = settingsState?.toBranding() != null,
            onDismiss = { showPdfDialog = false },
            onGenerate = { req ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val file = buildPdf(context, container, s, req)
                        pdfOutput.deliver(file, req.action, s.shareKhata)
                        (context as? android.app.Activity)?.let { com.udharhisab.ads.AdManager.maybeShowInterstitialAfterExport(it) }
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }

    // ── ⭐ গ্রাহককে WhatsApp / SMS-এ জানানো ──
    reminderDraft?.let { draft ->
        val cc = settingsState?.countryCode ?: "91"
        ReminderDialog(
            initialMessage = draft,
            onWhatsApp = { msg ->
                when {
                    shopVal.phone.isNullOrBlank() ->
                        scope.launch { snackbar.showSnackbar(s.reminderNoPhone) }
                    !PaymentReminder.sendWhatsApp(context, shopVal.phone, cc, msg) ->
                        scope.launch { snackbar.showSnackbar(s.reminderAppMissing) }
                    else -> reminderDraft = null
                }
            },
            onSms = { msg ->
                if (PaymentReminder.sendSms(context, shopVal.phone, cc, msg)) reminderDraft = null
                else scope.launch { snackbar.showSnackbar(s.reminderAppMissing) }
            },
            onDismiss = { reminderDraft = null }
        )
    }
}

@Composable
private fun TxnRow(tw: TransactionWithItems, onDelete: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val txn = tw.txn
    val isCredit = txn.type == TransactionEntity.TYPE_CREDIT
    val hasItems = tw.items.isNotEmpty()
    var showDetail by remember { mutableStateOf(false) }

    val tone = if (isCredit) c.Danger else c.Success
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier
            .fillMaxWidth()
            .let { if (hasItems) it.clickable { showDetail = true } else it }
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            // ⭐ রঙিন দিক-চিহ্ন: বাকি = ওপরে তীর (লাল), পরিশোধ = নিচে তীর (সবুজ)
            Box(
                Modifier.size(42.dp).background(tone.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isCredit) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null, tint = tone, modifier = Modifier.size(20.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        hasItems -> "${tw.items.size} ${s.itemsCountSuffix}"
                        isCredit -> sk?.creditFallback ?: s.creditFallback
                        else -> sk?.paymentFallback ?: s.paymentFallback
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                val details = buildString {
                    append(UnitConverter.dateShort(txn.date, s.code))
                    if (hasItems) {
                        append(" • " + tw.items.joinToString(", ") {
                            DefaultProducts.translateIfDefault(it.productName, s.code).ifBlank { sk?.creditFallback ?: s.creditFallback }
                        })
                    }
                    txn.paymentMethod?.let { append(" • $it") }
                    txn.note?.let { append(" • $it") }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(txn.amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = tone
            )
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete, s.deleteTxnAction,
                    tint = c.Muted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }

    if (showDetail) {
        com.udharhisab.ui.components.FriendlyDialog(
            title = if (isCredit) (sk?.creditButton ?: s.creditButton) else (sk?.paymentButton ?: s.paymentButton),
            icon = androidx.compose.material.icons.Icons.Default.Receipt,
            onDismiss = { showDetail = false },
            footer = {
                Button(
                    onClick = { showDetail = false },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text(s.cancel, fontWeight = FontWeight.ExtraBold) }
            }
        ) {
            tw.items.forEach { itm ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            DefaultProducts.translateIfDefault(itm.productName, s.code).ifBlank { sk?.creditFallback ?: s.creditFallback },
                            fontWeight = FontWeight.Bold
                        )
                        if (itm.quantity != null && itm.unit != null) {
                            Text(
                                "${UnitConverter.amountInput(itm.quantity!!)} ${itm.unit} × ${itm.unitPrice?.let { UnitConverter.amountInput(it) } ?: ""}",
                                style = MaterialTheme.typography.bodySmall, color = c.Muted
                            )
                        }
                    }
                    Text(UnitConverter.rupees(itm.amount), fontWeight = FontWeight.ExtraBold, color = if (isCredit) c.Danger else c.Success)
                }
                Spacer(Modifier.height(10.dp))
            }
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(s.totalPrefix, style = MaterialTheme.typography.titleMedium)
                Text(
                    UnitConverter.rupees(txn.amount),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isCredit) c.Danger else c.Success
                )
            }
        }
    }
}
