package com.udharhisab.ui.detail

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithItems
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.pdf.buildPdf
import com.udharhisab.ui.pdf.rememberPdfOutput
import com.udharhisab.ui.reminder.ReminderDialog
import com.udharhisab.domain.PaymentReminder
import com.udharhisab.domain.ReminderKind
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.automirrored.filled.Send
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopDetailScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onOpenCredit: () -> Unit,
    onOpenPayment: () -> Unit,
    /** ⭐ ধার/জমা সেভ করে ফিরলে "credit"/"payment"; নাহলে null */
    justSavedKind: String? = null,
    onSavedPromptHandled: () -> Unit = {}
) {
    val vm: ShopDetailViewModel = viewModel {
        ShopDetailViewModel(container.repo, shopId)
    }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val shop by vm.shop.collectAsState()
    val txns by vm.txns.collectAsState()
    val balance by vm.balance.collectAsState()
    val lastDeleted by vm.lastDeletedTxnId.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var showPermanentDeleteDialog by remember { mutableStateOf(false) }
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())

    // ⭐ দোকানদার মোড / রিমাইন্ডার
    val settingsState by container.store.settings.collectAsState(initial = null)
    val shopkeeper = settingsState?.shopkeeperMode == true
    var reminderDraft by remember { mutableStateOf<String?>(null) }

    val pdfOutput = rememberPdfOutput { ok ->
        scope.launch { snackbar.showSnackbar(if (ok) s.pdfSavedMessage else s.pdfSaveFailed) }
    }

    fun openReminder(kind: ReminderKind) {
        val cfg = settingsState ?: return
        val sh = shop ?: return
        scope.launch {
            val due = container.repo.balanceOnce(shopId)
            reminderDraft = PaymentReminder.buildMessage(s, cfg.businessName, sh.name, due, kind)
        }
    }

    // ধার/জমা সেভ হয়ে ফিরলে — ব্যালেন্স রিফ্রেশ করি, আর দোকানদার মোডে (ফোন নম্বর থাকলে) রিমাইন্ডার অপশন দেখাই
    LaunchedEffect(justSavedKind, settingsState, shop) {
        val kind = justSavedKind ?: return@LaunchedEffect
        val cfg = settingsState ?: return@LaunchedEffect
        val sh = shop ?: return@LaunchedEffect
        vm.refreshBalance()
        if (cfg.shopkeeperMode && cfg.customerReminderPrompt && !sh.phone.isNullOrBlank()) {
            val due = container.repo.balanceOnce(shopId)
            reminderDraft = PaymentReminder.buildMessage(
                s, cfg.businessName, sh.name, due,
                if (kind == "payment") ReminderKind.PAYMENT_RECEIVED else ReminderKind.CREDIT_ADDED
            )
        }
        onSavedPromptHandled()
    }

    val shopVal = shop
    if (shopVal == null) {
        // লোড হচ্ছে
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(shopVal.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                actions = {
                    // PDF এক্সপোর্ট
                    IconButton(onClick = { showPdfDialog = true }) {
                        Icon(Icons.Default.PictureAsPdf, s.pdfExport)
                    }
                    // আর্কাইভ
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Archive, s.archive)
                    }
                    // ⭐ পার্মানেন্ট ডিলিট
                    IconButton(onClick = { showPermanentDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, s.deleteShopAction)
                    }
                }
            )
        },
        bottomBar = {
            // ⭐ এখন দুটো বাটনই আলাদা পূর্ণ-স্ক্রিন পেজ খোলে (আগের মতো এক শিটে দুটো অপশন না)
            Surface(shadowElevation = 8.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenCredit,
                        colors = ButtonDefaults.buttonColors(containerColor = c.Danger),
                        modifier = Modifier.weight(1f)
                    ) { Text(s.creditButton) }

                    Button(
                        onClick = onOpenPayment,
                        colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                        modifier = Modifier.weight(1f)
                    ) { Text(s.paymentButton) }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // ── হিরো: বর্তমান বাকি ──
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (balance > 0) c.Danger else c.Success
                    ),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            if (balance > 0) s.dueLabel else "🎉 ${s.settledLabel}",
                            style = MaterialTheme.typography.displaySmall,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                        )
                        Text(
                            UnitConverter.rupees(if (balance > 0) balance else 0.0),
                            style = MaterialTheme.typography.displayLarge,
                            color = androidx.compose.ui.graphics.Color.White
                        )
                        shopVal.phone?.let {
                            Text("📞 $it", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f))
                        }
                        // ⭐ শুধু দোকানদার মোডে: গ্রাহককে বাকির রিমাইন্ডার
                        if (shopkeeper && balance > 0) {
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = { openReminder(ReminderKind.DUE) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = androidx.compose.ui.graphics.Color.White
                                ),
                                border = BorderStroke(1.dp, androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f))
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(s.reminderSendAction)
                            }
                        }
                    }
                }
            }

            // ── লেনদেন লিস্ট ──
            if (txns.isEmpty()) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("📝", style = MaterialTheme.typography.displayLarge)
                        Text(s.noTransactionsYet,
                            style = MaterialTheme.typography.bodyLarge, color = c.Muted)
                    }
                }
            } else {
                items(txns, key = { it.txn.id }) { tw ->
                    TxnRow(
                        tw = tw,
                        onDelete = { vm.deleteTxn(tw.txn.id) }
                    )
                }
            }
        }
    }

    // ── আনডু Snackbar ──
    LaunchedEffect(lastDeleted) {
        if (lastDeleted != null) {
            val result = snackbar.showSnackbar(
                message = s.txnDeletedSnackbar,
                actionLabel = s.undo,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) vm.undoDelete()
            else vm.lastDeletedTxnId.value = null
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(s.archiveConfirmTitle) },
            text = { Text(s.archiveConfirmText) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    vm.archiveShop { onBack() }
                }) { Text(s.yesArchive) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text(s.cancel) }
            }
        )
    }

    if (showPermanentDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showPermanentDeleteDialog = false },
            title = { Text(s.deleteConfirmTitle) },
            text = { Text(s.deleteConfirmText) },
            confirmButton = {
                TextButton(onClick = {
                    showPermanentDeleteDialog = false
                    vm.deleteShop { onBack() }
                }) { Text(s.yesDelete) }
            },
            dismissButton = {
                TextButton(onClick = { showPermanentDeleteDialog = false }) { Text(s.cancel) }
            }
        )
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = shopId,
            shopkeeperMode = shopkeeper,
            brandingAvailable = settingsState?.toBranding() != null,
            onDismiss = { showPdfDialog = false },
            onGenerate = { req ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val file = buildPdf(context, container, s, req)
                        pdfOutput.deliver(file, req.action, s.shareKhata)
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }

    // ── ⭐ গ্রাহককে WhatsApp / SMS-এ জানানো ──
    reminderDraft?.let { draft ->
        val cc = settingsState?.countryCode ?: "91"
        ReminderDialog(
            initialMessage = draft,
            onWhatsApp = { msg ->
                when {
                    shopVal.phone.isNullOrBlank() ->
                        scope.launch { snackbar.showSnackbar(s.reminderNoPhone) }
                    !PaymentReminder.sendWhatsApp(context, shopVal.phone, cc, msg) ->
                        scope.launch { snackbar.showSnackbar(s.reminderAppMissing) }
                    else -> reminderDraft = null
                }
            },
            onSms = { msg ->
                if (PaymentReminder.sendSms(context, shopVal.phone, cc, msg)) reminderDraft = null
                else scope.launch { snackbar.showSnackbar(s.reminderAppMissing) }
            },
            onDismiss = { reminderDraft = null }
        )
    }
}

@Composable
private fun TxnRow(tw: TransactionWithItems, onDelete: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val txn = tw.txn
    val isCredit = txn.type == TransactionEntity.TYPE_CREDIT
    val hasItems = tw.items.isNotEmpty()
    var showDetail by remember { mutableStateOf(false) }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .let { if (hasItems) it.clickable { showDetail = true } else it }
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        hasItems -> "${tw.items.size} ${s.itemsCountSuffix}"
                        isCredit -> s.creditFallback
                        else -> s.paymentFallback
                    },
                    style = MaterialTheme.typography.titleMedium
                )
                val details = buildString {
                    append(UnitConverter.dateShort(txn.date, s.code))
                    if (hasItems) {
                        append(" • " + tw.items.joinToString(", ") {
                            DefaultProducts.translateIfDefault(it.productName, s.code).ifBlank { s.creditFallback }
                        })
                    }
                    txn.paymentMethod?.let { append(" • $it") }
                    txn.note?.let { append(" • $it") }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(txn.amount),
                style = MaterialTheme.typography.titleMedium,
                color = if (isCredit) c.Danger else c.Success
            )
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete, s.deleteTxnAction,
                    tint = c.Muted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }

    if (showDetail) {
        AlertDialog(
            onDismissRequest = { showDetail = false },
            title = { Text(if (isCredit) s.creditButton else s.paymentButton) },
            text = {
                Column {
                    tw.items.forEach { itm ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(DefaultProducts.translateIfDefault(itm.productName, s.code).ifBlank { s.creditFallback })
                                if (itm.quantity != null && itm.unit != null) {
                                    Text(
                                        "${UnitConverter.amountInput(itm.quantity!!)} ${itm.unit} × ${itm.unitPrice?.let { UnitConverter.amountInput(it) } ?: ""}",
                                        style = MaterialTheme.typography.bodySmall, color = c.Muted
                                    )
                                }
                            }
                            Text(UnitConverter.rupees(itm.amount))
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    HorizontalDivider()
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.totalPrefix, style = MaterialTheme.typography.titleMedium)
                        Text(UnitConverter.rupees(txn.amount), style = MaterialTheme.typography.titleMedium)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetail = false }) { Text(s.cancel) }
            }
        )
    }
}
