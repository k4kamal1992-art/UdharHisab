package com.udharhisab.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.udharhisab.domain.UnitConverter

/**
 * ✨ "বেন্টো" টাইল — হোম ও রিপোর্ট পেজের একই রঙিন গ্রেডিয়েন্ট ভাষা।
 * (রিপোর্ট পেজের নিজস্ব কপি আগে থেকেই আছে; হোম পেজ এগুলো ব্যবহার করে।)
 */
object BentoBrush {
    val Hero = listOf(Color(0xFF087F5B), Color(0xFF14B8A6), Color(0xFF38BDF8))
    val Credit = listOf(Color(0xFFFF8A65), Color(0xFFFB5C7C))
    val Payment = listOf(Color(0xFF14B8A6), Color(0xFF34D399))
    val Count = listOf(Color(0xFFA78BFA), Color(0xFF6A8DFF))
}

fun Modifier.bentoShadow(color: Color, radius: Int, elevation: Int = 10): Modifier =
    this.shadow(elevation.dp, RoundedCornerShape(radius.dp), ambientColor = color, spotColor = color)

/** বড় হিরো: বাঁয়ে লেবেল + গুনে বাড়া অঙ্ক + ব্যাজ, ডানে অগ্রগতির রিং */
@Composable
fun BentoHero(dueLabel: String, due: Double, progress: Float, badge: String, modifier: Modifier = Modifier) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(progress) { anim.animateTo(progress.coerceIn(0f, 1f), tween(1100, easing = FastOutSlowInEasing)) }
    val shown = rememberCountUp(due)

    Box(
        modifier
            .fillMaxWidth()
            .bentoShadow(BentoBrush.Hero[1], 30, 14)
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(BentoBrush.Hero))
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.12f), size.height * 0.85f, Offset(size.width * 1.0f, size.height * 0.0f))
            drawCircle(Color.White.copy(alpha = 0.08f), size.height * 0.5f, Offset(size.width * 0.35f, size.height * 1.15f))
            drawCircle(Friendly.Sun, size.height * 0.03f, Offset(size.width * 0.62f, size.height * 0.2f))
            drawCircle(Friendly.Rose.copy(alpha = 0.9f), size.height * 0.022f, Offset(size.width * 0.52f, size.height * 0.82f))
        }
        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dueLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color.White.copy(alpha = 0.9f))
                Spacer(Modifier.height(2.dp))
                Text(
                    UnitConverter.rupees(shown),
                    style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1
                )
                Spacer(Modifier.height(10.dp))
                Box(Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text(badge, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.White)
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = size.minDimension * 0.14f
                    val pad = stroke / 2f
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(Color.White.copy(alpha = 0.25f), 0f, 360f, false, Offset(pad, pad), arcSize, style = Stroke(stroke))
                    drawArc(Color.White, -90f, 360f * anim.value, false, Offset(pad, pad), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Text("${(progress.coerceIn(0f, 1f) * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}

/** রঙিন গ্রেডিয়েন্ট স্ট্যাট-টাইল: আইকন, লেবেল, গুনে বাড়া অঙ্ক, নিচে ভাগ-দেখানো বার */
@Composable
fun BentoTile(
    modifier: Modifier, brush: List<Color>, icon: ImageVector, label: String, amount: Double, share: Float
) {
    val grow = remember { Animatable(0f) }
    LaunchedEffect(share) { grow.snapTo(0f); grow.animateTo(share.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing)) }
    val shown = rememberCountUp(amount)
    Box(
        modifier
            .bentoShadow(brush[0], 24, 10)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(brush))
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.15f), size.height * 0.55f, Offset(size.width * 1.0f, size.height * 0.0f))
        }
        Column(Modifier.padding(16.dp)) {
            Box(Modifier.size(34.dp).background(Color.White.copy(alpha = 0.25f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.92f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.weight(1f))
            Text(UnitConverter.rupees(shown), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.28f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(fraction = grow.value).clip(RoundedCornerShape(4.dp)).background(Color.White))
            }
        }
    }
}

/** চওড়া বেগুনি টাইল — দুটো সংখ্যা পাশাপাশি (যেমন "3 পরিশোধিত | 2 বাকি") */
@Composable
fun BentoDualCount(leftNumber: Int, leftLabel: String, rightNumber: Int, rightLabel: String, modifier: Modifier = Modifier) {
    val l = rememberCountUp(leftNumber.toDouble())
    val r = rememberCountUp(rightNumber.toDouble())
    Row(
        modifier
            .fillMaxWidth()
            .bentoShadow(BentoBrush.Count[0], 24, 8)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(BentoBrush.Count))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(l.toInt().toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(leftLabel, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.92f), maxLines = 1)
        }
        Box(Modifier.width(1.dp).height(40.dp).background(Color.White.copy(alpha = 0.4f)))
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(r.toInt().toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(rightLabel, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.92f), maxLines = 1)
        }
    }
}
