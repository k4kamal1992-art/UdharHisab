package com.udharhisab.ui.history

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ বটম-ন্যাভের "History" ট্যাব — সব দোকানের সব লেনদেন এক জায়গায়,
 * দোকান আর ধার/পরিশোধ অনুযায়ী ফিল্টার করা যায়। আর্কাইভ/পরিশোধিত দোকানের
 * পুরনো লিস্টটা এখন টপ বারের আইকন থেকে আলাদাভাবে দেখা যায়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit,
    onOpenArchived: () -> Unit
) {
    val vm: TransactionHistoryViewModel = viewModel { TransactionHistoryViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val txns by vm.filtered.collectAsState()
    val shopFilter by vm.shopFilter.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val availableShops by vm.availableShops.collectAsState()

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.history) },
                actions = {
                    IconButton(onClick = onOpenArchived) {
                        Icon(Icons.Default.Archive, s.viewArchivedAction)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // ── ধার/পরিশোধ ফিল্টার ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { vm.setTypeFilter(null) },
                    label = { Text(s.historyFilterAllTypes) }
                )
                FilterChip(
                    selected = typeFilter == TransactionEntity.TYPE_CREDIT,
                    onClick = { vm.setTypeFilter(TransactionEntity.TYPE_CREDIT) },
                    label = { Text(s.historyFilterCreditOnly) }
                )
                FilterChip(
                    selected = typeFilter == TransactionEntity.TYPE_PAYMENT,
                    onClick = { vm.setTypeFilter(TransactionEntity.TYPE_PAYMENT) },
                    label = { Text(s.historyFilterPaymentOnly) }
                )
            }

            Spacer(Modifier.height(8.dp))

            // ── দোকান ফিল্টার ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                FilterChip(
                    selected = shopFilter == null,
                    onClick = { vm.setShopFilter(null) },
                    label = { Text(s.historyFilterAllShops) }
                )
                availableShops.forEach { (shopId, shopName) ->
                    FilterChip(
                        selected = shopFilter == shopId,
                        onClick = { vm.setShopFilter(if (shopFilter == shopId) null else shopId) },
                        label = { Text(shopName) }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            if (txns.isEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🧾", style = MaterialTheme.typography.displayLarge)
                    Text(s.historyNoTxnsFound, color = c.Muted)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(txns, key = { it.txn.id }) { tws ->
                        TxnHistoryRow(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) })
                    }
                }
            }
        }
    }
}

@Composable
private fun TxnHistoryRow(tws: TransactionWithShop, langCode: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val t = tws.txn
    val isCredit = t.type == TransactionEntity.TYPE_CREDIT

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleMedium)
                val details = buildString {
                    append(UnitConverter.dateShort(t.date, langCode))
                    (t.productName ?: if (isCredit) s.creditFallback else s.paymentFallback).let {
                        append(" • $it")
                    }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(t.amount),
                style = MaterialTheme.typography.titleMedium,
                color = if (isCredit) c.Danger else c.Success
            )
        }
    }
}
