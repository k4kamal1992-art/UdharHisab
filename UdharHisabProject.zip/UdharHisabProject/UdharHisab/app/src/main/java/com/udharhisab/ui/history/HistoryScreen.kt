package com.udharhisab.ui.history

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.ui.text.font.FontWeight
import com.udharhisab.ui.components.LedgerIllustration
import com.udharhisab.ui.components.bouncyClick
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

/**
 * ⭐ বটম-ন্যাভের "History" ট্যাব — সব দোকানের সব লেনদেন এক জায়গায়,
 * দোকান আর ধার/পরিশোধ অনুযায়ী ফিল্টার করা যায়। আর্কাইভ/পরিশোধিত দোকানের
 * পুরনো লিস্টটা এখন টপ বারের আইকন থেকে আলাদাভাবে দেখা যায়।
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HistoryScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit,
    onOpenArchived: () -> Unit
) {
    val vm: TransactionHistoryViewModel = viewModel { TransactionHistoryViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    val txns by vm.filtered.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val shopFilter by vm.shopFilter.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val availableShops by vm.availableShops.collectAsState()

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.history, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                actions = {
                    IconButton(onClick = onOpenArchived) {
                        Icon(Icons.Default.Archive, s.viewArchivedAction)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // ── ধার/পরিশোধ ফিল্টার ──
            val chipColors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = c.Primary,
                selectedLabelColor = androidx.compose.ui.graphics.Color.White
            )
            val chipShape = RoundedCornerShape(20.dp)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { vm.setTypeFilter(null) },
                    shape = chipShape, colors = chipColors,
                    label = { Text(s.historyFilterAllTypes, fontWeight = FontWeight.SemiBold) }
                )
                FilterChip(
                    selected = typeFilter == TransactionEntity.TYPE_CREDIT,
                    onClick = { vm.setTypeFilter(TransactionEntity.TYPE_CREDIT) },
                    shape = chipShape,
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = c.Danger, selectedLabelColor = androidx.compose.ui.graphics.Color.White),
                    label = { Text(sk?.historyFilterCreditOnly ?: s.historyFilterCreditOnly, fontWeight = FontWeight.SemiBold) }
                )
                FilterChip(
                    selected = typeFilter == TransactionEntity.TYPE_PAYMENT,
                    onClick = { vm.setTypeFilter(TransactionEntity.TYPE_PAYMENT) },
                    shape = chipShape,
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = c.Success, selectedLabelColor = androidx.compose.ui.graphics.Color.White),
                    label = { Text(sk?.historyFilterPaymentOnly ?: s.historyFilterPaymentOnly, fontWeight = FontWeight.SemiBold) }
                )
            }

            Spacer(Modifier.height(8.dp))

            // ── দোকান ফিল্টার ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                FilterChip(
                    selected = shopFilter == null,
                    onClick = { vm.setShopFilter(null) },
                    shape = chipShape, colors = chipColors,
                    label = { Text(sk?.historyFilterAllShops ?: s.historyFilterAllShops, fontWeight = FontWeight.SemiBold) }
                )
                availableShops.forEach { (shopId, shopName) ->
                    FilterChip(
                        selected = shopFilter == shopId,
                        onClick = { vm.setShopFilter(if (shopFilter == shopId) null else shopId) },
                        shape = chipShape, colors = chipColors,
                        label = { Text(shopName, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            if (isLoading) {
                com.udharhisab.ui.components.SkeletonList()
            } else if (txns.isEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LedgerIllustration()
                    Spacer(Modifier.height(8.dp))
                    Text(s.historyNoTxnsFound, color = c.Muted, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(txns, key = { it.txn.id }) { tws ->
                        TxnHistoryRow(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) }, modifier = Modifier.animateItemPlacement())
                    }
                }
            }
        }
    }
}

@Composable
private fun TxnHistoryRow(tws: TransactionWithShop, langCode: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val t = tws.txn
    val isCredit = t.type == TransactionEntity.TYPE_CREDIT
    val tone = if (isCredit) c.Danger else c.Success

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier
            .fillMaxWidth()
            .bouncyClick(onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ⭐ রঙিন দিক-চিহ্ন (বাকি = ওপরে লাল, পরিশোধ = নিচে সবুজ)
            Box(
                Modifier.size(42.dp).background(tone.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isCredit) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null, tint = tone, modifier = Modifier.size(20.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val details = buildString {
                    append(UnitConverter.dateShort(t.date, langCode))
                    (tws.items.firstOrNull()?.productName?.let { DefaultProducts.translateIfDefault(it, langCode) }?.takeIf { tws.items.isNotEmpty() }
                        ?: if (isCredit) (sk?.creditFallback ?: s.creditFallback) else (sk?.paymentFallback ?: s.paymentFallback)).let {
                        append(" • $it")
                        if (tws.items.size > 1) append(" +${tws.items.size - 1}")
                    }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(t.amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = tone
            )
        }
    }
}
