package com.udharhisab.data.pdf

/**
 * ⭐ দোকানদারের নিজের দোকানের পরিচয় — PDF ইনভয়েস/স্টেটমেন্টের হেডার ও ফুটারে বসে।
 * [logoPath] অ্যাপের নিজস্ব ফাইল-স্টোরেজে রাখা লোগো ফাইল (না থাকলে অ্যাপের ডিফল্ট লোগো)।
 */
data class ShopBranding(
    val name: String,
    val address: String = "",
    val phone: String = "",
    val logoPath: String? = null
)
