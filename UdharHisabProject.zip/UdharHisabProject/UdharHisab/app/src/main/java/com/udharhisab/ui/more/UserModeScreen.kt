package com.udharhisab.ui.more

import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.shopkeeperLabelsFor
import com.udharhisab.ui.theme.LocalKhataColors

/** "আমি গ্রাহক" নাকি "আমি দোকানদার" — বেছে নিলে অ্যাপের কিছু শব্দ (দোকান↔কাস্টমার ইত্যাদি) বদলে যায় */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserModeScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()
    // এই পেজে অপশনের নাম দেখানোর জন্য সবসময় শপকিপার-লেবেল সেট লাগবে,
    // এমনকি এখনো কাস্টমার-মোডে থাকলেও — তাই LocalShopkeeperLabels (যেটা null হতে পারে) না ব্যবহার করে সরাসরি
    val sk = shopkeeperLabelsFor(settings.language)

    var selected by remember(settings.userMode) { mutableStateOf(settings.userMode) }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(sk.userModeSettingLabel) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(sk.userModeHint, color = c.Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))

            ChoiceRow(Icons.Default.Person, sk.userModeCustomerOption, selected == "customer") { selected = "customer" }
            Spacer(Modifier.height(10.dp))
            ChoiceRow(Icons.Default.Storefront, sk.userModeShopkeeperOption, selected == "shopkeeper") { selected = "shopkeeper" }

            Spacer(Modifier.weight(1f))
            Button(
                onClick = { viewModel.setUserMode(selected); onBack() },
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(s.save, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}
