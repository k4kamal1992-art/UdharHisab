package com.udharhisab.ui.common

import android.app.Activity
import android.content.Intent
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import com.udharhisab.ui.strings.LocalStrings

/**
 * ⭐ কন্টাক্ট থেকে ফোন নম্বর বাছা। সিস্টেমের নিজস্ব কন্টাক্ট-পিকার খোলে — তাই
 * READ_CONTACTS পারমিশন লাগে না, শুধু যে কন্টাক্টটা বাছা হয় সেটারই নম্বর/নাম পাওয়া যায়।
 *
 * @return পিকার খোলার ফাংশন। [onPicked] পায় (নাম, পরিষ্কার করা নম্বর)।
 */
@Composable
fun rememberContactPicker(onPicked: (name: String, number: String) -> Unit): () -> Unit {
    val context = LocalContext.current
    val latest = rememberUpdatedState(onPicked)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val uri = result.data?.data ?: return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val number = cleanPhone(cursor.getString(0).orEmpty())
                    val name = cursor.getString(1).orEmpty()
                    if (number.isNotEmpty()) latest.value(name, number)
                }
            }
        }
    }
    return {
        runCatching {
            launcher.launch(
                Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            )
        }
    }
}

/** "+91 98765-43210" → "+919876543210" (শুধু শুরুর + আর ডিজিট থাকে) */
fun cleanPhone(raw: String): String {
    val t = raw.trim()
    val digits = t.filter { it.isDigit() }
    return if (t.startsWith("+")) "+$digits" else digits
}

/** ফোন ফিল্ডের ডান পাশের "কন্টাক্ট থেকে নিন" আইকন-বাটন */
@Composable
fun ContactPickerButton(onClick: () -> Unit) {
    val s = LocalStrings.current
    IconButton(onClick = onClick) {
        Icon(Icons.Default.Contacts, contentDescription = s.pickFromContacts)
    }
}
