package com.udharhisab.ui.shopprofile

import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.settings.LogoStorage
import com.udharhisab.ui.common.ContactPickerButton
import com.udharhisab.ui.common.rememberContactPicker
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * ⭐ দোকানের প্রোফাইলের ফর্ম — দুই জায়গায় ব্যবহার হয়:
 * (১) প্রথমবার অ্যাপ খোলার সেটআপে, (২) আরও → দোকানের প্রোফাইল পেজে।
 * এখানকার তথ্য: PDF ইনভয়েসে দোকানের নাম/লোগো/ঠিকানা, আর গ্রাহককে WhatsApp/SMS রিমাইন্ডারে।
 */
@Composable
fun ShopProfileForm(
    container: AppContainer,
    modifier: Modifier = Modifier,
    saveLabel: String? = null,
    showArt: Boolean = false,
    onSaved: () -> Unit
) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vm: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by vm.settings.collectAsState()

    var loaded by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("91") }
    var nameError by remember { mutableStateOf(false) }

    // সেভ করা মান একবার ফর্মে ভরে নিই (টাইপ করার সময় যেন ওভাররাইট না হয়)
    LaunchedEffect(Unit) {
        val st = container.store.settings.first()
        name = st.businessName; address = st.businessAddress
        phone = st.businessPhone; countryCode = st.countryCode
        loaded = true
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = LogoStorage.saveFromUri(context, uri)
            if (path != null) vm.setBusinessLogo(path)
        }
    }

    val pickContact = rememberContactPicker { _, number -> phone = number }

    val logoBitmap = remember(settings.businessLogoPath) {
        settings.businessLogoPath?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
    }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
            if (showArt) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    com.udharhisab.ui.components.ShopIllustration(Modifier.size(170.dp, 142.dp))
                }
            }
            Text(s.shopProfileIntro, style = MaterialTheme.typography.bodyMedium, color = c.Muted)

            if (loaded) {
                // ── লোগো ──
                Card(
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(s.shopLogoLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = c.TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // ⭐ গ্রেডিয়েন্ট বর্ডারের গোল লোগো-বক্স
                            Box(
                                Modifier
                                    .size(78.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(c.ChipBg)
                                    .border(2.5.dp, Brush.linearGradient(listOf(c.Primary, c.Accent)), RoundedCornerShape(24.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (logoBitmap != null) {
                                    Image(
                                        bitmap = logoBitmap.asImageBitmap(),
                                        contentDescription = s.shopLogoLabel,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else Text("🏬", style = MaterialTheme.typography.headlineMedium)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    },
                                    shape = RoundedCornerShape(22.dp)
                                ) { Text(s.shopLogoPick, fontWeight = FontWeight.Bold) }
                                if (settings.businessLogoPath != null) {
                                    TextButton(onClick = {
                                        LogoStorage.delete(settings.businessLogoPath)
                                        vm.setBusinessLogo(null)
                                    }) { Text(s.shopLogoRemove) }
                                }
                            }
                        }
                    }
                }

                // ── নাম / ঠিকানা / ফোন ──
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; nameError = false },
                    label = { Text(s.shopBusinessNameLabel) },
                    isError = nameError,
                    supportingText = if (nameError) { { Text(s.errorShopNameForPdf) } } else null,
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(s.shopBusinessAddressLabel) },
                    minLines = 2,
                    maxLines = 3,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(s.shopBusinessPhoneLabel) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    trailingIcon = { ContactPickerButton(onClick = pickContact) },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = countryCode,
                    onValueChange = { countryCode = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text(s.countryCodeLabel) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // ── এন্ট্রির পর রিমাইন্ডার অপশন ──
                Card(
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            s.promptAfterEntryLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = c.TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = settings.customerReminderPrompt, onCheckedChange = vm::setCustomerReminderPrompt)
                    }
                }

                Button(
                    onClick = {
                        if (name.isBlank()) {
                            nameError = true
                        } else {
                            vm.saveBusinessProfile(name, address, phone, countryCode)
                            onSaved()
                        }
                    },
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text(saveLabel ?: s.saveProfileButton, fontWeight = FontWeight.ExtraBold) }
            }
        }
}

/** আরও → দোকানের প্রোফাইল পেজ ("আমি কে → দোকানদার" হলে আসে) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopProfileScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.shopProfileTitle, fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back) }
                }
            )
        }
    ) { padding ->
        ShopProfileForm(
            container = container,
            modifier = Modifier.fillMaxSize().padding(padding),
            showArt = true,
            onSaved = { scope.launch { snackbar.showSnackbar(s.profileSavedMessage) } }
        )
    }
}
