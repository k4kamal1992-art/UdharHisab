package com.udharhisab.ui.shopprofile

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.settings.LogoStorage
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * ⭐ দোকানের প্রোফাইলের ফর্ম — দুই জায়গায় ব্যবহার হয়:
 * (১) প্রথমবার অ্যাপ খোলার সেটআপে, (২) আরও → দোকানের প্রোফাইল পেজে।
 * এখানকার তথ্য: PDF ইনভয়েসে দোকানের নাম/লোগো/ঠিকানা, আর গ্রাহককে WhatsApp/SMS রিমাইন্ডারে।
 */
@Composable
fun ShopProfileForm(
    container: AppContainer,
    modifier: Modifier = Modifier,
    saveLabel: String? = null,
    onSaved: () -> Unit
) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vm: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by vm.settings.collectAsState()

    var loaded by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("91") }
    var nameError by remember { mutableStateOf(false) }

    // সেভ করা মান একবার ফর্মে ভরে নিই (টাইপ করার সময় যেন ওভাররাইট না হয়)
    LaunchedEffect(Unit) {
        val st = container.store.settings.first()
        name = st.businessName; address = st.businessAddress
        phone = st.businessPhone; countryCode = st.countryCode
        loaded = true
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = LogoStorage.saveFromUri(context, uri)
            if (path != null) vm.setBusinessLogo(path)
        }
    }

    val logoBitmap = remember(settings.businessLogoPath) {
        settings.businessLogoPath?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
    }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
            Text(s.shopProfileIntro, style = MaterialTheme.typography.bodyMedium, color = c.Muted)

            if (loaded) {
                // ── লোগো ──
                Card(colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(s.shopLogoLabel, style = MaterialTheme.typography.titleSmall, color = c.TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(72.dp).background(c.ChipBg, MaterialTheme.shapes.medium),
                                contentAlignment = Alignment.Center
                            ) {
                                if (logoBitmap != null) {
                                    Image(
                                        bitmap = logoBitmap.asImageBitmap(),
                                        contentDescription = s.shopLogoLabel,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else Text("🏬", style = MaterialTheme.typography.headlineMedium)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = {
                                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }) { Text(s.shopLogoPick) }
                                if (settings.businessLogoPath != null) {
                                    TextButton(onClick = {
                                        LogoStorage.delete(settings.businessLogoPath)
                                        vm.setBusinessLogo(null)
                                    }) { Text(s.shopLogoRemove) }
                                }
                            }
                        }
                    }
                }

                // ── নাম / ঠিকানা / ফোন ──
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; nameError = false },
                    label = { Text(s.shopBusinessNameLabel) },
                    isError = nameError,
                    supportingText = if (nameError) { { Text(s.errorShopNameForPdf) } } else null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text(s.shopBusinessAddressLabel) },
                    minLines = 2,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text(s.shopBusinessPhoneLabel) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = countryCode,
                    onValueChange = { countryCode = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text(s.countryCodeLabel) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // ── এন্ট্রির পর রিমাইন্ডার অপশন ──
                Card(colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            s.promptAfterEntryLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = c.TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = settings.customerReminderPrompt, onCheckedChange = vm::setCustomerReminderPrompt)
                    }
                }

                Button(
                    onClick = {
                        if (name.isBlank()) {
                            nameError = true
                        } else {
                            vm.saveBusinessProfile(name, address, phone, countryCode)
                            onSaved()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(saveLabel ?: s.saveProfileButton) }
            }
        }
}

/** আরও → দোকানের প্রোফাইল পেজ ("আমি কে → দোকানদার" হলে আসে) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopProfileScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.shopProfileTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back) }
                }
            )
        }
    ) { padding ->
        ShopProfileForm(
            container = container,
            modifier = Modifier.fillMaxSize().padding(padding),
            onSaved = { scope.launch { snackbar.showSnackbar(s.profileSavedMessage) } }
        )
    }
}
