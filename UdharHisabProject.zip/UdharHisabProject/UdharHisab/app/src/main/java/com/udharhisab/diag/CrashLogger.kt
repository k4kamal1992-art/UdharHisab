package com.udharhisab.diag

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ⭐ অ্যাপ হঠাৎ বন্ধ হলে (ক্র্যাশ) কারণটা ফাইলে লিখে রাখে, যাতে পরে "ক্র্যাশ রিপোর্ট পাঠান" দিয়ে ডেভেলপারকে দেওয়া যায়।
 *
 *  • জাভা/কোটলিন ক্র্যাশ: কোন ফাইলের কোন লাইনে ভুল — পুরো স্ট্যাক ট্রেস।
 *  • মেমোরি শেষ / নেটিভ ক্র্যাশ / ANR (অ্যাপ সাড়া দিচ্ছে না): Android 11+ এ সিস্টেমের নিজস্ব "কেন বন্ধ হলো" রেকর্ড পড়ে।
 * কোনো তথ্য অন্য কোথাও যায় না — ব্যবহারকারী নিজে "পাঠান" না চাপলে ফাইলটা ফোনেই থাকে।
 */
object CrashLogger {
    private const val FILE_NAME = "last_crash.txt"
    private const val PREFS = "crash_logger"
    private const val MAX_BYTES = 24_000

    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                append(app, "JAVA/KOTLIN CRASH (thread: ${thread.name})\n${stackTrace(error)}")
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
        try {
            recordPreviousExit(app)
        } catch (_: Throwable) {
        }
    }

    fun hasReport(context: Context): Boolean = file(context).let { it.exists() && it.length() > 0 }

    fun readReport(context: Context): String? =
        file(context).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }

    fun clear(context: Context) {
        file(context).delete()
    }

    private fun file(context: Context) = File(context.filesDir, FILE_NAME)

    /** Android 11+ : আগের বার অ্যাপ কেন বন্ধ হয়েছিল (OOM, native crash, ANR...) */
    private fun recordPreviousExit(app: Application) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastSeen = prefs.getLong("last_exit_ts", 0L)
        val exits = am.getHistoricalProcessExitReasons(app.packageName, 0, 8)
        val abnormal = exits.filter {
            it.timestamp > lastSeen && it.reason in setOf(
                android.app.ApplicationExitInfo.REASON_CRASH,
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE,
                android.app.ApplicationExitInfo.REASON_ANR,
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY,
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE,
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
                android.app.ApplicationExitInfo.REASON_SIGNALED
            )
        }
        for (info in abnormal.sortedBy { it.timestamp }) {
            val name = when (info.reason) {
                android.app.ApplicationExitInfo.REASON_CRASH -> "CRASH (java)"
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "NATIVE CRASH"
                android.app.ApplicationExitInfo.REASON_ANR -> "ANR (not responding)"
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW MEMORY KILL"
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE RESOURCE USAGE"
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "INIT FAILURE"
                android.app.ApplicationExitInfo.REASON_SIGNALED -> "KILLED BY SIGNAL"
                else -> "reason=${info.reason}"
            }
            val trace = try {
                info.traceInputStream?.bufferedReader()?.use { it.readText() }?.take(7000)
            } catch (_: Throwable) {
                null
            }
            append(
                app,
                "SYSTEM EXIT RECORD: $name\n" +
                    "time: ${fmt(info.timestamp)}\n" +
                    "description: ${info.description}\n" +
                    "status: ${info.status}, importance: ${info.importance}\n" +
                    "memory pss(kb): ${info.pss}, rss(kb): ${info.rss}\n" +
                    (if (trace != null) "trace:\n$trace\n" else "")
            )
        }
        if (abnormal.isNotEmpty()) {
            prefs.edit().putLong("last_exit_ts", abnormal.maxOf { it.timestamp }).apply()
        } else if (exits.isNotEmpty()) {
            prefs.edit().putLong("last_exit_ts", exits.maxOf { it.timestamp }).apply()
        }
    }

    private fun append(context: Context, body: String) {
        val f = file(context)
        val header = "==== ${fmt(System.currentTimeMillis())} | ${device(context)} ====\n"
        var text = (if (f.exists()) f.readText() else "") + header + body + "\n\n"
        if (text.length > MAX_BYTES) text = text.takeLast(MAX_BYTES)
        f.writeText(text)
    }

    private fun device(context: Context): String {
        val version = try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        } catch (_: Throwable) {
            "?"
        }
        val mem = try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            "memClass=${am.memoryClass}MB largeMemClass=${am.largeMemoryClass}MB"
        } catch (_: Throwable) {
            ""
        }
        return "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), app $version, $mem"
    }

    private fun fmt(ms: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    private fun stackTrace(e: Throwable): String {
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        return sw.toString().take(9000)
    }
}
