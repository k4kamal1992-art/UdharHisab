package com.udharhisab.ui.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.components.PersonIllustration
import com.udharhisab.ui.components.ShopkeeperIllustration
import com.udharhisab.ui.more.ChoiceRow
import com.udharhisab.ui.shopprofile.ShopProfileForm
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.shopkeeperLabelsFor
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * ⭐ প্রথমবার অ্যাপ খোলার সেটআপ — ভাষা বাছাইয়ের ঠিক পরে:
 * ধাপ ১: আমি কে (গ্রাহক / দোকানদার)
 * ধাপ ২ (শুধু দোকানদার হলে): দোকানের নাম, লোগো, ঠিকানা, ফোন — চাইলে পরে করার জন্য বাদও দেওয়া যায়।
 * এখানে বাছা মান পরে আরও → "আমি কে" ও "দোকানের প্রোফাইল" থেকে বদলানো যায়।
 */
@Composable
fun SetupOnboardingScreen(container: AppContainer) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()
    val sk = shopkeeperLabelsFor(s.code)

    var step by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf("customer") }

    fun finish() { scope.launch { container.store.setSetupCompleted() } }

    Scaffold(containerColor = c.Background) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            if (step == 0) {
                Spacer(Modifier.weight(1f))
                // ⭐ দুই চরিত্র: গ্রাহক ও দোকানদার — বাছা চরিত্রটা একটু বড় হয়ে ওঠে
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    PersonIllustration(Modifier.size(if (selected == "customer") 140.dp else 110.dp))
                    ShopkeeperIllustration(Modifier.size(if (selected == "shopkeeper") 140.dp else 110.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text(s.setupRoleTitle, style = MaterialTheme.typography.headlineMedium, color = c.TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text(sk.userModeHint, style = MaterialTheme.typography.bodyMedium, color = c.Muted)
                Spacer(Modifier.height(24.dp))
                ChoiceRow(Icons.Default.Person, sk.userModeCustomerOption, selected == "customer") { selected = "customer" }
                Spacer(Modifier.height(10.dp))
                ChoiceRow(Icons.Default.Storefront, sk.userModeShopkeeperOption, selected == "shopkeeper") { selected = "shopkeeper" }
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = {
                        scope.launch {
                            container.store.setUserMode(selected)
                            if (selected == "shopkeeper") step = 1 else container.store.setSetupCompleted()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(s.setupContinue) }
            } else {
                Text(s.setupProfileTitle, style = MaterialTheme.typography.headlineMedium, color = c.TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text(s.setupProfileSubtitle, style = MaterialTheme.typography.bodyMedium, color = c.Muted)
                ShopProfileForm(
                    container = container,
                    modifier = Modifier.weight(1f),
                    saveLabel = s.setupFinish,
                    onSaved = { finish() }
                )
                TextButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) { Text(s.setupSkip) }
            }
        }
    }
}
