package com.udharhisab.ads

import android.content.Context
import android.graphics.Color as AColor
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ তালিকার ভেতরের নেটিভ বিজ্ঞাপন — কাস্টমার কার্ডের মতো দেখতে, স্পষ্ট "বিজ্ঞাপন" ব্যাজসহ।
 * ব্যানারের চেয়ে কম বিরক্তিকর। নিয়ম না মানলে বা লোড না হলে কিছুই আঁকে না।
 * (বিজ্ঞাপন-ভিউ হাতে কোড করে বানানো — আলাদা XML লাগে না; Google-এর নিয়ম মেনে ছবি/শিরোনাম/বাটন নেটিভ-ভিউতে বাঁধা।)
 */
@Composable
fun NativeAdCard(modifier: Modifier = Modifier) {
    val eligible by AdPolicy.eligible.collectAsState()
    if (!eligible) return

    val context = LocalContext.current
    val c = LocalKhataColors.current
    val label = LocalStrings.current.adSponsoredLabel
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        val loader = AdLoader.Builder(context, AdIds.NATIVE)
            .forNativeAd { ad ->
                nativeAd?.destroy()
                nativeAd = ad
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) { nativeAd = null }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()
        loader.loadAd(AdRequest.Builder().build())
        onDispose {
            nativeAd?.destroy()
            nativeAd = null
        }
    }

    val ad = nativeAd ?: return
    val surface = c.Surface.toArgb()
    val border = c.Divider.toArgb()
    val ink = c.TextPrimary.toArgb()
    val muted = c.Muted.toArgb()
    val accent = c.Primary.toArgb()

    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx -> buildNativeView(ctx, label, surface, border, ink, muted, accent) },
        update = { view -> bindNative(view, ad) }
    )
}

private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

private fun buildNativeView(
    ctx: Context, label: String, surface: Int, border: Int, ink: Int, muted: Int, accent: Int
): NativeAdView {
    val root = NativeAdView(ctx)
    root.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    root.background = GradientDrawable().apply {
        setColor(surface)
        cornerRadius = ctx.dp(20).toFloat()
        setStroke(ctx.dp(1), border)
    }

    val column = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(14))
    }

    // ওপরের সারি: "বিজ্ঞাপন" ব্যাজ
    val badge = TextView(ctx).apply {
        text = label
        textSize = 11f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(accent)
        setPadding(ctx.dp(8), ctx.dp(2), ctx.dp(8), ctx.dp(2))
        background = GradientDrawable().apply {
            setColor(AColor.argb(30, AColor.red(accent), AColor.green(accent), AColor.blue(accent)))
            cornerRadius = ctx.dp(8).toFloat()
        }
    }
    column.addView(badge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    // আইকন + শিরোনাম + বর্ণনা
    val row = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, ctx.dp(8), 0, ctx.dp(8))
    }
    val icon = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    row.addView(icon, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)).apply { rightMargin = ctx.dp(12) })

    val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val headline = TextView(ctx).apply {
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(ink)
        maxLines = 2
    }
    val body = TextView(ctx).apply {
        textSize = 12f
        setTextColor(muted)
        maxLines = 2
    }
    texts.addView(headline)
    texts.addView(body)
    row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    column.addView(row)

    // কল-টু-অ্যাকশন বাটন
    val cta = Button(ctx).apply {
        isAllCaps = false
        textSize = 13f
        setTextColor(AColor.WHITE)
        background = GradientDrawable().apply {
            setColor(accent)
            cornerRadius = ctx.dp(22).toFloat()
        }
    }
    column.addView(cta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(44)))

    root.addView(column)
    root.iconView = icon
    root.headlineView = headline
    root.bodyView = body
    root.callToActionView = cta
    return root
}

private fun bindNative(view: NativeAdView, ad: NativeAd) {
    (view.headlineView as TextView).text = ad.headline
    (view.bodyView as TextView).apply {
        text = ad.body
        visibility = if (ad.body.isNullOrBlank()) View.GONE else View.VISIBLE
    }
    (view.callToActionView as Button).apply {
        text = ad.callToAction ?: ""
        visibility = if (ad.callToAction == null) View.GONE else View.VISIBLE
    }
    (view.iconView as ImageView).apply {
        val d = ad.icon?.drawable
        if (d != null) { setImageDrawable(d); visibility = View.VISIBLE } else visibility = View.GONE
    }
    view.setNativeAd(ad)
}
