package com.udharhisab.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn

class HistoryViewModel(repo: HisabRepository) : ViewModel() {

    enum class Tab { ARCHIVED, SETTLED }

    val tab = MutableStateFlow(Tab.ARCHIVED)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val shops: StateFlow<List<ShopWithBalance>> = tab
        .flatMapLatest { t ->
            when (t) {
                Tab.ARCHIVED -> repo.archivedShops()
                Tab.SETTLED -> repo.settledShops()
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setTab(t: Tab) { tab.value = t }
}
