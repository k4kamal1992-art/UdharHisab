package com.udharhisab.ui.reminder

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ দোকানদারের জন্য — গ্রাহককে পাঠানোর বার্তা দেখে এডিট করে WhatsApp বা SMS-এ পাঠানো
 */
@Composable
fun ReminderDialog(
    initialMessage: String,
    onWhatsApp: (String) -> Unit,
    onSms: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    var message by remember(initialMessage) { mutableStateOf(initialMessage) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(20.dp)) {
                Text(s.reminderDialogTitle, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(s.reminderDialogSubtitle, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text(s.reminderMessageLabel) },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onWhatsApp(message) },
                        enabled = message.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                        modifier = Modifier.weight(1f)
                    ) { Text(s.reminderWhatsapp) }
                    OutlinedButton(
                        onClick = { onSms(message) },
                        enabled = message.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) { Text(s.reminderSms) }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(androidx.compose.ui.Alignment.End)) {
                    Text(s.reminderSkip)
                }
            }
        }
    }
}
