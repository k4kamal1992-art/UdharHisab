package com.udharhisab.ui.reminder

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.components.FriendlyDialog
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ দোকানদারের জন্য — গ্রাহককে পাঠানোর বার্তা দেখে এডিট করে WhatsApp বা SMS-এ পাঠানো
 */
@Composable
fun ReminderDialog(
    initialMessage: String,
    onWhatsApp: (String) -> Unit,
    onSms: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    var message by remember(initialMessage) { mutableStateOf(initialMessage) }

    FriendlyDialog(
        title = s.reminderDialogTitle,
        subtitle = s.reminderDialogSubtitle,
        icon = Icons.AutoMirrored.Filled.Send,
        onDismiss = onDismiss,
        footer = {
            TextButton(onClick = onDismiss, modifier = Modifier.weight(0.8f)) { Text(s.reminderSkip, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { onSms(message) },
                enabled = message.isNotBlank(),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier.weight(1f).height(48.dp)
            ) { Text(s.reminderSms, fontWeight = FontWeight.ExtraBold) }
            Button(
                onClick = { onWhatsApp(message) },
                enabled = message.isNotBlank(),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                modifier = Modifier.weight(1.2f).height(48.dp)
            ) { Text(s.reminderWhatsapp, fontWeight = FontWeight.ExtraBold) }
        }
    ) {
        OutlinedTextField(
            value = message,
            onValueChange = { message = it },
            label = { Text(s.reminderMessageLabel) },
            shape = RoundedCornerShape(18.dp),
            minLines = 4,
            maxLines = 8,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
