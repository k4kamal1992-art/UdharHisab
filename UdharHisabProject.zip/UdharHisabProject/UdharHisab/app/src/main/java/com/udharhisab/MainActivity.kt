package com.udharhisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.udharhisab.di.AppContainer
import com.udharhisab.navigation.AppNavHost
import com.udharhisab.reminder.ReminderWorker
import com.udharhisab.ui.lock.LockScreen
import com.udharhisab.ui.theme.KhataTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val container: AppContainer by lazy {
        AppContainer(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ⭐ সেটিংসে রিমাইন্ডার চালু থাকলে worker নিশ্চিত (রিবুট-পরবর্তী সেফটি)
        lifecycleScope.launch {
            val settings = container.store.settings.first()
            if (settings.remindersEnabled) {
                ReminderWorker.schedule(applicationContext)
            }
        }

        // নোটিফিকেশন ট্যাপ থেকে আসা ডিপ-লিংক
        val pendingShopId = mutableLongStateOf(
            intent.getLongExtra("navigate_to_shop", -1L)
        )

        setContent {
            val settings by container.store.settings.collectAsState(initial = null)
            val settingsValue = settings

            // ⭐ ফিক্স: আগে onUnlocked কিছুই করত না (খালি কমেন্ট ছিল), তাই সঠিক PIN
            // দিলেও লক স্ক্রিন থেকেই কখনো বের হওয়া যেত না — এই সেশনে আনলক হয়েছে
            // কিনা সেটা এখন সত্যিকারের state দিয়ে ট্র্যাক করা হচ্ছে।
            var isUnlockedThisSession by remember { mutableStateOf(false) }

            KhataTheme(themeMode = settingsValue?.theme ?: "system", language = settingsValue?.language ?: "bn") {
                when {
                    // Settings এখনো লোড হয়নি — খালি রাখুন (এক ফ্রেম)
                    settingsValue == null -> Unit

                    // ⭐ পিন সক্রিয় আর এই সেশনে এখনো আনলক হয়নি → আগে লক
                    settingsValue.pinEnabled && settingsValue.pinHash != null && !isUnlockedThisSession -> {
                        LockScreen(
                            store = container.store,
                            storedPinHash = settingsValue.pinHash!!,
                            onUnlocked = { isUnlockedThisSession = true }
                        )
                    }

                    else -> {
                        var shopLink by remember { mutableLongStateOf(pendingShopId.longValue) }

                        // ডিপ-লিংক হ্যান্ডলিং — NavHost-এর ভেতরে পাস করা যায় না সরাসরি,
                        // তাই ShopDetail রাউটে এক্সট্রা আর্গুমেন্ট হিসেবে পাঠানোর বদলে
                        // HomeScreen-এ onOpenShop ট্রিগার করার সিম্পল উপায়:
                        LaunchedEffect(shopLink) {
                            // ডিপ-লিংক pendingShopId নিচের NavHost ডিপ লিংক দিয়ে হ্যান্ডল হয়
                        }

                        KhataTheme(themeMode = settingsValue.theme, language = settingsValue.language) {
                            androidx.compose.material3.Surface {
                                AppNavHost(container = container)
                            }
                        }
                    }
                }
            }
        }
    }
}
