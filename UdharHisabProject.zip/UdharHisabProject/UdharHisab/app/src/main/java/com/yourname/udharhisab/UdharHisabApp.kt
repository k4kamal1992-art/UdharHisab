package com.yourname.udharhisab

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.yourname.udharhisab.data.local.AppDatabase
import com.yourname.udharhisab.data.repository.ShopRepository
import com.yourname.udharhisab.data.repository.TransactionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Application class for Udhar Hisab
 * Initializes AdMob SDK and provides database/repository instances
 */
class UdharHisabApp : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val shopRepository by lazy { ShopRepository(database.shopDao()) }
    val transactionRepository by lazy { TransactionRepository(database.transactionDao()) }

    override fun onCreate() {
        super.onCreate()

        // Initialize AdMob SDK on background thread
        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(this@UdharHisabApp) {}
        }
    }
}
