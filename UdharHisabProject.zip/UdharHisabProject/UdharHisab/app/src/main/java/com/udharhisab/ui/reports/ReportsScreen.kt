package com.udharhisab.ui.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit
) {
    val vm: ReportsViewModel = viewModel { ReportsViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val period by vm.period.collectAsState()
    val totals by vm.totals.collectAsState()
    val shopRows by vm.shopRows.collectAsState()
    val recentPayments by vm.recentPayments.collectAsState()
    val currentDue by vm.currentTotalDue.collectAsState()
    val aging by vm.aging.collectAsState()

    var periodMenuOpen by remember { mutableStateOf(false) }

    fun periodLabel(p: ReportPeriod) = when (p) {
        ReportPeriod.D7 -> s.period7d
        ReportPeriod.D15 -> s.period15d
        ReportPeriod.D30 -> s.period30d
        ReportPeriod.M3 -> s.period3m
        ReportPeriod.Y1 -> s.period1y
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.reportsTitle) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ── সময় নির্বাচন ──
            item {
                Box {
                    AssistChip(
                        onClick = { periodMenuOpen = true },
                        leadingIcon = {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        label = { Text("${periodLabel(period)} ▾") }
                    )
                    DropdownMenu(expanded = periodMenuOpen, onDismissRequest = { periodMenuOpen = false }) {
                        ReportPeriod.entries.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(periodLabel(p)) },
                                onClick = { vm.setPeriod(p); periodMenuOpen = false }
                            )
                        }
                    }
                }
            }

            // ── স্মার্ট সামারি ──
            item {
                val summaryText = if (s.code == "en")
                    "In this period you took ${UnitConverter.rupees(totals.totalCredit)} in credit and received ${UnitConverter.rupees(totals.totalPayment)} in payments. ${s.reportCurrentDue}: ${UnitConverter.rupees(currentDue)}."
                else
                    "এই সময়ে আপনি ${UnitConverter.rupees(totals.totalCredit)} ধার দিয়েছেন এবং ${UnitConverter.rupees(totals.totalPayment)} পরিশোধ পেয়েছেন। ${s.reportCurrentDue}: ${UnitConverter.rupees(currentDue)}।"
                Card(colors = CardDefaults.cardColors(containerColor = c.ChipBg)) {
                    Text(
                        summaryText,
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // ── সামারি কার্ড (২x২) ──
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard(s.reportTotalCredit, UnitConverter.rupees(totals.totalCredit), c.Danger, Modifier.weight(1f))
                        SummaryCard(s.reportTotalPayment, UnitConverter.rupees(totals.totalPayment), c.Success, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard(s.reportCurrentDue, UnitConverter.rupees(currentDue), c.Primary, Modifier.weight(1f))
                        SummaryCard(s.reportTxnCount, totals.txnCount.toString(), c.TextSecondary, Modifier.weight(1f))
                    }
                }
            }

            // ── বার চার্ট ──
            item {
                Card {
                    Column(Modifier.padding(vertical = 16.dp)) {
                        Text(s.reportChartTitle, style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(horizontal = 16.dp))
                        Spacer(Modifier.height(8.dp))
                        CreditPaymentBarChart(
                            credit = totals.totalCredit,
                            payment = totals.totalPayment,
                            creditColor = c.Danger,
                            paymentColor = c.Success,
                            creditLabel = s.reportTotalCredit,
                            paymentLabel = s.reportTotalPayment
                        )
                    }
                }
            }

            // ── দোকানভিত্তিক বাকি ──
            item {
                Text(s.reportShopWiseTitle, style = MaterialTheme.typography.titleMedium)
            }
            if (shopRows.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                items(shopRows.take(10), key = { "shop_${it.shopId}" }) { row ->
                    ShopReportCard(row, onClick = { onOpenShop(row.shopId) })
                }
            }

            // ── পুরনো বাকি (Aging) ──
            item {
                Text(s.reportAgingTitle, style = MaterialTheme.typography.titleMedium)
            }
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AgingRow(c.Danger, s.reportAging30plus, aging.d30plus)
                        AgingRow(Color(0xFFE0902E), s.reportAging15to30, aging.d15to30)
                        AgingRow(Color(0xFFD9B613), s.reportAging7to15, aging.d7to15)
                        AgingRow(c.Success, s.reportAging0to7, aging.d0to7)
                    }
                }
            }

            // ── সাম্প্রতিক পরিশোধ ──
            item {
                Text(s.reportRecentPaymentsTitle, style = MaterialTheme.typography.titleMedium)
            }
            if (recentPayments.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                items(recentPayments, key = { "payment_${it.txn.id}" }) { tws ->
                    RecentPaymentRow(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) })
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, color = valueColor)
        }
    }
}

@Composable
private fun ShopReportCard(row: ShopReportRow, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium),
        onClick = onClick
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(row.shopName, style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${s.reportTotalCredit}: ${UnitConverter.rupees(row.periodCredit)} • " +
                        "${s.reportTotalPayment}: ${UnitConverter.rupees(row.periodPayment)}",
                    style = MaterialTheme.typography.bodySmall, color = c.Muted
                )
            }
            Text(
                UnitConverter.rupees(row.currentDue),
                style = MaterialTheme.typography.titleMedium,
                color = if (row.currentDue > 0) c.Danger else c.Success
            )
        }
    }
}

@Composable
private fun AgingRow(dotColor: Color, label: String, amount: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dotColor))
            Spacer(Modifier.width(8.dp))
            Text(label)
        }
        Text(UnitConverter.rupees(amount), style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun RecentPaymentRow(tws: TransactionWithShop, langCode: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Card(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleSmall)
                Text(UnitConverter.dateShort(tws.txn.date, langCode),
                    style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(UnitConverter.rupees(tws.txn.amount), color = c.Success)
        }
    }
}
