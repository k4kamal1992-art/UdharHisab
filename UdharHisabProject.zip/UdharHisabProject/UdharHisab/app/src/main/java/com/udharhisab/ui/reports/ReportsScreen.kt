package com.udharhisab.ui.reports

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.Friendly
import com.udharhisab.ui.components.FriendlyTiles
import com.udharhisab.ui.components.bouncyClick
import com.udharhisab.ui.components.rememberCountUp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

/**
 * ✨ আলট্রা-মডার্ন "বেন্টো" রিপোর্ট — রঙিন গ্রেডিয়েন্ট টাইল, অ্যানিমেটেড রিং ও ডোনাট চার্ট,
 * র‍্যাঙ্কিং-ধাঁচের কাস্টমার তালিকা, রঙিন কার্ডের ছায়া। থিম বদলালে রঙও থিমের সাথে মানিয়ে নেয়।
 */
private val HeroBrush = listOf(Color(0xFF087F5B), Color(0xFF14B8A6), Color(0xFF38BDF8))
private val CreditBrush = listOf(Color(0xFFFF8A65), Color(0xFFFB5C7C))
private val PaymentBrush = listOf(Color(0xFF14B8A6), Color(0xFF34D399))
private val CountBrush = listOf(Color(0xFFA78BFA), Color(0xFF6A8DFF))

private fun Modifier.colorShadow(color: Color, radius: Int, elevation: Int = 10): Modifier =
    this.shadow(elevation.dp, RoundedCornerShape(radius.dp), ambientColor = color, spotColor = color)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit
) {
    val vm: ReportsViewModel = viewModel { ReportsViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    val period by vm.period.collectAsState()
    val totals by vm.totals.collectAsState()
    val shopRows by vm.shopRows.collectAsState()
    val recentPayments by vm.recentPayments.collectAsState()
    val currentDue by vm.currentTotalDue.collectAsState()
    val aging by vm.aging.collectAsState()

    val dueLabel = sk?.pdfDueLabel ?: s.reportCurrentDue
    val creditLabel = sk?.pdfTotalCreditLabel ?: s.reportTotalCredit
    val paymentLabel = sk?.pdfTotalPaymentLabel ?: s.reportTotalPayment

    fun periodLabel(p: ReportPeriod) = when (p) {
        ReportPeriod.D7 -> s.period7d
        ReportPeriod.D15 -> s.period15d
        ReportPeriod.D30 -> s.period30d
        ReportPeriod.M3 -> s.period3m
        ReportPeriod.Y1 -> s.period1y
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.reportsTitle, fontWeight = FontWeight.ExtraBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Background,
                    scrolledContainerColor = c.Background,
                    titleContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── সময় বাছাই: বাছাটা গ্রেডিয়েন্ট ক্যাপসুল, রঙিন ছায়াসহ ──
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReportPeriod.entries.forEach { p ->
                        val selected = period == p
                        Box(
                            Modifier
                                .then(if (selected) Modifier.colorShadow(c.Primary, 20, 8) else Modifier)
                                .clip(RoundedCornerShape(20.dp))
                                .then(
                                    if (selected) Modifier.background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
                                    else Modifier.background(c.Surface).border(1.dp, c.Divider, RoundedCornerShape(20.dp))
                                )
                                .clickable { vm.setPeriod(p) }
                                .padding(horizontal = 18.dp, vertical = 10.dp)
                        ) {
                            Text(
                                periodLabel(p), fontWeight = FontWeight.ExtraBold,
                                color = if (selected) Color.White else c.TextSecondary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // ── হিরো: রঙিন গ্রেডিয়েন্ট + বড় অঙ্ক + ডানে রিং ──
            item { HeroCard(dueLabel, currentDue, totals.totalCredit, totals.totalPayment) }

            // ── বেন্টো: বাকি / পরিশোধ দুই রঙিন টাইল ──
            item {
                val maxV = maxOf(totals.totalCredit, totals.totalPayment, 1.0)
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BentoTile(Modifier.weight(1f).fillMaxHeight(), CreditBrush, Icons.Default.ArrowUpward, creditLabel, totals.totalCredit, (totals.totalCredit / maxV).toFloat())
                    BentoTile(Modifier.weight(1f).fillMaxHeight(), PaymentBrush, Icons.Default.ArrowDownward, paymentLabel, totals.totalPayment, (totals.totalPayment / maxV).toFloat())
                }
            }

            // ── লেনদেন গোনা: চওড়া বেগুনি টাইল ──
            item { CountTile(s.reportTxnCount, totals.txnCount) }

            // ── স্মার্ট সারাংশ ──
            item { InsightCard(totals.totalCredit, totals.totalPayment, currentDue, dueLabel) }

            // ── ডোনাট চার্ট ──
            item {
                Column(Modifier.fillMaxWidth().colorShadow(c.Primary, 26, 6).clip(RoundedCornerShape(26.dp)).background(c.Surface).padding(18.dp)) {
                    Text(s.reportChartTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = c.TextPrimary)
                    Spacer(Modifier.height(14.dp))
                    if (totals.totalCredit + totals.totalPayment <= 0.0) {
                        Text(s.reportNoData, color = c.Muted, modifier = Modifier.padding(vertical = 12.dp))
                    } else {
                        DonutChart(totals.totalCredit, totals.totalPayment, creditLabel, paymentLabel)
                    }
                }
            }

            // ── র‍্যাঙ্কিং: কার কত বাকি ──
            item { SectionHeader(Icons.Default.Storefront, sk?.reportShopWiseTitle ?: s.reportShopWiseTitle, shopRows.size.takeIf { it > 0 }) }
            if (shopRows.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                val maxDue = shopRows.maxOf { it.currentDue }.coerceAtLeast(1.0)
                itemsIndexedShops(shopRows.take(10), maxDue, onOpenShop)
            }

            // ── পুরনো বাকি: ২×২ রঙিন টাইল ──
            item { SectionHeader(Icons.Default.Schedule, s.reportAgingTitle, null) }
            item { AgingGrid(aging, s.reportAging30plus, s.reportAging15to30, s.reportAging7to15, s.reportAging0to7) }

            // ── সাম্প্রতিক পরিশোধ: টাইমলাইন ──
            item { SectionHeader(Icons.Default.Payments, s.reportRecentPaymentsTitle, recentPayments.size.takeIf { it > 0 }) }
            if (recentPayments.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                itemsTimeline(recentPayments, s.code, onOpenShop)
            }
        }
    }
}

// ────────────────────────── LazyColumn সহায়ক (items-এর র‍্যাঙ্ক/টাইমলাইন) ──────────────────────────

private fun androidx.compose.foundation.lazy.LazyListScope.itemsIndexedShops(
    rows: List<ShopReportRow>, maxDue: Double, onOpenShop: (Long) -> Unit
) {
    items(rows.size, key = { "shop_${rows[it].shopId}" }) { i ->
        RankedShopCard(i + 1, rows[i], maxDue) { onOpenShop(rows[i].shopId) }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.itemsTimeline(
    list: List<TransactionWithShop>, langCode: String, onOpenShop: (Long) -> Unit
) {
    items(list.size, key = { "payment_${list[it].txn.id}" }) { i ->
        TimelinePayment(list[i], langCode, isLast = i == list.lastIndex) { onOpenShop(list[i].txn.shopId) }
    }
}

// ────────────────────────── অংশগুলো ──────────────────────────

@Composable
private fun SectionHeader(icon: ImageVector, title: String, count: Int?) {
    val c = LocalKhataColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(c.Primary, c.Accent))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = c.TextPrimary)
        if (count != null) {
            Spacer(Modifier.width(8.dp))
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(c.ChipBg).padding(horizontal = 9.dp, vertical = 2.dp)) {
                Text(count.toString(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = c.Primary)
            }
        }
    }
}

@Composable
private fun HeroCard(dueLabel: String, due: Double, credit: Double, payment: Double) {
    val s = LocalStrings.current
    val percent = if (credit > 0) (payment / credit).coerceIn(0.0, 1.0).toFloat() else 0f
    val anim = remember { Animatable(0f) }
    LaunchedEffect(percent) { anim.animateTo(percent, tween(1100, easing = FastOutSlowInEasing)) }
    val shown = rememberCountUp(due)

    Box(
        Modifier
            .fillMaxWidth()
            .colorShadow(HeroBrush[1], 30, 14)
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(HeroBrush))
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.12f), size.height * 0.85f, Offset(size.width * 1.0f, size.height * 0.0f))
            drawCircle(Color.White.copy(alpha = 0.08f), size.height * 0.5f, Offset(size.width * 0.35f, size.height * 1.15f))
            drawCircle(Friendly.Sun, size.height * 0.03f, Offset(size.width * 0.62f, size.height * 0.2f))
            drawCircle(Friendly.Rose.copy(alpha = 0.9f), size.height * 0.022f, Offset(size.width * 0.52f, size.height * 0.82f))
        }
        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(dueLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color.White.copy(alpha = 0.9f))
                Spacer(Modifier.height(2.dp))
                Text(
                    UnitConverter.rupees(shown),
                    style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1
                )
                Spacer(Modifier.height(10.dp))
                val pct = (percent * 100).toInt()
                Box(Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text(
                        when (s.code) { "en" -> "$pct% paid back"; "hi" -> "$pct% चुकाया गया"; "mr" -> "$pct% चुकते"; "gu" -> "$pct% ચૂકતે"; "ta" -> "$pct% செலுத்தப்பட்டது"; else -> "$pct% পরিশোধিত" },
                        style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.White
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            // ডানের রিং গেজ
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = size.minDimension * 0.14f
                    val pad = stroke / 2f
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(Color.White.copy(alpha = 0.25f), 0f, 360f, false, Offset(pad, pad), arcSize, style = Stroke(stroke))
                    drawArc(Color.White, -90f, 360f * anim.value, false, Offset(pad, pad), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Text("${(percent * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}

@Composable
private fun BentoTile(
    modifier: Modifier, brush: List<Color>, icon: ImageVector, label: String, amount: Double, share: Float
) {
    val grow = remember { Animatable(0f) }
    LaunchedEffect(share) { grow.snapTo(0f); grow.animateTo(share.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing)) }
    val shown = rememberCountUp(amount)
    Box(
        modifier
            .colorShadow(brush[0], 24, 10)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(brush))
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.15f), size.height * 0.55f, Offset(size.width * 1.0f, size.height * 0.0f))
        }
        Column(Modifier.padding(16.dp)) {
            Box(Modifier.size(34.dp).background(Color.White.copy(alpha = 0.25f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.92f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.weight(1f))
            Text(UnitConverter.rupees(shown), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.28f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(fraction = grow.value).clip(RoundedCornerShape(4.dp)).background(Color.White))
            }
        }
    }
}

@Composable
private fun CountTile(label: String, count: Int) {
    val shown = rememberCountUp(count.toDouble())
    Row(
        Modifier
            .fillMaxWidth()
            .colorShadow(CountBrush[0], 24, 8)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(CountBrush))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).background(Color.White.copy(alpha = 0.25f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Receipt, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.titleMedium, color = Color.White.copy(alpha = 0.95f), modifier = Modifier.weight(1f))
        Text(shown.toInt().toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
    }
}

@Composable
private fun InsightCard(credit: Double, payment: Double, due: Double, dueLabel: String) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val shopkeeper = LocalShopkeeperLabels.current != null
    val t: List<String> = when (s.code) {
        "en" -> if (shopkeeper) listOf("In this period you gave ", " on credit and received ", " in payments. ", ".")
        else listOf("In this period you took ", " on credit and paid back ", ". ", ".")
        "hi" -> if (shopkeeper) listOf("इस अवधि में आपने ", " उधार दिया और ", " भुगतान पाया। ", "।")
        else listOf("इस अवधि में आपने ", " उधार लिया और ", " चुकाया। ", "।")
        "mr" -> if (shopkeeper) listOf("या कालावधीत तुम्ही ", " उधार दिले आणि ", " जमा मिळाले. ", ".")
        else listOf("या कालावधीत तुम्ही ", " उधार घेतले आणि ", " परत केले. ", ".")
        "gu" -> if (shopkeeper) listOf("આ સમયગાળામાં તમે ", " ઉધાર આપ્યું અને ", " જમા મળ્યા. ", ".")
        else listOf("આ સમયગાળામાં તમે ", " ઉધાર લીધું અને ", " ચૂકવ્યા. ", ".")
        "ta" -> if (shopkeeper) listOf("இந்தக் காலத்தில் நீங்கள் ", " கடன் கொடுத்து ", " பெற்றீர்கள். ", ".")
        else listOf("இந்தக் காலத்தில் நீங்கள் ", " கடன் வாங்கி ", " திருப்பிச் செலுத்தினீர்கள். ", ".")
        else -> if (shopkeeper) listOf("এই সময়ে আপনি ", " বাকি দিয়েছেন এবং ", " পরিশোধ পেয়েছেন। ", "।")
        else listOf("এই সময়ে আপনি ", " ধার নিয়েছেন এবং ", " পরিশোধ করেছেন। ", "।")
    }
    val text = buildAnnotatedString {
        append(t[0])
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = c.Danger)) { append(UnitConverter.rupees(credit)) }
        append(t[1])
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = c.Success)) { append(UnitConverter.rupees(payment)) }
        append(t[2])
        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append("$dueLabel: ") }
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = c.Primary)) { append(UnitConverter.rupees(due)) }
        append(t[3])
    }
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.Surface)
            .border(BorderStroke(1.5.dp, Brush.linearGradient(listOf(Friendly.Violet, Friendly.Teal, Friendly.Sun))), shape)
            .padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Friendly.Violet, Friendly.Teal))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = c.TextPrimary)
    }
}

/** দুই রঙের ডোনাট — ঘুরে ঘুরে আঁকা হয়, পাশে লেজেন্ড ও শতকরা ভাগ */
@Composable
private fun DonutChart(credit: Double, payment: Double, creditLabel: String, paymentLabel: String) {
    val c = LocalKhataColors.current
    val total = (credit + payment).coerceAtLeast(1.0)
    val creditShare = (credit / total).toFloat()
    val sweepAnim = remember { Animatable(0f) }
    LaunchedEffect(credit, payment) { sweepAnim.snapTo(0f); sweepAnim.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(130.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = size.minDimension * 0.17f
                val pad = stroke / 2f
                val arcSize = Size(size.width - stroke, size.height - stroke)
                val gap = 6f
                val creditSweep = 360f * creditShare * sweepAnim.value
                val paySweep = 360f * (1f - creditShare) * sweepAnim.value
                drawArc(Color(0x14000000), 0f, 360f, false, Offset(pad, pad), arcSize, style = Stroke(stroke))
                if (creditSweep > gap) drawArc(Brush.sweepGradient(CreditBrush + CreditBrush.first()), -90f, creditSweep - gap, false, Offset(pad, pad), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                if (paySweep > gap) drawArc(Brush.sweepGradient(PaymentBrush + PaymentBrush.first()), -90f + creditSweep, paySweep - gap, false, Offset(pad, pad), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            Text("${(creditShare * 100).toInt()}%", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = CreditBrush[1])
        }
        Spacer(Modifier.width(18.dp))
        Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.weight(1f)) {
            LegendRow(CreditBrush[1], creditLabel, credit, creditShare)
            LegendRow(PaymentBrush[0], paymentLabel, payment, 1f - creditShare)
        }
    }
}

@Composable
private fun LegendRow(color: Color, label: String, amount: Double, share: Float) {
    val c = LocalKhataColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(RoundedCornerShape(5.dp)).background(color))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = c.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(UnitConverter.rupees(amount), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = c.TextPrimary, maxLines = 1)
        }
        Text("${(share * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = color)
    }
}

@Composable
private fun RankedShopCard(rank: Int, row: ShopReportRow, maxDue: Double, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val creditWord = sk?.creditFallback ?: s.creditFallback
    val paymentWord = sk?.paymentFallback ?: s.paymentFallback
    val owing = row.currentDue > 0
    val tone = if (owing) c.Danger else c.Success
    val (tileBg, tileFg) = FriendlyTiles.forKey(row.shopName)

    val medal: List<Color>? = when (rank) {
        1 -> listOf(Color(0xFFFFD86B), Color(0xFFF59E0B))
        2 -> listOf(Color(0xFFE5E7EB), Color(0xFF9CA3AF))
        3 -> listOf(Color(0xFFF6B07A), Color(0xFFC2703D))
        else -> null
    }

    Column(
        Modifier
            .fillMaxWidth()
            .colorShadow(tone, 22, 4)
            .clip(RoundedCornerShape(22.dp))
            .background(c.Surface)
            .bouncyClick(onClick)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // র‍্যাঙ্ক-ব্যাজ
            Box(
                Modifier.size(28.dp).clip(CircleShape).then(
                    if (medal != null) Modifier.background(Brush.linearGradient(medal)) else Modifier.background(c.ChipBg)
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(rank.toString(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold,
                    color = if (medal != null) Color.White else c.Muted)
            }
            Spacer(Modifier.width(10.dp))
            Box(Modifier.size(44.dp).background(tileBg, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                Icon(painterResource(ShopType.fromKey(row.shopType).iconRes), null, tint = tileFg, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(row.shopName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = c.TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    buildAnnotatedString {
                        append("$creditWord ")
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = c.Danger)) { append(UnitConverter.rupees(row.periodCredit)) }
                        append("  •  $paymentWord ")
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = c.Success)) { append(UnitConverter.rupees(row.periodPayment)) }
                    },
                    style = MaterialTheme.typography.bodySmall, color = c.TextSecondary
                )
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.clip(RoundedCornerShape(14.dp)).background(tone.copy(alpha = 0.13f)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text(UnitConverter.rupees(row.currentDue), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = tone)
            }
        }
        Spacer(Modifier.height(10.dp))
        // মোট বাকিতে এই কাস্টমারের ভাগ — রঙিন প্রগ্রেস বার
        val frac = (row.currentDue / maxDue).toFloat().coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(c.ChipBg)) {
            if (frac > 0f) Box(
                Modifier.fillMaxHeight().fillMaxWidth(fraction = frac).clip(RoundedCornerShape(3.dp))
                    .background(Brush.horizontalGradient(if (owing) CreditBrush else PaymentBrush))
            )
        }
    }
}

@Composable
private fun AgingGrid(aging: AgingBuckets, l30: String, l15: String, l7: String, l0: String) {
    val c = LocalKhataColors.current
    val total = aging.d30plus + aging.d15to30 + aging.d7to15 + aging.d0to7
    val tiles = listOf(
        Triple(l30, aging.d30plus, Color(0xFFFB5C7C)),
        Triple(l15, aging.d15to30, Color(0xFFFF9F43)),
        Triple(l7, aging.d7to15, Color(0xFFE6B800)),
        Triple(l0, aging.d0to7, Color(0xFF14B8A6))
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // একটানা রঙিন বার
        Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(c.ChipBg)) {
            if (total > 0) Row(Modifier.fillMaxSize()) {
                tiles.forEach { (_, amount, color) ->
                    if (amount > 0) Box(Modifier.fillMaxHeight().weight((amount / total).toFloat()).background(color))
                }
            }
        }
        tiles.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { (label, amount, color) ->
                    Row(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(20.dp))
                            .background(color.copy(alpha = 0.12f))
                            .padding(end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(6.dp).fillMaxHeight().background(color))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.padding(vertical = 14.dp)) {
                            Text(label, style = MaterialTheme.typography.labelLarge, color = c.TextSecondary)
                            Text(
                                UnitConverter.rupees(amount),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (amount > 0) color else c.Muted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelinePayment(tws: TransactionWithShop, langCode: String, isLast: Boolean, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        // বাম পাশে টাইমলাইন রেখা ও বিন্দু
        Column(Modifier.width(28.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.padding(top = 18.dp).size(14.dp).clip(CircleShape).background(Brush.linearGradient(PaymentBrush)))
            if (!isLast) Box(Modifier.width(2.dp).weight(1f).background(c.Success.copy(alpha = 0.25f)))
        }
        Row(
            Modifier
                .padding(bottom = 10.dp)
                .weight(1f)
                .clip(RoundedCornerShape(20.dp))
                .background(c.Surface)
                .bouncyClick(onClick)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = c.TextPrimary)
                Text(UnitConverter.dateShort(tws.txn.date, langCode), style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(PaymentBrush)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text("+" + UnitConverter.rupees(tws.txn.amount), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}
