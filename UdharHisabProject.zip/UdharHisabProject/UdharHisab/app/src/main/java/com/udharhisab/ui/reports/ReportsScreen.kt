package com.udharhisab.ui.reports

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.rememberCountUp
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalShopkeeperLabels

/**
 * 🚀 ফিউচারিস্টিক রিপোর্ট — গাঢ় নীল-সবুজ "মহাকাশ" ব্যাকগ্রাউন্ড, ঝাপসা কাচের (glass) কার্ড,
 * নিয়ন আলোর ঝলকে আঁকা রিং ও বার, আর সব অঙ্ক/রিং অ্যানিমেশনে বেড়ে ওঠে।
 * এই পেজ থিম (লাইট/ডার্ক) যা-ই হোক, নিজের গাঢ় নিয়ন রঙে চলে।
 */
private object Neon {
    val Cyan = Color(0xFF22D3EE)
    val Mint = Color(0xFF34D399)
    val Rose = Color(0xFFFB7185)
    val Violet = Color(0xFFA78BFA)
    val Amber = Color(0xFFFBBF24)
    val Lime = Color(0xFFBEF264)
    val BgTop = Color(0xFF050B1A)
    val BgMid = Color(0xFF0A1B3D)
    val BgBottom = Color(0xFF06262B)
    val TextDim = Color(0xFFA9B8D0)
}

/** ঝাপসা কাচের মতো কার্ড — হালকা সাদা জমি + রঙিন আলোর বর্ডার */
private fun Modifier.glass(radius: Int = 24, glow: Color = Neon.Cyan): Modifier {
    val shape = RoundedCornerShape(radius.dp)
    return this
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f))))
        .border(1.dp, Brush.linearGradient(listOf(glow.copy(alpha = 0.65f), Neon.Violet.copy(alpha = 0.15f), glow.copy(alpha = 0.35f))), shape)
}

private fun glowText(color: Color, blur: Float = 22f) = TextStyle(shadow = Shadow(color.copy(alpha = 0.85f), Offset.Zero, blur))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit
) {
    val vm: ReportsViewModel = viewModel { ReportsViewModel(container.repo) }
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    val period by vm.period.collectAsState()
    val totals by vm.totals.collectAsState()
    val shopRows by vm.shopRows.collectAsState()
    val recentPayments by vm.recentPayments.collectAsState()
    val currentDue by vm.currentTotalDue.collectAsState()
    val aging by vm.aging.collectAsState()

    val dueLabel = sk?.pdfDueLabel ?: s.reportCurrentDue
    val creditLabel = sk?.pdfTotalCreditLabel ?: s.reportTotalCredit
    val paymentLabel = sk?.pdfTotalPaymentLabel ?: s.reportTotalPayment

    fun periodLabel(p: ReportPeriod) = when (p) {
        ReportPeriod.D7 -> s.period7d
        ReportPeriod.D15 -> s.period15d
        ReportPeriod.D30 -> s.period30d
        ReportPeriod.M3 -> s.period3m
        ReportPeriod.Y1 -> s.period1y
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Neon.BgTop, Neon.BgMid, Neon.BgBottom)))
    ) {
        // ── অরোরা আলো: কোণায় ঝাপসা রঙিন আভা ──
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Brush.radialGradient(listOf(Neon.Violet.copy(alpha = 0.32f), Color.Transparent), Offset(size.width * 0.05f, size.height * 0.08f), size.width * 0.7f),
                size.width * 0.7f, Offset(size.width * 0.05f, size.height * 0.08f))
            drawCircle(Brush.radialGradient(listOf(Neon.Cyan.copy(alpha = 0.25f), Color.Transparent), Offset(size.width * 0.98f, size.height * 0.35f), size.width * 0.65f),
                size.width * 0.65f, Offset(size.width * 0.98f, size.height * 0.35f))
            drawCircle(Brush.radialGradient(listOf(Neon.Mint.copy(alpha = 0.20f), Color.Transparent), Offset(size.width * 0.1f, size.height * 0.85f), size.width * 0.6f),
                size.width * 0.6f, Offset(size.width * 0.1f, size.height * 0.85f))
        }

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = {
                        Text(s.reportsTitle, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge.merge(glowText(Neon.Cyan, 18f)))
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        scrolledContainerColor = Color.Transparent,
                        titleContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ── সময় বাছাই: কাচের ক্যাপসুল, বাছাটা নিয়ন গ্রেডিয়েন্টে জ্বলে ──
                item {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ReportPeriod.entries.forEach { p ->
                            val selected = period == p
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .then(
                                        if (selected) Modifier.background(Brush.linearGradient(listOf(Neon.Cyan, Neon.Mint)))
                                        else Modifier.background(Color.White.copy(alpha = 0.07f)).border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(20.dp))
                                    )
                                    .clickable { vm.setPeriod(p) }
                                    .padding(horizontal = 16.dp, vertical = 9.dp)
                            ) {
                                Text(periodLabel(p), fontWeight = FontWeight.Bold,
                                    color = if (selected) Color(0xFF04141F) else Color.White.copy(alpha = 0.85f),
                                    style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }

                // ── হিরো: নিয়ন রিং (% পরিশোধ) + মাঝে বর্তমান বাকি ──
                item { HeroPanel(dueLabel, currentDue, totals.totalCredit, totals.totalPayment, totals.txnCount, creditLabel, paymentLabel, s.reportTxnCount) }

                // ── AI-ধাঁচের স্মার্ট সারাংশ ──
                item { InsightPanel(totals.totalCredit, totals.totalPayment, currentDue, dueLabel) }

                // ── নিয়ন বার চার্ট ──
                item {
                    GlassSection(title = s.reportChartTitle, icon = Icons.Default.TrendingUp, glow = Neon.Cyan) {
                        if (totals.totalCredit + totals.totalPayment <= 0.0) {
                            Text(s.reportNoData, color = Neon.TextDim, modifier = Modifier.padding(vertical = 16.dp))
                        } else {
                            NeonBars(totals.totalCredit, totals.totalPayment, creditLabel, paymentLabel)
                        }
                    }
                }

                // ── কাস্টমার/দোকানভিত্তিক বাকি ──
                item { NeonHeader(Icons.Default.Storefront, sk?.reportShopWiseTitle ?: s.reportShopWiseTitle, shopRows.size.takeIf { it > 0 }) }
                if (shopRows.isEmpty()) {
                    item { Text(s.reportNoData, color = Neon.TextDim) }
                } else {
                    items(shopRows.take(10), key = { "shop_${it.shopId}" }) { row ->
                        ShopGlassCard(row, onClick = { onOpenShop(row.shopId) })
                    }
                }

                // ── পুরনো বাকি ──
                item { NeonHeader(Icons.Default.Schedule, s.reportAgingTitle, null) }
                item {
                    Column(Modifier.fillMaxWidth().glass(24, Neon.Violet).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        AgingEnergyBar(aging)
                        AgingRow(Neon.Rose, s.reportAging30plus, aging.d30plus)
                        AgingRow(Neon.Amber, s.reportAging15to30, aging.d15to30)
                        AgingRow(Neon.Lime, s.reportAging7to15, aging.d7to15)
                        AgingRow(Neon.Mint, s.reportAging0to7, aging.d0to7)
                    }
                }

                // ── সাম্প্রতিক পরিশোধ ──
                item { NeonHeader(Icons.Default.Payments, s.reportRecentPaymentsTitle, recentPayments.size.takeIf { it > 0 }) }
                if (recentPayments.isEmpty()) {
                    item { Text(s.reportNoData, color = Neon.TextDim) }
                } else {
                    items(recentPayments, key = { "payment_${it.txn.id}" }) { tws ->
                        RecentPaymentGlass(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) })
                    }
                }
            }
        }
    }
}

@Composable
private fun NeonHeader(icon: ImageVector, title: String, count: Int?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(32.dp).clip(CircleShape).background(Neon.Cyan.copy(alpha = 0.15f)).border(1.dp, Neon.Cyan.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Neon.Cyan, modifier = Modifier.size(17.dp)) }
        Spacer(Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
        if (count != null) {
            Spacer(Modifier.width(8.dp))
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(Neon.Cyan, Neon.Mint))).padding(horizontal = 9.dp, vertical = 2.dp)) {
                Text(count.toString(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = Color(0xFF04141F))
            }
        }
    }
}

@Composable
private fun GlassSection(title: String, icon: ImageVector, glow: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().glass(24, glow).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = glow, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
        Spacer(Modifier.height(14.dp))
        content()
    }
}

/** মাঝখানে বর্তমান বাকি, চারপাশে জ্বলজ্বলে রিং (কত % শোধ হয়েছে) — নিচে তিনটা নিয়ন স্ট্যাট */
@Composable
private fun HeroPanel(
    dueLabel: String, due: Double, credit: Double, payment: Double, txnCount: Int,
    creditLabel: String, paymentLabel: String, txnLabel: String
) {
    val percent = if (credit > 0) (payment / credit).coerceIn(0.0, 1.0).toFloat() else 0f
    val anim = remember { Animatable(0f) }
    LaunchedEffect(percent) { anim.animateTo(percent, tween(1200, easing = FastOutSlowInEasing)) }
    val shownDue = rememberCountUp(due)
    val s = LocalStrings.current

    Column(Modifier.fillMaxWidth().glass(30, Neon.Cyan).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = size.minDimension * 0.085f
                val pad = stroke * 1.4f
                val arcSize = Size(size.width - 2 * pad, size.height - 2 * pad)
                val tl = Offset(pad, pad)
                // বাইরের ফিকে গাইড-রিং
                drawCircle(Color.White.copy(alpha = 0.05f), size.minDimension / 2f - stroke * 0.3f, style = Stroke(1.5f))
                // ট্র্যাক
                drawArc(Color.White.copy(alpha = 0.09f), 0f, 360f, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                val sweep = 360f * anim.value
                if (sweep > 0.5f) {
                    val brush = Brush.sweepGradient(listOf(Neon.Cyan, Neon.Mint, Neon.Violet, Neon.Cyan), center)
                    rotate(-90f) {
                        // ঝলক (glow) — মোটা, ফিকে স্তর
                        drawArc(brush, 0f, sweep, false, tl, arcSize, alpha = 0.18f, style = Stroke(stroke * 2.2f, cap = StrokeCap.Round))
                        drawArc(brush, 0f, sweep, false, tl, arcSize, alpha = 0.35f, style = Stroke(stroke * 1.5f, cap = StrokeCap.Round))
                        drawArc(brush, 0f, sweep, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(dueLabel, style = MaterialTheme.typography.labelLarge, color = Neon.TextDim, fontWeight = FontWeight.SemiBold)
                Text(
                    UnitConverter.rupees(shownDue),
                    style = MaterialTheme.typography.headlineLarge.merge(glowText(Neon.Cyan, 26f)),
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    maxLines = 1
                )
                Spacer(Modifier.height(4.dp))
                val pct = (percent * 100).toInt()
                Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Neon.Mint.copy(alpha = 0.16f)).border(1.dp, Neon.Mint.copy(alpha = 0.5f), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text(
                        when (s.code) { "en" -> "$pct% paid"; "hi" -> "$pct% चुकाया"; else -> "$pct% পরিশোধিত" },
                        style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = Neon.Mint
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonStat(Modifier.weight(1f).fillMaxHeight(), Icons.Default.TrendingUp, creditLabel, UnitConverter.rupees(credit), Neon.Rose)
            NeonStat(Modifier.weight(1f).fillMaxHeight(), Icons.Default.Payments, paymentLabel, UnitConverter.rupees(payment), Neon.Mint)
            NeonStat(Modifier.weight(1f).fillMaxHeight(), Icons.Default.Receipt, txnLabel, txnCount.toString(), Neon.Violet)
        }
    }
}

@Composable
private fun NeonStat(modifier: Modifier, icon: ImageVector, label: String, value: String, color: Color) {
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            .padding(10.dp)
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = Neon.TextDim, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.titleMedium.merge(glowText(color, 14f)), fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun InsightPanel(credit: Double, payment: Double, due: Double, dueLabel: String) {
    val s = LocalStrings.current
    val shopkeeper = LocalShopkeeperLabels.current != null
    val t: List<String> = when (s.code) {
        "en" -> if (shopkeeper) listOf("In this period you gave ", " on credit and received ", " in payments. ", ".")
        else listOf("In this period you took ", " on credit and paid back ", ". ", ".")
        "hi" -> if (shopkeeper) listOf("इस अवधि में आपने ", " उधार दिया और ", " भुगतान पाया। ", "।")
        else listOf("इस अवधि में आपने ", " उधार लिया और ", " चुकाया। ", "।")
        else -> if (shopkeeper) listOf("এই সময়ে আপনি ", " বাকি দিয়েছেন এবং ", " পরিশোধ পেয়েছেন। ", "।")
        else listOf("এই সময়ে আপনি ", " ধার নিয়েছেন এবং ", " পরিশোধ করেছেন। ", "।")
    }
    val text = buildAnnotatedString {
        append(t[0])
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = Neon.Rose)) { append(UnitConverter.rupees(credit)) }
        append(t[1])
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = Neon.Mint)) { append(UnitConverter.rupees(payment)) }
        append(t[2])
        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append("$dueLabel: ") }
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = Neon.Cyan)) { append(UnitConverter.rupees(due)) }
        append(t[3])
    }
    Row(Modifier.fillMaxWidth().glass(22, Neon.Violet).padding(16.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Neon.Violet, Neon.Cyan))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.92f))
    }
}

/** আলোর ঝলকসহ দুটো বার, পেছনে হালকা গ্রিড — নিচ থেকে বেড়ে ওঠে */
@Composable
private fun NeonBars(credit: Double, payment: Double, creditLabel: String, paymentLabel: String) {
    val grow = remember { Animatable(0f) }
    LaunchedEffect(credit, payment) { grow.snapTo(0f); grow.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    val maxV = maxOf(credit, payment, 1.0)

    Column {
        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
            val w = size.width
            val h = size.height
            // গ্রিড লাইন
            for (i in 0..4) {
                val y = h * i / 4f
                drawLine(Color.White.copy(alpha = if (i == 4) 0.25f else 0.07f), Offset(0f, y), Offset(w, y), 1.5f)
            }
            val barW = w * 0.2f
            fun bar(centerX: Float, value: Double, color: Color) {
                val bh = (h * (value / maxV).toFloat() * grow.value).coerceAtLeast(if (value > 0) 6f else 0f)
                val left = centerX - barW / 2
                val top = h - bh
                // ঝলক-স্তর
                for (k in 3 downTo 1) {
                    drawRoundRect(color.copy(alpha = 0.07f * k), Offset(left - k * 5f, top - k * 5f), Size(barW + k * 10f, bh + k * 5f), CornerRadius(22f + k * 4f))
                }
                drawRoundRect(Brush.verticalGradient(listOf(color, color.copy(alpha = 0.25f)), top, h), Offset(left, top), Size(barW, bh), CornerRadius(18f))
                drawRoundRect(Color.White.copy(alpha = 0.9f), Offset(left, top), Size(barW, 5f), CornerRadius(5f))
            }
            bar(w * 0.27f, credit, Neon.Rose)
            bar(w * 0.73f, payment, Neon.Mint)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(UnitConverter.rupees(credit), style = MaterialTheme.typography.titleMedium.merge(glowText(Neon.Rose, 14f)), fontWeight = FontWeight.ExtraBold, color = Neon.Rose)
                Text(creditLabel, style = MaterialTheme.typography.labelSmall, color = Neon.TextDim, maxLines = 1)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(UnitConverter.rupees(payment), style = MaterialTheme.typography.titleMedium.merge(glowText(Neon.Mint, 14f)), fontWeight = FontWeight.ExtraBold, color = Neon.Mint)
                Text(paymentLabel, style = MaterialTheme.typography.labelSmall, color = Neon.TextDim, maxLines = 1)
            }
        }
    }
}

@Composable
private fun AgingEnergyBar(aging: AgingBuckets) {
    val total = aging.d30plus + aging.d15to30 + aging.d7to15 + aging.d0to7
    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.08f))) {
        if (total > 0) {
            Row(Modifier.fillMaxSize()) {
                listOf(aging.d30plus to Neon.Rose, aging.d15to30 to Neon.Amber, aging.d7to15 to Neon.Lime, aging.d0to7 to Neon.Mint).forEach { (amount, color) ->
                    if (amount > 0) Box(Modifier.fillMaxHeight().weight((amount / total).toFloat()).background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.6f)))))
                }
            }
        }
    }
}

@Composable
private fun AgingRow(dot: Color, label: String, amount: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(dot).border(3.dp, dot.copy(alpha = 0.3f), CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = 0.9f))
        }
        Text(
            UnitConverter.rupees(amount),
            style = MaterialTheme.typography.titleSmall.merge(if (amount > 0) glowText(dot, 12f) else TextStyle()),
            fontWeight = if (amount > 0) FontWeight.ExtraBold else FontWeight.Normal,
            color = if (amount > 0) dot else Neon.TextDim
        )
    }
}

@Composable
private fun ShopGlassCard(row: ShopReportRow, onClick: () -> Unit) {
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val creditWord = sk?.creditFallback ?: s.creditFallback
    val paymentWord = sk?.paymentFallback ?: s.paymentFallback
    val owing = row.currentDue > 0
    val tone = if (owing) Neon.Rose else Neon.Mint

    Row(
        Modifier.fillMaxWidth().glass(22, tone).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(Neon.Cyan.copy(alpha = 0.12f)).border(1.5.dp, Brush.linearGradient(listOf(Neon.Cyan, Neon.Violet)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(ShopType.fromKey(row.shopType).iconRes), null, tint = Neon.Cyan, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(row.shopName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(
                buildAnnotatedString {
                    append("$creditWord ")
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Neon.Rose)) { append(UnitConverter.rupees(row.periodCredit)) }
                    append("  •  $paymentWord ")
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Neon.Mint)) { append(UnitConverter.rupees(row.periodPayment)) }
                },
                style = MaterialTheme.typography.bodySmall, color = Neon.TextDim
            )
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.clip(RoundedCornerShape(12.dp)).background(tone.copy(alpha = 0.14f)).border(1.dp, tone.copy(alpha = 0.55f), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(UnitConverter.rupees(row.currentDue), style = MaterialTheme.typography.titleMedium.merge(glowText(tone, 12f)), fontWeight = FontWeight.ExtraBold, color = tone)
        }
    }
}

@Composable
private fun RecentPaymentGlass(tws: TransactionWithShop, langCode: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(20, Neon.Mint).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Neon.Mint.copy(alpha = 0.15f)).border(1.dp, Neon.Mint.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Payments, null, tint = Neon.Mint, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tws.shopName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.White)
            Text(UnitConverter.dateShort(tws.txn.date, langCode), style = MaterialTheme.typography.bodySmall, color = Neon.TextDim)
        }
        Text("+" + UnitConverter.rupees(tws.txn.amount), style = MaterialTheme.typography.titleMedium.merge(glowText(Neon.Mint, 14f)), fontWeight = FontWeight.ExtraBold, color = Neon.Mint)
    }
}
