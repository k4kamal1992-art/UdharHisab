package com.udharhisab.ui.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit
) {
    val vm: ReportsViewModel = viewModel { ReportsViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    val period by vm.period.collectAsState()
    val totals by vm.totals.collectAsState()
    val shopRows by vm.shopRows.collectAsState()
    val recentPayments by vm.recentPayments.collectAsState()
    val currentDue by vm.currentTotalDue.collectAsState()
    val aging by vm.aging.collectAsState()

    var periodMenuOpen by remember { mutableStateOf(false) }

    fun periodLabel(p: ReportPeriod) = when (p) {
        ReportPeriod.D7 -> s.period7d
        ReportPeriod.D15 -> s.period15d
        ReportPeriod.D30 -> s.period30d
        ReportPeriod.M3 -> s.period3m
        ReportPeriod.Y1 -> s.period1y
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.reportsTitle) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ── সময় নির্বাচন ──
            item {
                Spacer(Modifier.height(4.dp))
                Box {
                    AssistChip(
                        onClick = { periodMenuOpen = true },
                        leadingIcon = {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        label = { Text("${periodLabel(period)} ▾") }
                    )
                    DropdownMenu(expanded = periodMenuOpen, onDismissRequest = { periodMenuOpen = false }) {
                        ReportPeriod.entries.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(periodLabel(p)) },
                                onClick = { vm.setPeriod(p); periodMenuOpen = false }
                            )
                        }
                    }
                }
            }

            // ── হিরো সামারি কার্ড — বর্তমান মোট বাকি বড় করে, ভেতরে মিনি-স্ট্যাট ──
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = c.Primary),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            s.reportCurrentDue,
                            style = MaterialTheme.typography.displaySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            UnitConverter.rupees(currentDue),
                            style = MaterialTheme.typography.displayLarge,
                            color = Color.White
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HeroMiniStat(
                                Modifier.weight(1f), Icons.Default.TrendingUp,
                                s.reportTotalCredit, UnitConverter.rupees(totals.totalCredit)
                            )
                            HeroMiniStat(
                                Modifier.weight(1f), Icons.Default.Payments,
                                s.reportTotalPayment, UnitConverter.rupees(totals.totalPayment)
                            )
                            HeroMiniStat(
                                Modifier.weight(1f), Icons.Default.Receipt,
                                s.reportTxnCount, totals.txnCount.toString()
                            )
                        }
                    }
                }
            }

            // ── স্মার্ট সামারি ──
            item {
                val summaryText = when (s.code) {
                    "en" -> "In this period you took ${UnitConverter.rupees(totals.totalCredit)} in credit and received ${UnitConverter.rupees(totals.totalPayment)} in payments. ${s.reportCurrentDue}: ${UnitConverter.rupees(currentDue)}."
                    "hi" -> "इस समय-सीमा में आपने ${UnitConverter.rupees(totals.totalCredit)} उधार दिया और ${UnitConverter.rupees(totals.totalPayment)} भुगतान पाया। ${s.reportCurrentDue}: ${UnitConverter.rupees(currentDue)}।"
                    else -> "এই সময়ে আপনি ${UnitConverter.rupees(totals.totalCredit)} ধার দিয়েছেন এবং ${UnitConverter.rupees(totals.totalPayment)} পরিশোধ পেয়েছেন। ${s.reportCurrentDue}: ${UnitConverter.rupees(currentDue)}।"
                }
                Card(colors = CardDefaults.cardColors(containerColor = c.ChipBg)) {
                    Text(
                        summaryText,
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // ── বার চার্ট + % পরিশোধিত প্রোগ্রেস বার ──
            item {
                Card {
                    Column(Modifier.padding(vertical = 16.dp)) {
                        Text(s.reportChartTitle, style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(horizontal = 16.dp))
                        Spacer(Modifier.height(8.dp))
                        CreditPaymentBarChart(
                            credit = totals.totalCredit,
                            payment = totals.totalPayment,
                            creditColor = c.Danger,
                            paymentColor = c.Success,
                            creditLabel = s.reportTotalCredit,
                            paymentLabel = s.reportTotalPayment
                        )
                        Spacer(Modifier.height(16.dp))
                        PaidRatioBar(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            credit = totals.totalCredit,
                            payment = totals.totalPayment
                        )
                    }
                }
            }

            // ── দোকানভিত্তিক বাকি ──
            item {
                SectionHeader(Icons.Default.Storefront, sk?.reportShopWiseTitle ?: s.reportShopWiseTitle, shopRows.size)
            }
            if (shopRows.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                items(shopRows.take(10), key = { "shop_${it.shopId}" }) { row ->
                    ShopReportCard(row, onClick = { onOpenShop(row.shopId) })
                }
            }

            // ── পুরনো বাকি (Aging) ──
            item {
                SectionHeader(Icons.Default.Schedule, s.reportAgingTitle, null)
            }
            item {
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AgingStackedBar(aging, c.Danger, Color(0xFFE0902E), Color(0xFFD9B613), c.Success)
                        AgingRow(c.Danger, s.reportAging30plus, aging.d30plus)
                        AgingRow(Color(0xFFE0902E), s.reportAging15to30, aging.d15to30)
                        AgingRow(Color(0xFFD9B613), s.reportAging7to15, aging.d7to15)
                        AgingRow(c.Success, s.reportAging0to7, aging.d0to7)
                    }
                }
            }

            // ── সাম্প্রতিক পরিশোধ ──
            item {
                SectionHeader(Icons.Default.Payments, s.reportRecentPaymentsTitle, recentPayments.size.takeIf { it > 0 })
            }
            if (recentPayments.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                items(recentPayments, key = { "payment_${it.txn.id}" }) { tws ->
                    RecentPaymentRow(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) })
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, count: Int?) {
    val c = LocalKhataColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (count != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.clip(RoundedCornerShape(10.dp)).background(c.ChipBg).padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(count.toString(), style = MaterialTheme.typography.labelSmall, color = c.Primary)
            }
        }
    }
}

@Composable
private fun HeroMiniStat(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 10.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(16.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun PaidRatioBar(modifier: Modifier = Modifier, credit: Double, payment: Double) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val percent = if (credit > 0) ((payment / credit) * 100).coerceIn(0.0, 100.0) else 0.0
    val label = if (s.code == "en") "${percent.toInt()}% paid back"
                else if (s.code == "hi") "${percent.toInt()}% चुकाया गया"
                else "${percent.toInt()}% পরিশোধিত"

    Column(modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(c.ChipBg)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction = (percent / 100.0).toFloat().coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(c.Success)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = c.Muted)
    }
}

@Composable
private fun AgingStackedBar(aging: AgingBuckets, c30: Color, c15: Color, c7: Color, c0: Color) {
    val c = LocalKhataColors.current
    val total = aging.d30plus + aging.d15to30 + aging.d7to15 + aging.d0to7
    Box(
        Modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(c.ChipBg)
    ) {
        if (total > 0) {
            Row(Modifier.fillMaxSize()) {
                val segments = listOf(aging.d30plus to c30, aging.d15to30 to c15, aging.d7to15 to c7, aging.d0to7 to c0)
                segments.forEach { (amount, color) ->
                    if (amount > 0) {
                        Box(
                            Modifier
                                .fillMaxHeight()
                                .weight((amount / total).toFloat())
                                .background(color)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopReportCard(row: ShopReportRow, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium),
        onClick = onClick
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(c.ChipBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(ShopType.fromKey(row.shopType).iconRes),
                    contentDescription = null,
                    tint = c.Primary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(row.shopName, style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${s.reportTotalCredit}: ${UnitConverter.rupees(row.periodCredit)} • " +
                        "${s.reportTotalPayment}: ${UnitConverter.rupees(row.periodPayment)}",
                    style = MaterialTheme.typography.bodySmall, color = c.Muted
                )
            }
            Text(
                UnitConverter.rupees(row.currentDue),
                style = MaterialTheme.typography.titleMedium,
                color = if (row.currentDue > 0) c.Danger else c.Success
            )
        }
    }
}

@Composable
private fun AgingRow(dotColor: Color, label: String, amount: Double) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dotColor))
            Spacer(Modifier.width(8.dp))
            Text(label)
        }
        Text(UnitConverter.rupees(amount), style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun RecentPaymentRow(tws: TransactionWithShop, langCode: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Card(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleSmall)
                Text(UnitConverter.dateShort(tws.txn.date, langCode),
                    style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(UnitConverter.rupees(tws.txn.amount), color = c.Success)
        }
    }
}
