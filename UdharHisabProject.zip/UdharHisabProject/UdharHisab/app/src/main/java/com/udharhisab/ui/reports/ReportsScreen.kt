package com.udharhisab.ui.reports

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

/** ⭐ কার্ডের সাধারণ চেহারা — সাদা জমি, হালকা বর্ডার, ছায়া ছাড়া (পরিষ্কার, আধুনিক) */
@Composable
private fun cardColors() = CardDefaults.cardColors(containerColor = LocalKhataColors.current.Surface)

@Composable
private fun cardBorder() = BorderStroke(1.dp, LocalKhataColors.current.Divider)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit
) {
    val vm: ReportsViewModel = viewModel { ReportsViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    val period by vm.period.collectAsState()
    val totals by vm.totals.collectAsState()
    val shopRows by vm.shopRows.collectAsState()
    val recentPayments by vm.recentPayments.collectAsState()
    val currentDue by vm.currentTotalDue.collectAsState()
    val aging by vm.aging.collectAsState()

    // দোকানদারের ভাষা: "মোট বাকি দিয়েছি / মোট পরিশোধ পেয়েছি / বর্তমান পাওনা"
    val dueLabel = sk?.pdfDueLabel ?: s.reportCurrentDue
    val creditLabel = sk?.pdfTotalCreditLabel ?: s.reportTotalCredit
    val paymentLabel = sk?.pdfTotalPaymentLabel ?: s.reportTotalPayment

    fun periodLabel(p: ReportPeriod) = when (p) {
        ReportPeriod.D7 -> s.period7d
        ReportPeriod.D15 -> s.period15d
        ReportPeriod.D30 -> s.period30d
        ReportPeriod.M3 -> s.period3m
        ReportPeriod.Y1 -> s.period1y
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.reportsTitle, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── সময় নির্বাচন — এক ট্যাপে বাছা যায় (আগে ড্রপডাউন ছিল) ──
            item {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ReportPeriod.entries.forEach { p ->
                        FilterChip(
                            selected = period == p,
                            onClick = { vm.setPeriod(p) },
                            label = { Text(periodLabel(p), fontWeight = FontWeight.SemiBold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = c.Primary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // ── হিরো কার্ড — গ্রেডিয়েন্ট, বড় বোল্ড অঙ্ক, নিচে তিনটা মিনি-স্ট্যাট ──
            item {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.large)
                        .background(Brush.linearGradient(listOf(c.Primary, c.PrimaryDark)))
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            dueLabel,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            UnitConverter.rupees(currentDue),
                            style = MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(
                            Modifier.height(IntrinsicSize.Max),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            HeroMiniStat(Modifier.weight(1f).fillMaxHeight(), Icons.Default.TrendingUp, creditLabel, UnitConverter.rupees(totals.totalCredit))
                            HeroMiniStat(Modifier.weight(1f).fillMaxHeight(), Icons.Default.Payments, paymentLabel, UnitConverter.rupees(totals.totalPayment))
                            HeroMiniStat(Modifier.weight(1f).fillMaxHeight(), Icons.Default.Receipt, s.reportTxnCount, totals.txnCount.toString())
                        }
                    }
                }
            }

            // ── স্মার্ট সামারি — অঙ্কগুলো রঙিন ও বোল্ড ──
            item { InsightCard(totals.totalCredit, totals.totalPayment, currentDue, dueLabel) }

            // ── বার চার্ট + % পরিশোধিত ──
            item {
                Card(colors = cardColors(), border = cardBorder(), elevation = CardDefaults.cardElevation(0.dp)) {
                    Column(Modifier.padding(vertical = 16.dp)) {
                        Text(
                            s.reportChartTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        if (totals.totalCredit + totals.totalPayment <= 0.0) {
                            // ⭐ কোনো লেনদেন নেই — বড় ফাঁকা জায়গার বদলে ছোট সুন্দর খালি-অবস্থা
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.BarChart, null, tint = c.Muted, modifier = Modifier.size(36.dp))
                                Spacer(Modifier.height(6.dp))
                                Text(s.reportNoData, color = c.Muted, style = MaterialTheme.typography.bodyMedium)
                            }
                        } else {
                            CreditPaymentBarChart(
                                credit = totals.totalCredit,
                                payment = totals.totalPayment,
                                creditColor = c.Danger,
                                paymentColor = c.Success,
                                creditLabel = creditLabel,
                                paymentLabel = paymentLabel
                            )
                            Spacer(Modifier.height(16.dp))
                            PaidRatioBar(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                credit = totals.totalCredit,
                                payment = totals.totalPayment
                            )
                        }
                    }
                }
            }

            // ── কাস্টমার/দোকানভিত্তিক বাকি ──
            item {
                SectionHeader(Icons.Default.Storefront, sk?.reportShopWiseTitle ?: s.reportShopWiseTitle, shopRows.size)
            }
            if (shopRows.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                items(shopRows.take(10), key = { "shop_${it.shopId}" }) { row ->
                    ShopReportCard(row, onClick = { onOpenShop(row.shopId) })
                }
            }

            // ── পুরনো বাকি (Aging) ──
            item { SectionHeader(Icons.Default.Schedule, s.reportAgingTitle, null) }
            item {
                Card(colors = cardColors(), border = cardBorder(), elevation = CardDefaults.cardElevation(0.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        AgingStackedBar(aging, c.Danger, Color(0xFFE0902E), Color(0xFFD9B613), c.Success)
                        AgingRow(c.Danger, s.reportAging30plus, aging.d30plus)
                        AgingRow(Color(0xFFE0902E), s.reportAging15to30, aging.d15to30)
                        AgingRow(Color(0xFFD9B613), s.reportAging7to15, aging.d7to15)
                        AgingRow(c.Success, s.reportAging0to7, aging.d0to7)
                    }
                }
            }

            // ── সাম্প্রতিক পরিশোধ ──
            item {
                SectionHeader(Icons.Default.Payments, s.reportRecentPaymentsTitle, recentPayments.size.takeIf { it > 0 })
            }
            if (recentPayments.isEmpty()) {
                item { Text(s.reportNoData, color = c.Muted) }
            } else {
                items(recentPayments, key = { "payment_${it.txn.id}" }) { tws ->
                    RecentPaymentRow(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) })
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(icon: ImageVector, title: String, count: Int?) {
    val c = LocalKhataColors.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(30.dp).clip(CircleShape).background(c.ChipBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = c.TextPrimary)
        if (count != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.clip(RoundedCornerShape(10.dp)).background(c.Primary).padding(horizontal = 9.dp, vertical = 2.dp)
            ) {
                Text(count.toString(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
private fun InsightCard(credit: Double, payment: Double, due: Double, dueLabel: String) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val shopkeeper = LocalShopkeeperLabels.current != null

    // (শুরু, ১ম অঙ্কের পর, ২য় অঙ্কের পর, শেষে)
    val t: List<String> = when (s.code) {
        "en" -> if (shopkeeper)
            listOf("In this period you gave ", " on credit and received ", " in payments. ", ".")
        else listOf("In this period you took ", " on credit and paid back ", ". ", ".")
        "hi" -> if (shopkeeper)
            listOf("इस अवधि में आपने ", " उधार दिया और ", " भुगतान पाया। ", "।")
        else listOf("इस अवधि में आपने ", " उधार लिया और ", " चुकाया। ", "।")
        else -> if (shopkeeper)
            listOf("এই সময়ে আপনি ", " বাকি দিয়েছেন এবং ", " পরিশোধ পেয়েছেন। ", "।")
        else listOf("এই সময়ে আপনি ", " ধার নিয়েছেন এবং ", " পরিশোধ করেছেন। ", "।")
    }

    val text = buildAnnotatedString {
        append(t[0])
        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = c.Danger)) { append(UnitConverter.rupees(credit)) }
        append(t[1])
        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = c.Success)) { append(UnitConverter.rupees(payment)) }
        append(t[2])
        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append("$dueLabel: ") }
        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = c.Primary)) { append(UnitConverter.rupees(due)) }
        append(t[3])
    }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(c.ChipBg)
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(Icons.Default.Insights, contentDescription = null, tint = c.Primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = c.TextPrimary)
    }
}

@Composable
private fun HeroMiniStat(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    value: String
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 10.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.9f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.weight(1f))
        Text(
            value,
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun PaidRatioBar(modifier: Modifier = Modifier, credit: Double, payment: Double) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val percent = if (credit > 0) ((payment / credit) * 100).coerceIn(0.0, 100.0) else 0.0
    val label = if (s.code == "en") "${percent.toInt()}% paid back"
                else if (s.code == "hi") "${percent.toInt()}% चुकाया गया"
                else "${percent.toInt()}% পরিশোধিত"

    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = c.Success)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(c.ChipBg)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction = (percent / 100.0).toFloat().coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(c.Success)
            )
        }
    }
}

@Composable
private fun AgingStackedBar(aging: AgingBuckets, c30: Color, c15: Color, c7: Color, c0: Color) {
    val c = LocalKhataColors.current
    val total = aging.d30plus + aging.d15to30 + aging.d7to15 + aging.d0to7
    Box(
        Modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(c.ChipBg)
    ) {
        if (total > 0) {
            Row(Modifier.fillMaxSize()) {
                val segments = listOf(aging.d30plus to c30, aging.d15to30 to c15, aging.d7to15 to c7, aging.d0to7 to c0)
                segments.forEach { (amount, color) ->
                    if (amount > 0) {
                        Box(
                            Modifier
                                .fillMaxHeight()
                                .weight((amount / total).toFloat())
                                .background(color)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopReportCard(row: ShopReportRow, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val creditWord = sk?.creditFallback ?: s.creditFallback
    val paymentWord = sk?.paymentFallback ?: s.paymentFallback
    val owing = row.currentDue > 0
    val amountColor = if (owing) c.Danger else c.Success

    Card(
        modifier = Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium),
        onClick = onClick,
        colors = cardColors(),
        border = cardBorder(),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(c.ChipBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(ShopType.fromKey(row.shopType).iconRes),
                    contentDescription = null,
                    tint = c.Primary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    row.shopName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = c.TextPrimary,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    buildAnnotatedString {
                        append("$creditWord ")
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, color = c.Danger)) {
                            append(UnitConverter.rupees(row.periodCredit))
                        }
                        append("  •  $paymentWord ")
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, color = c.Success)) {
                            append(UnitConverter.rupees(row.periodPayment))
                        }
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = c.TextSecondary
                )
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(amountColor.copy(alpha = 0.12f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    UnitConverter.rupees(row.currentDue),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = amountColor
                )
            }
        }
    }
}

@Composable
private fun AgingRow(dotColor: Color, label: String, amount: Double) {
    val c = LocalKhataColors.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(dotColor))
            Spacer(Modifier.width(10.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = c.TextPrimary)
        }
        Text(
            UnitConverter.rupees(amount),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = if (amount > 0) FontWeight.Bold else FontWeight.Normal,
            color = if (amount > 0) c.TextPrimary else c.Muted
        )
    }
}

@Composable
private fun RecentPaymentRow(tws: TransactionWithShop, langCode: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        colors = cardColors(),
        border = cardBorder(),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(c.Success.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Payments, contentDescription = null, tint = c.Success, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = c.TextPrimary)
                Text(UnitConverter.dateShort(tws.txn.date, langCode),
                    style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                "+" + UnitConverter.rupees(tws.txn.amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = c.Success
            )
        }
    }
}
