package com.udharhisab.ui.notes

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.NoteEntity
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditScreen(container: AppContainer, noteId: Long, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()

    var loaded by remember { mutableStateOf(noteId == 0L) }
    var original by remember { mutableStateOf<NoteEntity?>(null) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        if (noteId != 0L) {
            val n = container.repo.noteById(noteId)
            original = n
            title = n?.title ?: ""
            content = n?.content ?: ""
            loaded = true
        }
    }

    fun saveAndBack() {
        if (saved) { onBack(); return }
        saved = true
        val t = title.trim()
        val ct = content.trim()
        if (t.isBlank() && ct.isBlank()) {
            onBack()
            return
        }
        scope.launch {
            container.repo.saveNote(
                NoteEntity(
                    id = noteId,
                    title = t,
                    content = ct,
                    createdAt = original?.createdAt ?: System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
            )
            onBack()
        }
    }

    BackHandler(onBack = ::saveAndBack)

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = ::saveAndBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                actions = {
                    if (noteId != 0L) {
                        IconButton(onClick = {
                            original?.let {
                                scope.launch {
                                    container.repo.deleteNote(it)
                                    onBack()
                                }
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = c.Danger)
                        }
                    }
                    IconButton(onClick = ::saveAndBack) {
                        Icon(Icons.Default.Check, contentDescription = s.save, tint = c.Primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        if (!loaded) return@Scaffold
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            TextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text(s.noteTitlePlaceholder, style = MaterialTheme.typography.headlineMedium) },
                textStyle = MaterialTheme.typography.headlineMedium,
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            TextField(
                value = content,
                onValueChange = { content = it },
                placeholder = { Text(s.noteContentPlaceholder) },
                textStyle = MaterialTheme.typography.bodyLarge,
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
        }
    }
}
