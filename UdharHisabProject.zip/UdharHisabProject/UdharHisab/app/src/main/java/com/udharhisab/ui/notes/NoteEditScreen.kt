package com.udharhisab.ui.notes

import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.NoteEntity
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditScreen(container: AppContainer, noteId: Long, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()

    var loaded by remember { mutableStateOf(noteId == 0L) }
    var original by remember { mutableStateOf<NoteEntity?>(null) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        if (noteId != 0L) {
            val n = container.repo.noteById(noteId)
            original = n
            title = n?.title ?: ""
            content = n?.content ?: ""
            loaded = true
        }
    }

    fun saveAndBack() {
        if (saved) { onBack(); return }
        saved = true
        val t = title.trim()
        val ct = content.trim()
        if (t.isBlank() && ct.isBlank()) {
            onBack()
            return
        }
        scope.launch {
            container.repo.saveNote(
                NoteEntity(
                    id = noteId,
                    title = t,
                    content = ct,
                    createdAt = original?.createdAt ?: System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
            )
            onBack()
        }
    }

    BackHandler(onBack = ::saveAndBack)

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = ::saveAndBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                actions = {
                    if (noteId != 0L) {
                        // ⭐ মুছুন: লালচে গোল বাটন
                        Box(
                            Modifier.size(40.dp).background(c.Danger.copy(alpha = 0.12f), CircleShape).clip(CircleShape)
                                .clickable {
                                    original?.let {
                                        scope.launch {
                                            container.repo.deleteNote(it)
                                            onBack()
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Delete, contentDescription = null, tint = c.Danger) }
                        Spacer(Modifier.width(8.dp))
                    }
                    // ⭐ সেভ: গ্রেডিয়েন্ট গোল বাটন
                    Box(
                        Modifier.size(40.dp)
                            .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(c.Primary, c.Accent)), CircleShape)
                            .clip(CircleShape)
                            .clickable(onClick = ::saveAndBack),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Check, contentDescription = s.save, tint = androidx.compose.ui.graphics.Color.White) }
                    Spacer(Modifier.width(12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Background,
                    scrolledContainerColor = c.Background,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        if (!loaded) return@Scaffold
        // ⭐ লেখার জায়গাটা ওপরে রঙিন পট্টিসহ একটা বড় গোল কার্ড — কাগজের মতো
        val (noteTint, noteInk) = com.udharhisab.ui.components.FriendlyTiles.forKey(title.ifBlank { "note" })
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                .shadow(6.dp, RoundedCornerShape(26.dp))
                .clip(RoundedCornerShape(26.dp))
                .background(c.Surface)
        ) {
            Box(Modifier.fillMaxWidth().height(8.dp).background(noteInk))
            TextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text(s.noteTitlePlaceholder, style = MaterialTheme.typography.headlineMedium) },
                textStyle = MaterialTheme.typography.headlineMedium.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            TextField(
                value = content,
                onValueChange = { content = it },
                placeholder = { Text(s.noteContentPlaceholder) },
                textStyle = MaterialTheme.typography.bodyLarge,
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
        }
    }
}
