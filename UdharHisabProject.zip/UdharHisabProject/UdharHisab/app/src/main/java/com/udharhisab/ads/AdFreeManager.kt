package com.udharhisab.ads

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ⭐ "বিজ্ঞাপনমুক্ত" — একবারের কেনা (Google Play Billing, one-time product)।
 *
 * Play Console → Monetize → In-app products → নতুন প্রোডাক্ট, ID: `ad_free` (নিচের PRODUCT_ID-র সাথে হুবহু মিলতে হবে),
 * দাম বসিয়ে Active করুন। অ্যাপ প্রকাশিত (অন্তত Internal testing-এ) না হলে এখানে দাম আসবে না — তখন "এখন কেনা যাচ্ছে না" দেখায়।
 *
 * সার্ভারে যাচাই ছাড়া সরল ব্যবস্থা: কেনা থাকলে ফোনে ফ্ল্যাগ বসে (ইনস্টল ফিরিয়ে আনলে "আগের কেনা ফিরিয়ে আনুন" দিয়ে ফেরে)।
 */
object AdFreeManager {
    const val PRODUCT_ID = "ad_free"

    private var client: BillingClient? = null
    private var details: ProductDetails? = null
    private var appContext: Context? = null

    private val _price = MutableStateFlow<String?>(null)
    /** স্টোর থেকে পাওয়া দাম (যেমন "₹49.00"); না পেলে null */
    val price: StateFlow<String?> = _price.asStateFlow()

    fun init(context: Context) {
        val app = context.applicationContext
        appContext = app
        if (client != null) return
        client = BillingClient.newBuilder(app)
            .setListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                    purchases.forEach { handlePurchase(it) }
                }
            }
            .enablePendingPurchases()
            .build()
        connect()
    }

    private fun connect() {
        client?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryDetails()
                    restore()
                }
            }

            override fun onBillingServiceDisconnected() {
                // পরের বার ডায়ালগ খুললে আবার চেষ্টা হবে
            }
        })
    }

    private fun queryDetails() {
        val product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(PRODUCT_ID)
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build()
        client?.queryProductDetailsAsync(params) { result, list ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                details = list.firstOrNull()
                _price.value = details?.oneTimePurchaseOfferDetails?.formattedPrice
            }
        }
    }

    /** "আগের কেনা ফিরিয়ে আনুন" — আর অ্যাপ খোলার সময় নিজে থেকেও চলে */
    fun restore() {
        val params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
        client?.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                purchases.forEach { handlePurchase(it) }
            }
        }
    }

    /** কেনার স্ক্রিন খোলে; দাম না পেলে false */
    fun buy(activity: Activity): Boolean {
        val d = details
        if (d == null) {
            // সংযোগ ছিন্ন থাকলে আবার জোড়ার চেষ্টা
            if (client?.isReady != true) connect()
            return false
        }
        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build()
        val flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(productParams)).build()
        client?.launchBillingFlow(activity, flow)
        return true
    }

    private fun handlePurchase(purchase: Purchase) {
        if (PRODUCT_ID !in purchase.products) return
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return
        if (!purchase.isAcknowledged) {
            val ack = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
            client?.acknowledgePurchase(ack) { }
        }
        AdPolicy.setAdFree(true)
    }
}
