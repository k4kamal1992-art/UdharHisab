package com.udharhisab.ui.entry

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.repository.HisabRepository
import com.udharhisab.data.repository.NewTxnItem
import com.udharhisab.domain.UnitConverter
import kotlinx.coroutines.launch

enum class CreditMode { DIRECT, PRODUCT }

/** ⭐ একটা পণ্য-সারি — নাম/পরিমাণ/একক/দাম, amount তাৎক্ষণিকভাবে হিসাব হয় */
class ProductRow(
    productName: String = "",
    quantity: String = "",
    unit: String = "",
    unitPrice: String = ""
) {
    var productName by mutableStateOf(productName)
    var quantity by mutableStateOf(quantity)
    var unit by mutableStateOf(unit)
    var unitPrice by mutableStateOf(unitPrice)

    val amount: Double?
        get() {
            val q = quantity.toDoubleOrNull()
            val p = unitPrice.toDoubleOrNull()
            return if (q != null && p != null) q * p else null
        }
}

class CreditEntryViewModel(
    private val repo: HisabRepository,
    private val shopId: Long,
    isWoodShop: Boolean
) : ViewModel() {

    var mode by mutableStateOf(CreditMode.DIRECT)
        private set
    var directAmount by mutableStateOf("")
        private set

    /** ⭐ কাঠের দোকানে খালি শুরু হয় (Timber Calculator-ই মূল প্রবেশপথ),
     *  অন্য সব দোকানে একটা তৈরি সারি দিয়ে শুরু হয় — যাতে "পণ্য অনুযায়ী" বাছার
     *  সাথে সাথেই নাম/পরিমাণ/একক/দাম ফিল্ড দেখা যায়, "আরও পণ্য" চাপা না লাগে। */
    val productRows = mutableStateListOf<ProductRow>().apply {
        if (!isWoodShop) add(ProductRow())
    }
    var note by mutableStateOf("")
        private set
    var error by mutableStateOf(false)
        private set
    var saved by mutableStateOf(false)
        private set

    fun selectMode(m: CreditMode) { mode = m; error = false }
    fun updateDirectAmount(v: String) { directAmount = v; error = false }
    fun updateNote(v: String) { note = v }
    fun addProductRow() { productRows.add(ProductRow()) }
    fun removeProductRow(row: ProductRow) { productRows.remove(row) }

    /** ⭐ কাঠের হিসাব থেকে একটা সম্পূর্ণ পূরণ করা সারি (নাম + CFT + রেট) যোগ হয় */
    fun addProductRowFromTimber(productName: String, totalCft: Double, ratePerCft: Double) {
        productRows.add(
            ProductRow(
                productName = productName,
                quantity = UnitConverter.amountInput(totalCft),
                unit = "CFT",
                unitPrice = UnitConverter.amountInput(ratePerCft)
            )
        )
    }

    fun totalAmount(): Double = when (mode) {
        CreditMode.DIRECT -> directAmount.toDoubleOrNull() ?: 0.0
        CreditMode.PRODUCT -> productRows.sumOf { it.amount ?: 0.0 }
    }

    fun save(onDone: () -> Unit) {
        when (mode) {
            CreditMode.DIRECT -> {
                val amt = directAmount.toDoubleOrNull()
                if (amt == null || amt <= 0) { error = true; return }
                viewModelScope.launch {
                    repo.insertCredit(shopId, emptyList(), amt, note.ifBlank { null })
                    saved = true
                    onDone()
                }
            }
            CreditMode.PRODUCT -> {
                val items = productRows.mapNotNull { row ->
                    val amt = row.amount
                    if (amt == null || amt <= 0) null
                    else NewTxnItem(
                        productName = row.productName.trim(),
                        quantity = row.quantity.toDoubleOrNull(),
                        unit = row.unit.ifBlank { null },
                        unitPrice = row.unitPrice.toDoubleOrNull(),
                        amount = amt
                    )
                }
                if (items.isEmpty()) { error = true; return }
                viewModelScope.launch {
                    repo.insertCredit(shopId, items, null, note.ifBlank { null })
                    saved = true
                    onDone()
                }
            }
        }
    }
}
