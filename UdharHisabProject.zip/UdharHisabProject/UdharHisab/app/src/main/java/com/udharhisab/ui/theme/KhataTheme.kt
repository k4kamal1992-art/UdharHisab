package com.udharhisab.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.stringsFor

/**
 * @param themeMode "system" | "light" | "dark" — DataStore থেকে আসে
 * @param language "bn" | "en" — DataStore থেকে আসে
 */
@Composable
fun KhataTheme(
    themeMode: String = "system",
    language: String = "bn",
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }

    val khataColors = if (dark) DarkKhataColors else LightKhataColors
    val m3Scheme = if (dark) khataDarkScheme() else khataLightScheme()

    CompositionLocalProvider(
        LocalKhataColors provides khataColors,
        LocalStrings provides stringsFor(language)
    ) {
        Material3ThemeWrap(scheme = m3Scheme, content = content)
    }
}

// M3 MaterialTheme র‍্যাপার (import শর্টহ্যান্ডের জন্য আলাদা ফাংশন)
@Composable
private fun Material3ThemeWrap(
    scheme: androidx.compose.material3.ColorScheme,
    content: @Composable () -> Unit
) {
    androidx.compose.material3.MaterialTheme(
        colorScheme = scheme,
        typography = KhataTypography,
        shapes = KhataShapes,
        content = content
    )
}
