package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shops")
data class ShopEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String? = null,
    val shopType: String = ShopType.OTHER.key,
    val isArchived: Boolean = false,
    val lastUsedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ShopType(val key: String, val display: String, val emoji: String) {
    KIRANA("KIRANA", "মুদি দোকান", "🏪"),
    WOOD("WOOD", "কাঠের দোকান", "🪵"),
    HARDWARE("HARDWARE", "হার্ডওয়্যার", "🔧"),
    GARMENTS("GARMENTS", "পোশাক", "👕"),
    ELECTRONICS("ELECTRONICS", "ইলেকট্রনিক্স", "📱"),
    OTHER("OTHER", "অন্যান্য", "🏬");

    companion object {
        fun fromKey(key: String): ShopType =
            entries.firstOrNull { it.key == key } ?: OTHER
    }
}
