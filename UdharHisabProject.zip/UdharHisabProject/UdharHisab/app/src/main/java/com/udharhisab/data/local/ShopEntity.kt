package com.udharhisab.data.local

import androidx.annotation.DrawableRes
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.udharhisab.R

@Entity(tableName = "shops")
data class ShopEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String? = null,
    val shopType: String = ShopType.OTHER.key,
    val isArchived: Boolean = false,
    val lastUsedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ShopType(val key: String, @DrawableRes val iconRes: Int) {
    TEA("TEA", R.drawable.ic_cat_tea),
    HARDWARE_ELECTRIC("HARDWARE_ELECTRIC", R.drawable.ic_cat_hardware),
    KIRANA("KIRANA", R.drawable.ic_cat_kirana),
    VEGETABLE("VEGETABLE", R.drawable.ic_cat_vegetable),
    FISH_MEAT("FISH_MEAT", R.drawable.ic_cat_fish),
    BAKERY_SWEETS("BAKERY_SWEETS", R.drawable.ic_cat_bakery),
    PHARMACY("PHARMACY", R.drawable.ic_cat_pharmacy),
    COSMETICS("COSMETICS", R.drawable.ic_cat_cosmetics),
    STATIONERY("STATIONERY", R.drawable.ic_cat_stationery),
    XEROX_PRINTING("XEROX_PRINTING", R.drawable.ic_cat_xerox),
    WOOD("WOOD", R.drawable.ic_cat_wood),
    GARMENTS("GARMENTS", R.drawable.ic_cat_garments),
    OTHER("OTHER", R.drawable.ic_cat_other);

    companion object {
        fun fromKey(key: String): ShopType =
            entries.firstOrNull { it.key == key } ?: OTHER
    }
}
