package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shops")
data class ShopEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String? = null,
    val shopType: String = ShopType.OTHER.key,
    val isArchived: Boolean = false,
    val lastUsedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ShopType(val key: String, val emoji: String) {
    TEA("TEA", "🍵"),
    HARDWARE_ELECTRIC("HARDWARE_ELECTRIC", "🔧"),
    KIRANA("KIRANA", "🏪"),
    VEGETABLE("VEGETABLE", "🥦"),
    FISH_MEAT("FISH_MEAT", "🐟"),
    BAKERY_SWEETS("BAKERY_SWEETS", "🍞"),
    PHARMACY("PHARMACY", "💊"),
    COSMETICS("COSMETICS", "🧴"),
    STATIONERY("STATIONERY", "✏️"),
    XEROX_PRINTING("XEROX_PRINTING", "🖨️"),
    WOOD("WOOD", "🪵"),
    GARMENTS("GARMENTS", "👕"),
    OTHER("OTHER", "🏬");

    companion object {
        fun fromKey(key: String): ShopType =
            entries.firstOrNull { it.key == key } ?: OTHER
    }
}
