package com.udharhisab.ui.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.udharhisab.R
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.ui.more.LanguageGrid
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * অ্যাপ প্রথমবার খোলার সময় একবারই দেখানো হয় — ভাষা বেছে নেওয়ার আগ পর্যন্ত
 * এই স্ক্রিন language-agnostic (দুই ভাষাতেই একসাথে লেখা, কারণ তখনো ইউজারের পছন্দ জানা নেই)
 * Language পেজের সাথে একই ২-কলাম গ্রিড ব্যবহার করে — অ্যাপের নিজস্ব সবুজ প্যালেটে
 */
@Composable
fun LanguageOnboardingScreen(store: SettingsDataStore) {
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<String?>(null) }

    Scaffold(containerColor = c.Background) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = null,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(18.dp))
            )
            Spacer(Modifier.height(24.dp))
            Text(
                "আপনার ভাষা বেছে নিন",
                style = MaterialTheme.typography.headlineMedium,
                color = c.TextPrimary
            )
            Text(
                "Choose your language",
                style = MaterialTheme.typography.titleMedium,
                color = c.Muted
            )
            Spacer(Modifier.height(28.dp))

            LanguageGrid(selected = selected, onSelect = { selected = it })

            Spacer(Modifier.height(28.dp))
            Button(
                onClick = {
                    val lang = selected ?: return@Button
                    scope.launch { store.setLanguage(lang) }
                },
                enabled = selected != null,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(if (selected == "bn") "চালিয়ে যান" else if (selected == "hi") "आगे बढ़ें" else "Continue")
            }
        }
    }
}
