package com.udharhisab.ui.onboarding

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.R
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * অ্যাপ প্রথমবার খোলার সময় একবারই দেখানো হয় — ভাষা বেছে নেওয়ার আগ পর্যন্ত
 * এই স্ক্রিন language-agnostic (দুই ভাষাতেই একসাথে লেখা, কারণ তখনো ইউজারের পছন্দ জানা নেই)
 */
@Composable
fun LanguageOnboardingScreen(store: SettingsDataStore) {
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<String?>(null) }

    Scaffold(containerColor = c.Background) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = null,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(18.dp))
            )
            Spacer(Modifier.height(24.dp))
            Text(
                "আপনার ভাষা বেছে নিন",
                style = MaterialTheme.typography.headlineMedium,
                color = c.TextPrimary
            )
            Text(
                "Choose your language",
                style = MaterialTheme.typography.titleMedium,
                color = c.Muted
            )
            Spacer(Modifier.height(32.dp))

            OnboardingLangCard("বাংলা", "Bengali", selected == "bn") { selected = "bn" }
            Spacer(Modifier.height(12.dp))
            OnboardingLangCard("English", "ইংরেজি", selected == "en") { selected = "en" }

            Spacer(Modifier.height(32.dp))
            Button(
                onClick = {
                    val lang = selected ?: return@Button
                    scope.launch { store.setLanguage(lang) }
                },
                enabled = selected != null,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(if (selected == "bn") "চালিয়ে যান" else "Continue")
            }
        }
    }
}

@Composable
private fun OnboardingLangCard(mainLabel: String, subLabel: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) c.ChipBg else c.Surface)
            .then(
                if (selected) Modifier.border(BorderStroke(2.dp, c.Primary), RoundedCornerShape(14.dp))
                else Modifier.border(BorderStroke(1.dp, c.Divider), RoundedCornerShape(14.dp))
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(mainLabel, style = MaterialTheme.typography.titleLarge, color = c.TextPrimary, fontWeight = FontWeight.SemiBold)
            Text(subLabel, style = MaterialTheme.typography.bodySmall, color = c.Muted)
        }
        if (selected) {
            Box(
                Modifier.size(24.dp).background(c.Primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }
    }
}
