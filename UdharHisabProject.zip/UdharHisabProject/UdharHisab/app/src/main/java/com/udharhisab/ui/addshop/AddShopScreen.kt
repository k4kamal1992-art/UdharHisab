package com.udharhisab.ui.addshop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import com.udharhisab.ui.components.FriendlyTiles
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.udharhisab.ui.common.ContactPickerButton
import com.udharhisab.ui.common.rememberContactPicker
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddShopScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val vm: AddShopViewModel = viewModel { AddShopViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    // ⭐ কন্টাক্ট থেকে নম্বর (আর নাম খালি থাকলে নামও) বসানো
    val pickContact = rememberContactPicker { name, number ->
        vm.setPhone(number)
        if (vm.name.value.isBlank() && name.isNotBlank()) vm.setName(name)
    }

    // ⭐ সেভ হলে সরাসরি Detail-এ
    LaunchedEffect(vm.saved.value) {
        if (vm.saved.value) onSaved(vm.savedShopId.longValue)
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(sk?.newShopButton ?: s.newShop) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // নাম
            OutlinedTextField(
                value = vm.name.value,
                onValueChange = vm::setName,
                label = { Text(sk?.shopNameLabel ?: s.shopNameLabel) },
                placeholder = { Text(sk?.shopNamePlaceholder ?: s.shopNamePlaceholder) },
                singleLine = true,
                isError = vm.error.value != null,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            // ফোন
            OutlinedTextField(
                value = vm.phone.value,
                onValueChange = vm::setPhone,
                label = { Text(s.phoneLabel) },
                placeholder = { Text("01XXXXXXXXX") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                trailingIcon = { ContactPickerButton(onClick = pickContact) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Text(s.shopTypeLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(10.dp))

            // ShopType গ্রিড (২ কলাম)
            ShopType.entries.chunked(2).forEach { rowTypes ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    rowTypes.forEach { t ->
                        val selected = vm.selectedType.value == t
                        // ⭐ প্রতিটা ধরনের নিজের রঙ; বাছলে গাঢ় বর্ডার
                        val (tileBg, tileFg) = FriendlyTiles.forKey(t.name)
                        Card(
                            onClick = { vm.setType(t) },
                            shape = RoundedCornerShape(20.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 4.dp else 1.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) tileBg else c.Surface
                            ),
                            border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, tileFg) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                Modifier
                                    .padding(vertical = 14.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    Modifier.size(44.dp).background(tileBg, RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(t.iconRes),
                                        contentDescription = null,
                                        tint = tileFg,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(t.displayName(s), style = MaterialTheme.typography.labelLarge,
                                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold)
                            }
                        }
                    }
                    if (rowTypes.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
            }

            vm.error.value?.let { err ->
                val msg = when (err) {
                    AddShopError.NAME_REQUIRED -> s.errorNameRequired
                    AddShopError.TYPE_REQUIRED -> s.errorTypeRequired
                }
                Spacer(Modifier.height(8.dp))
                Text(msg, color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { vm.save(s.code) },
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(s.saveShopButton, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}
