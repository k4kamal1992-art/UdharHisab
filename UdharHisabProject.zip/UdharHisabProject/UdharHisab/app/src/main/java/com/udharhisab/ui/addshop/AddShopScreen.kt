package com.udharhisab.ui.addshop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddShopScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val vm: AddShopViewModel = viewModel { AddShopViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    // ⭐ সেভ হলে সরাসরি Detail-এ
    LaunchedEffect(vm.saved.value) {
        if (vm.saved.value) onSaved(vm.savedShopId.longValue)
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.newShop) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // নাম
            OutlinedTextField(
                value = vm.name.value,
                onValueChange = vm::setName,
                label = { Text(s.shopNameLabel) },
                placeholder = { Text(s.shopNamePlaceholder) },
                singleLine = true,
                isError = vm.error.value != null,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            // ফোন
            OutlinedTextField(
                value = vm.phone.value,
                onValueChange = vm::setPhone,
                label = { Text(s.phoneLabel) },
                placeholder = { Text("01XXXXXXXXX") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))
            Text(s.shopTypeLabel, style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(10.dp))

            // ShopType গ্রিড (২ কলাম)
            ShopType.entries.chunked(2).forEach { rowTypes ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    rowTypes.forEach { t ->
                        val selected = vm.selectedType.value == t
                        Card(
                            onClick = { vm.setType(t) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) c.ChipBg else c.Surface
                            ),
                            border = if (selected) CardDefaults.outlinedCardBorder() else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                Modifier
                                    .padding(vertical = 14.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    painter = painterResource(t.iconRes),
                                    contentDescription = null,
                                    tint = if (selected) c.Primary else c.TextSecondary,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(t.displayName(s), style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                    if (rowTypes.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
            }

            vm.error.value?.let { err ->
                val msg = when (err) {
                    AddShopError.NAME_REQUIRED -> s.errorNameRequired
                    AddShopError.TYPE_REQUIRED -> s.errorTypeRequired
                }
                Spacer(Modifier.height(8.dp))
                Text(msg, color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { vm.save(s.code) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(s.saveShopButton, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}
