package com.udharhisab.ui.reports

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.domain.UnitConverter

/** ⭐ কোনো charting library প্রজেক্টে নেই, তাই সাধারণ Canvas দিয়ে হাতে-আঁকা বার চার্ট */
@Composable
fun CreditPaymentBarChart(
    credit: Double,
    payment: Double,
    creditColor: Color,
    paymentColor: Color,
    creditLabel: String,
    paymentLabel: String
) {
    val maxVal = maxOf(credit, payment, 1.0)

    Column(Modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .padding(horizontal = 24.dp)
        ) {
            val barWidth = size.width / 4
            val chartHeight = size.height - 8
            val creditH = (credit / maxVal * chartHeight).toFloat().coerceAtLeast(0f)
            val paymentH = (payment / maxVal * chartHeight).toFloat().coerceAtLeast(0f)

            // ⭐ গোল কোণার বার — একটু বেশি পেশাদার চেহারা
            drawRoundRect(
                color = creditColor,
                topLeft = Offset(barWidth * 0.5f, size.height - creditH),
                size = Size(barWidth, creditH),
                cornerRadius = CornerRadius(14f, 14f)
            )
            drawRoundRect(
                color = paymentColor,
                topLeft = Offset(barWidth * 2.5f, size.height - paymentH),
                size = Size(barWidth, paymentH),
                cornerRadius = CornerRadius(14f, 14f)
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(UnitConverter.rupees(credit), color = creditColor, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(creditLabel, style = MaterialTheme.typography.bodySmall)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(UnitConverter.rupees(payment), color = paymentColor, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(paymentLabel, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
