package com.udharhisab.ui.entry

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ ধার/জমা এন্ট্রি বটম শিট
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryBottomSheet(
    initialType: String,
    isWoodShop: Boolean,          // কাঠের দোকান হলে CFT ক্যালকুলেটর দেখাবে
    onDismiss: () -> Unit,
    onSave: (EntryViewModel, () -> Unit) -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val vm = remember { EntryViewModel() }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            // ধার/জমা টগল
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = vm.type.value == TransactionEntity.TYPE_CREDIT,
                    onClick = { vm.setType(TransactionEntity.TYPE_CREDIT) },
                    label = { Text(s.creditButton) }
                )
                FilterChip(
                    selected = vm.type.value == TransactionEntity.TYPE_PAYMENT,
                    onClick = { vm.setType(TransactionEntity.TYPE_PAYMENT) },
                    label = { Text(s.paymentButton) }
                )
            }

            Spacer(Modifier.height(14.dp))

            if (vm.type.value == TransactionEntity.TYPE_CREDIT) {
                OutlinedTextField(
                    value = vm.productName.value,
                    onValueChange = vm::setProductName,
                    label = { Text(s.productNameLabel) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
            }

            // CFT ক্যালকুলেটর — শুধু কাঠের দোকান + ধারে
            if (isWoodShop && vm.type.value == TransactionEntity.TYPE_CREDIT) {
                CftCalculator { cft, rate ->
                    vm.setQuantity(UnitConverter.amountInput(cft))
                    vm.setUnit("cft")
                    vm.setUnitPrice(UnitConverter.amountInput(rate))
                }
                Spacer(Modifier.height(12.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vm.quantity.value, onValueChange = vm::setQuantity,
                    label = { Text(s.quantityLabel) }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = vm.unit.value, onValueChange = vm::setUnit,
                    label = { Text(s.unitLabel) }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = vm.unitPrice.value, onValueChange = vm::setUnitPrice,
                    label = { Text(s.pricePerUnitLabel) }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(10.dp))

            // ⭐ গণনা-প্রিভিউ
            val preview = vm.computedAmount()
            Text(
                "${s.totalPrefix}${if (preview != null) UnitConverter.rupees(preview) else "—"}",
                style = MaterialTheme.typography.titleMedium,
                color = if (vm.type.value == TransactionEntity.TYPE_CREDIT) c.Danger else c.Success
            )

            Spacer(Modifier.height(10.dp))

            if (vm.type.value == TransactionEntity.TYPE_PAYMENT) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(s.cash, s.bkash, s.bank).forEach { m ->
                        FilterChip(
                            selected = vm.paymentMethod.value == m,
                            onClick = { vm.setPaymentMethod(m) },
                            label = { Text(m) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            OutlinedTextField(
                value = vm.note.value, onValueChange = vm::setNote,
                label = { Text(s.noteLabel) },
                modifier = Modifier.fillMaxWidth()
            )

            if (vm.error.value) {
                Spacer(Modifier.height(8.dp))
                Text(s.invalidAmountError, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = { onSave(vm) { onDismiss() } },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) { Text(s.save) }
        }
    }
}
