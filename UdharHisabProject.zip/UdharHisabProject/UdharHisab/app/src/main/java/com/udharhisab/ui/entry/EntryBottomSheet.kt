package com.udharhisab.ui.entry

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ ধার/জমা এন্ট্রি বটম শিট
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryBottomSheet(
    initialType: String,
    isWoodShop: Boolean,          // কাঠের দোকান হলে CFT ক্যালকুলেটর দেখাবে
    onDismiss: () -> Unit,
    onSave: (EntryViewModel, () -> Unit) -> Unit
) {
    val c = LocalKhataColors.current
    val vm = remember { EntryViewModel() }
    // ⭐ VM এখানে লোকালি — remember দিয়ে, sheet বন্ধ হলে মুছে যাবে
  //  val vm = remember { EntryViewModel(object : HisabRepositoryStub()) }.let {
        // প্রত্যক্ষ repo ব্যবহার না করে save কলব্যাকে পাঠাচ্ছি
     //   it
  //  }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            // ধার/জমা টগল
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = vm.type.value == TransactionEntity.TYPE_CREDIT,
                    onClick = { vm.setType(TransactionEntity.TYPE_CREDIT) },
                    label = { Text("🔴 ধার নিলাম") }
                )
                FilterChip(
                    selected = vm.type.value == TransactionEntity.TYPE_PAYMENT,
                    onClick = { vm.setType(TransactionEntity.TYPE_PAYMENT) },
                    label = { Text("🟢 জমা দিলাম") }
                )
            }

            Spacer(Modifier.height(14.dp))

            if (vm.type.value == TransactionEntity.TYPE_CREDIT) {
                OutlinedTextField(
                    value = vm.productName.value,
                    onValueChange = vm::setProductName,
                    label = { Text("পণ্যের নাম (ঐচ্ছিক)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
            }

            // CFT ক্যালকুলেটর — শুধু কাঠের দোকান + ধারে
            if (isWoodShop && vm.type.value == TransactionEntity.TYPE_CREDIT) {
                CftCalculator { cft, rate ->
                    vm.setQuantity(UnitConverter.amountInput(cft))
                    vm.setUnit("cft")
                    vm.setUnitPrice(UnitConverter.amountInput(rate))
                }
                Spacer(Modifier.height(12.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vm.quantity.value, onValueChange = vm::setQuantity,
                    label = { Text("পরিমাণ") }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = vm.unit.value, onValueChange = vm::setUnit,
                    label = { Text("একক") }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = vm.unitPrice.value, onValueChange = vm::setUnitPrice,
                    label = { Text("দাম/একক") }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(10.dp))

            // ⭐ গণনা-প্রিভিউ
            val preview = vm.computedAmount()
            Text(
                "মোট: ${if (preview != null) UnitConverter.rupees(preview) else "—"}",
                style = MaterialTheme.typography.titleMedium,
                color = if (vm.type.value == TransactionEntity.TYPE_CREDIT) c.Danger else c.Success
            )

            Spacer(Modifier.height(10.dp))

            if (vm.type.value == TransactionEntity.TYPE_PAYMENT) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("নগদ", "বিকাশ", "ব্যাংক").forEach { m ->
                        FilterChip(
                            selected = vm.paymentMethod.value == m,
                            onClick = { vm.setPaymentMethod(m) },
                            label = { Text(m) }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            OutlinedTextField(
                value = vm.note.value, onValueChange = vm::setNote,
                label = { Text("নোট (ঐচ্ছিক)") },
                modifier = Modifier.fillMaxWidth()
            )

            vm.error.value?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = { onSave(vm) { onDismiss() } },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) { Text("সেভ করুন") }
        }
    }
}

/** শুধু VM constructor-এর জন্য প্লেসহোল্ডার — save আসলে onSave কলব্যাকে হয় */
//private class HisabRepositoryStub : HisabRepository(
   // com.udharhisab.data.local.AppDatabaseStub()

