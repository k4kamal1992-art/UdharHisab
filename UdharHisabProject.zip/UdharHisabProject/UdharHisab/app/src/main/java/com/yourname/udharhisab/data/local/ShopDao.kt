package com.yourname.udharhisab.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.yourname.udharhisab.data.model.Shop

@Dao
interface ShopDao {

    @Query("SELECT * FROM shops ORDER BY name ASC")
    fun getAllShops(): LiveData<List<Shop>>

    @Query("SELECT * FROM shops WHERE id = :shopId")
    suspend fun getShopById(shopId: Long): Shop?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShop(shop: Shop): Long

    @Update
    suspend fun updateShop(shop: Shop)

    @Delete
    suspend fun deleteShop(shop: Shop)

    @Query("SELECT COUNT(*) FROM shops")
    fun getShopCount(): LiveData<Int>

    @Query("SELECT * FROM shops WHERE name LIKE '%' || :query || '%' OR ownerName LIKE '%' || :query || '%'")
    fun searchShops(query: String): LiveData<List<Shop>>
}
