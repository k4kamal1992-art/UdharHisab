package com.udharhisab.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ShopEntity::class, TransactionEntity::class, ShopProductEntity::class, TransactionItemEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun shopDao(): ShopDao
    abstract fun transactionDao(): TransactionDao
    abstract fun shopProductDao(): ShopProductDao
    abstract fun transactionItemDao(): TransactionItemDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dhar_hisab.db"
                ).fallbackToDestructiveMigration().build()
            }.also { instance = it }
    }
}
