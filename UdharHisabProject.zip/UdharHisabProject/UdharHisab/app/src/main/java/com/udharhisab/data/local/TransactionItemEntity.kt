package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** ⭐ একটা ধার-লেনদেনের ভেতরের একটা পণ্য — "পণ্য অনুযায়ী" মোডে ব্যবহার হয় */
@Entity(
    tableName = "transaction_items",
    indices = [Index(value = ["transactionId"])]
)
data class TransactionItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long,
    val productName: String,
    val quantity: Double? = null,
    val unit: String? = null,
    val unitPrice: Double? = null,
    val amount: Double                                   // এই পণ্যের সাব-টোটাল
)
