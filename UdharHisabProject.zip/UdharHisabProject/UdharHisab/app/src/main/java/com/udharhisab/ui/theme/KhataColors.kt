package com.udharhisab.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// ── সেমান্টিক কালার (M3-এর বাইরে আমাদের নিজের) ──
data class KhataColors(
    val Primary: Color,
    val PrimaryDark: Color,
    val Accent: Color,
    val Background: Color,
    val Surface: Color,
    val TextPrimary: Color,
    val TextSecondary: Color,
    val Success: Color,      // জমা/পরিশোধ
    val Danger: Color,       // বাকি/ধার
    val Muted: Color,        // সেকেন্ডারি টেক্সট
    val ChipBg: Color,
    val Divider: Color
)

// ── লাইট থিম (ডিজাইন স্পেক অনুযায়ী) ──
val LightKhataColors = KhataColors(
    Primary = Color(0xFF087F5B),          // মূল ব্যবহার
    PrimaryDark = Color(0xFF064E3B),      // Pressed/Active
    Accent = Color(0xFF14B8A6),           // Highlight (আইকন/বড় টেক্সটে ব্যবহার করুন, body text-এ নয়)
    Background = Color(0xFFF6F8F7),
    Surface = Color(0xFFFFFFFF),
    TextPrimary = Color(0xFF1A2320),
    TextSecondary = Color(0xFF5B6B65),
    Success = Color(0xFF159570),          // পরিশোধ
    Danger = Color(0xFFE05252),           // ধার
    Muted = Color(0xFF9AA6A1),
    ChipBg = Color(0xFFE7F3EF),
    Divider = Color(0xFFE3E9E6)
)

// ── ডার্ক থিম ──
val DarkKhataColors = KhataColors(
    Primary = Color(0xFF2FB88B),
    PrimaryDark = Color(0xFF14B8A6),
    Accent = Color(0xFF3ECFBB),
    Background = Color(0xFF101512),
    Surface = Color(0xFF19211D),
    TextPrimary = Color(0xFFEAF0ED),
    TextSecondary = Color(0xFFA6B3AE),
    Success = Color(0xFF34C795),
    Danger = Color(0xFFEF7B7B),
    Muted = Color(0xFF6C7A75),
    ChipBg = Color(0xFF1F2A25),
    Divider = Color(0xFF2A3530)
)

val LocalKhataColors = staticCompositionLocalOf { LightKhataColors }

// ── M3 ColorScheme সিঙ্ক ──
fun khataLightScheme(): ColorScheme = lightColorScheme(
    primary = LightKhataColors.Primary,
    onPrimary = Color.White,
    secondary = LightKhataColors.Accent,
    onSecondary = Color.White,
    background = LightKhataColors.Background,
    onBackground = LightKhataColors.TextPrimary,
    surface = LightKhataColors.Surface,
    onSurface = LightKhataColors.TextPrimary,
    surfaceVariant = LightKhataColors.ChipBg,
    outline = LightKhataColors.Divider,
    error = LightKhataColors.Danger
)

fun khataDarkScheme(): ColorScheme = darkColorScheme(
    primary = DarkKhataColors.Primary,
    onPrimary = Color(0xFF07231A),
    secondary = DarkKhataColors.Accent,
    onSecondary = Color(0xFF07231A),
    background = DarkKhataColors.Background,
    onBackground = DarkKhataColors.TextPrimary,
    surface = DarkKhataColors.Surface,
    onSurface = DarkKhataColors.TextPrimary,
    surfaceVariant = DarkKhataColors.ChipBg,
    outline = DarkKhataColors.Divider,
    error = DarkKhataColors.Danger
)
