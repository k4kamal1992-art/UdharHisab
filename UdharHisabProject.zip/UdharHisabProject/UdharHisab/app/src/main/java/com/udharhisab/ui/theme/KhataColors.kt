package com.udharhisab.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// ── সেমান্টিক কালার (M3-এর বাইরে আমাদের নিজের) ──
data class KhataColors(
    val Primary: Color,
    val PrimaryDark: Color,
    val Background: Color,
    val Surface: Color,
    val TextPrimary: Color,
    val TextSecondary: Color,
    val Success: Color,      // জমা/পরিশোধ
    val Danger: Color,       // বাকি/ধার
    val Muted: Color,        // সেকেন্ডারি টেক্সট
    val ChipBg: Color,
    val Divider: Color
)

// ── লাইট থিম ──
val LightKhataColors = KhataColors(
    Primary = Color(0xFF2E7D32),          // সবুজ (টাকা-স্বাস্থ্য ফিল)
    PrimaryDark = Color(0xFF1B5E20),
    Background = Color(0xFFF7F8F5),       // হালকা সবুজাভ সাদা (খাতার পাতা)
    Surface = Color.White,
    TextPrimary = Color(0xFF212121),
    TextSecondary = Color(0xFF757575),
    Success = Color(0xFF2E7D32),
    Danger = Color(0xFFC62828),
    Muted = Color(0xFF9E9E9E),
    ChipBg = Color(0xFFE8F5E9),
    Divider = Color(0xFFE0E0E0)
)

// ── ডার্ক থিম ──
val DarkKhataColors = KhataColors(
    Primary = Color(0xFF81C784),
    PrimaryDark = Color(0xFF4CAF50),
    Background = Color(0xFF121511),
    Surface = Color(0xFF1E211C),
    TextPrimary = Color(0xFFEDEBE6),
    TextSecondary = Color(0xFFB0ADA6),
    Success = Color(0xFF81C784),
    Danger = Color(0xFFEF9A9A),
    Muted = Color(0xFF6E6B64),
    ChipBg = Color(0xFF2A3327),
    Divider = Color(0xFF33362F)
)

val LocalKhataColors = staticCompositionLocalOf { LightKhataColors }

// ── M3 ColorScheme সিঙ্ক ──
fun khataLightScheme(): ColorScheme = lightColorScheme(
    primary = LightKhataColors.Primary,
    onPrimary = Color.White,
    background = LightKhataColors.Background,
    onBackground = LightKhataColors.TextPrimary,
    surface = LightKhataColors.Surface,
    onSurface = LightKhataColors.TextPrimary,
    error = LightKhataColors.Danger
)

fun khataDarkScheme(): ColorScheme = darkColorScheme(
    primary = DarkKhataColors.Primary,
    onPrimary = Color(0xFF10280F),
    background = DarkKhataColors.Background,
    onBackground = DarkKhataColors.TextPrimary,
    surface = DarkKhataColors.Surface,
    onSurface = DarkKhataColors.TextPrimary,
    error = DarkKhataColors.Danger
)
