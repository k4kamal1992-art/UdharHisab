package com.udharhisab.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// ── UdharHisab Emerald + Teal design system ──
data class KhataColors(
    val Primary: Color,
    val PrimaryDark: Color,
    val Accent: Color,
    val Background: Color,
    val Surface: Color,
    val TextPrimary: Color,
    val TextSecondary: Color,
    val Success: Color,
    val Danger: Color,
    val Muted: Color,
    val ChipBg: Color,
    val Divider: Color
)

// ── Light theme ──
val LightKhataColors = KhataColors(
    Primary = Color(0xFF087F5B),       // Main brand / primary actions
    PrimaryDark = Color(0xFF064E3B),   // Pressed / deep contrast only
    Accent = Color(0xFF14B8A6),        // Highlights / active accents
    Background = Color(0xFFF6F8F7),
    Surface = Color.White,
    TextPrimary = Color(0xFF17201D),
    TextSecondary = Color(0xFF52615B),
    Success = Color(0xFF159570),
    Danger = Color(0xFFE05252),
    Muted = Color(0xFF7A8782),
    ChipBg = Color(0xFFE5F3EE),
    Divider = Color(0xFFDDE7E3)
)

// ── Dark theme ──
val DarkKhataColors = KhataColors(
    Primary = Color(0xFF34B88E),
    PrimaryDark = Color(0xFF064E3B),
    Accent = Color(0xFF2DD4BF),
    Background = Color(0xFF0D1714),
    Surface = Color(0xFF14211D),
    TextPrimary = Color(0xFFEAF4F0),
    TextSecondary = Color(0xFFB5C7C0),
    Success = Color(0xFF45C49B),
    Danger = Color(0xFFFF8A8A),
    Muted = Color(0xFF82958E),
    ChipBg = Color(0xFF19372F),
    Divider = Color(0xFF29413A)
)

val LocalKhataColors = staticCompositionLocalOf { LightKhataColors }

fun khataLightScheme(): ColorScheme = lightColorScheme(
    primary = LightKhataColors.Primary,
    onPrimary = Color.White,
    secondary = LightKhataColors.Accent,
    onSecondary = Color.White,
    background = LightKhataColors.Background,
    onBackground = LightKhataColors.TextPrimary,
    surface = LightKhataColors.Surface,
    onSurface = LightKhataColors.TextPrimary,
    error = LightKhataColors.Danger
)

fun khataDarkScheme(): ColorScheme = darkColorScheme(
    primary = DarkKhataColors.Primary,
    onPrimary = Color(0xFF062B21),
    secondary = DarkKhataColors.Accent,
    onSecondary = Color(0xFF003730),
    background = DarkKhataColors.Background,
    onBackground = DarkKhataColors.TextPrimary,
    surface = DarkKhataColors.Surface,
    onSurface = DarkKhataColors.TextPrimary,
    error = DarkKhataColors.Danger
)
