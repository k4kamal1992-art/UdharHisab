package com.udharhisab.ui.entry

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentEntryScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val shop by container.repo.shopByIdFlow(shopId).collectAsState(initial = null)

    val shopVal = shop
    if (shopVal == null) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Spacer(Modifier.height(40.dp))
            com.udharhisab.ui.components.SkeletonHeroCard()
            Spacer(Modifier.height(16.dp))
            com.udharhisab.ui.components.ShimmerBlock(Modifier.fillMaxWidth(), height = 52.dp, corner = 14.dp)
        }
        return
    }
    val shopName = shopVal.name

    val vm: PaymentEntryViewModel = viewModel { PaymentEntryViewModel(container.repo, shopId) }
    val currentDue = vm.currentDue

    LaunchedEffect(vm.saved) { if (vm.saved) onSaved() }

    val quickAmounts = listOf(50.0, 100.0, 200.0, 500.0).filter { it <= currentDue && it > 0 }
    val dueAfter = vm.dueAfter()
    val amountEntered = vm.amount.toDoubleOrNull() ?: 0.0

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(shopName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${sk?.currentDueLabel ?: s.currentDueLabel}: ${UnitConverter.rupees(currentDue)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Primary,
                    scrolledContainerColor = c.Primary,
                    titleContentColor = androidx.compose.ui.graphics.Color.White,
                    navigationIconContentColor = androidx.compose.ui.graphics.Color.White,
                    actionIconContentColor = androidx.compose.ui.graphics.Color.White
                )
            )
        },
        bottomBar = {
            Surface(shadowElevation = 12.dp, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
                Column(Modifier.padding(16.dp)) {
                    if (vm.error) {
                        Text(s.invalidAmountError, color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (vm.overpaymentError) {
                        Text(s.overpaymentBlockedMessage, color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Button(
                        onClick = { vm.save(onSaved) },
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("${s.addPaymentButton} — ${UnitConverter.rupees(amountEntered)}", fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).background(c.Success.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Payments, contentDescription = null, tint = c.Success) }
                Spacer(Modifier.width(10.dp))
                Text(sk?.paymentPageTitle ?: s.paymentPageTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(16.dp))

            // ⭐ বর্তমান বাকি — গ্রেডিয়েন্ট কার্ডে, সাদা বোল্ড অঙ্ক
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
                    .padding(18.dp)
            ) {
                Column {
                    Text(sk?.currentDueLabel ?: s.currentDueLabel, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.9f),
                        fontWeight = FontWeight.SemiBold)
                    Text(UnitConverter.rupees(currentDue), style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold, color = androidx.compose.ui.graphics.Color.White)
                }
            }
            Spacer(Modifier.height(20.dp))

            Text(s.howMuchPaymentLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = vm.amount,
                onValueChange = vm::updateAmount,
                singleLine = true,
                isError = vm.error || vm.overpaymentError,
                shape = RoundedCornerShape(20.dp),
                prefix = { Text("₹", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) },
                textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                quickAmounts.forEach { qa ->
                    AssistChip(
                        onClick = { vm.setQuickAmount(qa) },
                        shape = RoundedCornerShape(20.dp),
                        label = { Text(UnitConverter.rupees(qa), fontWeight = FontWeight.Bold) }
                    )
                }
                AssistChip(
                    onClick = { vm.setFullPayment() },
                    shape = RoundedCornerShape(20.dp),
                    colors = AssistChipDefaults.assistChipColors(containerColor = c.Success.copy(alpha = 0.15f), labelColor = c.Success),
                    label = { Text(s.fullPaymentButton, fontWeight = FontWeight.ExtraBold) }
                )
            }
            Spacer(Modifier.height(20.dp))

            Card(
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(s.dueAfterPaymentLabel, color = c.Muted, fontWeight = FontWeight.SemiBold)
                    Text(UnitConverter.rupees(dueAfter), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = c.Success)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${UnitConverter.rupees(currentDue)} − ${UnitConverter.rupees(amountEntered)} = ${UnitConverter.rupees(dueAfter)}",
                        style = MaterialTheme.typography.bodySmall, color = c.Muted
                    )
                    if (dueAfter == 0.0 && amountEntered > 0) {
                        Spacer(Modifier.height(6.dp))
                        Text(s.fullyPaidCelebration, color = c.Success, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = vm.note, onValueChange = vm::updateNote,
                label = { Text(s.noteLabel) },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
