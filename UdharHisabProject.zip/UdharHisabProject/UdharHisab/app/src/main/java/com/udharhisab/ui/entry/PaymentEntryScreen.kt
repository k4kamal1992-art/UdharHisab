package com.udharhisab.ui.entry

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentEntryScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    val shop by container.repo.shopByIdFlow(shopId).collectAsState(initial = null)

    val shopVal = shop
    if (shopVal == null) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Spacer(Modifier.height(40.dp))
            com.udharhisab.ui.components.SkeletonHeroCard()
            Spacer(Modifier.height(16.dp))
            com.udharhisab.ui.components.ShimmerBlock(Modifier.fillMaxWidth(), height = 52.dp, corner = 14.dp)
        }
        return
    }
    val shopName = shopVal.name

    val vm: PaymentEntryViewModel = viewModel { PaymentEntryViewModel(container.repo, shopId) }
    val currentDue = vm.currentDue

    LaunchedEffect(vm.saved) { if (vm.saved) onSaved() }

    val quickAmounts = listOf(50.0, 100.0, 200.0, 500.0).filter { it <= currentDue && it > 0 }
    val dueAfter = vm.dueAfter()
    val amountEntered = vm.amount.toDoubleOrNull() ?: 0.0

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(shopName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${sk?.currentDueLabel ?: s.currentDueLabel}: ${UnitConverter.rupees(currentDue)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Primary,
                    scrolledContainerColor = c.Primary,
                    titleContentColor = androidx.compose.ui.graphics.Color.White,
                    navigationIconContentColor = androidx.compose.ui.graphics.Color.White,
                    actionIconContentColor = androidx.compose.ui.graphics.Color.White
                )
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Column(Modifier.padding(16.dp)) {
                    if (vm.error) {
                        Text(s.invalidAmountError, color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (vm.overpaymentError) {
                        Text(s.overpaymentBlockedMessage, color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Button(
                        onClick = { vm.save(onSaved) },
                        colors = ButtonDefaults.buttonColors(containerColor = c.Success),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        Text("${s.addPaymentButton} — ${UnitConverter.rupees(amountEntered)}")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Payments, contentDescription = null, tint = c.Success)
                Spacer(Modifier.width(8.dp))
                Text(sk?.paymentPageTitle ?: s.paymentPageTitle, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.height(16.dp))

            Card(colors = CardDefaults.cardColors(containerColor = c.ChipBg), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(sk?.currentDueLabel ?: s.currentDueLabel, color = c.Muted)
                    Text(UnitConverter.rupees(currentDue), style = MaterialTheme.typography.headlineMedium, color = c.Primary)
                }
            }
            Spacer(Modifier.height(20.dp))

            Text(s.howMuchPaymentLabel, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = vm.amount,
                onValueChange = vm::updateAmount,
                singleLine = true,
                isError = vm.error || vm.overpaymentError,
                textStyle = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                quickAmounts.forEach { qa ->
                    AssistChip(
                        onClick = { vm.setQuickAmount(qa) },
                        label = { Text(UnitConverter.rupees(qa)) }
                    )
                }
                AssistChip(
                    onClick = { vm.setFullPayment() },
                    label = { Text(s.fullPaymentButton) }
                )
            }
            Spacer(Modifier.height(20.dp))

            Card(colors = CardDefaults.cardColors(containerColor = c.Surface), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(s.dueAfterPaymentLabel, color = c.Muted)
                    Text(UnitConverter.rupees(dueAfter), style = MaterialTheme.typography.headlineMedium, color = c.Success)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${UnitConverter.rupees(currentDue)} − ${UnitConverter.rupees(amountEntered)} = ${UnitConverter.rupees(dueAfter)}",
                        style = MaterialTheme.typography.bodySmall, color = c.Muted
                    )
                    if (dueAfter == 0.0 && amountEntered > 0) {
                        Spacer(Modifier.height(6.dp))
                        Text(s.fullyPaidCelebration, color = c.Success, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = vm.note, onValueChange = vm::updateNote,
                label = { Text(s.noteLabel) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
