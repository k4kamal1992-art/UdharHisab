package com.yourname.udharhisab.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.data.model.Transaction
import com.yourname.udharhisab.data.repository.TransactionRepository

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val transactionRepository: TransactionRepository =
        (application as UdharHisabApp).transactionRepository

    val allTransactions: LiveData<List<Transaction>> = transactionRepository.getAllTransactions()
}
