package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * ⭐ প্রতিটা দোকানের নিজস্ব প্রোডাক্ট লিস্ট + শেষবার ব্যবহৃত দাম।
 * একই প্রোডাক্টের দাম ভিন্ন ভিন্ন দোকানে ভিন্ন হতে পারে বলে shopId + name
 * — এই জোড়া মিলিয়ে ইউনিক রাখা হয়েছে (এক দোকানে এক নামের একটাই রেকর্ড)।
 */
@Entity(
    tableName = "shop_products",
    indices = [Index(value = ["shopId", "name"], unique = true)]
)
data class ShopProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: Long,
    val name: String,
    val lastUnit: String? = null,
    val lastUnitPrice: Double? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
