package com.udharhisab.domain

/**
 * ⭐ টাকার অঙ্ক কথায় — ক্যাশ মেমোর "টাকা কথায়" লাইনের জন্য (ভারতীয় হিসাব: হাজার, লক্ষ, কোটি)।
 * ভাষা: "bn" বাংলা, "hi" হিন্দি, "en" ইংরেজি।
 */
object AmountInWords {

    private val BN = arrayOf(
        "শূন্য", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়",
        "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোল", "সতেরো", "আঠারো", "উনিশ",
        "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আটাশ", "ঊনত্রিশ",
        "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁয়ত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ",
        "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁয়তাল্লিশ", "ছেচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ",
        "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট",
        "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁয়ষট্টি", "ছেষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর",
        "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি",
        "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই",
        "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"
    )

    private val HI = arrayOf(
        "शून्य", "एक", "दो", "तीन", "चार", "पाँच", "छह", "सात", "आठ", "नौ",
        "दस", "ग्यारह", "बारह", "तेरह", "चौदह", "पंद्रह", "सोलह", "सत्रह", "अठारह", "उन्नीस",
        "बीस", "इक्कीस", "बाईस", "तेईस", "चौबीस", "पच्चीस", "छब्बीस", "सत्ताईस", "अट्ठाईस", "उनतीस",
        "तीस", "इकतीस", "बत्तीस", "तैंतीस", "चौंतीस", "पैंतीस", "छत्तीस", "सैंतीस", "अड़तीस", "उनतालीस",
        "चालीस", "इकतालीस", "बयालीस", "तैंतालीस", "चौवालीस", "पैंतालीस", "छियालीस", "सैंतालीस", "अड़तालीस", "उनचास",
        "पचास", "इक्यावन", "बावन", "तिरेपन", "चौवन", "पचपन", "छप्पन", "सत्तावन", "अट्ठावन", "उनसठ",
        "साठ", "इकसठ", "बासठ", "तिरेसठ", "चौंसठ", "पैंसठ", "छियासठ", "सड़सठ", "अड़सठ", "उनहत्तर",
        "सत्तर", "इकहत्तर", "बहत्तर", "तिहत्तर", "चौहत्तर", "पचहत्तर", "छिहत्तर", "सतहत्तर", "अठहत्तर", "उन्यासी",
        "अस्सी", "इक्यासी", "बयासी", "तिरासी", "चौरासी", "पचासी", "छियासी", "सत्तासी", "अट्ठासी", "नवासी",
        "नब्बे", "इक्यानवे", "बानवे", "तिरानवे", "चौरानवे", "पंचानवे", "छियानवे", "सत्तानवे", "अट्ठानवे", "निन्यानवे"
    )

    private val EN_ONES = arrayOf(
        "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
        "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    )
    private val EN_TENS = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")

    /** 0..99 */
    private fun below100(lang: String, n: Int): String = when (lang) {
        "en" -> if (n < 20) EN_ONES[n] else EN_TENS[n / 10] + if (n % 10 != 0) " " + EN_ONES[n % 10] else ""
        "hi" -> HI[n]
        else -> BN[n]
    }

    private fun hundredWord(lang: String, digit: Int): String = when (lang) {
        "en" -> "${EN_ONES[digit]} Hundred"
        "hi" -> "${HI[digit]} सौ"
        else -> BN[digit] + "শো"
    }

    private fun unitWord(lang: String, unit: String): String = when (lang) {
        "en" -> when (unit) { "crore" -> "Crore"; "lakh" -> "Lakh"; else -> "Thousand" }
        "hi" -> when (unit) { "crore" -> "करोड़"; "lakh" -> "लाख"; else -> "हज़ार" }
        else -> when (unit) { "crore" -> "কোটি"; "lakh" -> "লক্ষ"; else -> "হাজার" }
    }

    /** ০ থেকে বড় যেকোনো পূর্ণসংখ্যা (ভারতীয় গ্রুপিং) */
    private fun words(lang: String, n: Long): String {
        if (n == 0L) return below100(lang, 0)
        val parts = mutableListOf<String>()
        var rest = n

        val crore = rest / 10_000_000L
        rest %= 10_000_000L
        if (crore > 0) parts += words(lang, crore) + " " + unitWord(lang, "crore")

        val lakh = (rest / 100_000L).toInt()
        rest %= 100_000L
        if (lakh > 0) parts += below100(lang, lakh) + " " + unitWord(lang, "lakh")

        val thousand = (rest / 1_000L).toInt()
        rest %= 1_000L
        if (thousand > 0) parts += below100(lang, thousand) + " " + unitWord(lang, "thousand")

        val hundred = (rest / 100L).toInt()
        val last = (rest % 100L).toInt()
        if (hundred > 0) parts += hundredWord(lang, hundred)
        if (last > 0) parts += below100(lang, last)

        return parts.joinToString(" ")
    }

    /** 1161837.0 → "এগারো লক্ষ একষট্টি হাজার আটশো সাঁইত্রিশ টাকা মাত্র" */
    fun format(lang: String, amount: Double): String {
        val totalPaise = kotlin.math.round(maxOf(amount, 0.0) * 100).toLong()
        val rupees = totalPaise / 100
        val paise = (totalPaise % 100).toInt()

        val rupeeWord: String; val paiseWord: String; val onlyWord: String; val andWord: String
        when (lang) {
            "en" -> { rupeeWord = "Rupees"; paiseWord = "Paise"; onlyWord = "Only"; andWord = "and" }
            "hi" -> { rupeeWord = "रुपये"; paiseWord = "पैसे"; onlyWord = "मात्र"; andWord = "और" }
            else -> { rupeeWord = "টাকা"; paiseWord = "পয়সা"; onlyWord = "মাত্র"; andWord = "ও" }
        }
        val sb = StringBuilder(words(lang, rupees)).append(' ').append(rupeeWord)
        if (paise > 0) sb.append(' ').append(andWord).append(' ').append(below100(lang, paise)).append(' ').append(paiseWord)
        sb.append(' ').append(onlyWord)
        return sb.toString()
    }
}
