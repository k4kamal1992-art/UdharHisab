package com.udharhisab.data.settings

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * ⭐ দোকানের লোগো — গ্যালারি থেকে বেছে নিলে ছোট করে (সর্বোচ্চ ৫১২px) অ্যাপের নিজস্ব
 * ফোল্ডারে PNG হিসেবে রাখা হয়, যাতে গ্যালারি থেকে ছবি মুছলেও PDF-এ লোগো থাকে।
 */
object LogoStorage {
    private const val MAX_SIDE = 512

    /** বাছাই করা ছবি সেভ করে ফাইল-পাথ ফেরত দেয়; ব্যর্থ হলে null */
    suspend fun saveFromUri(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > MAX_SIDE * 2 || bounds.outHeight / sample > MAX_SIDE * 2) sample *= 2

            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@withContext null

            val scale = MAX_SIDE.toFloat() / maxOf(decoded.width, decoded.height)
            val out = if (scale < 1f)
                Bitmap.createScaledBitmap(decoded, (decoded.width * scale).toInt().coerceAtLeast(1), (decoded.height * scale).toInt().coerceAtLeast(1), true)
            else decoded

            val file = File(context.filesDir, "shop_logo_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            // পুরনো লোগো ফাইল মুছে ফেলি
            context.filesDir.listFiles { f -> f.name.startsWith("shop_logo_") && f != file }?.forEach { it.delete() }
            file.absolutePath
        } catch (_: Exception) { null }
    }

    fun delete(path: String?) {
        if (path != null) runCatching { File(path).delete() }
    }

    /** PDF-এ আঁকার জন্য — মাঝখান থেকে বর্গাকারে কেটে [size]×[size] করে দেয় */
    fun loadSquare(path: String, size: Int): Bitmap? {
        val src = BitmapFactory.decodeFile(path) ?: return null
        val side = minOf(src.width, src.height)
        val cropped = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(cropped, size, size, true)
    }
}
