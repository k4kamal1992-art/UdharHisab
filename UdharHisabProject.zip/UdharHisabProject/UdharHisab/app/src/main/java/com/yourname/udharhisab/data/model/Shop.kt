package com.yourname.udharhisab.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Shop entity - represents a customer or shop
 */
@Entity(tableName = "shops")
data class Shop(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val ownerName: String = "",
    val phone: String = "",
    val address: String = "",
    val shopType: String = "general",
    val createdAt: Long = System.currentTimeMillis()
)
