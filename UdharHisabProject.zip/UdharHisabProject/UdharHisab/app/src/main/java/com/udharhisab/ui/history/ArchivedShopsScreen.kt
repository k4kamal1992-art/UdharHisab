package com.udharhisab.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ আগে এটাই "History" ছিল — এখন বটম-ন্যাভের "History" ট্যাব সব লেনদেনের লিস্ট দেখায়,
 * আর আর্কাইভ/পরিশোধিত দোকানের এই লিস্টটা সেখানকার টপ বার থেকে আলাদাভাবে খোলা যায়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchivedShopsScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onOpenShop: (Long) -> Unit
) {
    val vm: HistoryViewModel = viewModel { HistoryViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val shops by vm.shops.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val tab by vm.tab.collectAsState()

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.archive) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                }
            )
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                TabRow(selectedTabIndex = tab.ordinal) {
                    Tab(
                        selected = tab == HistoryViewModel.Tab.ARCHIVED,
                        onClick = { vm.setTab(HistoryViewModel.Tab.ARCHIVED) },
                        text = { Text(s.archive) }
                    )
                    Tab(
                        selected = tab == HistoryViewModel.Tab.SETTLED,
                        onClick = { vm.setTab(HistoryViewModel.Tab.SETTLED) },
                        text = { Text(s.settledLabel) }
                    )
                }

                Spacer(Modifier.height(12.dp))

                if (isLoading) {
                    com.udharhisab.ui.components.SkeletonList()
                } else if (shops.isEmpty()) {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        com.udharhisab.ui.components.EmptyStateIcon(Icons.Default.Archive)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (tab == HistoryViewModel.Tab.ARCHIVED)
                                s.noArchivedShops else s.noSettledShops,
                            color = c.Muted
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(shops, key = { it.shop.id }) { swb ->
                            Card(
                                shape = MaterialTheme.shapes.medium,
                                colors = CardDefaults.cardColors(containerColor = c.Surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenShop(swb.shop.id) }
                            ) {
                                Row(Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(c.ChipBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            painter = painterResource(ShopType.fromKey(swb.shop.shopType).iconRes),
                                            contentDescription = null,
                                            tint = c.Primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(swb.shop.name,
                                            style = MaterialTheme.typography.titleMedium)
                                    }
                                    if (swb.balance > 0) {
                                        Text(
                                            UnitConverter.rupees(swb.balance),
                                            color = c.Danger
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = c.Success,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
