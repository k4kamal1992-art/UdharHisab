package com.udharhisab.ui.entry

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.repository.HisabRepository
import com.udharhisab.domain.UnitConverter
import kotlinx.coroutines.launch

/**
 * ⭐ ফিক্স: currentDue কনস্ট্রাক্টরে না নিয়ে নিজেই suspend কল করে লোড করে —
 * আগে Composable-এ remember{mutableStateOf(0.0)} দিয়ে অ্যাসিঙ্ক্রোনাসলি লোড করে
 * viewModel{} factory-তে পাস করা হতো, কিন্তু factory শুধু প্রথমবারই চলে, তাই
 * due লোড হওয়ার আগে ViewModel তৈরি হলে চিরকাল 0.0-ই থেকে যেত — ফলে যেকোনো
 * পেমেন্টই "overpayment" হিসেবে block হয়ে যেত।
 */
class PaymentEntryViewModel(
    private val repo: HisabRepository,
    private val shopId: Long
) : ViewModel() {

    var currentDue by mutableStateOf(0.0)
        private set

    var amount by mutableStateOf("")
        private set
    var note by mutableStateOf("")
        private set
    var error by mutableStateOf(false)
        private set
    var overpaymentError by mutableStateOf(false)
        private set
    var saved by mutableStateOf(false)
        private set

    init {
        viewModelScope.launch { currentDue = repo.balanceOnce(shopId) }
    }

    fun updateAmount(v: String) { amount = v; error = false; overpaymentError = false }
    fun updateNote(v: String) { note = v }

    fun setQuickAmount(v: Double) {
        amount = UnitConverter.amountInput(v)
        error = false; overpaymentError = false
    }

    fun setFullPayment() {
        amount = UnitConverter.amountInput(currentDue)
        error = false; overpaymentError = false
    }

    fun dueAfter(): Double {
        val amt = amount.toDoubleOrNull() ?: 0.0
        return (currentDue - amt).coerceAtLeast(0.0)
    }

    fun save(onDone: () -> Unit) {
        val amt = amount.toDoubleOrNull()
        when {
            amt == null || amt <= 0 -> error = true
            amt > currentDue -> overpaymentError = true
            else -> viewModelScope.launch {
                repo.insertPayment(shopId, amt, null, note.ifBlank { null })
                saved = true
                onDone()
            }
        }
    }
}
