package com.udharhisab.ads

import android.app.Activity
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

/**
 * ⭐ Google UMP — ইউরোপ/যুক্তরাজ্যের মতো এলাকায় বিজ্ঞাপনের আগে ব্যবহারকারীর সম্মতি নেয়।
 * ভারত/বাংলাদেশে সাধারণত কোনো ফর্ম আসে না, সরাসরি এগিয়ে যায়।
 * (AdMob কনসোলের Privacy & messaging-এ একটা সম্মতি বার্তা তৈরি করে Publish করতে হবে।)
 */
object ConsentHelper {

    fun gather(activity: Activity, onDone: () -> Unit) {
        val info = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()
        info.requestConsentInfoUpdate(
            activity, params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { onDone() }
            },
            { onDone() }
        )
    }

    fun canRequestAds(activity: Activity): Boolean =
        UserMessagingPlatform.getConsentInformation(activity).canRequestAds()

    /** ইউরোপে "বিজ্ঞাপনের পছন্দ" বদলানোর সুযোগ দেওয়া বাধ্যতামূলক */
    fun privacyOptionsRequired(activity: Activity): Boolean =
        UserMessagingPlatform.getConsentInformation(activity).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity, onDismiss: () -> Unit = {}) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { onDismiss() }
    }
}
