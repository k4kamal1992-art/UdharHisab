package com.udharhisab.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.udharhisab.R
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onAddShop: () -> Unit,
    onOpenShop: (Long) -> Unit
) {
    val vm: HomeViewModel = viewModel {
        HomeViewModel(container.repo)
    }
    val shops by vm.visibleShops.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val totalDue by vm.totalDue.collectAsState()
    val monthlyTotals by vm.monthlyTotals.collectAsState()
    val search by vm.search.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    Scaffold(
        containerColor = c.Background,
        floatingActionButton = {
            if (!isLoading && shops.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = onAddShop,
                    containerColor = c.Primary,
                    contentColor = androidx.compose.ui.graphics.Color.White
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text(s.newShop)
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // ── টপ বার ──
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.logo),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(Modifier.width(8.dp))
                Text(s.homeHeadline, style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))

            // ── হিরো কার্ড: মোট বাকি + মাসিক সারাংশ ──
            Card(
                colors = CardDefaults.cardColors(containerColor = c.Primary),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(s.totalDueLabel,
                        style = MaterialTheme.typography.displaySmall,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f))
                    Spacer(Modifier.height(4.dp))
                    Text(
                        UnitConverter.rupees(totalDue),
                        style = MaterialTheme.typography.displayLarge,
                        color = androidx.compose.ui.graphics.Color.White
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MonthlyMiniCard(
                            modifier = Modifier.weight(1f),
                            label = s.thisMonthPaymentLabel,
                            amount = monthlyTotals.totalPayment,
                            bg = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.16f)
                        )
                        MonthlyMiniCard(
                            modifier = Modifier.weight(1f),
                            label = s.thisMonthCreditLabel,
                            amount = monthlyTotals.totalCredit,
                            bg = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.16f)
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // ── সার্চ ──
            OutlinedTextField(
                value = search,
                onValueChange = vm::setSearch,
                placeholder = { Text(s.searchPlaceholder) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Primary,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            // ── ফিল্টার চিপ ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { vm.setTypeFilter(null) },
                    label = { Text(s.filterAll) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = c.Primary,
                        selectedLabelColor = androidx.compose.ui.graphics.Color.White
                    )
                )
                ShopType.entries.forEach { t ->
                    FilterChip(
                        selected = typeFilter == t,
                        onClick = { vm.setTypeFilter(if (typeFilter == t) null else t) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(t.iconRes),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(t.displayName(s)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = c.Primary,
                            selectedLabelColor = androidx.compose.ui.graphics.Color.White,
                            selectedLeadingIconColor = androidx.compose.ui.graphics.Color.White
                        )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // ── লিস্ট / লোডিং স্কেলেটন / এম্পটি ──
            if (isLoading) {
                com.udharhisab.ui.components.SkeletonList()
            } else if (shops.isEmpty()) {
                EmptyHome(onAddShop = onAddShop)
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(shops, key = { it.shop.id }) { swb ->
                        ShopCard(swb, onClick = { onOpenShop(swb.shop.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopCard(swb: com.udharhisab.data.local.ShopWithBalance, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val type = ShopType.fromKey(swb.shop.shopType)
    val balance = swb.balance
    val isSettled = balance <= 0.0

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ক্যাটাগরি আইকন অবতার
            Box(
                Modifier
                    .size(46.dp)
                    .background(c.ChipBg, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(type.iconRes),
                    contentDescription = null,
                    tint = c.Primary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(swb.shop.name, style = MaterialTheme.typography.titleMedium)
                swb.shop.phone?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                }
                Text(type.displayName(s), style = MaterialTheme.typography.labelSmall, color = c.Muted)
            }
            if (isSettled) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = c.Success,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(s.settledLabel, style = MaterialTheme.typography.titleMedium, color = c.Success)
                }
            } else {
                Text(
                    UnitConverter.rupees(balance),
                    style = MaterialTheme.typography.titleMedium,
                    color = c.Danger
                )
            }
        }
    }
}

@Composable
private fun EmptyHome(onAddShop: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        com.udharhisab.ui.components.EmptyStateIcon(Icons.Default.Storefront)
        Spacer(Modifier.height(16.dp))
        Text(s.noShopsYetTitle,
            style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(s.noShopsYetSubtitle,
            style = MaterialTheme.typography.bodyMedium, color = c.Muted)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAddShop) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(s.addFirstShopButton)
        }
    }
}

@Composable
private fun MonthlyMiniCard(
    modifier: Modifier = Modifier,
    label: String,
    amount: Double,
    bg: androidx.compose.ui.graphics.Color
) {
    Column(
        modifier
            .clip(MaterialTheme.shapes.medium)
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f)
        )
        Spacer(Modifier.height(2.dp))
        Text(
            UnitConverter.rupees(amount),
            style = MaterialTheme.typography.titleMedium,
            color = androidx.compose.ui.graphics.Color.White
        )
    }
}
