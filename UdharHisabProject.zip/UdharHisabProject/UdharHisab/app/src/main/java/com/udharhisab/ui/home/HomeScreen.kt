package com.udharhisab.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onAddShop: () -> Unit,
    onOpenShop: (Long) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val vm: HomeViewModel = viewModel {
        HomeViewModel(container.repo)
    }
    val shops by vm.visibleShops.collectAsState()
    val totalDue by vm.totalDue.collectAsState()
    val search by vm.search.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    Scaffold(
        containerColor = c.Background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddShop,
                containerColor = c.Primary,
                contentColor = androidx.compose.ui.graphics.Color.White
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(s.newShop)
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // ── টপ বার ──
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s.homeHeadline, style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.weight(1f))
                IconButton(onClick = onOpenHistory) {
                    Icon(Icons.Default.History, s.history, tint = c.TextSecondary)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, s.settings, tint = c.TextSecondary)
                }
            }

            Spacer(Modifier.height(12.dp))

            // ── হিরো কার্ড: মোট বাকি ──
            Card(
                colors = CardDefaults.cardColors(containerColor = c.Primary),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(s.totalDueLabel,
                        style = MaterialTheme.typography.displaySmall,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f))
                    Spacer(Modifier.height(4.dp))
                    Text(
                        UnitConverter.rupees(totalDue),
                        style = MaterialTheme.typography.displayLarge,
                        color = androidx.compose.ui.graphics.Color.White
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ── সার্চ ──
            OutlinedTextField(
                value = search,
                onValueChange = vm::setSearch,
                placeholder = { Text(s.searchPlaceholder) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Primary,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            // ── ফিল্টার চিপ ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { vm.setTypeFilter(null) },
                    label = { Text(s.filterAll) }
                )
                ShopType.entries.forEach { t ->
                    FilterChip(
                        selected = typeFilter == t,
                        onClick = { vm.setTypeFilter(if (typeFilter == t) null else t) },
                        label = { Text("${t.emoji} ${t.displayName(s)}") }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // ── লিস্ট / এম্পটি ──
            if (shops.isEmpty()) {
                EmptyHome(onAddShop = onAddShop)
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(shops, key = { it.shop.id }) { swb ->
                        ShopCard(swb, onClick = { onOpenShop(swb.shop.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopCard(swb: com.udharhisab.data.local.ShopWithBalance, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val type = ShopType.fromKey(swb.shop.shopType)
    val balance = swb.balance
    val isSettled = balance <= 0.0

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // emoji অবতার
            Box(
                Modifier
                    .size(46.dp)
                    .background(c.ChipBg, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(type.emoji, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(swb.shop.name, style = MaterialTheme.typography.titleMedium)
                swb.shop.phone?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                }
                Text(type.displayName(s), style = MaterialTheme.typography.labelSmall, color = c.Muted)
            }
            Text(
                when {
                    isSettled -> "🎉 ${s.settledLabel}"
                    else -> UnitConverter.rupees(balance)
                },
                style = MaterialTheme.typography.titleMedium,
                color = if (isSettled) c.Success else c.Danger
            )
        }
    }
}

@Composable
private fun EmptyHome(onAddShop: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🏪", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(12.dp))
        Text(s.noShopsYetTitle,
            style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(s.noShopsYetSubtitle,
            style = MaterialTheme.typography.bodyMedium, color = c.Muted)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAddShop) {
            Text(s.addFirstShopButton)
        }
    }
}
