package com.udharhisab.ui.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.udharhisab.ui.components.ShopIllustration
import com.udharhisab.ui.components.bouncyClick
import com.udharhisab.ui.components.rememberCountUp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.udharhisab.R
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.theme.LocalShopkeeperLabels
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onAddShop: () -> Unit,
    onOpenShop: (Long) -> Unit
) {
    val vm: HomeViewModel = viewModel {
        HomeViewModel(container.repo)
    }
    val shops by vm.visibleShops.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val totalDue by vm.totalDue.collectAsState()
    val monthlyTotals by vm.monthlyTotals.collectAsState()
    val search by vm.search.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current

    Scaffold(
        containerColor = c.Background,
        floatingActionButton = {
            if (!isLoading && shops.isNotEmpty()) {
                com.udharhisab.ui.components.GradientFab(
                    text = sk?.newShopButton ?: s.newShop,
                    icon = Icons.Default.Add,
                    onClick = onAddShop
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            // ── টপ বার ──
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.logo),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Spacer(Modifier.width(10.dp))
                Text(s.homeHeadline, style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))

            // ── ⭐ হিরো কার্ড: গ্রেডিয়েন্ট, ভাসমান বৃত্ত, গুনে গুনে বাড়া অঙ্ক ──
            val shownDue = rememberCountUp(totalDue)
            Box(
                Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(28.dp), ambientColor = c.Primary, spotColor = c.Primary)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(c.Primary, c.Accent)))
            ) {
                // সাজসজ্জার নরম বৃত্ত
                Canvas(Modifier.matchParentSize()) {
                    drawCircle(Color.White.copy(alpha = 0.10f), size.height * 0.75f, Offset(size.width * 0.95f, size.height * 0.05f))
                    drawCircle(Color.White.copy(alpha = 0.08f), size.height * 0.45f, Offset(size.width * 0.78f, size.height * 1.0f))
                    drawCircle(Color(0xFFFFC857).copy(alpha = 0.9f), size.height * 0.035f, Offset(size.width * 0.9f, size.height * 0.28f))
                }
                Column(Modifier.padding(20.dp)) {
                    Text(sk?.totalDueLabel ?: s.totalDueLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.9f))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        UnitConverter.rupees(shownDue),
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MonthlyMiniCard(
                            modifier = Modifier.weight(1f),
                            label = sk?.thisMonthPaymentLabel ?: s.thisMonthPaymentLabel,
                            amount = monthlyTotals.totalPayment,
                            icon = Icons.Default.ArrowDownward,
                            iconBg = Color(0xFF7DDAB9)
                        )
                        MonthlyMiniCard(
                            modifier = Modifier.weight(1f),
                            label = sk?.thisMonthCreditLabel ?: s.thisMonthCreditLabel,
                            amount = monthlyTotals.totalCredit,
                            icon = Icons.Default.ArrowUpward,
                            iconBg = Color(0xFFFF8A65)
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // ── সার্চ ──
            OutlinedTextField(
                value = search,
                onValueChange = vm::setSearch,
                placeholder = { Text(sk?.searchPlaceholder ?: s.searchPlaceholder) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Primary,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            // ── ফিল্টার চিপ ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { vm.setTypeFilter(null) },
                    shape = RoundedCornerShape(20.dp),
                    label = { Text(s.filterAll, fontWeight = FontWeight.SemiBold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = c.Primary,
                        selectedLabelColor = androidx.compose.ui.graphics.Color.White
                    )
                )
                ShopType.entries.forEach { t ->
                    FilterChip(
                        selected = typeFilter == t,
                        shape = RoundedCornerShape(20.dp),
                        onClick = { vm.setTypeFilter(if (typeFilter == t) null else t) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(t.iconRes),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(t.displayName(s)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = c.Primary,
                            selectedLabelColor = androidx.compose.ui.graphics.Color.White,
                            selectedLeadingIconColor = androidx.compose.ui.graphics.Color.White
                        )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // ── লিস্ট / লোডিং স্কেলেটন / এম্পটি ──
            if (isLoading) {
                com.udharhisab.ui.components.SkeletonList()
            } else if (shops.isEmpty()) {
                // ⭐ বাকি জায়গাটুকুতেই বসে (ব্যানার বিজ্ঞাপনের জায়গা বাদ দিয়ে), বেশি লম্বা হলে স্ক্রল করে
                EmptyHome(onAddShop = onAddShop, modifier = Modifier.weight(1f))
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(shops, key = { it.shop.id }) { swb ->
                        ShopCard(swb, onClick = { onOpenShop(swb.shop.id) }, modifier = Modifier.animateItemPlacement())
                    }
                }
            }
        }
    }
}

/** প্রতিটা দোকানের নিজের রঙ — (নরম জমি, গাঢ় আইকন) */
private val AvatarPalette = listOf(
    Color(0xFFD9F5EA) to Color(0xFF087F5B),
    Color(0xFFFFE3D9) to Color(0xFFE2562B),
    Color(0xFFFFF0C9) to Color(0xFFB77F00),
    Color(0xFFDCEEFF) to Color(0xFF2B6FD1),
    Color(0xFFECE4FF) to Color(0xFF6A47D6),
    Color(0xFFFFE0E8) to Color(0xFFD1355F)
)

@Composable
private fun ShopCard(
    swb: com.udharhisab.data.local.ShopWithBalance,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val type = ShopType.fromKey(swb.shop.shopType)
    val balance = swb.balance
    val isSettled = balance <= 0.0
    val (avatarBg, avatarFg) = AvatarPalette[(swb.shop.id % AvatarPalette.size).toInt().coerceAtLeast(0)]

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .bouncyClick(onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ⭐ নিজস্ব রঙের অবতার
            Box(
                Modifier
                    .size(50.dp)
                    .background(avatarBg, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(type.iconRes),
                    contentDescription = null,
                    tint = avatarFg,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(swb.shop.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val sub = listOfNotNull(swb.shop.phone, type.displayName(s)).joinToString(" • ")
                Text(sub, style = MaterialTheme.typography.bodySmall, color = c.Muted, maxLines = 1)
            }
            // ⭐ টাকার পিল — বাকি হলে লালচে, পরিশোধ হলে সবুজ
            if (isSettled) {
                Row(
                    Modifier
                        .background(c.Success.copy(alpha = 0.14f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, null, tint = c.Success, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(s.settledLabel, style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold, color = c.Success)
                }
            } else {
                Box(
                    Modifier
                        .background(c.Danger.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        UnitConverter.rupees(balance),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = c.Danger
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyHome(onAddShop: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val sk = LocalShopkeeperLabels.current
    // ⭐ আগে ছিল স্থির ৬০dp উপরে ফাঁক আর স্ক্রল ছাড়া — ব্যানার বিজ্ঞাপন জায়গা নিলে "প্রথম দোকান যোগ করুন"
    // বাটন নিচে কেটে যেত। এখন মাঝখানে বসে, জায়গা কম হলে স্ক্রল করা যায়, তাই বাটন কখনো ঢাকে না।
    Column(
        modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ShopIllustration()
        Spacer(Modifier.height(8.dp))
        Text(sk?.noShopsYetTitle ?: s.noShopsYetTitle,
            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(4.dp))
        Text(sk?.noShopsYetSubtitle ?: s.noShopsYetSubtitle,
            style = MaterialTheme.typography.bodyMedium, color = c.Muted)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onAddShop,
            shape = RoundedCornerShape(24.dp),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(sk?.addFirstShopButton ?: s.addFirstShopButton, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MonthlyMiniCard(
    modifier: Modifier = Modifier,
    label: String,
    amount: Double,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color
) {
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(30.dp).background(iconBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.9f),
                maxLines = 1
            )
            Text(
                UnitConverter.rupees(amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                maxLines = 1
            )
        }
    }
}
