package com.udharhisab.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBasket
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onAddShop: () -> Unit,
    onOpenShop: (Long) -> Unit
) {
    val vm: HomeViewModel = viewModel { HomeViewModel(container.repo) }
    val shops by vm.visibleShops.collectAsState()
    val totalDue by vm.totalDue.collectAsState()
    val search by vm.search.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    Scaffold(
        containerColor = c.Background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddShop,
                containerColor = c.Primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 5.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = s.newShop)
                Spacer(Modifier.width(7.dp))
                Text(s.newShop, fontWeight = FontWeight.SemiBold)
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(10.dp))

            // Modern header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = s.homeHeadline,
                        style = MaterialTheme.typography.headlineMedium,
                        color = c.TextPrimary
                    )
                    Text(
                        text = "আপনার সব ধার-পাওনার হিসাব এক জায়গায়",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.Muted
                    )
                }
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(c.ChipBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = c.Primary)
                }
            }

            Spacer(Modifier.height(16.dp))

            // Balance hero card — deep green is reserved for the depth/contrast layer.
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = c.Primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(c.Primary)
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.14f)
                            ) {
                                Icon(
                                    Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.padding(9.dp)
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                s.totalDueLabel,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White.copy(alpha = 0.88f)
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            UnitConverter.rupees(totalDue),
                            style = MaterialTheme.typography.displayLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "বর্তমান মোট বাকি",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.72f)
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Search + filter
            OutlinedTextField(
                value = search,
                onValueChange = vm::setSearch,
                placeholder = { Text(s.searchPlaceholder) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = c.Muted) },
                trailingIcon = { Icon(Icons.Default.Tune, null, tint = c.Primary) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Primary,
                    unfocusedIndicatorColor = c.Divider,
                    cursorColor = c.Primary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .fillMaxWidth()
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { vm.setTypeFilter(null) },
                    label = { Text(s.filterAll) },
                    leadingIcon = if (typeFilter == null) {
                        { Icon(Icons.Default.Storefront, null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = c.ChipBg,
                        selectedLabelColor = c.Primary,
                        selectedLeadingIconColor = c.Primary
                    )
                )
                ShopType.entries.forEach { type ->
                    FilterChip(
                        selected = typeFilter == type,
                        onClick = { vm.setTypeFilter(if (typeFilter == type) null else type) },
                        label = { Text(type.displayName(s)) },
                        leadingIcon = {
                            Icon(shopTypeIcon(type), null, modifier = Modifier.size(16.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = c.ChipBg,
                            selectedLabelColor = c.Primary,
                            selectedLeadingIconColor = c.Primary
                        )
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            if (shops.isEmpty()) {
                EmptyHome(onAddShop = onAddShop)
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(shops, key = { it.shop.id }) { swb ->
                        ShopCard(swb, onClick = { onOpenShop(swb.shop.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopCard(swb: ShopWithBalance, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val type = ShopType.fromKey(swb.shop.shopType)
    val balance = swb.balance
    val isSettled = balance <= 0.0

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(c.ChipBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(shopTypeIcon(type), contentDescription = type.displayName(s), tint = c.Primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(swb.shop.name, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                swb.shop.phone?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                }
                Text(type.displayName(s), style = MaterialTheme.typography.labelSmall, color = c.Muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    if (isSettled) s.settledLabel else UnitConverter.rupees(balance),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isSettled) c.Success else c.Danger,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = c.Muted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyHome(onAddShop: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    Column(
        Modifier
            .fillMaxWidth()
            .weight(1f)
            .padding(bottom = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(c.ChipBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Storefront, contentDescription = null, tint = c.Primary, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(s.noShopsYetTitle, style = MaterialTheme.typography.titleLarge, color = c.TextPrimary)
        Spacer(Modifier.height(5.dp))
        Text(
            s.noShopsYetSubtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = c.Muted
        )
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onAddShop,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.Primary)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(s.addFirstShopButton)
        }
    }
}

private fun shopTypeIcon(type: ShopType): ImageVector = when (type) {
    ShopType.TEA -> Icons.Default.LocalCafe
    ShopType.HARDWARE_ELECTRIC -> Icons.Default.Build
    ShopType.KIRANA -> Icons.Default.ShoppingBasket
    ShopType.VEGETABLE -> Icons.Default.WaterDrop
    ShopType.FISH_MEAT -> Icons.Default.Cake
    ShopType.BAKERY_SWEETS -> Icons.Default.Cake
    ShopType.PHARMACY -> Icons.Default.LocalPharmacy
    ShopType.COSMETICS -> Icons.Default.Face
    ShopType.STATIONERY -> Icons.Default.EditNote
    ShopType.XEROX_PRINTING -> Icons.Default.Print
    ShopType.WOOD -> Icons.Default.Straighten
    ShopType.GARMENTS -> Icons.Default.Checkroom
    ShopType.OTHER -> Icons.Default.Storefront
}
