package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * ⭐ একটা লেনদেন — এখন এটা শুধু "প্যারেন্ট" রেকর্ড (মোট টাকা, নোট, তারিখ)।
 * একাধিক পণ্য থাকলে সেগুলো আলাদাভাবে [TransactionItemEntity]-তে থাকে,
 * এই এনটিটির সাথে যুক্ত (transactionId দিয়ে)। "সরাসরি টাকা" মোডের ধার আর
 * সব জমা (payment)-এর কোনো item থাকে না — শুধু amount।
 */
@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: Long,
    val amount: Double,                                  // মোট টাকা (একাধিক পণ্য থাকলে তাদের যোগফল)
    val type: String,                                    // TYPE_CREDIT / TYPE_PAYMENT
    val date: Long = System.currentTimeMillis(),
    val paymentMethod: String? = null,                   // শুধু জমায় — নগদ/বিকাশ/ব্যাংক
    val note: String? = null,
    val isDeleted: Boolean = false,                      // soft delete
    val deletedAt: Long? = null
) {
    companion object {
        const val TYPE_CREDIT = "CREDIT"      // ধার নিলাম (আমার দেনা বাড়ল)
        const val TYPE_PAYMENT = "PAYMENT"    // জমা দিলাম (দেনা কমল)
    }
}
