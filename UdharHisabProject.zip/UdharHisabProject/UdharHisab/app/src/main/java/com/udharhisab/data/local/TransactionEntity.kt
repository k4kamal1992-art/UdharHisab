package com.udharhisab.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: Long,
    val amount: Double,
    val type: String,                                    // TYPE_CREDIT / TYPE_PAYMENT
    val date: Long = System.currentTimeMillis(),
    val productName: String? = null,
    val quantity: Double? = null,
    val unit: String? = null,                            // "cft", "কেজি", "টোকা"...
    val unitPrice: Double? = null,
    val paymentMethod: String? = null,                   // নগদ/বিকাশ/ব্যাংক
    val note: String? = null,
    val isDeleted: Boolean = false,                      // soft delete
    val deletedAt: Long? = null
) {
    companion object {
        const val TYPE_CREDIT = "CREDIT"      // ধার নিলাম (আমার দেনা বাড়ল)
        const val TYPE_PAYMENT = "PAYMENT"    // জমা দিলাম (দেনা কমল)
    }
}
