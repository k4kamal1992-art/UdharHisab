package com.udharhisab.ui.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.reminder.ReminderWorker
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** নোটিফিকেশন সাব-অপশন — আগে Bottom Sheet ছিল, এখন পূর্ণ পেজ। টগল সাথে সাথে প্রয়োগ হয়। */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.notifSheetTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(s.notifSheetSubtitle, color = c.Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))

            ToggleRow(Icons.Default.Notifications, s.notifDueReminderOption, settings.remindersEnabled) {
                viewModel.setReminder(it)
                if (it) ReminderWorker.schedule(context) else ReminderWorker.cancel(context)
            }
            ToggleRow(Icons.Default.Summarize, s.notifWeeklySummaryOption, settings.weeklySummaryEnabled, viewModel::setWeeklySummary)
            ToggleRow(Icons.Default.Campaign, s.notifAppNewsOption, settings.appNewsEnabled, viewModel::setAppNews)

            Spacer(Modifier.weight(1f))
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(s.save)
            }
        }
    }
}

@Composable
private fun ToggleRow(icon: ImageVector, label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = c.Primary,
                checkedBorderColor = c.Primary
            )
        )
    }
}
