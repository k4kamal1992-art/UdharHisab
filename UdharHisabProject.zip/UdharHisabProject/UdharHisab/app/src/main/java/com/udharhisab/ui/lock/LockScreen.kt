package com.udharhisab.ui.lock

import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.domain.PinHasher
import com.udharhisab.ui.strings.LocalStrings
import kotlinx.coroutines.launch

/**
 * ⭐ পিন সেট (প্রথমবার) + আনলক — দুই মোড এক স্ক্রিনে
 * fingerprintEnabled থাকলে PIN-এর পাশাপাশি ফিঙ্গারপ্রিন্ট দিয়েও আনলক করা যায়
 * (নিরাপত্তা ও প্রাইভেসি পেজ থেকে অন করা হয়)
 */
@Composable
fun LockScreen(
    store: SettingsDataStore,
    storedPinHash: String?,      // null হলে = সেটআপ মোড
    fingerprintEnabled: Boolean = false,
    onUnlocked: () -> Unit
) {
    val s = LocalStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val isSetupMode = storedPinHash == null

    fun showBiometricPrompt() {
        val activity = context as? FragmentActivity ?: return
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onUnlocked()
                }
            }
        )
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(s.fingerprintTitle)
            .setNegativeButtonText(s.cancel)
            .build()
        prompt.authenticate(promptInfo)
    }

    // ⭐ আনলক মোডে ঢুকলেই ফিঙ্গারপ্রিন্ট অন থাকলে সাথে সাথে প্রম্পট দেখাও
    LaunchedEffect(isSetupMode, fingerprintEnabled) {
        if (!isSetupMode && fingerprintEnabled) showBiometricPrompt()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🔒", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(16.dp))

        Text(
            if (isSetupMode) s.setupPinTitle else s.unlockPinTitle,
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = pin,
            onValueChange = {
                if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it
                error = null
            },
            label = { Text(s.pinLabel) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            isError = error != null,
            modifier = Modifier.fillMaxWidth()
        )

        if (isSetupMode) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = confirmPin,
                onValueChange = {
                    if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmPin = it
                    error = null
                },
                label = { Text(s.confirmPinLabel) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                isError = error != null,
                modifier = Modifier.fillMaxWidth()
            )
        }

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                scope.launch {
                    if (isSetupMode) {
                        when {
                            pin.length != 4 -> error = s.pinDigitsError
                            pin != confirmPin -> error = s.pinsDontMatchError
                            else -> {
                                store.setPin(PinHasher.hash(pin))
                                onUnlocked()
                            }
                        }
                    } else {
                        if (PinHasher.verify(pin, storedPinHash!!)) {
                            onUnlocked()
                        } else {
                            error = s.wrongPinError
                            pin = ""
                        }
                    }
                }
            },
            enabled = pin.length == 4 && (!isSetupMode || confirmPin.length == 4),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isSetupMode) s.savePinButton else s.unlockButton)
        }

        if (!isSetupMode && fingerprintEnabled) {
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = { showBiometricPrompt() }, modifier = Modifier.fillMaxWidth()) {
                Text(s.fingerprintTitle)
            }
        }
    }
}
