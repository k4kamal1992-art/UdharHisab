package com.udharhisab.ui.lock

import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.domain.PinHasher
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * পিন সেট (প্রথমবার) + আনলক — দুই মোড এক স্ক্রিনে, ট্যাপ-ভিত্তিক সার্কুলার কিপ্যাড
 * fingerprintEnabled থাকলে PIN-এর পাশাপাশি ফিঙ্গারপ্রিন্ট দিয়েও আনলক করা যায়
 * (নিরাপত্তা ও প্রাইভেসি পেজ থেকে অন করা হয়)
 */
@Composable
fun LockScreen(
    store: SettingsDataStore,
    storedPinHash: String?,      // null হলে = সেটআপ মোড
    fingerprintEnabled: Boolean = false,
    onUnlocked: () -> Unit
) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val isSetupMode = storedPinHash == null

    // সেটআপ মোডে দুই ধাপ — প্রথমে পিন দাও, তারপর আবার দিয়ে কনফার্ম করো
    var confirmStep by remember { mutableStateOf(false) }
    var firstPin by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var shake by remember { mutableStateOf(0) }

    fun reset() {
        pin = ""
        firstPin = ""
        confirmStep = false
    }

    fun showBiometricPrompt() {
        val activity = context as? FragmentActivity ?: return
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onUnlocked()
                }
            }
        )
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(s.fingerprintTitle)
            .setNegativeButtonText(s.cancel)
            .build()
        prompt.authenticate(promptInfo)
    }

    // আনলক মোডে ঢুকলেই ফিঙ্গারপ্রিন্ট অন থাকলে সাথে সাথে প্রম্পট দেখাও
    LaunchedEffect(isSetupMode, fingerprintEnabled) {
        if (!isSetupMode && fingerprintEnabled) showBiometricPrompt()
    }

    // ৪ ডিজিট হয়ে গেলেই যাচাই/পরের ধাপ — আলাদা "সাবমিট" বাটন লাগে না
    LaunchedEffect(pin) {
        if (pin.length < 4) return@LaunchedEffect
        if (isSetupMode) {
            if (!confirmStep) {
                firstPin = pin
                pin = ""
                confirmStep = true
            } else {
                if (pin == firstPin) {
                    store.setPin(PinHasher.hash(pin))
                    onUnlocked()
                } else {
                    error = s.pinsDontMatchError
                    shake++
                    pin = ""
                    firstPin = ""
                    confirmStep = false
                }
            }
        } else {
            if (PinHasher.verify(pin, storedPinHash!!)) {
                onUnlocked()
            } else {
                error = s.wrongPinError
                shake++
                pin = ""
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Lock,
            contentDescription = null,
            tint = c.Primary,
            modifier = Modifier.size(40.dp)
        )
        Spacer(Modifier.height(14.dp))

        Text(
            when {
                isSetupMode && confirmStep -> s.confirmPinLabel
                isSetupMode -> s.setupPinTitle
                else -> s.unlockPinTitle
            },
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(Modifier.height(28.dp))

        // ── পিন ডট ইন্ডিকেটর ──
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            repeat(4) { i ->
                val filled = i < pin.length
                Box(
                    Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .then(
                            if (filled) Modifier.background(c.Primary)
                            else Modifier.border(1.5.dp, c.Divider, CircleShape)
                        )
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Box(Modifier.height(20.dp)) {
            error?.let {
                Text(it, color = c.Danger, style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(20.dp))

        // ── সার্কুলার নাম্বার কিপ্যাড ──
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9")
        )
        rows.forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { digit ->
                    KeypadButton(digit) {
                        error = null
                        if (pin.length < 4) pin += digit
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        // ── শেষ সারি: ফিঙ্গারপ্রিন্ট / ০ / ব্যাকস্পেস ──
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            if (!isSetupMode && fingerprintEnabled) {
                KeypadIconButton(Icons.Default.Fingerprint) { showBiometricPrompt() }
            } else {
                Spacer(Modifier.size(64.dp))
            }
            KeypadButton("0") {
                error = null
                if (pin.length < 4) pin += "0"
            }
            KeypadIconButton(Icons.AutoMirrored.Filled.Backspace) {
                error = null
                if (pin.isNotEmpty()) pin = pin.dropLast(1)
            }
        }

        if (isSetupMode && confirmStep) {
            Spacer(Modifier.height(20.dp))
            TextButton(onClick = { reset() }) {
                Text(s.back)
            }
        }
    }
}

@Composable
private fun KeypadButton(digit: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Box(
        Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(c.ChipBg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            digit,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            color = c.TextPrimary
        )
    }
}

@Composable
private fun KeypadIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Box(
        Modifier
            .size(64.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = c.Primary, modifier = Modifier.size(26.dp))
    }
}
