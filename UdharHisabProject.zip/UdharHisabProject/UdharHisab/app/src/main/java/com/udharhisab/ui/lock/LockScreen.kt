package com.udharhisab.ui.lock

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.domain.PinHasher
import kotlinx.coroutines.launch

/**
 * ⭐ পিন সেট (প্রথমবার) + আনলক — দুই মোড এক স্ক্রিনে
 */
@Composable
fun LockScreen(
    store: SettingsDataStore,
    storedPinHash: String?,      // null হলে = সেটআপ মোড
    onUnlocked: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val isSetupMode = storedPinHash == null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🔒", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(16.dp))

        Text(
            if (isSetupMode) "৪-ডিজিটের পিন সেট করুন" else "পিন দিয়ে আনলক করুন",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = pin,
            onValueChange = {
                if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it
                error = null
            },
            label = { Text("পিন") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            isError = error != null,
            modifier = Modifier.fillMaxWidth()
        )

        if (isSetupMode) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = confirmPin,
                onValueChange = {
                    if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmPin = it
                    error = null
                },
                label = { Text("আবার পিন লিখুন") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                isError = error != null,
                modifier = Modifier.fillMaxWidth()
            )
        }

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                scope.launch {
                    if (isSetupMode) {
                        when {
                            pin.length != 4 -> error = "৪ ডিজিট দিন"
                            pin != confirmPin -> error = "দুটো পিন মিলছে না"
                            else -> {
                                store.setPin(PinHasher.hash(pin))
                                onUnlocked()
                            }
                        }
                    } else {
                        if (PinHasher.verify(pin, storedPinHash!!)) {
                            onUnlocked()
                        } else {
                            error = "ভুল পিন — আবার চেষ্টা করুন"
                            pin = ""
                        }
                    }
                }
            },
            enabled = pin.length == 4 && (!isSetupMode || confirmPin.length == 4),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isSetupMode) "পিন সেভ করুন" else "আনলক")
        }
    }
}
