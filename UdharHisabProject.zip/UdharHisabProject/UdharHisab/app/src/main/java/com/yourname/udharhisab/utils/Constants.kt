package com.yourname.udharhisab.utils

/**
 * App constants
 */
object Constants {

    // Transaction types
    const val TYPE_CREDIT = "CREDIT"
    const val TYPE_PAYMENT = "PAYMENT"

    // Shop types
    const val SHOP_GENERAL = "general"
    const val SHOP_TEA_STALL = "tea_stall"
    const val SHOP_GROCERY = "grocery"
    const val SHOP_KIRANA = "kirana"
    const val SHOP_RESTAURANT = "restaurant"
    const val SHOP_HARDWARE = "hardware"

    // Ad unit IDs (TEST IDs - replace before publishing)
    const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

    // Shared Preferences keys
    const val PREFS_NAME = "udhar_hisab_prefs"
    const val KEY_LANGUAGE = "app_language"
    const val KEY_AD_COUNT = "ad_interstitial_count"
    const val KEY_FIRST_LAUNCH = "first_launch"

    // Backup
    const val BACKUP_FILE_NAME = "udhar_hisab_backup.json"
    const val PDF_FILE_NAME = "udhar_hisab_report.pdf"
}
