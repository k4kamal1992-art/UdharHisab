package com.udharhisab.data.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.udharhisab.R
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithItems
import com.udharhisab.data.settings.LogoStorage
import com.udharhisab.domain.AmountInWords
import com.udharhisab.domain.UnitConverter
import com.udharhisab.domain.WoodMeasure
import com.udharhisab.ui.strings.AppStrings
import com.udharhisab.ui.strings.BengaliStrings
import com.udharhisab.ui.strings.ShopkeeperLabels
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar

enum class PdfFormat { A4 }
enum class PdfContentScope { FULL, SUMMARY_ONLY, TRANSACTIONS_ONLY }

/**
 * ⭐ প্রফেশনাল PDF রিপোর্ট জেনারেটর — রঙিন সারি, রিপোর্ট নম্বর, ওয়াটারমার্ক,
 * সাপ্তাহিক মিনি-চার্ট, সিগনেচার লাইন, A4/রিসিট দুই ফরম্যাট, পৃষ্ঠা নম্বর সহ।
 */
class KhataPdfGenerator(
    private val context: Context,
    private val strings: AppStrings = BengaliStrings,
    /** ⭐ দোকানদারের ক্ষেত্রে — দোকানের নাম/ঠিকানা/লোগো হেডার ও ফুটারে বসে; null হলে আগের মতোই */
    private val branding: ShopBranding? = null,
    /** ⭐ দোকানদার মোডে — "বাকি দিয়েছি/পরিশোধ পেয়েছি/পাওনা" ধরনের শব্দ; null হলে আগের (গ্রাহকের) শব্দ */
    private val labels: ShopkeeperLabels? = null
) {
    private val txtShopBox get() = labels?.pdfShopBoxLabel ?: strings.pdfShopBoxLabel
    private val txtTotalCredit get() = labels?.pdfTotalCreditLabel ?: strings.reportTotalCredit
    private val txtTotalPayment get() = labels?.pdfTotalPaymentLabel ?: strings.reportTotalPayment
    private val txtDue get() = labels?.pdfDueLabel ?: strings.reportCurrentDue
    private val txtFinalDue get() = labels?.pdfDueLabel ?: strings.pdfFinalDueLabel
    private val txtWeeklyTitle get() = labels?.pdfWeeklyChartTitle ?: strings.pdfWeeklyChartTitle
    private val txtAllShopsTitle get() = labels?.pdfAllShopsReportTitle ?: strings.pdfAllShopsReportTitle
    private val txtCreditFallback get() = labels?.creditFallback ?: strings.creditFallback
    private val txtPaymentFallback get() = labels?.paymentFallback ?: strings.paymentFallback


    // ── কালার ──
    private val GREEN = Color.rgb(5, 150, 105)
    private val GREEN_DARK = Color.rgb(6, 78, 59)
    private val GREEN_DEEPEST = Color.rgb(5, 46, 22)
    private val RED = Color.rgb(185, 28, 28)
    private val RED_LIGHT_BG = Color.rgb(254, 242, 242)
    private val RED_LIGHT_BORDER = Color.rgb(254, 202, 202)
    private val RED_TAG_BG = Color.rgb(254, 226, 226)
    private val RED_TAG_TEXT = Color.rgb(185, 28, 28)
    private val RED_SOFT = Color.rgb(252, 165, 165)
    private val GREEN_LIGHT_BG = Color.rgb(236, 253, 245)
    private val GREEN_LIGHT_BORDER = Color.rgb(167, 243, 208)
    private val GREEN_TAG_BG = Color.rgb(209, 250, 229)
    private val GREEN_TAG_TEXT = Color.rgb(4, 120, 87)
    private val BLACK = Color.rgb(33, 33, 33)
    // ⭐ গাঢ় রং — পণ্যের নাম/টাকা যেন পরিষ্কার পড়া যায় (হালকা রঙে বোঝা কঠিন ছিল)
    private val PAYMENT_DEEP = Color.rgb(4, 105, 75)
    private val INK = Color.rgb(17, 24, 39)
    private val INK_MID = Color.rgb(55, 65, 81)
    private val GRAY = Color.rgb(117, 117, 117)
    private val GRAY_LIGHT = Color.rgb(229, 231, 235)
    private val WHITE = Color.WHITE

    private var PAGE_W = 595
    private var PAGE_H = 842
    private var MARGIN = 32f

    // ⭐ পণ্যভিত্তিক হিসাবের কলামের মাপ: ডান প্রান্ত থেকে "পণ্যের টাকা" কত দূরে, তার বাঁয়ে "পরিমাণ × দাম", আর প্রতি পণ্য-লাইনের উচ্চতা
    private val ITEM_AMT_GAP = 86f
    private val CALC_GAP = 64f
    private val MAIN_ROW_H = 28f      // লেনদেনের মূল সারি (তারিখ/ধরন/মোট)
    private val ITEM_ROW_H = 15f      // প্রতি পণ্যের সারি
    private val DETAIL_ROW_H = 13f    // কাঠের মাপ / নোটের লাইন
    private val BLOCK_GAP = 6f        // দুই লেনদেনের মাঝের ফাঁক

    private var bengaliRegular: Typeface? = null
    private var bengaliBold: Typeface? = null

    init {
        try {
            bengaliRegular = Typeface.createFromAsset(context.assets, "fonts/NotoSansBengali-Regular.ttf")
            bengaliBold = Typeface.createFromAsset(context.assets, "fonts/NotoSansBengali-Bold.ttf")
        } catch (_: Exception) { /* ফন্ট না থাকলে ডিফল্ট */ }
    }

    private fun paint(size: Float, bold: Boolean = false, color: Int = BLACK): Paint =
        Paint().apply {
            this.color = color
            textSize = size
            // ⭐ হিন্দির (দেবনাগরী) জন্য বাংলা ফন্টে গ্লিফ নেই — সিস্টেম ফন্ট
            typeface = if (strings.code == "hi") {
                if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            } else if (bold) bengaliBold ?: Typeface.DEFAULT_BOLD else bengaliRegular ?: Typeface.DEFAULT
            isAntiAlias = true
        }

    /** ⭐ কাস্টম লোগো থাকলে সেটা, নয়তো অ্যাপের ডিফল্ট লোগো */
    private fun brandLogo(size: Int): Bitmap? {
        val path = branding?.logoPath
        if (path != null) {
            val custom = try { LogoStorage.loadSquare(path, size) } catch (_: Exception) { null }
            if (custom != null) return custom
        }
        return logoBitmap(size)
    }

    /** টেক্সট [maxW]-এর চেয়ে চওড়া হলে শেষে "…" দিয়ে ছোট করে */
    private fun fitText(text: String, p: Paint, maxW: Float): String {
        if (p.measureText(text) <= maxW) return text
        var t = text
        while (t.isNotEmpty() && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    /** হেডারের উচ্চতা — ব্র্যান্ডিং থাকলে নাম/ঠিকানা/ফোনের জন্য বেশি জায়গা */
    private fun headerHeight(): Float = if (branding != null) 100f else 90f

    private fun logoBitmap(size: Int): Bitmap? = try {
        val src = BitmapFactory.decodeResource(context.resources, R.drawable.logo)
        Bitmap.createScaledBitmap(src, size, size, true)
    } catch (_: Exception) { null }

    // ═══════════════════════════ একটা দোকানের রিপোর্ট ═══════════════════════════

    fun generateShopReport(
        shop: ShopEntity,
        txns: List<TransactionWithItems>,
        reportNumber: Int,
        fromTime: Long,
        toTime: Long,
        format: PdfFormat,
        scope: PdfContentScope
    ): File {
        PAGE_W = 595
        PAGE_H = 842
        MARGIN = 32f

        // ⭐ প্রথমে পেজ গুনি (ফুটারের "পৃষ্ঠা x / y"-এর জন্য), তারপর আসল PDF বানাই
        val counter = renderMemo(shop, txns, reportNumber, fromTime, toTime, scope, totalPages = 0)
        val pages = counter.pageNo
        counter.closeQuietly()
        val memo = renderMemo(shop, txns, reportNumber, fromTime, toTime, scope, totalPages = pages)

        val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val safeName = shop.name.replace(Regex("[^\\p{L}\\p{N}]"), "_")
        val file = File(dir, "khata_${safeName}.pdf")
        FileOutputStream(file).use { memo.doc.writeTo(it) }
        memo.closeQuietly()
        return file
    }

    // ═══════════════════════════ সব দোকানের সারাংশ রিপোর্ট ═══════════════════════════

    fun generateAllShopsReport(
        rows: List<ShopReportRow>,
        reportNumber: Int,
        fromTime: Long,
        toTime: Long
    ): File {
        PAGE_W = 595
        PAGE_H = 842
        MARGIN = 32f

        // ⭐ ক্যাশ মেমো ধাঁচে সারাংশ — আগে পেজ গুনি, তারপর আসল PDF
        val counter = renderAllShopsMemo(rows, reportNumber, fromTime, toTime, totalPages = 0)
        val pages = counter.pageNo
        counter.closeQuietly()
        val memo = renderAllShopsMemo(rows, reportNumber, fromTime, toTime, totalPages = pages)

        val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val file = File(dir, "khata_all_shops.pdf")
        FileOutputStream(file).use { memo.doc.writeTo(it) }
        memo.closeQuietly()
        return file
    }

    private fun renderAllShopsMemo(
        rows: List<ShopReportRow>, reportNumber: Int, fromTime: Long, toTime: Long, totalPages: Int
    ): MemoDoc {
        val brandName = branding?.name ?: strings.homeHeadline
        val m = MemoDoc(brandName, reportNumber, totalPages)
        m.newPage()
        m.y = drawMemoHeader(m.canvas, reportNumber, strings.pdfSummaryTitle, "")
        m.y = drawMemoMeta(m.canvas, m.y, reportNumber, fromTime, toTime)

        var totalCredit = 0.0
        var totalPayment = 0.0
        var totalDue = 0.0
        rows.forEach {
            totalCredit += it.periodCredit
            totalPayment += it.periodPayment
            totalDue += it.currentDue
        }

        if (rows.isEmpty()) {
            m.ensure(30f)
            m.canvas.drawText(strings.historyNoTxnsFound, MARGIN, m.y + 14f, paint(10f, color = GRAY))
            m.y += 30f
        } else {
            drawMemoTable(
                m, txtAllShopsTitle,
                listOf(
                    MCol(strings.pdfColSl, 5f, 0), MCol(txtShopBox, 31f, 1),
                    MCol(txtTotalCredit, 21f, 2), MCol(txtTotalPayment, 21f, 2), MCol(txtDue, 22f, 2)
                ),
                rows.mapIndexed { i, r ->
                    listOf(
                        MCell((i + 1).toString()),
                        MCell(r.shopName, bold = true),
                        MCell(UnitConverter.rupees(r.periodCredit), bold = true, color = RED),
                        MCell(UnitConverter.rupees(r.periodPayment), bold = true, color = PAYMENT_DEEP),
                        MCell(UnitConverter.rupees(r.currentDue), bold = true, color = if (r.currentDue > 0) RED else PAYMENT_DEEP)
                    )
                },
                20f, 2, strings.pdfTableTotal,
                listOf(
                    MCell(UnitConverter.rupees(totalCredit), bold = true, color = RED),
                    MCell(UnitConverter.rupees(totalPayment), bold = true, color = PAYMENT_DEEP),
                    MCell(UnitConverter.rupees(totalDue), bold = true, color = if (totalDue > 0) RED else PAYMENT_DEEP)
                ),
                TEAL_LIGHT
            )
        }

        drawMemoSummary(m, totalCredit, totalPayment, totalDue)
        drawMemoSignatures(m)
        m.finishLastPage()
        return m
    }

    // ═══════════════ ⭐ ক্যাশ মেমো ডিজাইন (একটা দোকান/কাস্টমারের রিপোর্ট) ═══════════════

    private val TEAL = Color.rgb(15, 118, 110)
    private val TEAL_DARK = Color.rgb(19, 78, 74)
    private val TEAL_LIGHT = Color.rgb(240, 253, 250)
    private val GRID = Color.rgb(209, 213, 219)
    private val ZEBRA = Color.rgb(249, 250, 251)
    private val MEMO_FOOTER_H = 34f

    private class MCol(val title: String, val weight: Float, val align: Int)   // align: 0 মাঝে, 1 বামে, 2 ডানে
    private class MCell(
        val text: String,
        val bold: Boolean = false,
        val color: Int = Color.rgb(17, 24, 39),
        val badge: String? = null,
        val badgeColor: Int = 0
    )

    /** একটা মেমো-ডকুমেন্টের পেজ/ক্যানভাস/y-অবস্থান সামলায় */
    private inner class MemoDoc(val title: String, val reportNumber: Int, val totalPages: Int) {
        val doc = PdfDocument()
        var pageNo = 0
        private var page: PdfDocument.Page? = null
        lateinit var canvas: Canvas
        var y = MARGIN

        fun newPage() {
            page?.let { drawMemoFooter(canvas, pageNo, totalPages); doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
            canvas = page!!.canvas
            drawWatermark(canvas)
            y = if (pageNo > 1) drawMemoMiniHeader(canvas, title, reportNumber) else MARGIN
        }

        /** এই উচ্চতা জায়গা না থাকলে নতুন পেজ খোলে; খুললে true */
        fun ensure(h: Float): Boolean {
            if (y + h > PAGE_H - MARGIN - MEMO_FOOTER_H) { newPage(); return true }
            return false
        }

        fun finishLastPage() {
            page?.let { drawMemoFooter(canvas, pageNo, totalPages); doc.finishPage(it) }
            page = null
        }

        fun closeQuietly() { try { doc.close() } catch (_: Exception) {} }
    }

    private fun stroke(color: Int, width: Float) = Paint().apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = width; isAntiAlias = true
    }
    private fun fill(color: Int) = Paint().apply { this.color = color; style = Paint.Style.FILL; isAntiAlias = true }

    private fun n2(v: Double) = String.format(java.util.Locale.US, "%.2f", v)

    /** শব্দ ভেঙে সর্বোচ্চ [maxLines] লাইনে সাজায়; বেশি হলে শেষে "…" */
    private fun wrapText(text: String, p: Paint, maxW: Float, maxLines: Int): List<String> {
        val lines = mutableListOf<String>()
        var cur = ""
        for (word in text.split(" ")) {
            val trial = if (cur.isEmpty()) word else "$cur $word"
            if (p.measureText(trial) <= maxW || cur.isEmpty()) cur = trial
            else { lines += cur; cur = word }
        }
        if (cur.isNotEmpty()) lines += cur
        if (lines.size > maxLines) {
            val kept = lines.take(maxLines).toMutableList()
            kept[maxLines - 1] = fitText(lines.drop(maxLines - 1).joinToString(" "), p, maxW)
            return kept
        }
        return lines.map { fitText(it, p, maxW) }
    }

    private fun initialsOf(name: String): String {
        val words = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return when {
            words.isEmpty() -> ""
            words.size == 1 -> words[0].take(1)
            else -> words[0].take(1) + words[1].take(1)
        }
    }

    private fun drawMemoHeader(
        canvas: Canvas, reportNumber: Int,
        titleText: String = strings.pdfMemoTitle, subtitleText: String = strings.pdfMemoSubtitle
    ): Float {
        val x0 = MARGIN
        val x1 = PAGE_W - MARGIN
        val top = MARGIN
        val h = 64f
        val brand = branding?.name ?: strings.homeHeadline

        canvas.drawRoundRect(x0, top, x1, top + h, 8f, 8f, fill(TEAL_LIGHT))
        canvas.drawRoundRect(x0, top, x1, top + h, 8f, 8f, stroke(TEAL, 1.6f))

        // ── লোগো-বক্স ──
        val ls = 44f
        val lx = x0 + 10f
        val ly = top + (h - ls) / 2f
        val customLogo = branding?.logoPath?.let { path ->
            try { LogoStorage.loadSquare(path, 88) } catch (_: Exception) { null }
        }
        when {
            customLogo != null -> {
                canvas.save()
                val clip = android.graphics.Path().apply { addRoundRect(lx, ly, lx + ls, ly + ls, 10f, 10f, android.graphics.Path.Direction.CW) }
                canvas.clipPath(clip)
                canvas.drawBitmap(Bitmap.createScaledBitmap(customLogo, ls.toInt(), ls.toInt(), true), lx, ly, null)
                canvas.restore()
            }
            branding != null -> {
                val grad = Paint().apply {
                    isAntiAlias = true
                    shader = android.graphics.LinearGradient(lx, ly, lx + ls, ly + ls, TEAL, TEAL_DARK, android.graphics.Shader.TileMode.CLAMP)
                }
                canvas.drawRoundRect(lx, ly, lx + ls, ly + ls, 10f, 10f, grad)
                val ip = paint(17f, bold = true, color = WHITE)
                val txt = initialsOf(branding.name)
                canvas.drawText(txt, lx + (ls - ip.measureText(txt)) / 2f, ly + ls / 2f + 6f, ip)
            }
            else -> {
                canvas.drawRoundRect(lx, ly, lx + ls, ly + ls, 10f, 10f, fill(WHITE))
                canvas.drawRoundRect(lx, ly, lx + ls, ly + ls, 10f, 10f, stroke(GRID, 0.8f))
                logoBitmap(36)?.let { canvas.drawBitmap(it, lx + 4f, ly + 4f, null) }
            }
        }

        // ── দোকানের নাম (বামে) ──
        val nameP = paint(17f, bold = true, color = GREEN_DARK)
        val tx = lx + ls + 12f
        canvas.drawText(fitText(brand, nameP, (x1 - 150f) - tx), tx, top + h / 2f + 6f, nameP)

        // ── "ক্যাশ মেমো" (ডানে, লাল) ──
        val titleP = paint(15f, bold = true, color = RED)
        val subP = paint(8f, color = GRAY)
        val t = titleText
        canvas.drawText(t, x1 - 12f - titleP.measureText(t), top + 28f, titleP)
        val sub = subtitleText
        if (sub.isNotBlank()) canvas.drawText(sub, x1 - 12f - subP.measureText(sub), top + 43f, subP)

        return top + h + 8f
    }

    private fun drawMemoMiniHeader(canvas: Canvas, title: String, reportNumber: Int): Float {
        val top = MARGIN
        canvas.drawRoundRect(MARGIN, top, PAGE_W - MARGIN, top + 24f, 6f, 6f, fill(TEAL))
        val p = paint(9.5f, bold = true, color = WHITE)
        canvas.drawText(fitText(title, p, 300f), MARGIN + 10f, top + 16f, p)
        val r = "${strings.pdfMemoTitle}  •  #INV-$reportNumber"
        canvas.drawText(r, PAGE_W - MARGIN - 10f - p.measureText(r), top + 16f, p)
        return top + 34f
    }

    private fun drawMemoFooter(canvas: Canvas, pageNo: Int, totalPages: Int) {
        val y = PAGE_H - MARGIN
        canvas.drawLine(MARGIN, y - 16f, PAGE_W - MARGIN, y - 16f, stroke(GRID, 0.8f))
        val fp = paint(7.5f, color = GRAY)
        val pageText = if (totalPages > 0) "${strings.pdfPageLabel} $pageNo / $totalPages" else "${strings.pdfPageLabel} $pageNo"
        canvas.drawText(fitText(strings.pdfMemoFooter, fp, PAGE_W - 2 * MARGIN - fp.measureText(pageText) - 12f), MARGIN, y - 4f, fp)
        canvas.drawText(pageText, PAGE_W - MARGIN - fp.measureText(pageText), y - 4f, fp)
    }

    /** বিল নং / তারিখ / সময়কাল — তিনটা ছোট কার্ড */
    private fun drawMemoMeta(canvas: Canvas, yStart: Float, reportNumber: Int, fromTime: Long, toTime: Long): Float {
        val gap = 8f
        val w = (PAGE_W - 2 * MARGIN - 2 * gap) / 3f
        val h = 38f
        val items = listOf(
            strings.pdfBillNo to "#INV-$reportNumber",
            strings.pdfDateTitle to UnitConverter.dateShort(System.currentTimeMillis(), strings.code),
            strings.pdfPeriodTitle to "${UnitConverter.dateShort(fromTime, strings.code)} – ${UnitConverter.dateShort(toTime, strings.code)}"
        )
        items.forEachIndexed { i, (label, value) ->
            val x = MARGIN + i * (w + gap)
            canvas.drawRoundRect(x, yStart, x + w, yStart + h, 6f, 6f, fill(ZEBRA))
            canvas.drawRoundRect(x, yStart, x + w, yStart + h, 6f, 6f, stroke(GRID, 0.9f))
            canvas.drawText(fitText(label, paint(7.5f, color = GRAY), w - 16f), x + 8f, yStart + 13f, paint(7.5f, color = GRAY))
            val vp = paint(10f, bold = true, color = INK)
            canvas.drawText(fitText(value, vp, w - 16f), x + 8f, yStart + 29f, vp)
        }
        return yStart + h + 8f
    }

    private class Party(val title: String, val name: String, val phone: String, val address: String, val bg: Int, val border: Int, val titleColor: Int)

    /** বিক্রেতা / ক্রেতা কার্ড (গ্রাহক মোডে শুধু বিক্রেতা = দোকান) */
    private fun drawMemoParties(canvas: Canvas, yStart: Float, parties: List<Party>): Float {
        val gap = 8f
        val total = PAGE_W - 2 * MARGIN
        val w = if (parties.size == 1) total else (total - gap) / 2f
        val hasAddr = parties.any { it.address.isNotBlank() }
        val h = if (hasAddr) 70f else 56f
        parties.forEachIndexed { i, pt ->
            val x = MARGIN + i * (w + gap)
            canvas.drawRoundRect(x, yStart, x + w, yStart + h, 6f, 6f, fill(pt.bg))
            canvas.drawRoundRect(x, yStart, x + w, yStart + h, 6f, 6f, stroke(pt.border, 1.4f))
            var ty = yStart + 14f
            canvas.drawText(pt.title, x + 10f, ty, paint(7.5f, bold = true, color = pt.titleColor)); ty += 15f
            val np = paint(11.5f, bold = true, color = GREEN_DARK)
            canvas.drawText(fitText(pt.name, np, w - 20f), x + 10f, ty, np); ty += 13f
            val dp = paint(8.5f, color = INK_MID)
            if (pt.phone.isNotBlank()) { canvas.drawText(fitText(strings.pdfPhoneLabel + pt.phone, dp, w - 20f), x + 10f, ty, dp); ty += 11f }
            if (pt.address.isNotBlank()) {
                wrapText(strings.pdfAddressLabel + pt.address, dp, w - 20f, 2).forEach { line ->
                    canvas.drawText(line, x + 10f, ty, dp); ty += 11f
                }
            }
        }
        return yStart + h + 10f
    }

    // ── টেবিল ──

    private fun colWidths(cols: List<MCol>): FloatArray {
        val total = PAGE_W - 2 * MARGIN
        val sum = cols.sumOf { it.weight.toDouble() }.toFloat()
        return FloatArray(cols.size) { cols[it].weight / sum * total }
    }

    private fun drawMemoSectionTitle(m: MemoDoc, title: String) {
        val c = m.canvas
        c.drawRect(MARGIN, m.y, PAGE_W - MARGIN, m.y + 20f, fill(TEAL_LIGHT))
        c.drawRect(MARGIN, m.y, MARGIN + 4f, m.y + 20f, fill(TEAL))
        val p = paint(10f, bold = true, color = TEAL)
        c.drawText(fitText(title, p, PAGE_W - 2 * MARGIN - 20f), MARGIN + 12f, m.y + 14f, p)
        m.y += 24f
    }

    private fun drawMemoHeaderRow(m: MemoDoc, cols: List<MCol>, widths: FloatArray) {
        val c = m.canvas
        val h = 26f
        val hp = paint(7.8f, bold = true, color = WHITE)
        var x = MARGIN
        cols.forEachIndexed { i, col ->
            val w = widths[i]
            c.drawRect(x, m.y, x + w, m.y + h, fill(TEAL))
            c.drawRect(x, m.y, x + w, m.y + h, stroke(TEAL, 0.8f))
            val lines = wrapText(col.title, hp, w - 4f, 2)
            val startY = m.y + h / 2f + 3f - (lines.size - 1) * 5f
            lines.forEachIndexed { li, line ->
                c.drawText(line, x + (w - hp.measureText(line)) / 2f, startY + li * 10f, hp)
            }
            x += w
        }
        m.y += h
    }

    private fun drawMemoRow(m: MemoDoc, cols: List<MCol>, widths: FloatArray, cells: List<MCell>, h: Float, zebra: Boolean) {
        val c = m.canvas
        var x = MARGIN
        cols.forEachIndexed { i, col ->
            val w = widths[i]
            val cell = cells[i]
            if (zebra) c.drawRect(x, m.y, x + w, m.y + h, fill(ZEBRA))
            c.drawRect(x, m.y, x + w, m.y + h, stroke(GRID, 0.6f))

            val tp = paint(if (cell.badge != null) 8f else 8.8f, bold = cell.bold, color = cell.color)
            val text = fitText(cell.text, tp, w - 8f)
            val tw = tp.measureText(text)
            val tx = when (col.align) { 1 -> x + 5f; 2 -> x + w - 5f - tw; else -> x + (w - tw) / 2f }
            if (cell.badge != null) {
                val bp = paint(7f, bold = true, color = WHITE)
                val bw = bp.measureText(cell.badge) + 12f
                val bx = if (col.align == 2) x + w - 5f - bw else x + 5f
                c.drawRoundRect(bx, m.y + 4f, bx + bw, m.y + 15f, 5.5f, 5.5f, fill(cell.badgeColor))
                c.drawText(cell.badge, bx + 6f, m.y + 12f, bp)
                c.drawText(text, tx, m.y + h - 6f, tp)
            } else {
                c.drawText(text, tx, m.y + h / 2f + 3.2f, tp)
            }
            x += w
        }
        m.y += h
    }

    /** শেষের মোটের সারি: প্রথম [span]টা ঘর জুড়ে ডানদিকে লেবেল, বাকি ঘরে [rest] */
    private fun drawMemoTotalRow(m: MemoDoc, cols: List<MCol>, widths: FloatArray, span: Int, label: String, rest: List<MCell>, bg: Int) {
        val c = m.canvas
        val h = 22f
        val spanW = widths.take(span).sum()
        c.drawRect(MARGIN, m.y, MARGIN + spanW, m.y + h, fill(bg))
        c.drawRect(MARGIN, m.y, MARGIN + spanW, m.y + h, stroke(GRID, 0.6f))
        c.drawLine(MARGIN, m.y, MARGIN + spanW, m.y, stroke(TEAL, 2f))
        val lp = paint(9f, bold = true, color = INK)
        c.drawText(label, MARGIN + spanW - 6f - lp.measureText(label), m.y + h / 2f + 3.2f, lp)
        var x = MARGIN + spanW
        rest.forEachIndexed { k, cell ->
            val w = widths[span + k]
            c.drawRect(x, m.y, x + w, m.y + h, fill(bg))
            c.drawRect(x, m.y, x + w, m.y + h, stroke(GRID, 0.6f))
            c.drawLine(x, m.y, x + w, m.y, stroke(TEAL, 2f))
            val tp = paint(9f, bold = true, color = cell.color)
            val text = fitText(cell.text, tp, w - 8f)
            c.drawText(text, x + w - 5f - tp.measureText(text), m.y + h / 2f + 3.2f, tp)
            x += w
        }
        m.y += h
    }

    /** একটা পূর্ণ টেবিল: শিরোনাম + হেডার + সারি (পেজ ভাঙলে হেডার আবার) + মোটের সারি */
    private fun drawMemoTable(
        m: MemoDoc, sectionTitle: String, cols: List<MCol>, rows: List<List<MCell>>, rowH: Float,
        totalSpan: Int, totalLabel: String, totalCells: List<MCell>, totalBg: Int
    ) {
        if (rows.isEmpty()) return
        val widths = colWidths(cols)
        m.ensure(20f + 4f + 26f + rowH + 22f)
        drawMemoSectionTitle(m, sectionTitle)
        drawMemoHeaderRow(m, cols, widths)
        rows.forEachIndexed { idx, cells ->
            if (m.ensure(rowH + 22f)) drawMemoHeaderRow(m, cols, widths)
            drawMemoRow(m, cols, widths, cells, rowH, zebra = idx % 2 == 1)
        }
        if (m.ensure(22f)) drawMemoHeaderRow(m, cols, widths)
        drawMemoTotalRow(m, cols, widths, totalSpan, totalLabel, totalCells, totalBg)
        m.y += 12f
    }

    // ── সারাংশ, কথায় টাকা, স্বাক্ষর ──

    private fun drawMemoSummary(m: MemoDoc, totalCredit: Double, totalPayment: Double, due: Double) {
        val c = m.canvas
        val gap = 8f
        val w = (PAGE_W - 2 * MARGIN - 2 * gap) / 3f
        val h = 52f
        m.ensure(h + 24f + 60f + 70f)
        val y = m.y

        val cardLabel = labels?.pdfTotalCreditLabel ?: strings.pdfSumBill
        val paidLabel = labels?.pdfTotalPaymentLabel ?: strings.pdfSumPaid
        val dueLabel = labels?.pdfDueLabel ?: strings.pdfSumDue

        fun card(i: Int, label: String, value: String, bg: Int, border: Int, labelColor: Int, valueColor: Int, gradient: Boolean) {
            val x = MARGIN + i * (w + gap)
            if (gradient) {
                val gp = Paint().apply {
                    isAntiAlias = true
                    shader = android.graphics.LinearGradient(x, y, x + w, y + h, Color.rgb(6, 78, 59), Color.rgb(2, 44, 34), android.graphics.Shader.TileMode.CLAMP)
                }
                c.drawRoundRect(x, y, x + w, y + h, 8f, 8f, gp)
            } else {
                c.drawRoundRect(x, y, x + w, y + h, 8f, 8f, fill(bg))
                c.drawRoundRect(x, y, x + w, y + h, 8f, 8f, stroke(border, 1.6f))
            }
            val lp = paint(8f, bold = true, color = labelColor)
            val lt = fitText(label, lp, w - 12f)
            c.drawText(lt, x + (w - lp.measureText(lt)) / 2f, y + 18f, lp)
            val vp = paint(15f, bold = true, color = valueColor)
            val vt = fitText(value, vp, w - 12f)
            c.drawText(vt, x + (w - vp.measureText(vt)) / 2f, y + 39f, vp)
        }
        card(0, cardLabel, UnitConverter.rupees(totalCredit), RED_LIGHT_BG, RED_LIGHT_BORDER, RED, RED, false)
        card(1, paidLabel, UnitConverter.rupees(totalPayment), GREEN_LIGHT_BG, GREEN_LIGHT_BORDER, PAYMENT_DEEP, PAYMENT_DEEP, false)
        card(2, dueLabel, UnitConverter.rupees(due), 0, 0, Color.argb(220, 255, 255, 255),
            if (due > 0) Color.rgb(252, 165, 165) else Color.rgb(110, 231, 183), true)
        m.y += h + 10f

        // ── টাকা কথায় ──
        val wp = paint(8.8f, color = INK_MID)
        val words = AmountInWords.format(strings.code, due)
        val lines = wrapText(words, wp, PAGE_W - 2 * MARGIN - 20f, 2)
        val boxH = 24f + lines.size * 11f
        c.drawRoundRect(MARGIN, m.y, PAGE_W - MARGIN, m.y + boxH, 6f, 6f, fill(Color.rgb(243, 244, 246)))
        c.drawRoundRect(MARGIN, m.y, PAGE_W - MARGIN, m.y + boxH, 6f, 6f,
            stroke(Color.rgb(156, 163, 175), 1f).apply { pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f) })
        c.drawText(strings.pdfWordsTitle, MARGIN + 10f, m.y + 14f, paint(8.8f, bold = true, color = INK))
        lines.forEachIndexed { i, line -> c.drawText(line, MARGIN + 10f, m.y + 27f + i * 11f, wp) }
        m.y += boxH + 14f
    }

    private fun drawMemoSignatures(m: MemoDoc) {
        m.ensure(70f)
        val c = m.canvas
        val y = m.y + 36f
        val bw = 190f
        val blocks = listOf(
            MARGIN + 10f to (strings.pdfSellerSign to strings.pdfSellerSignSub),
            (PAGE_W - MARGIN - 10f - bw) to (strings.pdfBuyerSign to strings.pdfBuyerSignSub)
        )
        blocks.forEach { (x, texts) ->
            c.drawLine(x, y, x + bw, y, stroke(INK_MID, 0.9f))
            val lp = paint(8.8f, bold = true, color = INK)
            val lt = fitText(texts.first, lp, bw)
            c.drawText(lt, x + (bw - lp.measureText(lt)) / 2f, y + 12f, lp)
            if (texts.second.isNotBlank()) {
                val sp = paint(7.3f, color = GRAY)
                c.drawText(texts.second, x + (bw - sp.measureText(texts.second)) / 2f, y + 23f, sp)
            }
        }
        m.y = y + 28f
    }

    // ── পুরো রিপোর্ট সাজানো ──

    private fun renderMemo(
        shop: ShopEntity, txns: List<TransactionWithItems>, reportNumber: Int,
        fromTime: Long, toTime: Long, scope: PdfContentScope, totalPages: Int
    ): MemoDoc {
        val includeTable = scope != PdfContentScope.SUMMARY_ONLY
        val includeSummary = scope != PdfContentScope.TRANSACTIONS_ONLY
        val shopkeeper = labels != null
        val brandName = branding?.name ?: strings.homeHeadline
        val m = MemoDoc(brandName, reportNumber, totalPages)
        m.newPage()

        m.y = drawMemoHeader(m.canvas, reportNumber)
        m.y = drawMemoMeta(m.canvas, m.y, reportNumber, fromTime, toTime)

        val parties = if (shopkeeper) listOf(
            Party(strings.pdfSeller, brandName, branding?.phone.orEmpty(), branding?.address.orEmpty(),
                GREEN_LIGHT_BG, GREEN_LIGHT_BORDER, Color.rgb(5, 150, 105)),
            Party(strings.pdfBuyer, shop.name, shop.phone.orEmpty(), "",
                RED_LIGHT_BG, RED_LIGHT_BORDER, RED)
        ) else listOf(
            Party(strings.pdfSeller, shop.name, shop.phone.orEmpty(), "",
                GREEN_LIGHT_BG, GREEN_LIGHT_BORDER, Color.rgb(5, 150, 105))
        )
        m.y = drawMemoParties(m.canvas, m.y, parties)

        // ── লেনদেন ভাগ করি: চেরাই কাঠ / গোল কাঠ / অন্য পণ্য / নগদ বাকি / জমা ──
        class WoodRow(val date: Long, val name: String, val wm: WoodMeasure, val rate: Double?, val amount: Double)
        class OtherRow(val date: Long, val name: String, val qty: String, val rate: Double?, val amount: Double)
        class MoneyRow(val date: Long, val note: String, val amount: Double)

        val sawn = mutableListOf<WoodRow>()
        val round = mutableListOf<WoodRow>()
        val other = mutableListOf<OtherRow>()
        val cash = mutableListOf<MoneyRow>()
        val payments = mutableListOf<MoneyRow>()
        var totalCredit = 0.0
        var totalPayment = 0.0

        txns.forEach { tw ->
            val t = tw.txn
            if (t.type == TransactionEntity.TYPE_CREDIT) {
                totalCredit += t.amount
                if (tw.items.isEmpty()) {
                    cash += MoneyRow(t.date, t.note.orEmpty(), t.amount)
                } else tw.items.forEach { item ->
                    val name = DefaultProducts.translateIfDefault(item.productName, strings.code).ifBlank { txtCreditFallback }
                    val wm = WoodMeasure.fromJson(item.measure)
                    if (wm != null) {
                        val target = if (wm.round) round else sawn
                        target.add(WoodRow(t.date, name, wm, item.unitPrice, item.amount))
                    } else {
                        val qty = item.quantity?.let {
                            UnitConverter.amountInput(it) + (item.unit?.takeIf { u -> u.isNotBlank() }?.let { u -> " $u" } ?: "")
                        } ?: ""
                        other += OtherRow(t.date, name, qty, item.unitPrice, item.amount)
                    }
                }
            } else {
                totalPayment += t.amount
                payments += MoneyRow(t.date, t.note.orEmpty(), t.amount)
            }
        }

        if (includeTable) {
            fun d(ts: Long) = UnitConverter.dateShort(ts, strings.code)

            // ── চেরাই কাঠ ──
            drawMemoTable(
                m, strings.pdfSecSawn,
                listOf(
                    MCol(strings.pdfColSl, 4f, 0), MCol(strings.pdfColDate, 13f, 0), MCol(strings.pdfColDesc, 18f, 1),
                    MCol(strings.lengthFtLabel, 8f, 0), MCol(strings.widthInLabel, 8f, 0), MCol(strings.thicknessInLabel, 8f, 0),
                    MCol(strings.pdfColPieces, 6f, 0), MCol(strings.pdfColCft, 10f, 2),
                    MCol(strings.pdfColRate, 11f, 2), MCol(strings.pdfColAmountRs, 14f, 2)
                ),
                sawn.mapIndexed { i, r ->
                    listOf(
                        MCell((i + 1).toString()), MCell(d(r.date)),
                        MCell(r.name, color = INK_MID, badge = strings.pdfBadgeSawn, badgeColor = TEAL),
                        MCell(UnitConverter.amountInput(r.wm.lengthFt)), MCell(UnitConverter.amountInput(r.wm.widthIn)),
                        MCell(UnitConverter.amountInput(r.wm.thicknessIn)), MCell(r.wm.pieces.toString()),
                        MCell(n2(r.wm.totalCft), bold = true),
                        MCell(r.rate?.let { UnitConverter.rupees(it) } ?: "—"),
                        MCell(UnitConverter.rupees(r.amount), bold = true, color = RED)
                    )
                },
                30f, 7, strings.pdfSawnTotal,
                listOf(
                    MCell("${n2(sawn.sumOf { it.wm.totalCft })} CFT", bold = true, color = INK),
                    MCell(strings.pdfTableTotal, bold = true, color = INK),
                    MCell(UnitConverter.rupees(sawn.sumOf { it.amount }), bold = true, color = RED)
                ),
                TEAL_LIGHT
            )

            // ── গোল কাঠ ──
            drawMemoTable(
                m, strings.pdfSecRound,
                listOf(
                    MCol(strings.pdfColSl, 4f, 0), MCol(strings.pdfColDate, 13f, 0), MCol(strings.pdfColDesc, 22f, 1),
                    MCol(strings.lengthFtLabel, 9f, 0), MCol(strings.girthInLabel, 12f, 0),
                    MCol(strings.pdfColPieces, 7f, 0), MCol(strings.pdfColCft, 10f, 2),
                    MCol(strings.pdfColRate, 9f, 2), MCol(strings.pdfColAmountRs, 14f, 2)
                ),
                round.mapIndexed { i, r ->
                    listOf(
                        MCell((i + 1).toString()), MCell(d(r.date)),
                        MCell(r.name, color = INK_MID, badge = strings.pdfBadgeRound, badgeColor = RED),
                        MCell(UnitConverter.amountInput(r.wm.lengthFt)), MCell(UnitConverter.amountInput(r.wm.girthIn)),
                        MCell(r.wm.pieces.toString()), MCell(n2(r.wm.totalCft), bold = true),
                        MCell(r.rate?.let { UnitConverter.rupees(it) } ?: "—"),
                        MCell(UnitConverter.rupees(r.amount), bold = true, color = RED)
                    )
                },
                30f, 6, strings.pdfRoundTotal,
                listOf(
                    MCell("${n2(round.sumOf { it.wm.totalCft })} CFT", bold = true, color = INK),
                    MCell(strings.pdfTableTotal, bold = true, color = INK),
                    MCell(UnitConverter.rupees(round.sumOf { it.amount }), bold = true, color = RED)
                ),
                RED_LIGHT_BG
            )

            // ── অন্যান্য পণ্য ──
            drawMemoTable(
                m, strings.pdfSecOther,
                listOf(
                    MCol(strings.pdfColSl, 5f, 0), MCol(strings.pdfColDate, 13f, 0), MCol(strings.pdfColDesc, 32f, 1),
                    MCol(strings.pdfColQty, 18f, 0), MCol(strings.pdfColUnitPrice, 14f, 2), MCol(strings.pdfColAmountRs, 18f, 2)
                ),
                other.mapIndexed { i, r ->
                    listOf(
                        MCell((i + 1).toString()), MCell(d(r.date)), MCell(r.name, bold = true),
                        MCell(r.qty.ifBlank { "—" }),
                        MCell(r.rate?.let { UnitConverter.rupees(it) } ?: "—"),
                        MCell(UnitConverter.rupees(r.amount), bold = true, color = RED)
                    )
                },
                20f, 5, strings.pdfTableTotal,
                listOf(MCell(UnitConverter.rupees(other.sumOf { it.amount }), bold = true, color = RED)),
                TEAL_LIGHT
            )

            // ── নগদ বাকি (সরাসরি টাকা) ──
            drawMemoTable(
                m, strings.pdfSecCashCredit,
                listOf(MCol(strings.pdfColSl, 5f, 0), MCol(strings.pdfColDate, 14f, 0), MCol(strings.pdfColDesc, 51f, 1), MCol(strings.pdfColAmountRs, 30f, 2)),
                cash.mapIndexed { i, r ->
                    listOf(MCell((i + 1).toString()), MCell(d(r.date)),
                        MCell(r.note.ifBlank { txtCreditFallback }, bold = true),
                        MCell(UnitConverter.rupees(r.amount), bold = true, color = RED))
                },
                20f, 3, strings.pdfTableTotal,
                listOf(MCell(UnitConverter.rupees(cash.sumOf { it.amount }), bold = true, color = RED)),
                TEAL_LIGHT
            )

            // ── জমা / পরিশোধ ──
            drawMemoTable(
                m, strings.pdfSecPayments,
                listOf(MCol(strings.pdfColSl, 5f, 0), MCol(strings.pdfColDate, 14f, 0), MCol(strings.pdfColDesc, 51f, 1), MCol(strings.pdfColAmountRs, 30f, 2)),
                payments.mapIndexed { i, r ->
                    listOf(MCell((i + 1).toString()), MCell(d(r.date)),
                        MCell(r.note.ifBlank { txtPaymentFallback }, bold = true),
                        MCell(UnitConverter.rupees(r.amount), bold = true, color = PAYMENT_DEEP))
                },
                20f, 3, strings.pdfTableTotal,
                listOf(MCell(UnitConverter.rupees(payments.sumOf { it.amount }), bold = true, color = PAYMENT_DEEP)),
                GREEN_LIGHT_BG
            )

            if (txns.isEmpty()) {
                m.ensure(30f)
                val ep = paint(10f, color = GRAY)
                m.canvas.drawText(strings.historyNoTxnsFound, MARGIN, m.y + 14f, ep)
                m.y += 30f
            }
        }

        if (includeSummary) {
            drawMemoSummary(m, totalCredit, totalPayment, totalCredit - totalPayment)
            drawMemoSignatures(m)
        }

        m.finishLastPage()
        return m
    }

    // ═══════════════════════════ শেয়ার্ড ড্রয়িং হেল্পার ═══════════════════════════

    private fun drawWatermark(canvas: Canvas) {
        val p = paint(64f, bold = true, color = Color.argb(15, 5, 150, 105))
        val text = branding?.name ?: strings.homeHeadline
        var w = p.measureText(text)
        val maxW = PAGE_W - 24f
        if (w > maxW) { p.textSize = p.textSize * maxW / w; w = p.measureText(text) }
        canvas.save()
        canvas.rotate(-24f, PAGE_W / 2f, PAGE_H / 2f)
        canvas.drawText(text, PAGE_W / 2f - w / 2f, PAGE_H / 2f, p)
        canvas.restore()
    }

    private fun drawMainHeader(canvas: Canvas, titleLine: String, reportNumber: Int, format: PdfFormat): Float {
        val headerH = headerHeight()
        val bg = Paint().apply {
            shader = android.graphics.LinearGradient(
                0f, 0f, PAGE_W.toFloat(), headerH, GREEN_DARK, GREEN, android.graphics.Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, PAGE_W.toFloat(), headerH, bg)

        branding?.let { b ->
            drawBrandedHeader(canvas, b, titleLine, reportNumber, headerH)
            return headerH + 24f
        }

        val logoSize = 44
        var textX = MARGIN
        if (logoSize > 0) {
            logoBitmap(logoSize)?.let { canvas.drawBitmap(it, MARGIN, (headerH - logoSize) / 2f, null) }
            textX = MARGIN + logoSize + 10f
        }
        canvas.drawText(
            titleLine.take(28),
            textX, headerH / 2f - 2f,
            paint(16f, bold = true, color = WHITE)
        )
        canvas.drawText(
            "${strings.pdfReportNumberLabel}: #UH-$reportNumber",
            PAGE_W - MARGIN - 130f, 26f, paint(9.5f, color = Color.argb(230, 255, 255, 255))
        )
        return headerH + 24f
    }

    /** ⭐ ইনভয়েস হেডার: বামে লোগো, ডানে দোকানের নাম → রিপোর্ট/গ্রাহকের নাম → ঠিকানা → ফোন */
    private fun drawBrandedHeader(canvas: Canvas, b: ShopBranding, titleLine: String, reportNumber: Int, headerH: Float) {
        val logoSize = 52
        brandLogo(logoSize)?.let { canvas.drawBitmap(it, MARGIN, (headerH - logoSize) / 2f, null) }
        val textX = MARGIN + logoSize + 12f
        val maxW = PAGE_W - textX - MARGIN
        val white = Color.argb(235, 255, 255, 255)
        val nameP = paint(17f, bold = true, color = WHITE)
        val subP = paint(11f, color = white)
        val smallP = paint(9.5f, color = white)

        canvas.drawText(fitText(b.name, nameP, maxW), textX, 30f, nameP)
        canvas.drawText(fitText(titleLine, subP, maxW), textX, 47f, subP)
        var ly = 64f
        if (b.address.isNotBlank()) {
            canvas.drawText(fitText(b.address, smallP, maxW), textX, ly, smallP)
            ly += 14f
        }
        if (b.phone.isNotBlank()) {
            canvas.drawText(fitText(strings.pdfPhoneLabel + b.phone, smallP, maxW), textX, ly, smallP)
        }
        val rn = "${strings.pdfReportNumberLabel}: #INV-$reportNumber"
        val rp = paint(9f, color = white)
        canvas.drawText(rn, PAGE_W - MARGIN - rp.measureText(rn), headerH - 8f, rp)
    }

    private fun drawMiniHeader(canvas: Canvas, title: String): Float {
        canvas.drawText(title.take(30), MARGIN, MARGIN, paint(11f, bold = true, color = GREEN_DARK))
        val line = Paint().apply { strokeWidth = 1f; color = GRAY_LIGHT }
        canvas.drawLine(MARGIN, MARGIN + 8f, PAGE_W - MARGIN, MARGIN + 8f, line)
        return MARGIN + 26f
    }

    private fun drawShopMetaBoxes(canvas: Canvas, yStart: Float, shop: ShopEntity, fromTime: Long, toTime: Long): Float {
        var y = yStart
        val boxW = (PAGE_W - 2 * MARGIN - 10f) / 2f
        val boxH = 52f
        val bg = Paint().apply { color = GREEN_LIGHT_BG }
        val border = Paint().apply { color = GREEN_LIGHT_BORDER; style = Paint.Style.STROKE; strokeWidth = 1f }

        // বক্স ১: দোকান
        canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 10f, 10f, bg)
        canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 10f, 10f, border)
        canvas.drawText(txtShopBox, MARGIN + 10f, y + 16f, paint(8.5f, bold = true, color = GREEN))
        canvas.drawText(shop.name.take(20), MARGIN + 10f, y + 32f, paint(12f, bold = true))
        shop.phone?.let { canvas.drawText(it, MARGIN + 10f, y + 46f, paint(9.5f, color = GRAY)) }

        // বক্স ২: তারিখ
        val x2 = MARGIN + boxW + 10f
        canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 10f, 10f, bg)
        canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 10f, 10f, border)
        canvas.drawText(strings.pdfDateBoxLabel, x2 + 10f, y + 16f, paint(8.5f, bold = true, color = GREEN))
        canvas.drawText(UnitConverter.dateShort(toTime, strings.code), x2 + 10f, y + 32f, paint(12f, bold = true))
        val days = daysBetween(fromTime, toTime)
        canvas.drawText("$days ${strings.pdfDaysOfRecordsSuffix}", x2 + 10f, y + 46f, paint(9.5f, color = GRAY))

        y += boxH + 16f
        return y
    }

    private fun drawTableHeader(canvas: Canvas, yStart: Float): Float {
        val y = yStart
        val bg = Paint().apply { color = GREEN_DARK }
        canvas.drawRect(MARGIN - 4f, y - 16f, PAGE_W - MARGIN + 4f, y + 8f, bg)
        val hp = paint(9.5f, bold = true, color = WHITE)
        val colDate = MARGIN + 4f
        val colDesc = MARGIN + 80f
        val totalRight = PAGE_W - MARGIN - 8f
        val itemAmtRight = PAGE_W - MARGIN - ITEM_AMT_GAP
        val calcRight = itemAmtRight - CALC_GAP
        canvas.drawText(strings.pdfColDate, colDate, y, hp)
        canvas.drawText(strings.pdfColDesc, colDesc, y, hp)
        val qp = strings.pdfColQtyPrice
        val ip = strings.pdfColItemTotal
        canvas.drawText(qp, calcRight - hp.measureText(qp), y, hp)
        canvas.drawText(ip, itemAmtRight - hp.measureText(ip), y, hp)
        val totalLabel = strings.totalPrefix.trim().removeSuffix(":")
        canvas.drawText(totalLabel, totalRight - hp.measureText(totalLabel), y, hp)
        return y + 28f
    }

    /** ⭐ কাঠের মাপের একটা লাইন: "চেরাই কাঠ — দৈর্ঘ্য (ফুট): ১০ • প্রস্থ (ইঞ্চি): ৬ • পুরত্ব (ইঞ্চি): ২ • পিস সংখ্যা: ৫" */
    private fun woodDimsLine(wm: WoodMeasure): String {
        fun n(v: Double) = UnitConverter.amountInput(v)
        return if (wm.round) {
            "${strings.pdfWoodRound} — ${strings.lengthFtLabel}: ${n(wm.lengthFt)} • " +
                "${strings.girthInLabel}: ${n(wm.girthIn)} • ${strings.pieceCountLabel}: ${wm.pieces}"
        } else {
            "${strings.pdfWoodSawn} — ${strings.lengthFtLabel}: ${n(wm.lengthFt)} • " +
                "${strings.widthInLabel}: ${n(wm.widthIn)} • ${strings.thicknessInLabel}: ${n(wm.thicknessIn)} • " +
                "${strings.pieceCountLabel}: ${wm.pieces}"
        }
    }

    /** ⭐ একটা লেনদেনের ব্লকের মোট উচ্চতা — পণ্য, কাঠের মাপ ও নোট যত, তত লম্বা (পেজ ভাঙার হিসাবেও এটাই) */
    private fun txnRowHeight(tw: TransactionWithItems): Float {
        var h = MAIN_ROW_H
        tw.items.forEach { item ->
            h += ITEM_ROW_H
            if (WoodMeasure.fromJson(item.measure) != null) h += DETAIL_ROW_H
        }
        if (tw.items.isNotEmpty() && !tw.txn.note.isNullOrBlank()) h += DETAIL_ROW_H
        return h + BLOCK_GAP
    }

    /**
     * ⭐ একটা লেনদেনের ব্লক:
     *  ┌ গাঢ় রঙের পাশের পট্টি │ তারিখ/সময় │ [ধার/জমা ট্যাগ] ............ মোট ┐
     *  │                    │ ● পণ্যের নাম      পরিমাণ × দাম      পণ্যের টাকা │
     *  │                    │   (কাঠের মাপ — শুধু কাঠ হলে)                     │
     *  └ নোট (থাকলে) ─────────────────────────────────────────────────┘
     */
    private fun drawTxnRow(canvas: Canvas, yStart: Float, tw: TransactionWithItems): Float {
        val t = tw.txn
        val isCredit = t.type == TransactionEntity.TYPE_CREDIT
        val deep = if (isCredit) RED else PAYMENT_DEEP
        val tint = if (isCredit) RED_LIGHT_BG else GREEN_LIGHT_BG
        val h = txnRowHeight(tw)
        val top = yStart - 14f
        val bottom = top + h - BLOCK_GAP
        val left = MARGIN - 4f
        val right = PAGE_W - MARGIN + 4f

        val colDate = MARGIN + 4f
        val colDesc = MARGIN + 80f
        val totalRight = PAGE_W - MARGIN - 8f
        val itemAmtRight = PAGE_W - MARGIN - ITEM_AMT_GAP
        val calcRight = itemAmtRight - CALC_GAP

        // ── মূল সারির পটভূমি + পুরো ব্লকের পাশে গাঢ় পট্টি + নিচে সীমারেখা ──
        canvas.drawRect(left, top, right, top + MAIN_ROW_H, Paint().apply { color = tint })
        canvas.drawRect(left, top, left + 4f, bottom, Paint().apply { color = deep })
        canvas.drawLine(left, bottom, right, bottom, Paint().apply { color = GRAY_LIGHT; strokeWidth = 0.8f })

        // ── তারিখ (গাঢ়) + সময় ──
        canvas.drawText(UnitConverter.dateShort(t.date, strings.code), colDate, top + 12f, paint(10f, bold = true, color = INK))
        val timeText = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.US).format(java.util.Date(t.date))
        canvas.drawText(timeText, colDate, top + 23f, paint(8f, color = INK_MID))

        // ── ধরনের ট্যাগ (গাঢ় জমি, সাদা লেখা) ──
        val tagText = if (isCredit) txtCreditFallback else txtPaymentFallback
        val tagPaint = paint(9f, bold = true, color = WHITE)
        val tagW = tagPaint.measureText(tagText) + 16f
        canvas.drawRoundRect(colDesc, top + 6f, colDesc + tagW, top + 22f, 8f, 8f, Paint().apply { color = deep })
        canvas.drawText(tagText, colDesc + 8f, top + 17f, tagPaint)

        // ── লেনদেনের মোট (ডান প্রান্তে, বড় ও গাঢ়) ──
        val amtText = (if (isCredit) "+" else "-") + UnitConverter.rupees(t.amount)
        val amtPaint = paint(12f, bold = true, color = deep)
        val amtW = amtPaint.measureText(amtText)
        canvas.drawText(amtText, totalRight - amtW, top + 18f, amtPaint)

        // ── পণ্যের তালিকা নেই (সরাসরি টাকা): ট্যাগের পাশে নোট/বিবরণ ──
        if (tw.items.isEmpty()) {
            val note = t.note?.takeIf { it.isNotBlank() }
            if (note != null) {
                val dp = paint(10f, color = INK)
                val x = colDesc + tagW + 10f
                canvas.drawText(fitText(note, dp, (totalRight - amtW - 10f) - x), x, top + 17f, dp)
            }
            return yStart + h
        }

        // ── ⭐ পণ্যভিত্তিক হিসাব: ● নাম | পরিমাণ × দাম | পণ্যের টাকা ──
        val namePaint = paint(10f, bold = true, color = INK)
        val calcPaint = paint(9.5f, color = INK_MID)
        val itemAmtPaint = paint(10f, bold = true, color = deep)
        val dotPaint = Paint().apply { color = deep; isAntiAlias = true }
        val sepPaint = Paint().apply { color = GRAY_LIGHT; strokeWidth = 0.5f }

        var ly = top + MAIN_ROW_H + 11f
        tw.items.forEachIndexed { index, item ->
            val name = DefaultProducts.translateIfDefault(item.productName, strings.code)
                .ifBlank { txtCreditFallback }

            val qtyText = item.quantity?.let {
                UnitConverter.amountInput(it) + (item.unit?.takeIf { u -> u.isNotBlank() }?.let { u -> " $u" } ?: "")
            }
            val calc = when {
                qtyText != null && item.unitPrice != null -> "$qtyText × ${UnitConverter.rupees(item.unitPrice!!)}"
                qtyText != null -> qtyText
                else -> ""
            }

            val itemAmt = UnitConverter.rupees(item.amount)
            val itemAmtW = itemAmtPaint.measureText(itemAmt)
            canvas.drawText(itemAmt, itemAmtRight - itemAmtW, ly, itemAmtPaint)

            var nameMaxRight = itemAmtRight - itemAmtW - 8f
            if (calc.isNotEmpty()) {
                val calcW = calcPaint.measureText(calc)
                canvas.drawText(calc, calcRight - calcW, ly, calcPaint)
                nameMaxRight = calcRight - calcW - 8f
            }
            canvas.drawCircle(colDesc + 2.5f, ly - 3.5f, 2.2f, dotPaint)
            canvas.drawText(fitText(name, namePaint, nameMaxRight - (colDesc + 10f)), colDesc + 10f, ly, namePaint)

            // ── ⭐ কাঠ হলে সম্পূর্ণ মাপ — গাঢ় ধূসর, পণ্যের ঠিক নিচে ──
            WoodMeasure.fromJson(item.measure)?.let { wm ->
                ly += DETAIL_ROW_H
                val dp = paint(9f, color = INK_MID)
                canvas.drawText(fitText(woodDimsLine(wm), dp, (PAGE_W - MARGIN) - (colDesc + 10f)), colDesc + 10f, ly, dp)
            }
            ly += ITEM_ROW_H
            // পণ্যগুলোর মাঝে সরু রেখা (শেষ পণ্যের পরে নয়)
            if (index < tw.items.lastIndex) {
                canvas.drawLine(colDesc, ly - ITEM_ROW_H + 5f, itemAmtRight, ly - ITEM_ROW_H + 5f, sepPaint)
            }
        }

        // নোট থাকলে সবার শেষে
        t.note?.let {
            if (it.isNotBlank()) {
                val np = paint(9f, color = INK_MID)
                canvas.drawText(fitText("— $it", np, (PAGE_W - MARGIN) - colDesc), colDesc, ly - 2f, np)
            }
        }
        return yStart + h
    }

    private fun drawSummarySection(
        canvas: Canvas, yStart: Float,
        totalCredit: Double, totalPayment: Double, currentDue: Double, txnCount: Int,
        format: PdfFormat
    ): Float {
        var y = yStart + 10f
        val small = false

        if (!small) {
            // দুটো বক্স পাশাপাশি
            val boxW = (PAGE_W - 2 * MARGIN - 10f) / 2f
            val boxH = 46f
            val bgD = Paint().apply { color = RED_LIGHT_BG }
            val bdD = Paint().apply { color = RED_LIGHT_BORDER; style = Paint.Style.STROKE; strokeWidth = 1.3f }
            canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 12f, 12f, bgD)
            canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 12f, 12f, bdD)
            canvas.drawText(txtTotalCredit, MARGIN + 12f, y + 18f, paint(9.5f, bold = true, color = RED))
            canvas.drawText(UnitConverter.rupees(totalCredit), MARGIN + 12f, y + 36f, paint(15f, bold = true, color = RED))

            val x2 = MARGIN + boxW + 10f
            val bgP = Paint().apply { color = GREEN_LIGHT_BG }
            val bdP = Paint().apply { color = GREEN_LIGHT_BORDER; style = Paint.Style.STROKE; strokeWidth = 1.3f }
            canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 12f, 12f, bgP)
            canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 12f, 12f, bdP)
            canvas.drawText(txtTotalPayment, x2 + 12f, y + 18f, paint(9.5f, bold = true, color = PAYMENT_DEEP))
            canvas.drawText(UnitConverter.rupees(totalPayment), x2 + 12f, y + 36f, paint(15f, bold = true, color = PAYMENT_DEEP))

            y += boxH + 12f
        }

        // চূড়ান্ত বাকি — গাঢ় সবুজ বক্স
        val subtitle = if (strings.code == "en") "$txnCount transactions"
                       else "মোট ${txnCount}টি লেনদেন"
        val dueText = UnitConverter.rupees(currentDue)
        val finalBg = Paint().apply { color = GREEN_DEEPEST }

        if (small) {
            // ── সরু রিসিটে পাশাপাশি না রেখে উপর-নিচ সাজানো, ওভারল্যাপ এড়াতে ──
            val finalH = 64f
            canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + finalH, 14f, 14f, finalBg)
            canvas.drawText(txtFinalDue, MARGIN + 12f, y + 18f, paint(10f, bold = true, color = WHITE))
            canvas.drawText(dueText, MARGIN + 12f, y + 42f, paint(20f, bold = true, color = RED_SOFT))
            canvas.drawText(subtitle, MARGIN + 12f, y + 56f, paint(8f, color = Color.argb(200, 255, 255, 255)))
            y += finalH + 16f
        } else {
            val finalH = 52f
            canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + finalH, 14f, 14f, finalBg)
            canvas.drawText(txtFinalDue, MARGIN + 14f, y + 20f, paint(13f, bold = true, color = WHITE))
            canvas.drawText(subtitle, MARGIN + 14f, y + 36f, paint(8f, color = Color.argb(200, 255, 255, 255)))
            val dueW = paint(20f, bold = true).measureText(dueText)
            canvas.drawText(dueText, PAGE_W - MARGIN - 14f - dueW, y + finalH / 2f + 7f, paint(20f, bold = true, color = RED_SOFT))
            y += finalH + 16f
        }
        return y
    }

    private fun drawSignatureLines(canvas: Canvas, yStart: Float): Float {
        var y = yStart + 26f
        if (y + 30f > PAGE_H - MARGIN - 30f) return y // জায়গা না থাকলে বাদ
        val dash = Paint().apply {
            color = GRAY; strokeWidth = 1.3f
            pathEffect = DashPathEffect(floatArrayOf(5f, 4f), 0f)
        }
        val lineW = 140f
        canvas.drawLine(MARGIN, y, MARGIN + lineW, y, dash)
        canvas.drawText(strings.pdfShopSignatureLabel, MARGIN, y + 14f, paint(9f, color = GRAY))

        canvas.drawLine(PAGE_W - MARGIN - lineW, y, PAGE_W - MARGIN, y, dash)
        canvas.drawText(strings.pdfCustomerSignatureLabel, PAGE_W - MARGIN - lineW, y + 14f, paint(9f, color = GRAY))
        return y + 28f
    }

    private fun drawFooter(canvas: Canvas, pageNo: Int, totalPages: Int) {
        if (PAGE_W < 300) {
            // ── সরু রিসিটে ফুটার এক লাইনে আর জায়গা পায় না, তাই মাঝখানে বসানো ──
            val p = paint(7f, color = GRAY)
            val w = p.measureText(strings.pdfFooter)
            canvas.drawText(strings.pdfFooter, (PAGE_W - w) / 2f, PAGE_H - 12f, p)
            return
        }
        val footerP = paint(8f, color = GRAY)
        val pageText = "${strings.pdfPageLabel} $pageNo/$totalPages"
        val w = paint(8f).measureText(pageText)
        val footer = branding?.let { b ->
            listOf(b.name, b.phone).filter { it.isNotBlank() }.joinToString(" • ")
        } ?: strings.pdfFooter
        canvas.drawText(fitText(footer, footerP, PAGE_W - 2 * MARGIN - w - 8f), MARGIN, PAGE_H - 18f, footerP)
        canvas.drawText(pageText, PAGE_W - MARGIN - w, PAGE_H - 18f, paint(8f, color = GRAY))
    }

    private fun estimateA4Pages(rowCount: Int, includeTable: Boolean, includeMetaAndChart: Boolean, includeSummary: Boolean): Int {
        if (!includeTable) return 1
        val hh = headerHeight().toInt()
        val firstPageHeader = if (includeMetaAndChart) hh + 24 + 52 + 16 else hh + 24
        val rowsPage1 = ((PAGE_H - MARGIN - firstPageHeader - 40 - 22) / 20).toInt().coerceAtLeast(1)
        val rowsOtherPages = ((PAGE_H - MARGIN - 60 - 40 - 22) / 20).toInt().coerceAtLeast(1)
        if (rowCount <= rowsPage1) return 1
        val remaining = rowCount - rowsPage1
        return 1 + kotlin.math.ceil(remaining.toDouble() / rowsOtherPages).toInt()
    }

    /** ⭐ পণ্যসহ লেনদেনের আসল উচ্চতা ধরে মোট পেজ গোনা — ফুটারের "পৃষ্ঠা x/y"-এর জন্য */
    private fun estimateShopPages(
        txns: List<TransactionWithItems>,
        includeTable: Boolean, includeMetaAndChart: Boolean, includeSummary: Boolean
    ): Int {
        if (!includeTable) return 1
        val hh = headerHeight()
        val firstHeader = if (includeMetaAndChart) hh + 24f + 52f + 16f else hh + 24f
        val firstUsable = PAGE_H - MARGIN - firstHeader - 40f - 22f
        val otherUsable = PAGE_H - MARGIN - 60f - 40f - 22f
        var pages = 1
        var left = firstUsable
        txns.forEach { tw ->
            val h = txnRowHeight(tw)
            if (h > left) { pages++; left = otherUsable }
            left -= h
        }
        if (includeSummary && left < 190f) pages++
        return pages
    }

    private fun daysBetween(fromTime: Long, toTime: Long): Int =
        (((toTime - fromTime) / (24L * 60 * 60 * 1000)) + 1).toInt().coerceAtLeast(1)
}
