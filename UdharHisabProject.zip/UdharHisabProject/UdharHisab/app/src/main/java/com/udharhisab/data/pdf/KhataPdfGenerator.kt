// ❌ package com.udharhis.data.pdf
package com.udharhisab.data.pdf

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.Canvas
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.AppStrings
import com.udharhisab.ui.strings.BengaliStrings
import java.io.File
import java.io.FileOutputStream

/**
 * ⭐ খাতা-স্টাইল A4 PDF — মাল্টি-পেজ, বাংলা ফন্ট (assets/fonts থেকে)
 * @param strings বর্তমান UI ভাষায় PDF-এর লেবেলগুলো আঁকতে — সেটিংসের ভাষা অনুযায়ী পাস করুন
 */
class KhataPdfGenerator(private val context: Context, private val strings: AppStrings = BengaliStrings) {

    // কালার
    private val GREEN = Color.rgb(46, 125, 50)
    private val RED = Color.rgb(198, 40, 40)
    private val BLACK = Color.rgb(33, 33, 33)
    private val GRAY = Color.rgb(117, 117, 117)
    private val ROW_ALT = Color.rgb(241, 243, 239)
    private val WHITE = Color.WHITE

    private val PAGE_W = 595    // A4 @72dpi
    private val PAGE_H = 842
    private val MARGIN = 40f

    private var bengaliRegular: Typeface? = null
    private var bengaliBold: Typeface? = null

    init {
        try {
            bengaliRegular = Typeface.createFromAsset(
                context.assets, "fonts/NotoSansBengali-Regular.ttf"
            )
            bengaliBold = Typeface.createFromAsset(
                context.assets, "fonts/NotoSansBengali-Bold.ttf"
            )
        } catch (_: Exception) { /* ফন্ট না থাকলে ডিফল্ট */ }
    }

    fun generate(shop: ShopEntity, txns: List<TransactionEntity>): File {
        val doc = PdfDocument()
        var pageNo = 0
        var y = 0f
        var canvas: Canvas? = null
        var page: PdfDocument.Page? = null

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val info = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create()
            page = doc.startPage(info)
            canvas = page!!.canvas
            y = MARGIN
        }

        fun ensureSpace(needed: Float, onNext: () -> Unit) {
            if (y + needed > PAGE_H - MARGIN) {
                newPage()
                onNext()
            }
        }

        fun paint(size: Float, bold: Boolean = false, color: Int = BLACK): Paint =
            Paint().apply {
                this.color = color
                textSize = size
                typeface = if (bold) bengaliBold ?: Typeface.DEFAULT_BOLD
                           else bengaliRegular ?: Typeface.DEFAULT
                isAntiAlias = true
            }

        // ── পৃষ্ঠা ১ + হেডার ──
        newPage()

        // হেডার ব্যান্ড
        val headerPaint = Paint().apply { color = GREEN }
        canvas!!.drawRect(0f, 0f, PAGE_W.toFloat(), 90f, headerPaint)
        canvas!!.drawText(strings.pdfHeaderTitle, MARGIN, 40f, paint(20f, bold = true, color = WHITE))
        val type = ShopType.fromKey(shop.shopType)
        canvas!!.drawText("${type.emoji} ${shop.name} — ${strings.pdfFullKhataSuffix}", MARGIN, 68f, paint(14f, color = WHITE))
        y = 115f

        // দোকানের তথ্য
        canvas!!.drawText("${strings.pdfShopLabel}${shop.name}", MARGIN, y, paint(13f, bold = true))
        y += 20f
        shop.phone?.let {
            canvas!!.drawText("${strings.pdfPhoneLabel}$it", MARGIN, y, paint(12f, color = GRAY))
            y += 20f
        }
        canvas!!.drawText("${strings.pdfCreatedLabel}${UnitConverter.dateShort(System.currentTimeMillis(), strings.code)}", MARGIN, y, paint(12f, color = GRAY))
        y += 28f

        // ── লেনদেন টেবিল ──
        val colDate = MARGIN
        val colDesc = MARGIN + 100f
        val colCredit = PAGE_W - MARGIN - 220f
        val colPayment = PAGE_W - MARGIN - 110f

        // টেবিল হেডার
        val headBg = Paint().apply { color = Color.rgb(46, 125, 50) }
        canvas!!.drawRect(MARGIN - 4f, y - 14f, PAGE_W - MARGIN + 4f, y + 8f, headBg)
        canvas!!.drawText(strings.pdfColDate, colDate, y, paint(11f, bold = true, color = WHITE))
        canvas!!.drawText(strings.pdfColDesc, colDesc, y, paint(11f, bold = true, color = WHITE))
        canvas!!.drawText(strings.creditFallback, colCredit, y, paint(11f, bold = true, color = WHITE))
        canvas!!.drawText(strings.paymentFallback, colPayment, y, paint(11f, bold = true, color = WHITE))
        y += 22f

        // চলমান ব্যালেন্স হিসাব (পুরনো-ক্রম)
        var running = 0.0
        var totalCredit = 0.0
        var totalPayment = 0.0

        val altBg = Paint().apply { color = ROW_ALT }

        txns.forEachIndexed { i, t ->
            ensureSpace(30f) { /* নতুন পৃষ্ঠায় হেডার আবার */ }

            if (i % 2 == 1) {
                altBg.color = ROW_ALT
                canvas!!.drawRect(MARGIN - 4f, y - 14f, PAGE_W - MARGIN + 4f, y + 6f, altBg)
            }

            val isCredit = t.type == TransactionEntity.TYPE_CREDIT
            if (isCredit) running += t.amount else running -= t.amount
            if (isCredit) totalCredit += t.amount else totalPayment += t.amount

            canvas!!.drawText(UnitConverter.dateShort(t.date, strings.code), colDate, y, paint(10f))
            val desc = buildString {
                t.productName?.let { append(it) }
                if (t.quantity != null && t.unit != null) {
                    append(" (${UnitConverter.amountInput(t.quantity!!)} ${t.unit}")
                    t.unitPrice?.let { append(" × ${UnitConverter.amountInput(it)}") }
                    append(")")
                }
                t.note?.let { if (isNotEmpty()) append(" — $it") }
                if (isEmpty()) append(if (isCredit) strings.creditFallback else strings.paymentFallback)
            }
            canvas!!.drawText(desc.take(32), colDesc, y, paint(10f))
            canvas!!.drawText(
                if (isCredit) UnitConverter.rupees(t.amount) else "",
                colCredit, y, paint(10f, color = RED)
            )
            canvas!!.drawText(
                if (!isCredit) UnitConverter.rupees(t.amount) else "",
                colPayment, y, paint(10f, color = GREEN)
            )
            y += 20f
        }

        // ── সারাংশ ──
        ensureSpace(100f) {}
        y += 14f
        val linePaint = Paint().apply { strokeWidth = 1f; color = GRAY }
        canvas!!.drawLine(MARGIN, y, PAGE_W - MARGIN, y, linePaint)
        y += 24f

        canvas!!.drawText(strings.pdfTotalCredit, colDate, y, paint(12f, bold = true))
        canvas!!.drawText(UnitConverter.rupees(totalCredit), colCredit, y, paint(12f, bold = true, color = RED))
        y += 22f
        canvas!!.drawText(strings.pdfTotalPayment, colDate, y, paint(12f, bold = true))
        canvas!!.drawText(UnitConverter.rupees(totalPayment), colPayment, y, paint(12f, bold = true, color = GREEN))
        y += 30f

        val balance = totalCredit - totalPayment
        val balanceColor = if (balance > 0) RED else GREEN
        val summaryBg = Paint().apply { color = if (balance > 0) Color.rgb(255, 235, 238) else Color.rgb(232, 245, 233) }
        canvas!!.drawRect(MARGIN - 4f, y - 16f, PAGE_W - MARGIN + 4f, y + 12f, summaryBg)
        canvas!!.drawText(strings.pdfCurrentDue, MARGIN, y, paint(15f, bold = true, color = balanceColor))
        canvas!!.drawText(UnitConverter.rupees(balance), PAGE_W - MARGIN - 120f, y, paint(15f, bold = true, color = balanceColor))

        // ফুটার
        canvas!!.drawText(
            strings.pdfFooter,
            PAGE_W / 2 - 60f, PAGE_H - 25f, paint(9f, color = GRAY)
        )

        page?.let { doc.finishPage(it) }

        // ── ফাইলে সেভ ──
        val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val file = File(dir, "khata_${shop.name.replace(Regex("[^\\p{L}\\p{N}]"), "_")}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
