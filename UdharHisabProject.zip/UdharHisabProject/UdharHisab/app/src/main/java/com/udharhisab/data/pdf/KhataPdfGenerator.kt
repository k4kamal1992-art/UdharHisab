package com.udharhisab.data.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.udharhisab.R
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithItems
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.AppStrings
import com.udharhisab.ui.strings.BengaliStrings
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar

enum class PdfFormat { A4, RECEIPT }
enum class PdfContentScope { FULL, SUMMARY_ONLY, TRANSACTIONS_ONLY }

/**
 * ⭐ প্রফেশনাল PDF রিপোর্ট জেনারেটর — রঙিন সারি, রিপোর্ট নম্বর, ওয়াটারমার্ক,
 * সাপ্তাহিক মিনি-চার্ট, সিগনেচার লাইন, A4/রিসিট দুই ফরম্যাট, পৃষ্ঠা নম্বর সহ।
 */
class KhataPdfGenerator(private val context: Context, private val strings: AppStrings = BengaliStrings) {

    // ── কালার ──
    private val GREEN = Color.rgb(5, 150, 105)
    private val GREEN_DARK = Color.rgb(6, 78, 59)
    private val GREEN_DEEPEST = Color.rgb(5, 46, 22)
    private val RED = Color.rgb(220, 38, 38)
    private val RED_LIGHT_BG = Color.rgb(254, 242, 242)
    private val RED_LIGHT_BORDER = Color.rgb(254, 202, 202)
    private val RED_TAG_BG = Color.rgb(254, 226, 226)
    private val RED_TAG_TEXT = Color.rgb(185, 28, 28)
    private val RED_SOFT = Color.rgb(252, 165, 165)
    private val GREEN_LIGHT_BG = Color.rgb(236, 253, 245)
    private val GREEN_LIGHT_BORDER = Color.rgb(167, 243, 208)
    private val GREEN_TAG_BG = Color.rgb(209, 250, 229)
    private val GREEN_TAG_TEXT = Color.rgb(4, 120, 87)
    private val BLACK = Color.rgb(33, 33, 33)
    private val GRAY = Color.rgb(117, 117, 117)
    private val GRAY_LIGHT = Color.rgb(229, 231, 235)
    private val WHITE = Color.WHITE

    private var PAGE_W = 595
    private var PAGE_H = 842
    private val MARGIN = 32f

    private var bengaliRegular: Typeface? = null
    private var bengaliBold: Typeface? = null

    init {
        try {
            bengaliRegular = Typeface.createFromAsset(context.assets, "fonts/NotoSansBengali-Regular.ttf")
            bengaliBold = Typeface.createFromAsset(context.assets, "fonts/NotoSansBengali-Bold.ttf")
        } catch (_: Exception) { /* ফন্ট না থাকলে ডিফল্ট */ }
    }

    private fun paint(size: Float, bold: Boolean = false, color: Int = BLACK): Paint =
        Paint().apply {
            this.color = color
            textSize = size
            typeface = if (bold) bengaliBold ?: Typeface.DEFAULT_BOLD else bengaliRegular ?: Typeface.DEFAULT
            isAntiAlias = true
        }

    private fun logoBitmap(size: Int): Bitmap? = try {
        val src = BitmapFactory.decodeResource(context.resources, R.drawable.logo)
        Bitmap.createScaledBitmap(src, size, size, true)
    } catch (_: Exception) { null }

    // ═══════════════════════════ একটা দোকানের রিপোর্ট ═══════════════════════════

    fun generateShopReport(
        shop: ShopEntity,
        txns: List<TransactionWithItems>,
        reportNumber: Int,
        fromTime: Long,
        toTime: Long,
        format: PdfFormat,
        scope: PdfContentScope
    ): File {
        PAGE_W = if (format == PdfFormat.A4) 595 else 164
        val rowH = 20f
        val includeTable = scope != PdfContentScope.SUMMARY_ONLY
        val includeSummary = scope != PdfContentScope.TRANSACTIONS_ONLY
        val includeMetaAndChart = format == PdfFormat.A4 && scope != PdfContentScope.TRANSACTIONS_ONLY

        // ⭐ রিসিট মোড: এক লম্বা পেজ, পেজিনেশন লাগবে না
        PAGE_H = if (format == PdfFormat.RECEIPT) {
            (170 + (if (includeTable) txns.size * rowH.toInt() + 40 else 0) + 130).coerceAtLeast(300)
        } else 842

        val totalPages = if (format == PdfFormat.RECEIPT) 1
        else estimateA4Pages(txns.size, includeTable, includeMetaAndChart, includeSummary)

        val doc = PdfDocument()
        var pageNo = 0
        var y: Float
        lateinit var canvas: Canvas
        var page: PdfDocument.Page? = null

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val info = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create()
            page = doc.startPage(info)
            canvas = page!!.canvas
            drawWatermark(canvas)
            y = MARGIN
        }
        newPage()
        y = MARGIN

        // ── হেডার (শুধু প্রথম পেজে সম্পূর্ণ, বাকিগুলোয় ছোট) ──
        if (pageNo == 1) {
            y = drawMainHeader(canvas, shop.name, reportNumber, format)
        } else {
            y = drawMiniHeader(canvas, shop.name)
        }

        if (includeMetaAndChart && pageNo == 1) {
            y = drawShopMetaBoxes(canvas, y, shop, fromTime, toTime)
            y = drawWeeklyChart(canvas, y, txns)
        }

        var totalCredit = 0.0
        var totalPayment = 0.0
        var txnCount = 0

        if (includeTable) {
            y = drawTableHeader(canvas, y)
            txns.forEachIndexed { i, tw ->
                if (y + rowH > PAGE_H - MARGIN - 40f && format == PdfFormat.A4) {
                    newPage()
                    y = drawMiniHeader(canvas, shop.name)
                    y = drawTableHeader(canvas, y)
                }
                y = drawTxnRow(canvas, y, tw)
                val isCredit = tw.txn.type == TransactionEntity.TYPE_CREDIT
                if (isCredit) totalCredit += tw.txn.amount else totalPayment += tw.txn.amount
                txnCount++
            }
        } else {
            txns.forEach { tw ->
                val isCredit = tw.txn.type == TransactionEntity.TYPE_CREDIT
                if (isCredit) totalCredit += tw.txn.amount else totalPayment += tw.txn.amount
                txnCount++
            }
        }

        if (includeSummary) {
            if (y + 150f > PAGE_H - MARGIN && format == PdfFormat.A4) {
                newPage()
                y = drawMiniHeader(canvas, shop.name)
            }
            val currentDue = totalCredit - totalPayment
            val daysOfRecords = daysBetween(fromTime, toTime)
            y = drawSummarySection(canvas, y, totalCredit, totalPayment, currentDue, txnCount, format)
            if (format == PdfFormat.A4) {
                y = drawSignatureLines(canvas, y)
            }
        }

        drawFooter(canvas, pageNo, totalPages)
        page?.let { doc.finishPage(it) }

        val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val safeName = shop.name.replace(Regex("[^\\p{L}\\p{N}]"), "_")
        val file = File(dir, "khata_${safeName}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    // ═══════════════════════════ সব দোকানের সারাংশ রিপোর্ট ═══════════════════════════

    fun generateAllShopsReport(
        rows: List<ShopReportRow>,
        reportNumber: Int,
        fromTime: Long,
        toTime: Long
    ): File {
        PAGE_W = 595
        PAGE_H = 842
        val rowH = 22f
        val totalPages = estimateA4Pages(rows.size, true, false, true)

        val doc = PdfDocument()
        var pageNo = 0
        var y: Float
        lateinit var canvas: Canvas
        var page: PdfDocument.Page? = null

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val info = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create()
            page = doc.startPage(info)
            canvas = page!!.canvas
            drawWatermark(canvas)
            y = MARGIN
        }
        newPage()
        y = MARGIN

        y = if (pageNo == 1) drawMainHeader(canvas, strings.pdfAllShopsReportTitle, reportNumber, PdfFormat.A4)
            else drawMiniHeader(canvas, strings.pdfAllShopsReportTitle)

        // টেবিল হেডার: দোকান | ধার | জমা | বাকি
        val colName = MARGIN
        val colCredit = PAGE_W - MARGIN - 3 * 90f
        val colPayment = PAGE_W - MARGIN - 2 * 90f
        val colDue = PAGE_W - MARGIN - 90f

        fun tableHeader() {
            val bg = Paint().apply { color = GREEN }
            canvas.drawRect(MARGIN - 4f, y - 14f, PAGE_W - MARGIN + 4f, y + 8f, bg)
            canvas.drawText(strings.pdfShopBoxLabel, colName, y, paint(11f, bold = true, color = WHITE))
            canvas.drawText(strings.reportTotalCredit, colCredit, y, paint(11f, bold = true, color = WHITE))
            canvas.drawText(strings.reportTotalPayment, colPayment, y, paint(11f, bold = true, color = WHITE))
            canvas.drawText(strings.reportCurrentDue, colDue, y, paint(11f, bold = true, color = WHITE))
            y += 22f
        }
        y += 6f
        tableHeader()

        var totalCredit = 0.0
        var totalPayment = 0.0
        var totalDue = 0.0

        rows.forEachIndexed { i, row ->
            if (y + rowH > PAGE_H - MARGIN - 40f) {
                newPage()
                y = drawMiniHeader(canvas, strings.pdfAllShopsReportTitle)
                tableHeader()
            }
            if (i % 2 == 1) {
                val alt = Paint().apply { color = Color.rgb(248, 250, 249) }
                canvas.drawRect(MARGIN - 4f, y - 14f, PAGE_W - MARGIN + 4f, y + 6f, alt)
            }
            canvas.drawText(row.shopName.take(18), colName, y, paint(10.5f))
            canvas.drawText(UnitConverter.rupees(row.periodCredit), colCredit, y, paint(10.5f, color = RED))
            canvas.drawText(UnitConverter.rupees(row.periodPayment), colPayment, y, paint(10.5f, color = GREEN))
            canvas.drawText(
                UnitConverter.rupees(row.currentDue), colDue, y,
                paint(10.5f, bold = true, color = if (row.currentDue > 0) RED else GREEN)
            )
            totalCredit += row.periodCredit
            totalPayment += row.periodPayment
            totalDue += row.currentDue
            y += rowH
        }

        if (y + 150f > PAGE_H - MARGIN) {
            newPage()
            y = drawMiniHeader(canvas, strings.pdfAllShopsReportTitle)
        }
        y = drawSummarySection(canvas, y, totalCredit, totalPayment, totalDue, rows.size, PdfFormat.A4)

        drawFooter(canvas, pageNo, totalPages)
        page?.let { doc.finishPage(it) }

        val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val file = File(dir, "khata_all_shops.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    // ═══════════════════════════ শেয়ার্ড ড্রয়িং হেল্পার ═══════════════════════════

    private fun drawWatermark(canvas: Canvas) {
        val p = paint(64f, bold = true, color = Color.argb(15, 5, 150, 105))
        val text = strings.homeHeadline
        val w = p.measureText(text)
        canvas.save()
        canvas.rotate(-24f, PAGE_W / 2f, PAGE_H / 2f)
        canvas.drawText(text, PAGE_W / 2f - w / 2f, PAGE_H / 2f, p)
        canvas.restore()
    }

    private fun drawMainHeader(canvas: Canvas, titleLine: String, reportNumber: Int, format: PdfFormat): Float {
        val headerH = if (format == PdfFormat.RECEIPT) 60f else 90f
        val bg = Paint().apply {
            shader = android.graphics.LinearGradient(
                0f, 0f, PAGE_W.toFloat(), headerH, GREEN_DARK, GREEN, android.graphics.Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, PAGE_W.toFloat(), headerH, bg)

        val logoSize = if (format == PdfFormat.RECEIPT) 0 else 44
        var textX = MARGIN
        if (logoSize > 0) {
            logoBitmap(logoSize)?.let { canvas.drawBitmap(it, MARGIN, (headerH - logoSize) / 2f, null) }
            textX = MARGIN + logoSize + 10f
        }
        canvas.drawText(titleLine.take(28), textX, headerH / 2f - 2f, paint(if (format == PdfFormat.RECEIPT) 13f else 16f, bold = true, color = WHITE))
        if (format != PdfFormat.RECEIPT) {
            canvas.drawText(
                "${strings.pdfReportNumberLabel}: #UH-$reportNumber",
                PAGE_W - MARGIN - 130f, 26f, paint(9.5f, color = Color.argb(230, 255, 255, 255))
            )
        }
        return headerH + 24f
    }

    private fun drawMiniHeader(canvas: Canvas, title: String): Float {
        canvas.drawText(title.take(30), MARGIN, MARGIN, paint(11f, bold = true, color = GREEN_DARK))
        val line = Paint().apply { strokeWidth = 1f; color = GRAY_LIGHT }
        canvas.drawLine(MARGIN, MARGIN + 8f, PAGE_W - MARGIN, MARGIN + 8f, line)
        return MARGIN + 26f
    }

    private fun drawShopMetaBoxes(canvas: Canvas, yStart: Float, shop: ShopEntity, fromTime: Long, toTime: Long): Float {
        var y = yStart
        val boxW = (PAGE_W - 2 * MARGIN - 10f) / 2f
        val boxH = 52f
        val bg = Paint().apply { color = GREEN_LIGHT_BG }
        val border = Paint().apply { color = GREEN_LIGHT_BORDER; style = Paint.Style.STROKE; strokeWidth = 1f }

        // বক্স ১: দোকান
        canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 10f, 10f, bg)
        canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 10f, 10f, border)
        canvas.drawText(strings.pdfShopBoxLabel, MARGIN + 10f, y + 16f, paint(8.5f, bold = true, color = GREEN))
        canvas.drawText(shop.name.take(20), MARGIN + 10f, y + 32f, paint(12f, bold = true))
        shop.phone?.let { canvas.drawText(it, MARGIN + 10f, y + 46f, paint(9.5f, color = GRAY)) }

        // বক্স ২: তারিখ
        val x2 = MARGIN + boxW + 10f
        canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 10f, 10f, bg)
        canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 10f, 10f, border)
        canvas.drawText(strings.pdfDateBoxLabel, x2 + 10f, y + 16f, paint(8.5f, bold = true, color = GREEN))
        canvas.drawText(UnitConverter.dateShort(toTime, strings.code), x2 + 10f, y + 32f, paint(12f, bold = true))
        val days = daysBetween(fromTime, toTime)
        canvas.drawText("$days ${strings.pdfDaysOfRecordsSuffix}", x2 + 10f, y + 46f, paint(9.5f, color = GRAY))

        y += boxH + 16f
        return y
    }

    private fun drawWeeklyChart(canvas: Canvas, yStart: Float, txns: List<TransactionWithItems>): Float {
        var y = yStart
        canvas.drawText(strings.pdfWeeklyChartTitle, MARGIN, y, paint(9.5f, bold = true, color = GRAY))
        y += 10f

        val now = System.currentTimeMillis()
        val dayMs = 24L * 60 * 60 * 1000
        // শেষ ৭ দিনের প্রতিটার জন্য নেট ধার/পরিশোধ
        data class DayAgg(var credit: Double = 0.0, var payment: Double = 0.0)
        val days = Array(7) { DayAgg() }
        txns.forEach { tw ->
            val age = (now - tw.txn.date) / dayMs
            if (age in 0..6) {
                val idx = 6 - age.toInt()
                if (tw.txn.type == TransactionEntity.TYPE_CREDIT) days[idx].credit += tw.txn.amount
                else days[idx].payment += tw.txn.amount
            }
        }
        val maxVal = days.maxOf { maxOf(it.credit, it.payment) }.coerceAtLeast(1.0)
        val chartH = 42f
        val colW = (PAGE_W - 2 * MARGIN) / 7f

        days.forEachIndexed { i, d ->
            val isDue = d.credit >= d.payment
            val v = if (isDue) d.credit else d.payment
            val barH = (v / maxVal * chartH).toFloat().coerceAtLeast(2f)
            val barPaint = Paint().apply { color = if (isDue) RED_SOFT else Color.rgb(110, 231, 183) }
            val cx = MARGIN + i * colW + colW * 0.25f
            canvas.drawRoundRect(cx, y + chartH - barH, cx + colW * 0.5f, y + chartH, 3f, 3f, barPaint)

            val cal = Calendar.getInstance().apply { timeInMillis = now - (6 - i) * dayMs }
            val dayLabel = shortDayLabel(cal.get(Calendar.DAY_OF_WEEK))
            canvas.drawText(dayLabel, MARGIN + i * colW + colW / 2f - 8f, y + chartH + 12f, paint(7.5f, color = GRAY))
        }
        y += chartH + 24f
        return y
    }

    private fun shortDayLabel(dayOfWeek: Int): String {
        val bnLabels = arrayOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি")
        val enLabels = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        val idx = (dayOfWeek - 1).coerceIn(0, 6)
        return if (strings.code == "en") enLabels[idx] else bnLabels[idx]
    }

    private fun drawTableHeader(canvas: Canvas, yStart: Float): Float {
        var y = yStart
        val bg = Paint().apply { color = GREEN }
        canvas.drawRect(MARGIN - 4f, y - 14f, PAGE_W - MARGIN + 4f, y + 8f, bg)
        val colDate = MARGIN
        val colDesc = MARGIN + (if (PAGE_W < 300) 55f else 80f)
        val colAmt = PAGE_W - MARGIN - 55f
        canvas.drawText(strings.pdfColDate, colDate, y, paint(if (PAGE_W < 300) 9f else 11f, bold = true, color = WHITE))
        canvas.drawText(strings.pdfColDesc, colDesc, y, paint(if (PAGE_W < 300) 9f else 11f, bold = true, color = WHITE))
        canvas.drawText(strings.totalPrefix.trim().removeSuffix(":"), colAmt, y, paint(if (PAGE_W < 300) 9f else 11f, bold = true, color = WHITE))
        y += 22f
        return y
    }

    private fun drawTxnRow(canvas: Canvas, yStart: Float, tw: TransactionWithItems): Float {
        var y = yStart
        val small = PAGE_W < 300
        val t = tw.txn
        val isCredit = t.type == TransactionEntity.TYPE_CREDIT
        val rowBg = Paint().apply { color = if (isCredit) RED_LIGHT_BG else GREEN_LIGHT_BG }
        canvas.drawRect(MARGIN - 4f, y - 14f, PAGE_W - MARGIN + 4f, y + 6f, rowBg)

        val colDate = MARGIN
        val colDesc = MARGIN + (if (small) 55f else 80f)
        val colAmt = PAGE_W - MARGIN - 55f

        canvas.drawText(UnitConverter.dateShort(t.date, strings.code), colDate, y, paint(if (small) 8f else 10f))

        val desc = buildString {
            if (tw.items.isNotEmpty()) {
                append(tw.items.joinToString(", ") { item ->
                    DefaultProducts.translateIfDefault(item.productName, strings.code)
                        .ifBlank { strings.creditFallback }
                })
            }
            t.note?.let { if (it.isNotBlank()) { if (isNotEmpty()) append(" — "); append(it) } }
            if (isEmpty()) append(if (isCredit) strings.creditFallback else strings.paymentFallback)
        }
        canvas.drawText(desc.take(if (small) 12 else 26), colDesc, y, paint(if (small) 8f else 10f))
        canvas.drawText(
            (if (isCredit) "+" else "-") + UnitConverter.rupees(t.amount),
            colAmt, y, paint(if (small) 8f else 10f, bold = true, color = if (isCredit) RED else GREEN)
        )
        y += 20f
        return y
    }

    private fun drawSummarySection(
        canvas: Canvas, yStart: Float,
        totalCredit: Double, totalPayment: Double, currentDue: Double, txnCount: Int,
        format: PdfFormat
    ): Float {
        var y = yStart + 10f
        val small = format == PdfFormat.RECEIPT

        if (!small) {
            // দুটো বক্স পাশাপাশি
            val boxW = (PAGE_W - 2 * MARGIN - 10f) / 2f
            val boxH = 46f
            val bgD = Paint().apply { color = RED_LIGHT_BG }
            val bdD = Paint().apply { color = RED_LIGHT_BORDER; style = Paint.Style.STROKE; strokeWidth = 1.3f }
            canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 12f, 12f, bgD)
            canvas.drawRoundRect(MARGIN, y, MARGIN + boxW, y + boxH, 12f, 12f, bdD)
            canvas.drawText(strings.reportTotalCredit, MARGIN + 12f, y + 18f, paint(9.5f, bold = true, color = RED))
            canvas.drawText(UnitConverter.rupees(totalCredit), MARGIN + 12f, y + 36f, paint(15f, bold = true, color = RED))

            val x2 = MARGIN + boxW + 10f
            val bgP = Paint().apply { color = GREEN_LIGHT_BG }
            val bdP = Paint().apply { color = GREEN_LIGHT_BORDER; style = Paint.Style.STROKE; strokeWidth = 1.3f }
            canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 12f, 12f, bgP)
            canvas.drawRoundRect(x2, y, x2 + boxW, y + boxH, 12f, 12f, bdP)
            canvas.drawText(strings.reportTotalPayment, x2 + 12f, y + 18f, paint(9.5f, bold = true, color = GREEN))
            canvas.drawText(UnitConverter.rupees(totalPayment), x2 + 12f, y + 36f, paint(15f, bold = true, color = GREEN))

            y += boxH + 12f
        }

        // চূড়ান্ত বাকি — গাঢ় সবুজ বক্স
        val finalH = if (small) 44f else 52f
        val finalBg = Paint().apply { color = GREEN_DEEPEST }
        canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + finalH, 14f, 14f, finalBg)
        canvas.drawText(strings.pdfFinalDueLabel, MARGIN + 14f, y + 20f, paint(if (small) 11f else 13f, bold = true, color = WHITE))
        val subtitle = if (strings.code == "en") "$txnCount transactions"
                       else "মোট ${txnCount}টি লেনদেন"
        canvas.drawText(subtitle, MARGIN + 14f, y + 36f, paint(8f, color = Color.argb(200, 255, 255, 255)))
        val dueText = UnitConverter.rupees(currentDue)
        val dueW = paint(if (small) 16f else 20f, bold = true).measureText(dueText)
        canvas.drawText(dueText, PAGE_W - MARGIN - 14f - dueW, y + finalH / 2f + 7f, paint(if (small) 16f else 20f, bold = true, color = RED_SOFT))
        y += finalH + 16f
        return y
    }

    private fun drawSignatureLines(canvas: Canvas, yStart: Float): Float {
        var y = yStart + 26f
        if (y + 30f > PAGE_H - MARGIN - 30f) return y // জায়গা না থাকলে বাদ
        val dash = Paint().apply {
            color = GRAY; strokeWidth = 1.3f
            pathEffect = DashPathEffect(floatArrayOf(5f, 4f), 0f)
        }
        val lineW = 140f
        canvas.drawLine(MARGIN, y, MARGIN + lineW, y, dash)
        canvas.drawText(strings.pdfShopSignatureLabel, MARGIN, y + 14f, paint(9f, color = GRAY))

        canvas.drawLine(PAGE_W - MARGIN - lineW, y, PAGE_W - MARGIN, y, dash)
        canvas.drawText(strings.pdfCustomerSignatureLabel, PAGE_W - MARGIN - lineW, y + 14f, paint(9f, color = GRAY))
        return y + 28f
    }

    private fun drawFooter(canvas: Canvas, pageNo: Int, totalPages: Int) {
        canvas.drawText(strings.pdfFooter, MARGIN, PAGE_H - 18f, paint(8f, color = GRAY))
        val pageText = "${strings.pdfPageLabel} $pageNo/$totalPages"
        val w = paint(8f).measureText(pageText)
        canvas.drawText(pageText, PAGE_W - MARGIN - w, PAGE_H - 18f, paint(8f, color = GRAY))
    }

    private fun estimateA4Pages(rowCount: Int, includeTable: Boolean, includeMetaAndChart: Boolean, includeSummary: Boolean): Int {
        if (!includeTable) return 1
        val firstPageHeader = if (includeMetaAndChart) 90 + 24 + 52 + 16 + 66 else 90 + 24
        val rowsPage1 = ((PAGE_H - MARGIN - firstPageHeader - 40 - 22) / 20).toInt().coerceAtLeast(1)
        val rowsOtherPages = ((PAGE_H - MARGIN - 60 - 40 - 22) / 20).toInt().coerceAtLeast(1)
        if (rowCount <= rowsPage1) return 1
        val remaining = rowCount - rowsPage1
        return 1 + kotlin.math.ceil(remaining.toDouble() / rowsOtherPages).toInt()
    }

    private fun daysBetween(fromTime: Long, toTime: Long): Int =
        (((toTime - fromTime) / (24L * 60 * 60 * 1000)) + 1).toInt().coerceAtLeast(1)
}
