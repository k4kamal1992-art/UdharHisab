package com.udharhisab.ui.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.PeriodTotals
import com.udharhisab.data.local.ShopReportRow
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** ⭐ প্রিসেট সময়কাল — কাস্টম তারিখ-রেঞ্জ এখনো নেই (ভবিষ্যতে যোগ করা যাবে) */
enum class ReportPeriod(val days: Int) {
    D7(7), D15(15), D30(30), M3(90), Y1(365)
}

data class AgingBuckets(
    val d0to7: Double = 0.0,
    val d7to15: Double = 0.0,
    val d15to30: Double = 0.0,
    val d30plus: Double = 0.0
)

class ReportsViewModel(repo: HisabRepository) : ViewModel() {

    val period = MutableStateFlow(ReportPeriod.D7)

    private fun fromTimeFor(p: ReportPeriod): Long =
        System.currentTimeMillis() - p.days * 24L * 60 * 60 * 1000

    @OptIn(ExperimentalCoroutinesApi::class)
    val totals: StateFlow<PeriodTotals> = period
        .flatMapLatest { repo.periodTotals(fromTimeFor(it)) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PeriodTotals(0.0, 0.0, 0))

    @OptIn(ExperimentalCoroutinesApi::class)
    val shopRows: StateFlow<List<ShopReportRow>> = period
        .flatMapLatest { repo.shopReportRows(fromTimeFor(it)) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val recentPayments: StateFlow<List<TransactionWithShop>> = period
        .flatMapLatest { repo.recentPayments(fromTimeFor(it), 10) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** ⭐ বর্তমান মোট বাকি — সব সময়ের (নির্বাচিত পিরিয়ডের নয়) */
    val currentTotalDue: StateFlow<Double> = shopRows
        .map { rows -> rows.sumOf { it.currentDue } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    /** ⭐ পুরনো বাকি — শেষ কবে ওই দোকানে কার্যক্রম হয়েছে তার ভিত্তিতে (lastUsedAt) */
    val aging: StateFlow<AgingBuckets> = shopRows.map { rows ->
        val now = System.currentTimeMillis()
        var b0 = 0.0; var b1 = 0.0; var b2 = 0.0; var b3 = 0.0
        rows.forEach { row ->
            if (row.currentDue > 0) {
                val days = (now - row.lastUsedAt) / (24L * 60 * 60 * 1000)
                when {
                    days <= 7 -> b0 += row.currentDue
                    days <= 15 -> b1 += row.currentDue
                    days <= 30 -> b2 += row.currentDue
                    else -> b3 += row.currentDue
                }
            }
        }
        AgingBuckets(b0, b1, b2, b3)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AgingBuckets())

    fun setPeriod(p: ReportPeriod) { period.value = p }
}
