package com.udharhisab.data.local

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class ShopWithBalance(
    @Embedded val shop: ShopEntity,
    val balance: Double
)

@Dao
interface ShopDao {

    @Insert
    suspend fun insert(shop: ShopEntity): Long

    /** ব্যাকআপ/রিস্টোরের জন্য — আর্কাইভসহ সব দোকান, আইডি-সহ */
    @Insert
    suspend fun insertAll(shops: List<ShopEntity>)

    @Query("SELECT * FROM shops")
    suspend fun getAllRaw(): List<ShopEntity>

    @Query("DELETE FROM shops")
    suspend fun deleteAll()

    @Query("""
        SELECT s.*, COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'CREDIT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
          - COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'PAYMENT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
        AS balance
        FROM shops s
        WHERE s.isArchived = 0
        ORDER BY s.lastUsedAt DESC
    """)
    fun shopsWithBalance(): Flow<List<ShopWithBalance>>

    @Query("""
        SELECT s.*, COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'CREDIT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
          - COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'PAYMENT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
        AS balance
        FROM shops s
        WHERE s.isArchived = 1
        ORDER BY s.lastUsedAt DESC
    """)
    fun archivedShops(): Flow<List<ShopWithBalance>>

    @Query("""
        SELECT s.*, COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'CREDIT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
          - COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'PAYMENT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
        AS balance
        FROM shops s
        WHERE s.isArchived = 0
          AND COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'CREDIT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0)
          - COALESCE(
            (SELECT SUM(CASE WHEN t.type = 'PAYMENT' THEN t.amount ELSE 0 END)
             FROM transactions t WHERE t.shopId = s.id AND t.isDeleted = 0), 0) <= 0
        ORDER BY s.lastUsedAt DESC
    """)
    fun settledShops(): Flow<List<ShopWithBalance>>

    @Query("SELECT * FROM shops WHERE id = :shopId")
    suspend fun shopById(shopId: Long): ShopEntity?

    @Query("SELECT * FROM shops WHERE id = :shopId")
    fun shopByIdFlow(shopId: Long): Flow<ShopEntity?>

    /** এক দোকানের বাকি — নোটিফিকেশন টেক্সটের জন্য */
    @Query("""
        SELECT COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0)
             - COALESCE(SUM(CASE WHEN type = 'PAYMENT' THEN amount ELSE 0 END), 0)
        FROM transactions WHERE shopId = :shopId AND isDeleted = 0
    """)
    suspend fun balanceOf(shopId: Long): Double?

    /** ⭐ রিমাইন্ডার-যোগ্য দোকান: বাকি > 0, আর্কাইভ না, দীর্ঘদিন টাচ হয়নি */
    @Query("""
        SELECT * FROM shops s
        WHERE s.isArchived = 0
          AND s.id IN (
            SELECT shopId FROM transactions WHERE isDeleted = 0
            GROUP BY shopId
            HAVING COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0)
                 - COALESCE(SUM(CASE WHEN type = 'PAYMENT' THEN amount ELSE 0 END), 0) > 0
          )
          AND s.lastUsedAt < :cutoff
    """)
    suspend fun shopsDueForReminder(cutoff: Long): List<ShopEntity>

    @Query("UPDATE shops SET lastUsedAt = :time WHERE id = :shopId")
    suspend fun touch(shopId: Long, time: Long)

    @Query("UPDATE shops SET name = :name, phone = :phone, shopType = :shopType WHERE id = :shopId")
    suspend fun updateShop(shopId: Long, name: String, phone: String?, shopType: String)

    @Query("UPDATE shops SET isArchived = 1 WHERE id = :shopId")
    suspend fun archive(shopId: Long)

    @Query("UPDATE shops SET isArchived = 0 WHERE id = :shopId")
    suspend fun restore(shopId: Long)

    @Query("DELETE FROM shops WHERE id = :shopId")
    suspend fun deletePermanently(shopId: Long)
}
