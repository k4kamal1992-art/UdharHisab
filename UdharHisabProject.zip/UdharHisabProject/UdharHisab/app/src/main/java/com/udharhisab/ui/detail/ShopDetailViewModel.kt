package com.udharhisab.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.TransactionWithItems
import com.udharhisab.data.repository.HisabRepository
import com.udharhisab.data.repository.NewTxnItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopDetailViewModel(
    private val repo: HisabRepository,
    private val shopId: Long
) : ViewModel() {

    val shop: StateFlow<ShopEntity?> = repo.shopByIdFlow(shopId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /** ⭐ প্রতিটা লেনদেনের সাথে তার পণ্য-আইটেম (থাকলে) */
    val txns: StateFlow<List<TransactionWithItems>> = repo.txnsWithItemsOf(shopId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _balance = MutableStateFlow(0.0)
    val balance: StateFlow<Double> = _balance

    /** আনডু-এর জন্য শেষ ডিলিট করা txn id */
    val lastDeletedTxnId = MutableStateFlow<Long?>(null)

    init { refreshBalance() }

    fun refreshBalance() {
        viewModelScope.launch { _balance.value = repo.balanceOnce(shopId) }
    }

    /** ⭐ "ধার নিলাম" — items খালি রেখে directAmount দিলে সরাসরি টাকা, নয়তো পণ্য অনুযায়ী */
    fun addCredit(items: List<NewTxnItem>, directAmount: Double?, note: String?, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.insertCredit(shopId, items, directAmount, note)
            refreshBalance()
            onDone()
        }
    }

    /** ⭐ "জমা দিলাম" */
    fun addPayment(amount: Double, paymentMethod: String?, note: String?, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.insertPayment(shopId, amount, paymentMethod, note)
            refreshBalance()
            onDone()
        }
    }

    fun deleteTxn(txnId: Long) {
        viewModelScope.launch {
            repo.softDeleteTxn(txnId)
            lastDeletedTxnId.value = txnId
            refreshBalance()
        }
    }

    fun undoDelete() {
        val id = lastDeletedTxnId.value ?: return
        viewModelScope.launch {
            repo.undoDeleteTxn(id)
            lastDeletedTxnId.value = null
            refreshBalance()
        }
    }

    fun archiveShop(onDone: () -> Unit) {
        viewModelScope.launch { repo.archiveShop(shopId); onDone() }
    }

    /** ⭐ পার্মানেন্ট ডিলিট — দোকান + সব লেনদেন (ফিরে পাওয়া যাবে না) */
    fun deleteShop(onDone: () -> Unit) {
        viewModelScope.launch { repo.deleteShopPermanently(shopId); onDone() }
    }
}
