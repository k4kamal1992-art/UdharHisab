package com.udharhisab.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.repository.HisabRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopDetailViewModel(
    private val repo: HisabRepository,
    private val shopId: Long
) : ViewModel() {

    val shop: StateFlow<ShopEntity?> = repo.shopByIdFlow(shopId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val txns: StateFlow<List<TransactionEntity>> = repo.txnsOf(shopId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _balance = MutableStateFlow(0.0)
    val balance: StateFlow<Double> = _balance

    /** আনডিউ-এর জন্য শেষ ডিলিট করা txn id */
    val lastDeletedTxnId = MutableStateFlow<Long?>(null)

    init { refreshBalance() }

    fun refreshBalance() {
        viewModelScope.launch { _balance.value = repo.balanceOnce(shopId) }
    }

    fun addTxn(txn: TransactionEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.insertTxn(txn)
            refreshBalance()
            onDone()
        }
    }

    fun deleteTxn(txnId: Long) {
        viewModelScope.launch {
            repo.softDeleteTxn(txnId)
            lastDeletedTxnId.value = txnId
            refreshBalance()
        }
    }

    fun undoDelete() {
        val id = lastDeletedTxnId.value ?: return
        viewModelScope.launch {
            repo.undoDeleteTxn(id)
            lastDeletedTxnId.value = null
            refreshBalance()
        }
    }

    fun archiveShop(onDone: () -> Unit) {
        viewModelScope.launch { repo.archiveShop(shopId); onDone() }
    }
}
