package com.udharhisab.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val pinEnabled by viewModel.pinEnabled.collectAsState()
    val reminderEnabled by viewModel.reminderEnabled.collectAsState()
    var showPinDialog by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সেটিংস") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // নিরাপত্তা সেকশন
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("নিরাপত্তা", style = MaterialTheme.typography.titleMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (pinEnabled) "PIN লক চালু আছে" else "PIN লক বন্ধ আছে")
                        Switch(
                            checked = pinEnabled,
                            onCheckedChange = { checked ->
                                if (checked) showPinDialog = true else showRemoveDialog = true
                            }
                        )
                    }
                    if (pinEnabled) {
                        TextButton(onClick = { showPinDialog = true }) {
                            Text("PIN পরিবর্তন করুন")
                        }
                    }
                }
            }

            // রিমাইন্ডার সেকশন
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("বকেয়া রিমাইন্ডার", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "প্রতিদিন বকেয়ার কথা মনে করিয়ে দেবে",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(
                        checked = reminderEnabled,
                        onCheckedChange = { viewModel.setReminder(it) }
                    )
                }
            }

            // সম্পর্কে
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("সম্পর্কে", style = MaterialTheme.typography.titleMedium)
                    Text("উধার হিসাব — দোকানের বাকির খাতা", style = MaterialTheme.typography.bodySmall)
                    Text("সংস্করণ 1.0", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    // PIN সেট করার ডায়ালগ
    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }

 AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("PIN সেট করুন") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.take(6) },
                        label = { Text("নতুন PIN") },
                        isError = error
                    )
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it.take(6) },
                        label = { Text("PIN আবার লিখুন") },
                        isError = error
                    )
                    if (error) {
                        Text(
                            "PIN মিলছে না (কমপক্ষে ৪ ডিজিট)",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pin.length >= 4 && pin == confirm) {
                            viewModel.savePin(pin)
                            showPinDialog = false
                        } else {
                            error = true
                        }
                    }
                ) { Text("সেভ করুন") }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text("বাতিল") }
            }
        )
    }

    // PIN মুছার ডায়ালগ
    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            title = { Text("PIN লক বন্ধ করবেন?") },
            text = { Text("অ্যাপ খোলার সময় আর PIN চাওয়া হবে না।") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.removePin()
                    showRemoveDialog = false
                }) { Text("হ্যাঁ, বন্ধ করুন") }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveDialog = false }) { Text("না") }
            }
        )
    }
}
