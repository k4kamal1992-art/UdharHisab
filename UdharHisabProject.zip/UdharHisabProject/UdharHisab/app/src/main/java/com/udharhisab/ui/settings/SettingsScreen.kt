package com.udharhisab.ui.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.reminder.ReminderWorker
import com.udharhisab.ui.theme.KhataTheme
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    container: AppContainer,
    onBack: () -> Unit
) {
    val vm: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val c = LocalKhataColors.current
    val context = LocalContext.current

    val s by vm.settings.collectAsState()
    val settings = s ?: return

    // ⭐ Android 13+ নোটিফিকেশন পারমিশন
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        vm.setReminders(granted)
        if (granted) ReminderWorker.schedule(context)
    }

    var showPinDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = c.Background,
       Bar = {
            TopAppBar(
 title = { Text("সেটিংস") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
 .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ═══════════ নিরাপত্তা ═══════════
            SectionHeader("🔒 নিরাপত্তা")

            // পিন লক
            Card(shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = c.Surface)) {
                Row(Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("পিন লক", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (settings.pinHash != null) "চালু ছে" else "পিন সেট করা নেই",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.Muted
                        )
                    }
                    Switch(
                        checked = settings.pinEnabled && settings.pinHash != null,
                        onCheckedChange = { on ->
                            if (on) showPinDialog = true
                            else vm.clearPin()
 }
                    )
                }
            }

            // ═══════════ রিমাইন্ডার ═══════════
            SectionHeader("🔔 রিমাইন্ডার")

            Card(shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = c.Surface)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("বাকি রিমাইন্ডার", style = MaterialTheme.typography.titleMedium)
                            Text("দীর্ঘদিন বাকি থাকা দোকানে নোটিফিকেশন",
                                style = MaterialTheme.typography.bodySmall, color = c.Muted)
                        }
                        Switch(
                            checked = settings.remindersEnabled,
                            onCheckedChange = { on ->
                                if (on) {
                                    if (Build.VERSION.SDK_INT >= 33) {
                                        notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    else {
                                        vm.setReminders(true)
                                        ReminderWorker.schedule(context)
                                    }
                                } else {
                                    vm.setReminders(false)
                                    ReminderWorker.cancel(context)
                                }
                            }
                        )
                    }

                    // কত দিন পর রিমাইন্ডার
                    if (settings.remindersEnabled) {
                        Spacer(Modifier.height(10.dp))
                        Text("কত দিন বাকি থাকলে মনে করাবো?",
                            style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(3, 7, 15, 30).forEach { d ->
                                FilterChip(
                                    selected = settings.reminderDays == d,
                                    onClick = {
                                        vm.setReminderDays(d)
                                        ReminderWorker.schedule(context)   // আপডেট
                                    },
                                    label = { Text("${d} দিন") }
                                )
                            }
                        }
                    }
                }
            }

            ═══════════ চেহারা ═══════════
            SectionHeader("🎨 চেহারা")

            Card(shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = c.Surface)) {
                Column(Modifier.padding(14.dp)) {
                    Text("থিম", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            "system" to "⚙️ সিস্টেম",
                            "light" to "☀️ লাইট",
                            "dark" to "🌙 ডার্ক"
                        ).forEach { (mode, label) ->
                            FilterChip(
                                selected = settings.theme == mode,
                                onClick = { vm.setTheme(mode) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "ধার হিসাব v1.0\nছোট ব্যবসার ধার-খাতা",
                style = MaterialTheme.typography.bodySmall,
                color = c.Muted,
                modifier = Modifier.fillMaxWidth(),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(30.dp))
        }
    }

    // ⭐ পিন সেট ডায়ালগ
    if (showPinDialog) {
        PinSetupDialog(
            onDismiss = { showPinDialog = false },
            onSet = { pin ->
                vm.setPin(pin)
                showPinDialog = false
            }
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = LocalKhataColors.current.Muted,
        modifier = Modifier.padding(top = 8.dp, start = 4.dp)
    )
}

@Composable
private fun PinSetupDialog(
    onDismiss: () -> Unit,
    onSet: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest onDismiss,
        title = { Text("৪-ডিজিটের পিন সেট করুন") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        if (it.length <= 4 && it.all { ch -> ch.isDigit() }) pin = it
                    },
                    label = { Text("পিন") },
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword
                    ),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirm,
                    onValueChange = {
                        if (it.length <= 4 && it.all { ch -> ch.isDigit() }) confirm = it
                    },
                    label = { Text("আবার লিখুন") },
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword
                    ),
                    singleLine = true
                )
                error?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it, color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    when {
                        pin.length !=  -> error = "৪ ডিজিট দিন"
                        pin != confirm -> error = "পিন মিলছে না"
                        else -> onSet(pin)
                    }
                },
                enabled = pin.length == 4 && confirm.length == 4
            ) { Text("সেভ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
