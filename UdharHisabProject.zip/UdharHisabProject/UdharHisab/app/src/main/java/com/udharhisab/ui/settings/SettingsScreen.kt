package com.udharhisab.ui.settings

import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.CardDefaults
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.reminder.ReminderWorker
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    container: AppContainer,
    onBack: () -> Unit
) {
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current

    val settings by viewModel.settings.collectAsState()
    val pinEnabled = settings.pinEnabled
    val reminderEnabled = settings.remindersEnabled
    val language = settings.language
    val theme = settings.theme

    var showPinDialog by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(s.settingsTitle) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // নিরাপত্তা সেকশন
Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = c.Surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(s.security, style = MaterialTheme.typography.titleMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (pinEnabled) s.pinLockOn else s.pinLockOff)
                        Switch(
                            checked = pinEnabled,
                            onCheckedChange = { checked ->
                                if (checked) showPinDialog = true else showRemoveDialog = true
                            }
                        )
                    }
                    if (pinEnabled) {
                        TextButton(onClick = { showPinDialog = true }) {
                            Text(s.changePin)
                        }
                    }
                }
            }

            // রিমাইন্ডার সেকশন
Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = c.Surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(s.reminderTitle, style = MaterialTheme.typography.titleMedium)
                        Text(
                            s.reminderDesc,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(
                        checked = reminderEnabled,
                        onCheckedChange = { checked ->
                            viewModel.setReminder(checked)
                            // ⭐ সাথে সাথে WorkManager-এ শিডিউল/ক্যান্সেল করুন —
                            // আগে শুধু DataStore-এ সেভ হতো, পরের অ্যাপ-স্টার্ট পর্যন্ত
                            // reminder আসলে চালু হতো না
                            if (checked) ReminderWorker.schedule(context)
                            else ReminderWorker.cancel(context)
                        }
                    )
                }
            }

            // ⭐ ভাষা সেকশন
Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = c.Surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(s.languageTitle, style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = language == "bn",
                            onClick = { viewModel.setLanguage("bn") },
                            label = { Text(s.languageBengaliOption) }
                        )
                        FilterChip(
                            selected = language == "en",
                            onClick = { viewModel.setLanguage("en") },
                            label = { Text(s.languageEnglishOption) }
                        )
                    }
                }
            }

            // ⭐ অ্যাপের চেহারা
Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = c.Surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(s.appearanceTitle, style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = theme == "light",
                            onClick = { viewModel.setTheme("light") },
                            label = { Text(s.themeLight) }
                        )
                        FilterChip(
                            selected = theme == "dark",
                            onClick = { viewModel.setTheme("dark") },
                            label = { Text(s.themeDark) }
                        )
                        FilterChip(
                            selected = theme == "system",
                            onClick = { viewModel.setTheme("system") },
                            label = { Text(s.themeSystem) }
                        )
                    }
                }
            }

            // সম্পর্কে
Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = c.Surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(s.about, style = MaterialTheme.typography.titleMedium)
                    Text(s.aboutLine, style = MaterialTheme.typography.bodySmall)
                    Text(s.versionLine, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    // PIN সেট করার ডায়ালগ
    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }

        com.udharhisab.ui.components.FriendlyDialog(
            title = s.setPinTitle,
            icon = androidx.compose.material.icons.Icons.Default.Lock,
            onDismiss = { showPinDialog = false },
            footer = {
                TextButton(onClick = { showPinDialog = false }, modifier = Modifier.weight(1f)) { Text(s.cancel, fontWeight = FontWeight.Bold) }
                Button(
                    onClick = {
                        if (pin.length >= 4 && pin == confirm) {
                            viewModel.savePin(pin)
                            showPinDialog = false
                        } else {
                            error = true
                        }
                    },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
                    modifier = Modifier.weight(1.4f).height(48.dp)
                ) { Text(s.save, fontWeight = FontWeight.ExtraBold) }
            }
        ) {
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.take(6) },
                label = { Text(s.newPinLabel) },
                isError = error,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = confirm,
                onValueChange = { confirm = it.take(6) },
                label = { Text(s.confirmPinLabel) },
                isError = error,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            )
            if (error) {
                Spacer(Modifier.height(6.dp))
                Text(s.pinSetupError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    // PIN মুছার ডায়ালগ
    if (showRemoveDialog) {
        com.udharhisab.ui.components.FriendlyConfirmDialog(
            title = s.removePinTitle,
            message = s.removePinText,
            icon = androidx.compose.material.icons.Icons.Default.LockOpen,
            danger = true,
            confirmLabel = s.yesTurnOff,
            dismissLabel = s.no,
            onConfirm = {
                viewModel.removePin()
                showRemoveDialog = false
            },
            onDismiss = { showRemoveDialog = false }
        )
    }
}
