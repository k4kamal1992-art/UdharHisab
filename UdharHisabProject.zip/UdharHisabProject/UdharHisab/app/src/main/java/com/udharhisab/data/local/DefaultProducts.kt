package com.udharhisab.data.local

/**
 * ⭐ নতুন দোকান খোলার সময় দোকানের ধরন অনুযায়ী কিছু কমন প্রোডাক্ট আগে থেকে
 * সাজেশন হিসেবে বসিয়ে দেওয়া হয় (দাম ছাড়া — দাম প্রথমবার এন্ট্রি দেওয়ার সময় বসবে,
 * তারপর মনে থেকে যাবে)। এগুলো শুধু শুরুর সাজেশন — ব্যবহারকারী চাইলে অন্য নাম
 * লিখলে সেটাও পরের বার থেকে দোকানের নিজস্ব লিস্টে যোগ হয়ে যাবে।
 */
object DefaultProducts {

    private val bn: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("দুধ চা", "লিকার চা", "বিস্কুট", "টোস্ট", "কেক", "ভুজিয়া", "চিপস", "পান", "সিগারেট"),
        ShopType.HARDWARE_ELECTRIC to listOf("বাল্ব", "ইলেকট্রিক তার", "কল/ট্যাপ", "সুইচ", "স্ক্রু", "নাট-বোল্ট"),
        ShopType.KIRANA to listOf("চাল", "ডাল", "সয়াবিন তেল", "লবণ", "চিনি", "আটা/ময়দা", "মশলা"),
        ShopType.VEGETABLE to listOf("আলু", "পেঁয়াজ", "টমেটো", "বেগুন", "কাঁচা মরিচ", "কলা", "আপেল"),
        ShopType.FISH_MEAT to listOf("রুই মাছ", "ইলিশ মাছ", "মুরগির মাংস", "খাসির মাংস"),
        ShopType.BAKERY_SWEETS to listOf("পাঁউরুটি", "বিস্কুট", "দুধ", "রসগোল্লা", "দই"),
        ShopType.PHARMACY to listOf("প্যারাসিটামল", "ব্যান্ডেজ", "স্যালাইন", "তুলা", "ORS"),
        ShopType.COSMETICS to listOf("সাবান", "শ্যাম্পু", "টুথপেস্ট", "লোশন", "চুলের তেল"),
        ShopType.STATIONERY to listOf("খাতা", "কলম", "পেন্সিল", "রাবার", "বই"),
        ShopType.XEROX_PRINTING to listOf("ফটোকপি", "প্রিন্ট", "লেমিনেশন", "স্ক্যান"),
        ShopType.WOOD to listOf("কাঠ", "প্লাইউড", "আঠা", "পেরেক"),
        ShopType.GARMENTS to listOf("শার্ট", "প্যান্ট", "শাড়ি", "লুঙ্গি")
    )

    private val en: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("Milk tea", "Liquor tea", "Biscuit", "Toast", "Cake", "Bhujia", "Chips", "Paan", "Cigarette"),
        ShopType.HARDWARE_ELECTRIC to listOf("Bulb", "Electric wire", "Tap", "Switch", "Screw", "Nut-bolt"),
        ShopType.KIRANA to listOf("Rice", "Lentils", "Soybean oil", "Salt", "Sugar", "Flour", "Spices"),
        ShopType.VEGETABLE to listOf("Potato", "Onion", "Tomato", "Eggplant", "Green chili", "Banana", "Apple"),
        ShopType.FISH_MEAT to listOf("Rohu fish", "Hilsa fish", "Chicken", "Mutton"),
        ShopType.BAKERY_SWEETS to listOf("Bread", "Biscuit", "Milk", "Rasgulla", "Yogurt"),
        ShopType.PHARMACY to listOf("Paracetamol", "Bandage", "Saline", "Cotton", "ORS"),
        ShopType.COSMETICS to listOf("Soap", "Shampoo", "Toothpaste", "Lotion", "Hair oil"),
        ShopType.STATIONERY to listOf("Notebook", "Pen", "Pencil", "Eraser", "Book"),
        ShopType.XEROX_PRINTING to listOf("Photocopy", "Print", "Lamination", "Scan"),
        ShopType.WOOD to listOf("Wood", "Plywood", "Glue", "Nail"),
        ShopType.GARMENTS to listOf("Shirt", "Pant", "Saree", "Lungi")
    )

    private val hi: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("दूध चाय", "लिकर चाय", "बिस्कुट", "टोस्ट", "केक", "भुजिया", "चिप्स", "पान", "सिगरेट"),
        ShopType.HARDWARE_ELECTRIC to listOf("बल्ब", "इलेक्ट्रिक तार", "नल", "स्विच", "स्क्रू", "नट-बोल्ट"),
        ShopType.KIRANA to listOf("चावल", "दाल", "सोयाबीन तेल", "नमक", "चीनी", "आटा", "मसाले"),
        ShopType.VEGETABLE to listOf("आलू", "प्याज़", "टमाटर", "बैंगन", "हरी मिर्च", "केला", "सेब"),
        ShopType.FISH_MEAT to listOf("रोहू मछली", "हिल्सा मछली", "चिकन", "मटन"),
        ShopType.BAKERY_SWEETS to listOf("ब्रेड", "बिस्कुट", "दूध", "रसगुल्ला", "दही"),
        ShopType.PHARMACY to listOf("पैरासिटामोल", "बैंडेज", "सलाइन", "रुई", "ORS"),
        ShopType.COSMETICS to listOf("साबुन", "शैम्पू", "टूथपेस्ट", "लोशन", "बालों का तेल"),
        ShopType.STATIONERY to listOf("कॉपी", "पेन", "पेंसिल", "रबर", "किताब"),
        ShopType.XEROX_PRINTING to listOf("फ़ोटोकॉपी", "प्रिंट", "लैमिनेशन", "स्कैन"),
        ShopType.WOOD to listOf("लकड़ी", "प्लाईवुड", "गोंद", "कील"),
        ShopType.GARMENTS to listOf("शर्ट", "पैंट", "साड़ी", "लुंगी")
    )

    private val mr: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("दुधाचा चहा", "काळा चहा", "बिस्कीट", "टोस्ट", "केक", "भुजिया", "चिप्स", "पान", "सिगारेट"),
        ShopType.HARDWARE_ELECTRIC to listOf("बल्ब", "इलेक्ट्रिक वायर", "नळ", "स्विच", "स्क्रू", "नट-बोल्ट"),
        ShopType.KIRANA to listOf("तांदूळ", "डाळ", "सोयाबीन तेल", "मीठ", "साखर", "पीठ", "मसाले"),
        ShopType.VEGETABLE to listOf("बटाटा", "कांदा", "टोमॅटो", "वांगी", "हिरवी मिरची", "केळी", "सफरचंद"),
        ShopType.FISH_MEAT to listOf("रोहू मासा", "हिल्सा मासा", "चिकन", "मटण"),
        ShopType.BAKERY_SWEETS to listOf("ब्रेड", "बिस्कीट", "दूध", "रसगुल्ला", "दही"),
        ShopType.PHARMACY to listOf("पॅरासिटामॉल", "पट्टी", "सलाईन", "कापूस", "ORS"),
        ShopType.COSMETICS to listOf("साबण", "शॅम्पू", "टूथपेस्ट", "लोशन", "केसांचे तेल"),
        ShopType.STATIONERY to listOf("वही", "पेन", "पेन्सिल", "रबर", "पुस्तक"),
        ShopType.XEROX_PRINTING to listOf("झेरॉक्स", "प्रिंट", "लॅमिनेशन", "स्कॅन"),
        ShopType.WOOD to listOf("लाकूड", "प्लायवूड", "डिंक", "खिळा"),
        ShopType.GARMENTS to listOf("शर्ट", "पँट", "साडी", "लुंगी")
    )

    private val gu: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("દૂધની ચા", "કાળી ચા", "બિસ્કિટ", "ટોસ્ટ", "કેક", "ભુજિયા", "ચિપ્સ", "પાન", "સિગારેટ"),
        ShopType.HARDWARE_ELECTRIC to listOf("બલ્બ", "ઇલેક્ટ્રિક વાયર", "નળ", "સ્વિચ", "સ્ક્રૂ", "નટ-બોલ્ટ"),
        ShopType.KIRANA to listOf("ચોખા", "દાળ", "સોયાબીન તેલ", "મીઠું", "ખાંડ", "લોટ", "મસાલા"),
        ShopType.VEGETABLE to listOf("બટાકા", "ડુંગળી", "ટામેટા", "રીંગણ", "લીલું મરચું", "કેળાં", "સફરજન"),
        ShopType.FISH_MEAT to listOf("રોહુ માછલી", "હિલ્સા માછલી", "ચિકન", "મટન"),
        ShopType.BAKERY_SWEETS to listOf("બ્રેડ", "બિસ્કિટ", "દૂધ", "રસગુલ્લા", "દહીં"),
        ShopType.PHARMACY to listOf("પેરાસિટામોલ", "પટ્ટી", "સલાઇન", "રૂ", "ORS"),
        ShopType.COSMETICS to listOf("સાબુ", "શેમ્પૂ", "ટૂથપેસ્ટ", "લોશન", "વાળનું તેલ"),
        ShopType.STATIONERY to listOf("નોટબુક", "પેન", "પેન્સિલ", "રબર", "પુસ્તક"),
        ShopType.XEROX_PRINTING to listOf("ઝેરોક્સ", "પ્રિન્ટ", "લેમિનેશન", "સ્કેન"),
        ShopType.WOOD to listOf("લાકડું", "પ્લાયવુડ", "ગુંદર", "ખીલી"),
        ShopType.GARMENTS to listOf("શર્ટ", "પેન્ટ", "સાડી", "લુંગી")
    )

    private val ta: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("பால் தேநீர்", "கட்டஞ்சாயா", "பிஸ்கட்", "டோஸ்ட்", "கேக்", "புஜியா", "சிப்ஸ்", "பான்", "சிகரெட்"),
        ShopType.HARDWARE_ELECTRIC to listOf("மின்விளக்கு", "மின் கம்பி", "குழாய்", "சுவிட்ச்", "திருகு", "நட்-போல்ட்"),
        ShopType.KIRANA to listOf("அரிசி", "பருப்பு", "சோயா எண்ணெய்", "உப்பு", "சர்க்கரை", "மாவு", "மசாலா"),
        ShopType.VEGETABLE to listOf("உருளைக்கிழங்கு", "வெங்காயம்", "தக்காளி", "கத்தரிக்காய்", "பச்சை மிளகாய்", "வாழைப்பழம்", "ஆப்பிள்"),
        ShopType.FISH_MEAT to listOf("ரோகு மீன்", "ஹில்சா மீன்", "கோழி", "ஆட்டிறைச்சி"),
        ShopType.BAKERY_SWEETS to listOf("ரொட்டி", "பிஸ்கட்", "பால்", "ரசகுல்லா", "தயிர்"),
        ShopType.PHARMACY to listOf("பாராசிட்டமால்", "கட்டு", "சலைன்", "பஞ்சு", "ORS"),
        ShopType.COSMETICS to listOf("சோப்பு", "ஷாம்பு", "பற்பசை", "லோஷன்", "தலை எண்ணெய்"),
        ShopType.STATIONERY to listOf("நோட்டுப்புத்தகம்", "பேனா", "பென்சில்", "அழிப்பான்", "புத்தகம்"),
        ShopType.XEROX_PRINTING to listOf("ஜெராக்ஸ்", "அச்சு", "லேமினேஷன்", "ஸ்கேன்"),
        ShopType.WOOD to listOf("மரம்", "ஒட்டுப்பலகை", "பசை", "ஆணி"),
        ShopType.GARMENTS to listOf("சட்டை", "கால்சட்டை", "புடவை", "லுங்கி")
    )

    fun forType(type: ShopType, language: String): List<String> =
        when (language) {
            "en" -> en
            "hi" -> hi
            "mr" -> mr
            "gu" -> gu
            "ta" -> ta
            else -> bn
        }[type] ?: emptyList()

    /** নাম → (ShopType, index) — bn, en ও hi তিন দিক থেকেই খোঁজার জন্য, একবারই বানানো হয় */
    private val nameIndex: Map<String, Pair<ShopType, Int>> by lazy {
        val map = mutableMapOf<String, Pair<ShopType, Int>>()
        bn.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        en.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        hi.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        mr.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        gu.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        ta.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        map
    }

    /**
     * ⭐ কোনো প্রোডাক্টের নাম যদি ডিফল্ট সিড-লিস্টের হয় (যেমন "দুধ চা"/"Milk tea"),
     * বর্তমান অ্যাপ-ভাষায় অনুবাদ করে দেখায় — দোকান তৈরির সময় বা ভাষা পরিবর্তনের
     * আগে যে ভাষাতেই সেভ হয়ে থাকুক না কেন। কাস্টম (ইউজার-টাইপ করা) নাম হলে
     * অপরিবর্তিত থাকে, কারণ সেগুলোর কোনো অনুবাদ জানা নেই।
     */
    fun translateIfDefault(name: String, targetLanguage: String): String {
        val trimmed = name.trim()
        val (type, idx) = nameIndex[trimmed] ?: return name
        val list = when (targetLanguage) {
            "en" -> en[type]
            "hi" -> hi[type]
            "mr" -> mr[type]
            "gu" -> gu[type]
            "ta" -> ta[type]
            else -> bn[type]
        }
        return list?.getOrNull(idx) ?: name
    }
}
