package com.udharhisab.data.local

/**
 * ⭐ নতুন দোকান খোলার সময় দোকানের ধরন অনুযায়ী কিছু কমন প্রোডাক্ট আগে থেকে
 * সাজেশন হিসেবে বসিয়ে দেওয়া হয় (দাম ছাড়া — দাম প্রথমবার এন্ট্রি দেওয়ার সময় বসবে,
 * তারপর মনে থেকে যাবে)। এগুলো শুধু শুরুর সাজেশন — ব্যবহারকারী চাইলে অন্য নাম
 * লিখলে সেটাও পরের বার থেকে দোকানের নিজস্ব লিস্টে যোগ হয়ে যাবে।
 */
object DefaultProducts {

    private val bn: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("দুধ চা", "লিকার চা", "বিস্কুট", "টোস্ট", "কেক", "ভুজিয়া", "চিপস", "পান", "সিগারেট"),
        ShopType.HARDWARE_ELECTRIC to listOf("বাল্ব", "ইলেকট্রিক তার", "কল/ট্যাপ", "সুইচ", "স্ক্রু", "নাট-বোল্ট"),
        ShopType.KIRANA to listOf("চাল", "ডাল", "সয়াবিন তেল", "লবণ", "চিনি", "আটা/ময়দা", "মশলা"),
        ShopType.VEGETABLE to listOf("আলু", "পেঁয়াজ", "টমেটো", "বেগুন", "কাঁচা মরিচ", "কলা", "আপেল"),
        ShopType.FISH_MEAT to listOf("রুই মাছ", "ইলিশ মাছ", "মুরগির মাংস", "খাসির মাংস"),
        ShopType.BAKERY_SWEETS to listOf("পাঁউরুটি", "বিস্কুট", "দুধ", "রসগোল্লা", "দই"),
        ShopType.PHARMACY to listOf("প্যারাসিটামল", "ব্যান্ডেজ", "স্যালাইন", "তুলা", "ORS"),
        ShopType.COSMETICS to listOf("সাবান", "শ্যাম্পু", "টুথপেস্ট", "লোশন", "চুলের তেল"),
        ShopType.STATIONERY to listOf("খাতা", "কলম", "পেন্সিল", "রাবার", "বই"),
        ShopType.XEROX_PRINTING to listOf("ফটোকপি", "প্রিন্ট", "লেমিনেশন", "স্ক্যান"),
        ShopType.WOOD to listOf("কাঠ", "প্লাইউড", "আঠা", "পেরেক"),
        ShopType.GARMENTS to listOf("শার্ট", "প্যান্ট", "শাড়ি", "লুঙ্গি")
    )

    private val en: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("Milk tea", "Liquor tea", "Biscuit", "Toast", "Cake", "Bhujia", "Chips", "Paan", "Cigarette"),
        ShopType.HARDWARE_ELECTRIC to listOf("Bulb", "Electric wire", "Tap", "Switch", "Screw", "Nut-bolt"),
        ShopType.KIRANA to listOf("Rice", "Lentils", "Soybean oil", "Salt", "Sugar", "Flour", "Spices"),
        ShopType.VEGETABLE to listOf("Potato", "Onion", "Tomato", "Eggplant", "Green chili", "Banana", "Apple"),
        ShopType.FISH_MEAT to listOf("Rohu fish", "Hilsa fish", "Chicken", "Mutton"),
        ShopType.BAKERY_SWEETS to listOf("Bread", "Biscuit", "Milk", "Rasgulla", "Yogurt"),
        ShopType.PHARMACY to listOf("Paracetamol", "Bandage", "Saline", "Cotton", "ORS"),
        ShopType.COSMETICS to listOf("Soap", "Shampoo", "Toothpaste", "Lotion", "Hair oil"),
        ShopType.STATIONERY to listOf("Notebook", "Pen", "Pencil", "Eraser", "Book"),
        ShopType.XEROX_PRINTING to listOf("Photocopy", "Print", "Lamination", "Scan"),
        ShopType.WOOD to listOf("Wood", "Plywood", "Glue", "Nail"),
        ShopType.GARMENTS to listOf("Shirt", "Pant", "Saree", "Lungi")
    )

    fun forType(type: ShopType, language: String): List<String> =
        (if (language == "en") en else bn)[type] ?: emptyList()
}
