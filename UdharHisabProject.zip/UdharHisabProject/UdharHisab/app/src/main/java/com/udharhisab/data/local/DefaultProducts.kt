package com.udharhisab.data.local

/**
 * ⭐ নতুন দোকান খোলার সময় দোকানের ধরন অনুযায়ী কিছু কমন প্রোডাক্ট আগে থেকে
 * সাজেশন হিসেবে বসিয়ে দেওয়া হয় (দাম ছাড়া — দাম প্রথমবার এন্ট্রি দেওয়ার সময় বসবে,
 * তারপর মনে থেকে যাবে)। এগুলো শুধু শুরুর সাজেশন — ব্যবহারকারী চাইলে অন্য নাম
 * লিখলে সেটাও পরের বার থেকে দোকানের নিজস্ব লিস্টে যোগ হয়ে যাবে।
 */
object DefaultProducts {

    private val bn: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("দুধ চা", "লিকার চা", "বিস্কুট", "টোস্ট", "কেক", "ভুজিয়া", "চিপস", "পান", "সিগারেট"),
        ShopType.HARDWARE_ELECTRIC to listOf("বাল্ব", "ইলেকট্রিক তার", "কল/ট্যাপ", "সুইচ", "স্ক্রু", "নাট-বোল্ট"),
        ShopType.KIRANA to listOf("চাল", "ডাল", "সয়াবিন তেল", "লবণ", "চিনি", "আটা/ময়দা", "মশলা"),
        ShopType.VEGETABLE to listOf("আলু", "পেঁয়াজ", "টমেটো", "বেগুন", "কাঁচা মরিচ", "কলা", "আপেল"),
        ShopType.FISH_MEAT to listOf("রুই মাছ", "ইলিশ মাছ", "মুরগির মাংস", "খাসির মাংস"),
        ShopType.BAKERY_SWEETS to listOf("পাঁউরুটি", "বিস্কুট", "দুধ", "রসগোল্লা", "দই"),
        ShopType.PHARMACY to listOf("প্যারাসিটামল", "ব্যান্ডেজ", "স্যালাইন", "তুলা", "ORS"),
        ShopType.COSMETICS to listOf("সাবান", "শ্যাম্পু", "টুথপেস্ট", "লোশন", "চুলের তেল"),
        ShopType.STATIONERY to listOf("খাতা", "কলম", "পেন্সিল", "রাবার", "বই"),
        ShopType.XEROX_PRINTING to listOf("ফটোকপি", "প্রিন্ট", "লেমিনেশন", "স্ক্যান"),
        ShopType.WOOD to listOf("কাঠ", "প্লাইউড", "আঠা", "পেরেক"),
        ShopType.GARMENTS to listOf("শার্ট", "প্যান্ট", "শাড়ি", "লুঙ্গি")
    )

    private val en: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("Milk tea", "Liquor tea", "Biscuit", "Toast", "Cake", "Bhujia", "Chips", "Paan", "Cigarette"),
        ShopType.HARDWARE_ELECTRIC to listOf("Bulb", "Electric wire", "Tap", "Switch", "Screw", "Nut-bolt"),
        ShopType.KIRANA to listOf("Rice", "Lentils", "Soybean oil", "Salt", "Sugar", "Flour", "Spices"),
        ShopType.VEGETABLE to listOf("Potato", "Onion", "Tomato", "Eggplant", "Green chili", "Banana", "Apple"),
        ShopType.FISH_MEAT to listOf("Rohu fish", "Hilsa fish", "Chicken", "Mutton"),
        ShopType.BAKERY_SWEETS to listOf("Bread", "Biscuit", "Milk", "Rasgulla", "Yogurt"),
        ShopType.PHARMACY to listOf("Paracetamol", "Bandage", "Saline", "Cotton", "ORS"),
        ShopType.COSMETICS to listOf("Soap", "Shampoo", "Toothpaste", "Lotion", "Hair oil"),
        ShopType.STATIONERY to listOf("Notebook", "Pen", "Pencil", "Eraser", "Book"),
        ShopType.XEROX_PRINTING to listOf("Photocopy", "Print", "Lamination", "Scan"),
        ShopType.WOOD to listOf("Wood", "Plywood", "Glue", "Nail"),
        ShopType.GARMENTS to listOf("Shirt", "Pant", "Saree", "Lungi")
    )

    private val hi: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("दूध वाली चाय", "कड़क चाय", "बिस्कुट", "टोस्ट", "केक", "भुजिया", "चिप्स", "पान", "सिगरेट"),
        ShopType.HARDWARE_ELECTRIC to listOf("बल्ब", "बिजली का तार", "नल/टैप", "स्विच", "स्क्रू", "नट-बोल्ट"),
        ShopType.KIRANA to listOf("चावल", "दाल", "सोयाबीन तेल", "नमक", "चीनी", "आटा/मैदा", "मसाले"),
        ShopType.VEGETABLE to listOf("आलू", "प्याज़", "टमाटर", "बैंगन", "हरी मिर्च", "केला", "सेब"),
        ShopType.FISH_MEAT to listOf("रोहू मछली", "हिलसा मछली", "चिकन", "मटन"),
        ShopType.BAKERY_SWEETS to listOf("ब्रेड", "बिस्कुट", "दूध", "रसगुल्ला", "दही"),
        ShopType.PHARMACY to listOf("पैरासिटामोल", "पट्टी", "सलाइन", "रूई", "ORS"),
        ShopType.COSMETICS to listOf("साबुन", "शैम्पू", "टूथपेस्ट", "लोशन", "बालों का तेल"),
        ShopType.STATIONERY to listOf("कॉपी", "कलम", "पेंसिल", "रबर", "किताब"),
        ShopType.XEROX_PRINTING to listOf("फ़ोटोकॉपी", "प्रिंट", "लैमिनेशन", "स्कैन"),
        ShopType.WOOD to listOf("लकड़ी", "प्लाईवुड", "गोंद", "कील"),
        ShopType.GARMENTS to listOf("शर्ट", "पैंट", "साड़ी", "लुंगी")
    )

    private fun listsFor(language: String) = when (language) {
        "en" -> en
        "hi" -> hi
        else -> bn
    }

    fun forType(type: ShopType, language: String): List<String> =
        listsFor(language)[type] ?: emptyList()

    /** নাম → (ShopType, index) — bn ও en দুটো দিক থেকেই খোঁজার জন্য, একবারই বানানো হয় */
    private val nameIndex: Map<String, Pair<ShopType, Int>> by lazy {
        val map = mutableMapOf<String, Pair<ShopType, Int>>()
        bn.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        en.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        hi.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        map
    }

    /**
     * ⭐ কোনো প্রোডাক্টের নাম যদি ডিফল্ট সিড-লিস্টের হয় (যেমন "দুধ চা"/"Milk tea"),
     * বর্তমান অ্যাপ-ভাষায় অনুবাদ করে দেখায় — দোকান তৈরির সময় বা ভাষা পরিবর্তনের
     * আগে যে ভাষাতেই সেভ হয়ে থাকুক না কেন। কাস্টম (ইউজার-টাইপ করা) নাম হলে
     * অপরিবর্তিত থাকে, কারণ সেগুলোর কোনো অনুবাদ জানা নেই।
     */
    fun translateIfDefault(name: String, targetLanguage: String): String {
        val trimmed = name.trim()
        val (type, idx) = nameIndex[trimmed] ?: return name
        val list = listsFor(targetLanguage)[type]
        return list?.getOrNull(idx) ?: name
    }
}
