package com.udharhisab.data.local

/**
 * ⭐ নতুন দোকান খোলার সময় দোকানের ধরন অনুযায়ী কিছু কমন প্রোডাক্ট আগে থেকে
 * সাজেশন হিসেবে বসিয়ে দেওয়া হয় (দাম ছাড়া — দাম প্রথমবার এন্ট্রি দেওয়ার সময় বসবে,
 * তারপর মনে থেকে যাবে)। এগুলো শুধু শুরুর সাজেশন — ব্যবহারকারী চাইলে অন্য নাম
 * লিখলে সেটাও পরের বার থেকে দোকানের নিজস্ব লিস্টে যোগ হয়ে যাবে।
 */
object DefaultProducts {

    private val bn: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("দুধ চা", "লিকার চা", "বিস্কুট", "টোস্ট", "কেক", "ভুজিয়া", "চিপস", "পান", "সিগারেট"),
        ShopType.HARDWARE_ELECTRIC to listOf("বাল্ব", "ইলেকট্রিক তার", "কল/ট্যাপ", "সুইচ", "স্ক্রু", "নাট-বোল্ট"),
        ShopType.KIRANA to listOf("চাল", "ডাল", "সয়াবিন তেল", "লবণ", "চিনি", "আটা/ময়দা", "মশলা"),
        ShopType.VEGETABLE to listOf("আলু", "পেঁয়াজ", "টমেটো", "বেগুন", "কাঁচা মরিচ", "কলা", "আপেল"),
        ShopType.FISH_MEAT to listOf("রুই মাছ", "ইলিশ মাছ", "মুরগির মাংস", "খাসির মাংস"),
        ShopType.BAKERY_SWEETS to listOf("পাঁউরুটি", "বিস্কুট", "দুধ", "রসগোল্লা", "দই"),
        ShopType.PHARMACY to listOf("প্যারাসিটামল", "ব্যান্ডেজ", "স্যালাইন", "তুলা", "ORS"),
        ShopType.COSMETICS to listOf("সাবান", "শ্যাম্পু", "টুথপেস্ট", "লোশন", "চুলের তেল"),
        ShopType.STATIONERY to listOf("খাতা", "কলম", "পেন্সিল", "রাবার", "বই"),
        ShopType.XEROX_PRINTING to listOf("ফটোকপি", "প্রিন্ট", "লেমিনেশন", "স্ক্যান"),
        ShopType.WOOD to listOf("কাঠ", "প্লাইউড", "আঠা", "পেরেক"),
        ShopType.GARMENTS to listOf("শার্ট", "প্যান্ট", "শাড়ি", "লুঙ্গি")
    )

    private val en: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("Milk tea", "Liquor tea", "Biscuit", "Toast", "Cake", "Bhujia", "Chips", "Paan", "Cigarette"),
        ShopType.HARDWARE_ELECTRIC to listOf("Bulb", "Electric wire", "Tap", "Switch", "Screw", "Nut-bolt"),
        ShopType.KIRANA to listOf("Rice", "Lentils", "Soybean oil", "Salt", "Sugar", "Flour", "Spices"),
        ShopType.VEGETABLE to listOf("Potato", "Onion", "Tomato", "Eggplant", "Green chili", "Banana", "Apple"),
        ShopType.FISH_MEAT to listOf("Rohu fish", "Hilsa fish", "Chicken", "Mutton"),
        ShopType.BAKERY_SWEETS to listOf("Bread", "Biscuit", "Milk", "Rasgulla", "Yogurt"),
        ShopType.PHARMACY to listOf("Paracetamol", "Bandage", "Saline", "Cotton", "ORS"),
        ShopType.COSMETICS to listOf("Soap", "Shampoo", "Toothpaste", "Lotion", "Hair oil"),
        ShopType.STATIONERY to listOf("Notebook", "Pen", "Pencil", "Eraser", "Book"),
        ShopType.XEROX_PRINTING to listOf("Photocopy", "Print", "Lamination", "Scan"),
        ShopType.WOOD to listOf("Wood", "Plywood", "Glue", "Nail"),
        ShopType.GARMENTS to listOf("Shirt", "Pant", "Saree", "Lungi")
    )

    private val hi: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("दूध चाय", "लिकर चाय", "बिस्कुट", "टोस्ट", "केक", "भुजिया", "चिप्स", "पान", "सिगरेट"),
        ShopType.HARDWARE_ELECTRIC to listOf("बल्ब", "इलेक्ट्रिक तार", "नल", "स्विच", "स्क्रू", "नट-बोल्ट"),
        ShopType.KIRANA to listOf("चावल", "दाल", "सोयाबीन तेल", "नमक", "चीनी", "आटा", "मसाले"),
        ShopType.VEGETABLE to listOf("आलू", "प्याज़", "टमाटर", "बैंगन", "हरी मिर्च", "केला", "सेब"),
        ShopType.FISH_MEAT to listOf("रोहू मछली", "हिल्सा मछली", "चिकन", "मटन"),
        ShopType.BAKERY_SWEETS to listOf("ब्रेड", "बिस्कुट", "दूध", "रसगुल्ला", "दही"),
        ShopType.PHARMACY to listOf("पैरासिटामोल", "बैंडेज", "सलाइन", "रुई", "ORS"),
        ShopType.COSMETICS to listOf("साबुन", "शैम्पू", "टूथपेस्ट", "लोशन", "बालों का तेल"),
        ShopType.STATIONERY to listOf("कॉपी", "पेन", "पेंसिल", "रबर", "किताब"),
        ShopType.XEROX_PRINTING to listOf("फ़ोटोकॉपी", "प्रिंट", "लैमिनेशन", "स्कैन"),
        ShopType.WOOD to listOf("लकड़ी", "प्लाईवुड", "गोंद", "कील"),
        ShopType.GARMENTS to listOf("शर्ट", "पैंट", "साड़ी", "लुंगी")
    )

    private val mr: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("दुधाचा चहा", "काळा चहा", "बिस्कीट", "टोस्ट", "केक", "भुजिया", "चिप्स", "पान", "सिगारेट"),
        ShopType.HARDWARE_ELECTRIC to listOf("बल्ब", "इलेक्ट्रिक वायर", "नळ", "स्विच", "स्क्रू", "नट-बोल्ट"),
        ShopType.KIRANA to listOf("तांदूळ", "डाळ", "सोयाबीन तेल", "मीठ", "साखर", "पीठ", "मसाले"),
        ShopType.VEGETABLE to listOf("बटाटा", "कांदा", "टोमॅटो", "वांगी", "हिरवी मिरची", "केळी", "सफरचंद"),
        ShopType.FISH_MEAT to listOf("रोहू मासा", "हिल्सा मासा", "चिकन", "मटण"),
        ShopType.BAKERY_SWEETS to listOf("ब्रेड", "बिस्कीट", "दूध", "रसगुल्ला", "दही"),
        ShopType.PHARMACY to listOf("पॅरासिटामॉल", "पट्टी", "सलाईन", "कापूस", "ORS"),
        ShopType.COSMETICS to listOf("साबण", "शॅम्पू", "टूथपेस्ट", "लोशन", "केसांचे तेल"),
        ShopType.STATIONERY to listOf("वही", "पेन", "पेन्सिल", "रबर", "पुस्तक"),
        ShopType.XEROX_PRINTING to listOf("झेरॉक्स", "प्रिंट", "लॅमिनेशन", "स्कॅन"),
        ShopType.WOOD to listOf("लाकूड", "प्लायवूड", "डिंक", "खिळा"),
        ShopType.GARMENTS to listOf("शर्ट", "पँट", "साडी", "लुंगी")
    )

    private val gu: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("દૂધની ચા", "કાળી ચા", "બિસ્કિટ", "ટોસ્ટ", "કેક", "ભુજિયા", "ચિપ્સ", "પાન", "સિગારેટ"),
        ShopType.HARDWARE_ELECTRIC to listOf("બલ્બ", "ઇલેક્ટ્રિક વાયર", "નળ", "સ્વિચ", "સ્ક્રૂ", "નટ-બોલ્ટ"),
        ShopType.KIRANA to listOf("ચોખા", "દાળ", "સોયાબીન તેલ", "મીઠું", "ખાંડ", "લોટ", "મસાલા"),
        ShopType.VEGETABLE to listOf("બટાકા", "ડુંગળી", "ટામેટા", "રીંગણ", "લીલું મરચું", "કેળાં", "સફરજન"),
        ShopType.FISH_MEAT to listOf("રોહુ માછલી", "હિલ્સા માછલી", "ચિકન", "મટન"),
        ShopType.BAKERY_SWEETS to listOf("બ્રેડ", "બિસ્કિટ", "દૂધ", "રસગુલ્લા", "દહીં"),
        ShopType.PHARMACY to listOf("પેરાસિટામોલ", "પટ્ટી", "સલાઇન", "રૂ", "ORS"),
        ShopType.COSMETICS to listOf("સાબુ", "શેમ્પૂ", "ટૂથપેસ્ટ", "લોશન", "વાળનું તેલ"),
        ShopType.STATIONERY to listOf("નોટબુક", "પેન", "પેન્સિલ", "રબર", "પુસ્તક"),
        ShopType.XEROX_PRINTING to listOf("ઝેરોક્સ", "પ્રિન્ટ", "લેમિનેશન", "સ્કેન"),
        ShopType.WOOD to listOf("લાકડું", "પ્લાયવુડ", "ગુંદર", "ખીલી"),
        ShopType.GARMENTS to listOf("શર્ટ", "પેન્ટ", "સાડી", "લુંગી")
    )

    private val ta: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("பால் தேநீர்", "கட்டஞ்சாயா", "பிஸ்கட்", "டோஸ்ட்", "கேக்", "புஜியா", "சிப்ஸ்", "பான்", "சிகரெட்"),
        ShopType.HARDWARE_ELECTRIC to listOf("மின்விளக்கு", "மின் கம்பி", "குழாய்", "சுவிட்ச்", "திருகு", "நட்-போல்ட்"),
        ShopType.KIRANA to listOf("அரிசி", "பருப்பு", "சோயா எண்ணெய்", "உப்பு", "சர்க்கரை", "மாவு", "மசாலா"),
        ShopType.VEGETABLE to listOf("உருளைக்கிழங்கு", "வெங்காயம்", "தக்காளி", "கத்தரிக்காய்", "பச்சை மிளகாய்", "வாழைப்பழம்", "ஆப்பிள்"),
        ShopType.FISH_MEAT to listOf("ரோகு மீன்", "ஹில்சா மீன்", "கோழி", "ஆட்டிறைச்சி"),
        ShopType.BAKERY_SWEETS to listOf("ரொட்டி", "பிஸ்கட்", "பால்", "ரசகுல்லா", "தயிர்"),
        ShopType.PHARMACY to listOf("பாராசிட்டமால்", "கட்டு", "சலைன்", "பஞ்சு", "ORS"),
        ShopType.COSMETICS to listOf("சோப்பு", "ஷாம்பு", "பற்பசை", "லோஷன்", "தலை எண்ணெய்"),
        ShopType.STATIONERY to listOf("நோட்டுப்புத்தகம்", "பேனா", "பென்சில்", "அழிப்பான்", "புத்தகம்"),
        ShopType.XEROX_PRINTING to listOf("ஜெராக்ஸ்", "அச்சு", "லேமினேஷன்", "ஸ்கேன்"),
        ShopType.WOOD to listOf("மரம்", "ஒட்டுப்பலகை", "பசை", "ஆணி"),
        ShopType.GARMENTS to listOf("சட்டை", "கால்சட்டை", "புடவை", "லுங்கி")
    )

    private val tel: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("పాల టీ", "బ్లాక్ టీ", "బిస్కెట్", "టోస్ట్", "కేక్", "భుజియా", "చిప్స్", "పాన్", "సిగరెట్"),
        ShopType.HARDWARE_ELECTRIC to listOf("బల్బ్", "ఎలక్ట్రిక్ వైర్", "కుళాయి", "స్విచ్", "స్క్రూ", "నట్-బోల్ట్"),
        ShopType.KIRANA to listOf("బియ్యం", "పప్పు", "సోయాబీన్ నూనె", "ఉప్పు", "చక్కెర", "పిండి", "మసాలాలు"),
        ShopType.VEGETABLE to listOf("బంగాళాదుంప", "ఉల్లిపాయ", "టమాటా", "వంకాయ", "పచ్చిమిర్చి", "అరటిపండు", "ఆపిల్"),
        ShopType.FISH_MEAT to listOf("రోహు చేప", "హిల్సా చేప", "చికెన్", "మటన్"),
        ShopType.BAKERY_SWEETS to listOf("బ్రెడ్", "బిస్కెట్", "పాలు", "రసగుల్లా", "పెరుగు"),
        ShopType.PHARMACY to listOf("పారాసిటమాల్", "కట్టు", "సెలైన్", "దూది", "ORS"),
        ShopType.COSMETICS to listOf("సబ్బు", "షాంపూ", "టూత్‌పేస్ట్", "లోషన్", "తలనూనె"),
        ShopType.STATIONERY to listOf("నోట్‌బుక్", "పెన్", "పెన్సిల్", "ఎరేజర్", "పుస్తకం"),
        ShopType.XEROX_PRINTING to listOf("జిరాక్స్", "ప్రింట్", "లామినేషన్", "స్కాన్"),
        ShopType.WOOD to listOf("కలప", "ప్లైవుడ్", "జిగురు", "మేకు"),
        ShopType.GARMENTS to listOf("షర్ట్", "ప్యాంట్", "చీర", "లుంగీ")
    )

    private val kan: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("ಹಾಲಿನ ಚಹಾ", "ಕಪ್ಪು ಚಹಾ", "ಬಿಸ್ಕತ್ತು", "ಟೋಸ್ಟ್", "ಕೇಕ್", "ಭುಜಿಯಾ", "ಚಿಪ್ಸ್", "ಪಾನ್", "ಸಿಗರೇಟ್"),
        ShopType.HARDWARE_ELECTRIC to listOf("ಬಲ್ಬ್", "ವಿದ್ಯುತ್ ತಂತಿ", "ನಲ್ಲಿ", "ಸ್ವಿಚ್", "ಸ್ಕ್ರೂ", "ನಟ್-ಬೋಲ್ಟ್"),
        ShopType.KIRANA to listOf("ಅಕ್ಕಿ", "ಬೇಳೆ", "ಸೋಯಾಬೀನ್ ಎಣ್ಣೆ", "ಉಪ್ಪು", "ಸಕ್ಕರೆ", "ಹಿಟ್ಟು", "ಮಸಾಲೆ"),
        ShopType.VEGETABLE to listOf("ಆಲೂಗಡ್ಡೆ", "ಈರುಳ್ಳಿ", "ಟೊಮೆಟೊ", "ಬದನೆಕಾಯಿ", "ಹಸಿ ಮೆಣಸಿನಕಾಯಿ", "ಬಾಳೆಹಣ್ಣು", "ಸೇಬು"),
        ShopType.FISH_MEAT to listOf("ರೋಹು ಮೀನು", "ಹಿಲ್ಸಾ ಮೀನು", "ಚಿಕನ್", "ಮಟನ್"),
        ShopType.BAKERY_SWEETS to listOf("ಬ್ರೆಡ್", "ಬಿಸ್ಕತ್ತು", "ಹಾಲು", "ರಸಗುಲ್ಲಾ", "ಮೊಸರು"),
        ShopType.PHARMACY to listOf("ಪ್ಯಾರಸಿಟಮಾಲ್", "ಬ್ಯಾಂಡೇಜ್", "ಸಲೈನ್", "ಹತ್ತಿ", "ORS"),
        ShopType.COSMETICS to listOf("ಸಾಬೂನು", "ಶಾಂಪೂ", "ಟೂತ್‌ಪೇಸ್ಟ್", "ಲೋಷನ್", "ತಲೆ ಎಣ್ಣೆ"),
        ShopType.STATIONERY to listOf("ನೋಟ್‌ಬುಕ್", "ಪೆನ್", "ಪೆನ್ಸಿಲ್", "ರಬ್ಬರ್", "ಪುಸ್ತಕ"),
        ShopType.XEROX_PRINTING to listOf("ಜೆರಾಕ್ಸ್", "ಪ್ರಿಂಟ್", "ಲ್ಯಾಮಿನೇಷನ್", "ಸ್ಕ್ಯಾನ್"),
        ShopType.WOOD to listOf("ಮರ", "ಪ್ಲೈವುಡ್", "ಅಂಟು", "ಮೊಳೆ"),
        ShopType.GARMENTS to listOf("ಶರ್ಟ್", "ಪ್ಯಾಂಟ್", "ಸೀರೆ", "ಲುಂಗಿ")
    )

    private val mal: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("പാൽ ചായ", "കട്ടൻ ചായ", "ബിസ്കറ്റ്", "ടോസ്റ്റ്", "കേക്ക്", "ഭുജിയ", "ചിപ്സ്", "പാൻ", "സിഗരറ്റ്"),
        ShopType.HARDWARE_ELECTRIC to listOf("ബൾബ്", "ഇലക്ട്രിക് വയർ", "ടാപ്പ്", "സ്വിച്ച്", "സ്ക്രൂ", "നട്ട്-ബോൾട്ട്"),
        ShopType.KIRANA to listOf("അരി", "പരിപ്പ്", "സോയാബീൻ എണ്ണ", "ഉപ്പ്", "പഞ്ചസാര", "മാവ്", "മസാല"),
        ShopType.VEGETABLE to listOf("ഉരുളക്കിഴങ്ങ്", "സവാള", "തക്കാളി", "വഴുതന", "പച്ചമുളക്", "വാഴപ്പഴം", "ആപ്പിൾ"),
        ShopType.FISH_MEAT to listOf("രോഹു മീൻ", "ഹിൽസ മീൻ", "ചിക്കൻ", "മട്ടൺ"),
        ShopType.BAKERY_SWEETS to listOf("ബ്രെഡ്", "ബിസ്കറ്റ്", "പാൽ", "രസഗുള", "തൈര്"),
        ShopType.PHARMACY to listOf("പാരസെറ്റമോൾ", "ബാൻഡേജ്", "സലൈൻ", "പഞ്ഞി", "ORS"),
        ShopType.COSMETICS to listOf("സോപ്പ്", "ഷാംപൂ", "ടൂത്ത്‌പേസ്റ്റ്", "ലോഷൻ", "തലയെണ്ണ"),
        ShopType.STATIONERY to listOf("നോട്ടുബുക്ക്", "പേന", "പെൻസിൽ", "റബ്ബർ", "പുസ്തകം"),
        ShopType.XEROX_PRINTING to listOf("സീറോക്സ്", "പ്രിന്റ്", "ലാമിനേഷൻ", "സ്കാൻ"),
        ShopType.WOOD to listOf("തടി", "പ്ലൈവുഡ്", "പശ", "ആണി"),
        ShopType.GARMENTS to listOf("ഷർട്ട്", "പാന്റ്", "സാരി", "ലുങ്കി")
    )

    private val pun: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("ਦੁੱਧ ਵਾਲੀ ਚਾਹ", "ਕਾਲੀ ਚਾਹ", "ਬਿਸਕੁਟ", "ਟੋਸਟ", "ਕੇਕ", "ਭੁਜੀਆ", "ਚਿਪਸ", "ਪਾਨ", "ਸਿਗਰੇਟ"),
        ShopType.HARDWARE_ELECTRIC to listOf("ਬੱਲਬ", "ਬਿਜਲੀ ਦੀ ਤਾਰ", "ਟੂਟੀ", "ਸਵਿੱਚ", "ਪੇਚ", "ਨਟ-ਬੋਲਟ"),
        ShopType.KIRANA to listOf("ਚੌਲ", "ਦਾਲ", "ਸੋਇਆਬੀਨ ਤੇਲ", "ਲੂਣ", "ਚੀਨੀ", "ਆਟਾ", "ਮਸਾਲੇ"),
        ShopType.VEGETABLE to listOf("ਆਲੂ", "ਪਿਆਜ਼", "ਟਮਾਟਰ", "ਬੈਂਗਣ", "ਹਰੀ ਮਿਰਚ", "ਕੇਲਾ", "ਸੇਬ"),
        ShopType.FISH_MEAT to listOf("ਰੋਹੂ ਮੱਛੀ", "ਹਿਲਸਾ ਮੱਛੀ", "ਚਿਕਨ", "ਮਟਨ"),
        ShopType.BAKERY_SWEETS to listOf("ਬਰੈੱਡ", "ਬਿਸਕੁਟ", "ਦੁੱਧ", "ਰਸਗੁੱਲਾ", "ਦਹੀਂ"),
        ShopType.PHARMACY to listOf("ਪੈਰਾਸੀਟਾਮੋਲ", "ਪੱਟੀ", "ਸੈਲਾਈਨ", "ਰੂੰ", "ORS"),
        ShopType.COSMETICS to listOf("ਸਾਬਣ", "ਸ਼ੈਂਪੂ", "ਟੂਥਪੇਸਟ", "ਲੋਸ਼ਨ", "ਵਾਲਾਂ ਦਾ ਤੇਲ"),
        ShopType.STATIONERY to listOf("ਕਾਪੀ", "ਪੈੱਨ", "ਪੈਨਸਿਲ", "ਰਬੜ", "ਕਿਤਾਬ"),
        ShopType.XEROX_PRINTING to listOf("ਫੋਟੋਕਾਪੀ", "ਪ੍ਰਿੰਟ", "ਲੈਮੀਨੇਸ਼ਨ", "ਸਕੈਨ"),
        ShopType.WOOD to listOf("ਲੱਕੜ", "ਪਲਾਈਵੁੱਡ", "ਗੂੰਦ", "ਕਿੱਲ"),
        ShopType.GARMENTS to listOf("ਕਮੀਜ਼", "ਪੈਂਟ", "ਸਾੜ੍ਹੀ", "ਲੁੰਗੀ")
    )

    private val odi: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("କ୍ଷୀର ଚାହା", "ଲାଲ ଚାହା", "ବିସ୍କୁଟ", "ଟୋଷ୍ଟ", "କେକ୍", "ଭୁଜିଆ", "ଚିପ୍ସ", "ପାନ", "ସିଗାରେଟ୍"),
        ShopType.HARDWARE_ELECTRIC to listOf("ବଲ୍ବ", "ବିଜୁଳି ତାର", "ଟ୍ୟାପ୍", "ସୁଇଚ୍", "ସ୍କ୍ରୁ", "ନଟ୍-ବୋଲ୍ଟ"),
        ShopType.KIRANA to listOf("ଚାଉଳ", "ଡାଲି", "ସୋୟାବିନ୍ ତେଲ", "ଲୁଣ", "ଚିନି", "ଅଟା", "ମସଲା"),
        ShopType.VEGETABLE to listOf("ଆଳୁ", "ପିଆଜ", "ଟମାଟୋ", "ବାଇଗଣ", "କଞ୍ଚା ଲଙ୍କା", "କଦଳୀ", "ସେଓ"),
        ShopType.FISH_MEAT to listOf("ରୋହି ମାଛ", "ଇଲିଶି ମାଛ", "ଚିକେନ୍", "ମଟନ୍"),
        ShopType.BAKERY_SWEETS to listOf("ପାଉଁରୁଟି", "ବିସ୍କୁଟ", "କ୍ଷୀର", "ରସଗୋଲା", "ଦହି"),
        ShopType.PHARMACY to listOf("ପାରାସିଟାମୋଲ୍", "ପଟି", "ସେଲାଇନ୍", "ତୁଳା", "ORS"),
        ShopType.COSMETICS to listOf("ସାବୁନ", "ସ୍ୟାମ୍ପୁ", "ଟୁଥପେଷ୍ଟ", "ଲୋସନ୍", "କେଶ ତେଲ"),
        ShopType.STATIONERY to listOf("ଖାତା", "କଲମ", "ପେନସିଲ", "ରବର", "ବହି"),
        ShopType.XEROX_PRINTING to listOf("ଜେରକ୍ସ", "ପ୍ରିଣ୍ଟ", "ଲାମିନେସନ୍", "ସ୍କାନ୍"),
        ShopType.WOOD to listOf("କାଠ", "ପ୍ଲାଇଉଡ୍", "ଅଠା", "ପେରେକ"),
        ShopType.GARMENTS to listOf("ସାର୍ଟ", "ପ୍ୟାଣ୍ଟ", "ଶାଢ଼ୀ", "ଲୁଙ୍ଗି")
    )

    private val asm: Map<ShopType, List<String>> = mapOf(
        ShopType.TEA to listOf("গাখীৰৰ চাহ", "ৰঙা চাহ", "বিস্কুট", "টোষ্ট", "কেক", "ভুজিয়া", "চিপছ", "পান", "চিগাৰেট"),
        ShopType.HARDWARE_ELECTRIC to listOf("বাল্ব", "বিদ্যুতৰ তাঁৰ", "কল", "চুইচ", "স্ক্ৰু", "নাট-বল্ট"),
        ShopType.KIRANA to listOf("চাউল", "দাইল", "সয়াবিন তেল", "নিমখ", "চেনি", "আটা", "মছলা"),
        ShopType.VEGETABLE to listOf("আলু", "পেঁয়াজ", "বিলাহী", "বাইগন", "কেঁচা জলকীয়া", "কল", "আপেল"),
        ShopType.FISH_MEAT to listOf("ৰৌ মাছ", "ইলিছ মাছ", "কুকুৰাৰ মাংস", "খাচীৰ মাংস"),
        ShopType.BAKERY_SWEETS to listOf("পাউৰুটী", "বিস্কুট", "গাখীৰ", "ৰসগোল্লা", "দৈ"),
        ShopType.PHARMACY to listOf("পেৰাচিটামল", "পট্টি", "ছেলাইন", "কপাহ", "ORS"),
        ShopType.COSMETICS to listOf("চাবোন", "শ্বাম্পু", "টুথপেষ্ট", "লোচন", "চুলিৰ তেল"),
        ShopType.STATIONERY to listOf("খাতা", "কলম", "পেন্সিল", "ৰবাৰ", "কিতাপ"),
        ShopType.XEROX_PRINTING to listOf("জেৰক্স", "প্ৰিণ্ট", "লেমিনেচন", "স্কেন"),
        ShopType.WOOD to listOf("কাঠ", "প্লাইউড", "আঠা", "পেৰেক"),
        ShopType.GARMENTS to listOf("চাৰ্ট", "পেণ্ট", "শাড়ী", "লুঙ্গি")
    )

    fun forType(type: ShopType, language: String): List<String> =
        when (language) {
            "en" -> en
            "hi" -> hi
            "mr" -> mr
            "gu" -> gu
            "ta" -> ta
            "te" -> tel
            "kn" -> kan
            "ml" -> mal
            "pa" -> pun
            "or" -> odi
            "as" -> asm
            else -> bn
        }[type] ?: emptyList()

    /** নাম → (ShopType, index) — bn, en ও hi তিন দিক থেকেই খোঁজার জন্য, একবারই বানানো হয় */
    private val nameIndex: Map<String, Pair<ShopType, Int>> by lazy {
        val map = mutableMapOf<String, Pair<ShopType, Int>>()
        bn.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        en.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        hi.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        mr.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        gu.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        ta.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        tel.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        kan.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        mal.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        pun.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        odi.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        asm.forEach { (type, list) -> list.forEachIndexed { i, name -> map[name] = type to i } }
        map
    }

    /**
     * ⭐ কোনো প্রোডাক্টের নাম যদি ডিফল্ট সিড-লিস্টের হয় (যেমন "দুধ চা"/"Milk tea"),
     * বর্তমান অ্যাপ-ভাষায় অনুবাদ করে দেখায় — দোকান তৈরির সময় বা ভাষা পরিবর্তনের
     * আগে যে ভাষাতেই সেভ হয়ে থাকুক না কেন। কাস্টম (ইউজার-টাইপ করা) নাম হলে
     * অপরিবর্তিত থাকে, কারণ সেগুলোর কোনো অনুবাদ জানা নেই।
     */
    fun translateIfDefault(name: String, targetLanguage: String): String {
        val trimmed = name.trim()
        val (type, idx) = nameIndex[trimmed] ?: return name
        val list = when (targetLanguage) {
            "en" -> en[type]
            "hi" -> hi[type]
            "mr" -> mr[type]
            "gu" -> gu[type]
            "ta" -> ta[type]
            "te" -> tel[type]
            "kn" -> kan[type]
            "ml" -> mal[type]
            "pa" -> pun[type]
            "or" -> odi[type]
            "as" -> asm[type]
            else -> bn[type]
        }
        return list?.getOrNull(idx) ?: name
    }
}
