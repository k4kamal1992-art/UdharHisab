package com.udharhisab.ui.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.NoteEntity
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.components.EmptyStateIcon
import com.udharhisab.ui.components.SkeletonList
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val noteColors = listOf(
    Color(0xFF7C6FF0), Color(0xFF3B9AE1), Color(0xFFE0902E), Color(0xFF14B8A6), Color(0xFFE05252)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(container: AppContainer, onBack: () -> Unit, onOpenNote: (Long) -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val vm: NotesViewModel = viewModel { NotesViewModel(container.repo) }

    val notes by vm.notes.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val search by vm.search.collectAsState()

    var pendingDelete by remember { mutableStateOf<NoteEntity?>(null) }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.notesTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onOpenNote(0L) },
                containerColor = c.Primary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(s.addNoteButton) }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = vm::setSearch,
                placeholder = { Text(s.notesSearchPlaceholder) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            when {
                isLoading -> SkeletonList()
                notes.isEmpty() -> Column(
                    Modifier.fillMaxWidth().padding(top = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    EmptyStateIcon(Icons.Default.Description)
                    Spacer(Modifier.height(12.dp))
                    Text(s.noNotesYetTitle, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        s.noNotesYetSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.Muted
                    )
                }
                else -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(notes, key = { it.id }) { note ->
                        NoteRow(
                            note = note,
                            onClick = { onOpenNote(note.id) },
                            onDelete = { pendingDelete = note }
                        )
                    }
                }
            }
        }
    }

    pendingDelete?.let { note ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(s.deleteNoteConfirmTitle) },
            text = { Text(s.deleteNoteConfirmMessage) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteNote(note)
                    pendingDelete = null
                }) { Text(s.deleteTxnAction, color = c.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text(s.cancel) }
            }
        )
    }
}

@Composable
private fun NoteRow(note: NoteEntity, onClick: () -> Unit, onDelete: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val color = noteColors[(note.id % noteColors.size).toInt().let { if (it < 0) it + noteColors.size else it }]

    Card(
        colors = CardDefaults.cardColors(containerColor = c.Surface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Description, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    note.title.ifBlank { s.untitledNote },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.US).format(Date(note.updatedAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = c.Muted
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = c.Muted)
            }
        }
    }
}
