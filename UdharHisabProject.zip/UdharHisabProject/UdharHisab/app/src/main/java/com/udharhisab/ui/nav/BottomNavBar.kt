package com.udharhisab.ui.nav

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.material.icons.automirrored.outlined.List
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.ads.BannerAdView
import com.udharhisab.navigation.Route
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** চারটা ট্যাব — Home | History | Reports | More */
private data class NavItem(val route: Route, val icon: ImageVector, val iconOutlined: ImageVector, val label: String)

@Composable
fun BottomNavBar(currentRoute: String?, onNavigate: (Route) -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val items = listOf(
        NavItem(Route.Home, Icons.Filled.Home, Icons.Outlined.Home, s.navHome),
        NavItem(Route.History, Icons.Filled.History, Icons.Outlined.History, s.navHistory),
        NavItem(Route.Reports, Icons.Filled.Assessment, Icons.Outlined.Assessment, s.navReports),
        NavItem(Route.More, Icons.AutoMirrored.Filled.List, Icons.AutoMirrored.Outlined.List, s.navMore)
    )

    Column {
        // ── ব্যানার বিজ্ঞাপন — নেভ বারের ঠিক ওপরে, স্থির ও ছোট ──
        BannerAdView()

        // ⭐ ওপরের কোণ গোল, নরম ছায়ায় ভাসমান বার (আগে সমতল রেখা ছিল)
        androidx.compose.material3.Surface(
            color = c.Surface,
            shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            shadowElevation = 16.dp
        ) {
            NavigationBar(
                containerColor = c.Surface,
                tonalElevation = 0.dp
            ) {
                items.forEach { item ->
                    val selected = currentRoute == item.route.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = { onNavigate(item.route) },
                        icon = {
                            // ⭐ বাছা ট্যাবের আইকন ভরাট ও একটু বড় হয়ে লাফিয়ে ওঠে, না-বাছাগুলো রেখাচিত্র
                            val scale by animateFloatAsState(
                                targetValue = if (selected) 1.18f else 1f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                label = "navIcon"
                            )
                            Icon(
                                if (selected) item.icon else item.iconOutlined,
                                item.label,
                                modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
                            )
                        },
                        label = {
                            Text(item.label, fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold)
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = c.Primary,
                            unselectedIconColor = c.Muted,
                            unselectedTextColor = c.Muted,
                            indicatorColor = c.Primary
                        )
                    )
                }
            }
        }
    }
}
