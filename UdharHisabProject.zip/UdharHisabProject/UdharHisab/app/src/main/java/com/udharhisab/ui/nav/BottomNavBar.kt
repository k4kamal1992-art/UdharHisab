package com.udharhisab.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.udharhisab.navigation.Route
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** চারটা ট্যাব — Home | History | Reports | More */
private data class NavItem(val route: Route, val icon: ImageVector, val label: String)

@Composable
fun BottomNavBar(currentRoute: String?, onNavigate: (Route) -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val items = listOf(
        NavItem(Route.Home, Icons.Filled.Home, s.navHome),
        NavItem(Route.History, Icons.Filled.History, s.navHistory),
        NavItem(Route.Reports, Icons.Filled.Assessment, s.navReports),
        NavItem(Route.More, Icons.AutoMirrored.Filled.List, s.navMore)
    )

    Box {
        // ── হালকা top hairline — ছায়ার বদলে flat-modern ডেপথ ──
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(c.Divider)
        )
        NavigationBar(
            containerColor = c.Surface,
            tonalElevation = 0.dp
        ) {
            items.forEach { item ->
                val selected = currentRoute == item.route.route
                NavigationBarItem(
                    selected = selected,
                    onClick = { onNavigate(item.route) },
                    icon = { Icon(item.icon, item.label) },
                    label = {
                        Text(item.label, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = c.Primary,
                        unselectedIconColor = c.Muted,
                        unselectedTextColor = c.Muted,
                        indicatorColor = c.Primary
                    )
                )
            }
        }
    }
}
