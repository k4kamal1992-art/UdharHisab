package com.udharhisab.ui.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import com.udharhisab.navigation.Route
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** ⭐ চারটা ট্যাব — Home | History | Reports | More */
private data class NavItem(val route: Route, val icon: ImageVector, val label: String)

@Composable
fun BottomNavBar(currentRoute: String?, onNavigate: (Route) -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val items = listOf(
        NavItem(Route.Home, Icons.Filled.Home, s.navHome),
        NavItem(Route.History, Icons.Filled.History, s.navHistory),
        NavItem(Route.Reports, Icons.Filled.Assessment, s.navReports),
        NavItem(Route.More, Icons.AutoMirrored.Filled.List, s.navMore)
    )

    NavigationBar(containerColor = c.Surface) {
        items.forEach { item ->
            val selected = currentRoute == item.route.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = { Icon(item.icon, item.label) },
                label = {
                    Text(item.label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = c.Primary,
                    selectedTextColor = c.Primary,
                    unselectedIconColor = c.Muted,
                    unselectedTextColor = c.Muted,
                    indicatorColor = c.ChipBg
                )
            )
        }
    }
}
