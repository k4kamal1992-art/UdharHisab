package com.udharhisab.ui.settings

import android.app.Application
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.security.MessageDigest

private val android.content.Context.settingsStore by preferencesDataStore(name = "settings")

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
    private val PIN_HASH = stringPreferencesKey("pin_hash")
    private val REMINDER = booleanPreferencesKey("reminder_enabled")

    val pinEnabled = getApplication<Application>().settingsStore.data
        .map { it[PIN_ENABLED] ?: false }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val reminderEnabled = getApplication<Application>().settingsStore.data
        .map { it[REMINDER] ?: false }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private fun hash(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return Base64.encodeToString(digest, Base64.NO_WRAP)
    }

    fun savePin(pin: String) {
        viewModelScope.launch {
            getApplication<Application>().settingsStore.edit { prefs ->
                prefs[PIN_HASH] = hash(pin)
                prefs[PIN_ENABLED] = true
            }
        }
    }

    fun removePin() {
        viewModelScope.launch {
            getApplication<Application>().settingsStore.edit { prefs ->
                prefs[PIN_ENABLED] = false
                prefs.remove(PIN_HASH)
            }
        }
    }

    fun setReminder(enabled: Boolean) {
        viewModelScope.launch {
            getApplication<Application>().settingsStore.edit { prefs ->
                prefs[REMINDER] = enabled
            }
        }
    }
}
