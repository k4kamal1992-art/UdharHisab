package com.udharhisab.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.settings.Settings
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.domain.PinHasher
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val store: SettingsDataStore) : ViewModel() {

    val settings: StateFlow<Settings?> = store.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun setPin(pin: String) {
        viewModelScope.launch { store.setPin(PinHasher.hash(pin)) }
    }

    fun clearPin() {
        viewModelScope.launch { store.clearPin() }
    }

    fun setPinEnabled(enabled: Boolean) {
        viewModelScope.launch { store.setPinEnabled(enabled) }
    }

    fun setReminders(enabled: Boolean) {
        viewModelScope.launch { store.setReminders(enabled) }
    }

    fun setReminderDays(days: Int) {
        viewModelScope.launch { store.setReminderDays(days) }
    }

    fun setTheme(mode: String) {
        viewModelScope.launch { store.setTheme(mode)    }
    }
