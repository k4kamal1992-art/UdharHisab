package com.udharhisab.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.udharhisab.data.settings.Settings
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.domain.PinHasher
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ⭐ ফিক্স: আগে এই ViewModel তার নিজস্ব আলাদা DataStore("settings") ব্যবহার করত,
 * অথচ MainActivity/LockScreen/ReminderWorker সবাই AppContainer.store (DataStore
 * নাম "khata_settings") পড়ে — ফলে PIN সেট বা রিমাইন্ডার অন করলেও তা আসলে
 * কখনো কার্যকর হতো না, কারণ দুটো সম্পূর্ণ আলাদা ফাইলে সেভ হতো।
 * এখন সবাই একই store ব্যবহার করছে।
 *
 * এছাড়াও PIN হ্যাশ এখন PinHasher (সল্টসহ SHA-256, hex) দিয়ে হচ্ছে —
 * আগে এখানে আলাদা un-salted Base64 হ্যাশ হতো যেটা LockScreen-এর PinHasher.verify()-এর
 * সাথে কখনোই মিলত না।
 */
class SettingsViewModel(private val store: SettingsDataStore) : ViewModel() {

    val settings: StateFlow<Settings> = store.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    fun savePin(pin: String) {
        viewModelScope.launch { store.setPin(PinHasher.hash(pin)) }
    }

    fun removePin() {
        viewModelScope.launch { store.clearPin() }
    }

    fun setReminder(enabled: Boolean) {
        viewModelScope.launch {
            store.setReminders(enabled)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch { store.setLanguage(lang) }
    }

    fun setTheme(mode: String) {
        viewModelScope.launch { store.setTheme(mode) }
    }

    fun setUserMode(mode: String) {
        viewModelScope.launch { store.setUserMode(mode) }
    }

    fun setWeeklySummary(enabled: Boolean) {
        viewModelScope.launch { store.setWeeklySummary(enabled) }
    }

    fun setAppNews(enabled: Boolean) {
        viewModelScope.launch { store.setAppNews(enabled) }
    }

    fun setFingerprint(enabled: Boolean) {
        viewModelScope.launch { store.setFingerprint(enabled) }
    }

    fun setLockImmediately(enabled: Boolean) {
        viewModelScope.launch { store.setLockImmediately(enabled) }
    }

    // ── ⭐ দোকানদার প্রোফাইল ──
    fun saveBusinessProfile(name: String, address: String, phone: String, countryCode: String) {
        viewModelScope.launch { store.saveBusinessProfile(name, address, phone, countryCode) }
    }

    fun setBusinessLogo(path: String?) {
        viewModelScope.launch { store.setBusinessLogo(path) }
    }

    fun setCustomerReminderPrompt(enabled: Boolean) {
        viewModelScope.launch { store.setCustomerReminderPrompt(enabled) }
    }
}
