package com.udharhisab.domain

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.udharhisab.ui.strings.AppStrings

enum class ReminderKind { DUE, CREDIT_ADDED, PAYMENT_RECEIVED }

/**
 * ⭐ গ্রাহককে WhatsApp / SMS-এ বাকির বার্তা পাঠানো।
 * অ্যান্ড্রয়েড নিজে থেকে চুপচাপ SMS/WhatsApp পাঠাতে দেয় না (এবং Play Store-ও SMS-পারমিশনে কড়া),
 * তাই বার্তা তৈরি করে সংশ্লিষ্ট অ্যাপ খুলে দেওয়া হয় — দোকানদার শুধু "Send" চাপেন।
 */
object PaymentReminder {

    fun buildMessage(
        strings: AppStrings,
        businessName: String,
        customerName: String,
        due: Double,
        kind: ReminderKind
    ): String {
        val shop = businessName.trim().ifBlank { strings.reminderShopFallback }
        val amount = UnitConverter.rupees(if (due > 0) due else 0.0)
        val template = when (kind) {
            ReminderKind.DUE -> strings.reminderMsgDue
            ReminderKind.CREDIT_ADDED -> strings.reminderMsgCredit
            ReminderKind.PAYMENT_RECEIVED ->
                if (due > 0) strings.reminderMsgPayment else strings.reminderMsgSettled
        }
        return String.format(template, customerName, shop, amount)
    }

    /** "98765 43210" / "09876543210" / "+91 98765…" → শুধু ডিজিট, দেশের কোডসহ (wa.me ফরম্যাট) */
    fun normalizePhone(raw: String?, countryCode: String): String? {
        val r = raw?.trim() ?: return null
        val digits = r.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        val cc = countryCode.filter { it.isDigit() }.ifEmpty { "91" }
        val trimmed = digits.trimStart('0')
        if (trimmed.isEmpty()) return null
        return when {
            r.startsWith("+") -> trimmed
            trimmed.length > 10 && trimmed.startsWith(cc) -> trimmed
            trimmed.length <= 10 -> cc + trimmed
            else -> trimmed
        }
    }

    fun sendWhatsApp(context: Context, rawPhone: String?, countryCode: String, message: String): Boolean {
        val number = normalizePhone(rawPhone, countryCode) ?: return false
        val uri = Uri.parse("https://wa.me/$number?text=${Uri.encode(message)}")
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri)); true
        } catch (_: ActivityNotFoundException) { false }
    }

    fun sendSms(context: Context, rawPhone: String?, countryCode: String, message: String): Boolean {
        val number = normalizePhone(rawPhone, countryCode)
        val uri = Uri.parse("smsto:" + (number?.let { "+$it" } ?: ""))
        val intent = Intent(Intent.ACTION_SENDTO, uri).putExtra("sms_body", message)
        return try {
            context.startActivity(intent); true
        } catch (_: ActivityNotFoundException) { false }
    }
}
