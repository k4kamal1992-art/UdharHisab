package com.udharhisab.ui.more

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.settings.SettingsViewModel
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/** থিম (লাইট/ডার্ক/সিস্টেম) — আগে Bottom Sheet ছিল, এখন পূর্ণ পেজ */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(container: AppContainer, onBack: () -> Unit) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val settings by viewModel.settings.collectAsState()

    var selected by remember(settings.theme) { mutableStateOf(settings.theme) }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.moreAppearance) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.Surface,
                    scrolledContainerColor = c.Surface,
                    titleContentColor = c.TextPrimary,
                    navigationIconContentColor = c.TextPrimary,
                    actionIconContentColor = c.TextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(s.themeSheetSubtitle, color = c.Muted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))

            ChoiceRow(Icons.Default.LightMode, s.themeLight, selected == "light") { selected = "light" }
            Spacer(Modifier.height(10.dp))
            ChoiceRow(Icons.Default.DarkMode, s.themeDark, selected == "dark") { selected = "dark" }
            Spacer(Modifier.height(10.dp))
            ChoiceRow(Icons.Default.BrightnessAuto, s.themeSystem, selected == "system") { selected = "system" }

            Spacer(Modifier.weight(1f))
            Button(
                onClick = { viewModel.setTheme(selected); onBack() },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(s.save)
            }
        }
    }
}
