package com.udharhisab.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * ⚠️ এই তিনটা ID Google-এর অফিসিয়াল TEST ID — এখনই কোড চলবে, টেস্ট বিজ্ঞাপন দেখাবে।
 * Play Store-এ আপলোডের আগে admob.google.com থেকে নিজের আসল Ad Unit ID দিয়ে বদলে দিন:
 *   Apps → আপনার অ্যাপ → Ad units → Banner/Interstitial-এর ID কপি করুন
 * আসল ID না বদলালে রিয়েল বিজ্ঞাপন দেখাবে না এবং ইনকামও আসবে না।
 */
object AdIds {
    const val BANNER = "ca-app-pub-3940256099942544/6300978111"
    const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    const val NATIVE = "ca-app-pub-3940256099942544/2247696110"      // তালিকার ভেতরের নেটিভ বিজ্ঞাপন
    const val APP_OPEN = "ca-app-pub-3940256099942544/9257395921"    // অ্যাপে ফিরে আসার বিজ্ঞাপন
}

/**
 * ফুল-স্ক্রিন বিজ্ঞাপনের ব্যবস্থাপক (ইন্টারস্টিশিয়াল + অ্যাপ-ওপেন)।
 * কখন দেখানো যাবে সেই নিয়ম সব [AdPolicy]-তে — এখানে শুধু লোড করা আর দেখানো।
 * SDK শুরু হয় সম্মতি (UMP) পাওয়ার পরেই — MainActivity দেখুন।
 */
object AdManager {
    private var interstitial: InterstitialAd? = null
    private var appOpen: AppOpenAd? = null
    private var loadingInterstitial = false
    private var loadingAppOpen = false
    private var initialized = false
    private var showingFullScreen = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        val app = context.applicationContext
        MobileAds.initialize(app)
        loadInterstitial(app)
        loadAppOpen(app)
    }

    private fun loadInterstitial(context: Context) {
        if (loadingInterstitial || interstitial != null) return
        loadingInterstitial = true
        InterstitialAd.load(
            context, AdIds.INTERSTITIAL, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    loadingInterstitial = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    loadingInterstitial = false
                }
            }
        )
    }

    private fun loadAppOpen(context: Context) {
        if (loadingAppOpen || appOpen != null) return
        loadingAppOpen = true
        AppOpenAd.load(
            context, AdIds.APP_OPEN, AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpen = ad
                    loadingAppOpen = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpen = null
                    loadingAppOpen = false
                }
            }
        )
    }

    /**
     * একটা কাজ শেষ হওয়ার স্বাভাবিক বিরতিতে কল করুন (PDF শেয়ার/সেভ, ব্যাকআপ সফল)।
     * দেখাবে কি না তা [AdPolicy] ঠিক করে: বিরতি, দিনের সীমা, মোড, দেশ, বিজ্ঞাপনমুক্ত কেনা...
     */
    fun maybeShowInterstitial(activity: Activity) {
        if (!initialized || showingFullScreen) return
        val now = System.currentTimeMillis()
        if (!AdPolicy.canShowInterstitial(now)) return
        val ad = interstitial ?: run { loadInterstitial(activity); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                showingFullScreen = true
                AdPolicy.recordInterstitialShown(System.currentTimeMillis())
            }
            override fun onAdDismissedFullScreenContent() {
                showingFullScreen = false
                interstitial = null
                loadInterstitial(activity)
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                showingFullScreen = false
                interstitial = null
                loadInterstitial(activity)
            }
        }
        ad.show(activity)
    }

    /** আগের নামে কল থাকা জায়গাগুলোর জন্য — এখন একই নিয়মে চলে */
    fun maybeShowInterstitialAfterExport(activity: Activity) = maybeShowInterstitial(activity)

    /** অ্যাপে ফিরে আসার সময় (অন্তত ৫ মিনিট বাইরে থাকলে, দিনে ১ বার) */
    fun maybeShowAppOpen(activity: Activity, awayMs: Long) {
        if (!initialized || showingFullScreen) return
        val now = System.currentTimeMillis()
        if (!AdPolicy.canShowAppOpen(now, awayMs)) return
        val ad = appOpen ?: run { loadAppOpen(activity); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                showingFullScreen = true
                AdPolicy.recordAppOpenShown(System.currentTimeMillis())
            }
            override fun onAdDismissedFullScreenContent() {
                showingFullScreen = false
                appOpen = null
                loadAppOpen(activity)
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                showingFullScreen = false
                appOpen = null
                loadAppOpen(activity)
            }
        }
        ad.show(activity)
    }
}
