package com.udharhisab.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * ⚠️ এই তিনটা ID Google-এর অফিসিয়াল TEST ID — এখনই কোড চলবে, টেস্ট বিজ্ঞাপন দেখাবে।
 * Play Store-এ আপলোডের আগে admob.google.com থেকে নিজের আসল Ad Unit ID দিয়ে বদলে দিন:
 *   Apps → আপনার অ্যাপ → Ad units → Banner/Interstitial-এর ID কপি করুন
 * আসল ID না বদলালে রিয়েল বিজ্ঞাপন দেখাবে না এবং ইনকামও আসবে না।
 */
object AdIds {
    const val BANNER = "ca-app-pub-3940256099942544/6300978111"
    const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
}

/**
 * পুরো অ্যাপে একবারই SDK init করলেই হয় — MainActivity-র onCreate-এ কল করুন।
 * ইন্টারস্টিশিয়াল আগে থেকেই লোড করে রাখে, আর কতবার-কখন দেখানো হবে সেটা এখান থেকেই নিয়ন্ত্রণ হয়
 * (প্রতিটা PDF এক্সপোর্টে না দেখিয়ে, প্রতি তৃতীয়বারে একবার — বেশি বিরক্তিকর না হওয়ার জন্য)
 */
object AdManager {
    private var interstitial: InterstitialAd? = null
    private var isLoading = false
    private var exportCount = 0
    private const val SHOW_EVERY_N = 3

    fun init(context: Context) {
        MobileAds.initialize(context)
        loadInterstitial(context)
    }

    private fun loadInterstitial(context: Context) {
        if (isLoading || interstitial != null) return
        isLoading = true
        InterstitialAd.load(
            context, AdIds.INTERSTITIAL, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    isLoading = false
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    isLoading = false
                }
            }
        )
    }

    /**
     * PDF এক্সপোর্ট/শেয়ারের মতো "একটা কাজ শেষ হওয়ার" স্বাভাবিক বিরতিতে কল করুন।
     * প্রতিবার দেখাবে না — frequency capping নিজে থেকেই সামলাবে।
     */
    fun maybeShowInterstitialAfterExport(activity: Activity) {
        exportCount++
        if (exportCount % SHOW_EVERY_N != 0) return
        val ad = interstitial ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitial = null
                loadInterstitial(activity)
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitial = null
                loadInterstitial(activity)
            }
        }
        ad.show(activity)
    }
}
