package com.udharhisab.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {

    @Insert
    suspend fun insert(txn: TransactionEntity): Long

    @Query("SELECT * FROM transactions WHERE shopId = :shopId AND isDeleted = 0 ORDER BY date DESC")
    fun txnsOf(shopId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE shopId = :shopId AND isDeleted = 0 ORDER BY date ASC")
    suspend fun txnsOnce(shopId: Long): List<TransactionEntity>

    /** সব লেনদেন (PDF-এর জন্য) — শুধু একবার */
    @Query("SELECT * FROM transactions WHERE isDeleted = 0 ORDER BY date ASC")
    suspend fun allTxnsOnce(): List<TransactionEntity>

    @Query("UPDATE transactions SET isDeleted = 1, deletedAt = :time WHERE id = :txnId")
    suspend fun softDelete(txnId: Long, time: Long = System.currentTimeMillis())

    @Query("UPDATE transactions SET isDeleted = 0, deletedAt = NULL WHERE id = :txnId")
    suspend fun undoDelete(txnId: Long)

    @Query("DELETE FROM transactions WHERE shopId = :shopId")
    suspend fun deleteAllOfShop(shopId: Long)
}
