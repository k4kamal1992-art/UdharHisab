package com.udharhisab.data.local

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Relation
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/** ⭐ লেনদেন + কোন দোকানের + তার পণ্য-আইটেম (থাকলে) — হিস্ট্রি স্ক্রিনের জন্য */
data class TransactionWithShop(
    @Embedded val txn: TransactionEntity,
    val shopName: String,
    @Relation(parentColumn = "id", entityColumn = "transactionId")
    val items: List<TransactionItemEntity>
)

/** ⭐ লেনদেন + তার সব পণ্য (থাকলে) — শপ ডিটেইল আর PDF-এর জন্য */
data class TransactionWithItems(
    @Embedded val txn: TransactionEntity,
    @Relation(parentColumn = "id", entityColumn = "transactionId")
    val items: List<TransactionItemEntity>
)

/** ⭐ Reports — সময়ভিত্তিক টোটাল */
data class PeriodTotals(
    val totalCredit: Double,
    val totalPayment: Double,
    val txnCount: Int
)

/** ⭐ Reports — দোকান-ভিত্তিক সারি (ধার/পরিশোধ = নির্বাচিত সময়ের, বাকি = সবসময়ের বর্তমান) */
data class ShopReportRow(
    val shopId: Long,
    val shopName: String,
    val periodCredit: Double,
    val periodPayment: Double,
    val currentDue: Double,
    val lastUsedAt: Long
)

@Dao
interface TransactionDao {

    @Insert
    suspend fun insert(txn: TransactionEntity): Long

    @Transaction
    @Query("SELECT * FROM transactions WHERE shopId = :shopId AND isDeleted = 0 ORDER BY date DESC")
    fun txnsWithItemsOf(shopId: Long): Flow<List<TransactionWithItems>>

    @Query("SELECT * FROM transactions WHERE shopId = :shopId AND isDeleted = 0 ORDER BY date ASC")
    suspend fun txnsOnce(shopId: Long): List<TransactionEntity>

    /** সব লেনদেন (PDF-এর জন্য) — শুধু একবার */
    @Transaction
    @Query("SELECT * FROM transactions WHERE shopId = :shopId AND isDeleted = 0 ORDER BY date ASC")
    suspend fun txnsWithItemsOnce(shopId: Long): List<TransactionWithItems>

    /** ⭐ হিস্ট্রি স্ক্রিন — সব লেনদেন + দোকানের নাম, রিয়েক্টিভ */
    @Transaction
    @Query("""
        SELECT t.*, s.name AS shopName
        FROM transactions t
        JOIN shops s ON s.id = t.shopId
        WHERE t.isDeleted = 0
        ORDER BY t.date DESC
    """)
    fun allTxnsWithShop(): Flow<List<TransactionWithShop>>

    @Query("UPDATE transactions SET isDeleted = 1, deletedAt = :time WHERE id = :txnId")
    suspend fun softDelete(txnId: Long, time: Long = System.currentTimeMillis())

    @Query("UPDATE transactions SET isDeleted = 0, deletedAt = NULL WHERE id = :txnId")
    suspend fun undoDelete(txnId: Long)

    @Query("DELETE FROM transactions WHERE shopId = :shopId")
    suspend fun deleteAllOfShop(shopId: Long)

    // ── ⭐ Reports ──

    @Query("""
        SELECT
          COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0) AS totalCredit,
          COALESCE(SUM(CASE WHEN type = 'PAYMENT' THEN amount ELSE 0 END), 0) AS totalPayment,
          COUNT(*) AS txnCount
        FROM transactions
        WHERE isDeleted = 0 AND date >= :fromTime
    """)
    fun periodTotals(fromTime: Long): Flow<PeriodTotals>

    @Query("""
        SELECT s.id AS shopId, s.name AS shopName, s.lastUsedAt AS lastUsedAt,
          COALESCE((SELECT SUM(amount) FROM transactions
                     WHERE shopId = s.id AND type = 'CREDIT' AND isDeleted = 0 AND date >= :fromTime), 0) AS periodCredit,
          COALESCE((SELECT SUM(amount) FROM transactions
                     WHERE shopId = s.id AND type = 'PAYMENT' AND isDeleted = 0 AND date >= :fromTime), 0) AS periodPayment,
          COALESCE((SELECT SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE -amount END)
                     FROM transactions WHERE shopId = s.id AND isDeleted = 0), 0) AS currentDue
        FROM shops s
        WHERE s.isArchived = 0
        ORDER BY currentDue DESC
    """)
    fun shopReportRows(fromTime: Long): Flow<List<ShopReportRow>>

    @Transaction
    @Query("""
        SELECT t.*, s.name AS shopName
        FROM transactions t
        JOIN shops s ON s.id = t.shopId
        WHERE t.isDeleted = 0 AND t.type = 'PAYMENT' AND t.date >= :fromTime
        ORDER BY t.date DESC
        LIMIT :limit
    """)
    fun recentPayments(fromTime: Long, limit: Int = 10): Flow<List<TransactionWithShop>>
}
