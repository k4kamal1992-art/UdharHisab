package com.udharhisab

import android.app.Application

class KhataApp : Application()
