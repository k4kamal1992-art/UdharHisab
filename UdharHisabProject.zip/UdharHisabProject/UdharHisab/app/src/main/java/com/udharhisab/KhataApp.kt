package com.udharhisab

import android.app.Application

class KhataApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // ⭐ ক্র্যাশের কারণ ধরে রাখা — "আরও" পেজে "ক্র্যাশ রিপোর্ট পাঠান" দিয়ে ডেভেলপারকে দেওয়া যায়
        com.udharhisab.diag.CrashLogger.install(this)
    }
}
