package com.yourname.udharhisab.ui.shop

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yourname.udharhisab.R
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.repository.ShopRepository
import com.yourname.udharhisab.databinding.ActivityAddShopBinding
import com.yourname.udharhisab.utils.Constants
import kotlinx.coroutines.launch

class AddShopActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddShopBinding
    private lateinit var shopRepository: ShopRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddShopBinding.inflate(layoutInflater)
        setContentView(binding.root)

        shopRepository = (application as UdharHisabApp).shopRepository

        setupToolbar()
        setupShopTypeDropdown()
        setupSaveButton()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.add_shop)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupShopTypeDropdown() {
        val shopTypes = arrayOf(
            Constants.SHOP_GENERAL,
            Constants.SHOP_TEA_STALL,
            Constants.SHOP_GROCERY,
            Constants.SHOP_KIRANA,
            Constants.SHOP_RESTAURANT,
            Constants.SHOP_HARDWARE
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, shopTypes)
        binding.dropdownShopType.setAdapter(adapter)
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            val name = binding.etShopName.text.toString().trim()
            val ownerName = binding.etOwnerName.text.toString().trim()
            val phone = binding.etPhone.text.toString().trim()
            val address = binding.etAddress.text.toString().trim()
            val shopType = binding.dropdownShopType.text.toString().ifEmpty { Constants.SHOP_GENERAL }

            if (name.isEmpty()) {
                binding.etShopName.error = getString(R.string.error_shop_name)
                return@setOnClickListener
            }

            val shop = Shop(
                name = name,
                ownerName = ownerName,
                phone = phone,
                address = address,
                shopType = shopType
            )

            lifecycleScope.launch {
                shopRepository.insert(shop)
                Toast.makeText(this@AddShopActivity, getString(R.string.shop_saved), Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
