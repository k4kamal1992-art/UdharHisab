package com.udharhisab.ui.pdf

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.pdf.PdfContentScope
import com.udharhisab.data.pdf.PdfFormat
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import java.util.Calendar

enum class PdfPeriodOption { THIS_MONTH, LAST_MONTH, LAST_3_MONTHS, CUSTOM }

/** সময়সীমা থেকে (fromTime, toTime) — মিলিসেকেন্ড রেঞ্জ বের করে */
private fun rangeFor(option: PdfPeriodOption, customFrom: Long?, customTo: Long?): Pair<Long, Long> {
    val cal = Calendar.getInstance()
    fun startOfDay(c: Calendar) = c.apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    fun endOfDay(c: Calendar) = c.apply {
        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
    }.timeInMillis

    return when (option) {
        PdfPeriodOption.THIS_MONTH -> {
            val from = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
            startOfDay(from) to System.currentTimeMillis()
        }
        PdfPeriodOption.LAST_MONTH -> {
            val from = Calendar.getInstance().apply { add(Calendar.MONTH, -1); set(Calendar.DAY_OF_MONTH, 1) }
            val to = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); add(Calendar.DAY_OF_MONTH, -1)
            }
            startOfDay(from) to endOfDay(to)
        }
        PdfPeriodOption.LAST_3_MONTHS -> {
            val from = Calendar.getInstance().apply { add(Calendar.MONTH, -2); set(Calendar.DAY_OF_MONTH, 1) }
            startOfDay(from) to System.currentTimeMillis()
        }
        PdfPeriodOption.CUSTOM -> {
            val f = customFrom ?: cal.timeInMillis
            val t = customTo ?: System.currentTimeMillis()
            f to t
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfOptionsDialog(
    shops: List<ShopEntity>,
    preselectedShopId: Long?,
    onDismiss: () -> Unit,
    onGenerate: (shopId: Long?, fromTime: Long, toTime: Long, scope: PdfContentScope, format: PdfFormat) -> Unit
) {
    val s = LocalStrings.current
    var period by remember { mutableStateOf(PdfPeriodOption.THIS_MONTH) }
    var selectedShopId by remember { mutableStateOf(preselectedShopId) }
    var scope by remember { mutableStateOf(PdfContentScope.FULL) }
    var format by remember { mutableStateOf(PdfFormat.A4) }
    var customFrom by remember { mutableStateOf<Long?>(null) }
    var customTo by remember { mutableStateOf<Long?>(null) }
    var showFromPicker by remember { mutableStateOf(false) }
    var showToPicker by remember { mutableStateOf(false) }
    var shopMenuOpen by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.large) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Text(s.pdfOptionsTitle, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(14.dp))

                // ── সময়সীমা ──
                Text(s.pdfPeriodLabel, style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        PdfPeriodOption.THIS_MONTH to s.pdfThisMonth,
                        PdfPeriodOption.LAST_MONTH to s.pdfLastMonth,
                        PdfPeriodOption.LAST_3_MONTHS to s.pdfLast3Months,
                        PdfPeriodOption.CUSTOM to s.pdfCustomRange
                    ).forEach { (opt, label) ->
                        FilterChip(
                            selected = period == opt,
                            onClick = { period = opt },
                            label = { Text(label) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                if (period == PdfPeriodOption.CUSTOM) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showFromPicker = true }, modifier = Modifier.weight(1f)) {
                            Text(customFrom?.let { UnitConverter.dateShort(it, s.code) } ?: s.pdfFromDateLabel)
                        }
                        OutlinedButton(onClick = { showToPicker = true }, modifier = Modifier.weight(1f)) {
                            Text(customTo?.let { UnitConverter.dateShort(it, s.code) } ?: s.pdfToDateLabel)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // ── দোকান ──
                Text(s.pdfShopLabelOption, style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Box {
                    OutlinedButton(onClick = { shopMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(shops.firstOrNull { it.id == selectedShopId }?.name ?: s.pdfAllShopsOption)
                    }
                    DropdownMenu(expanded = shopMenuOpen, onDismissRequest = { shopMenuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(s.pdfAllShopsOption) },
                            onClick = { selectedShopId = null; shopMenuOpen = false }
                        )
                        shops.forEach { shop ->
                            DropdownMenuItem(
                                text = { Text(shop.name) },
                                onClick = { selectedShopId = shop.id; shopMenuOpen = false }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // ── কী কী দেখাবে (শুধু নির্দিষ্ট দোকান হলে প্রযোজ্য) ──
                if (selectedShopId != null) {
                    Text(s.pdfContentLabel, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            PdfContentScope.FULL to s.pdfContentFull,
                            PdfContentScope.SUMMARY_ONLY to s.pdfContentSummaryOnly,
                            PdfContentScope.TRANSACTIONS_ONLY to s.pdfContentTxnsOnly
                        ).forEach { (opt, label) ->
                            FilterChip(
                                selected = scope == opt,
                                onClick = { scope = opt },
                                label = { Text(label) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                // ── ফরম্যাট (শুধু নির্দিষ্ট দোকান হলে প্রযোজ্য — সব দোকানের রিপোর্ট সবসময় A4) ──
                if (selectedShopId != null) {
                    Text(s.pdfFormatLabel, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = format == PdfFormat.A4,
                            onClick = { format = PdfFormat.A4 },
                            label = { Text(s.pdfFormatA4) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = format == PdfFormat.RECEIPT,
                            onClick = { format = PdfFormat.RECEIPT },
                            label = { Text(s.pdfFormatReceipt) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text(s.cancel) }
                    Button(
                        onClick = {
                            val (from, to) = rangeFor(period, customFrom, customTo)
                            onGenerate(selectedShopId, from, to, scope, format)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(s.pdfGenerateButton) }
                }
            }
        }
    }

    if (showFromPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = customFrom)
        DatePickerDialog(
            onDismissRequest = { showFromPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    customFrom = state.selectedDateMillis
                    showFromPicker = false
                }) { Text(s.save) }
            },
            dismissButton = { TextButton(onClick = { showFromPicker = false }) { Text(s.cancel) } }
        ) { DatePicker(state = state) }
    }
    if (showToPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = customTo)
        DatePickerDialog(
            onDismissRequest = { showToPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    customTo = state.selectedDateMillis
                    showToPicker = false
                }) { Text(s.save) }
            },
            dismissButton = { TextButton(onClick = { showToPicker = false }) { Text(s.cancel) } }
        ) { DatePicker(state = state) }
    }
}
