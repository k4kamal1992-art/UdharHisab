package com.udharhisab.ui.pdf

import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.components.FriendlyDialog
import com.udharhisab.ui.components.DialogSectionLabel
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.pdf.PdfContentScope
import com.udharhisab.data.pdf.PdfFormat
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import java.util.Calendar

enum class PdfPeriodOption { THIS_MONTH, LAST_MONTH, LAST_3_MONTHS, CUSTOM }

/** সময়সীমা থেকে (fromTime, toTime) — মিলিসেকেন্ড রেঞ্জ বের করে */
private fun rangeFor(option: PdfPeriodOption, customFrom: Long?, customTo: Long?): Pair<Long, Long> {
    val cal = Calendar.getInstance()
    fun startOfDay(c: Calendar) = c.apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    fun endOfDay(c: Calendar) = c.apply {
        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
    }.timeInMillis

    return when (option) {
        PdfPeriodOption.THIS_MONTH -> {
            val from = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
            startOfDay(from) to System.currentTimeMillis()
        }
        PdfPeriodOption.LAST_MONTH -> {
            val from = Calendar.getInstance().apply { add(Calendar.MONTH, -1); set(Calendar.DAY_OF_MONTH, 1) }
            val to = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); add(Calendar.DAY_OF_MONTH, -1)
            }
            startOfDay(from) to endOfDay(to)
        }
        PdfPeriodOption.LAST_3_MONTHS -> {
            val from = Calendar.getInstance().apply { add(Calendar.MONTH, -2); set(Calendar.DAY_OF_MONTH, 1) }
            startOfDay(from) to System.currentTimeMillis()
        }
        PdfPeriodOption.CUSTOM -> {
            val f = customFrom ?: cal.timeInMillis
            val t = customTo ?: System.currentTimeMillis()
            f to t
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PdfOptionsDialog(
    shops: List<ShopEntity>,
    preselectedShopId: Long?,
    shopkeeperMode: Boolean,
    brandingAvailable: Boolean,
    onDismiss: () -> Unit,
    onGenerate: (PdfRequest) -> Unit
) {
    val s = LocalStrings.current
    var period by remember { mutableStateOf(PdfPeriodOption.THIS_MONTH) }
    var selectedShopId by remember { mutableStateOf(preselectedShopId) }
    var scope by remember { mutableStateOf(PdfContentScope.FULL) }
    var format by remember { mutableStateOf(PdfFormat.A4) }
    var customFrom by remember { mutableStateOf<Long?>(null) }
    var customTo by remember { mutableStateOf<Long?>(null) }
    var showFromPicker by remember { mutableStateOf(false) }
    var showToPicker by remember { mutableStateOf(false) }
    var shopMenuOpen by remember { mutableStateOf(false) }
    var useBranding by remember { mutableStateOf(true) }
    var action by remember { mutableStateOf(PdfAction.SHARE) }

    val c = LocalKhataColors.current
    val chipShape = RoundedCornerShape(20.dp)
    val chipColors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = c.Primary,
        selectedLabelColor = Color.White
    )

    FriendlyDialog(
        title = s.pdfOptionsTitle.removePrefix("⚙️").trim(),
        icon = Icons.Default.PictureAsPdf,
        onDismiss = onDismiss,
        footer = {
            TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text(s.cancel, fontWeight = FontWeight.Bold) }
            Button(
                onClick = {
                    val (from, to) = rangeFor(period, customFrom, customTo)
                    onGenerate(
                        PdfRequest(
                            shopId = selectedShopId, fromTime = from, toTime = to,
                            scope = scope, format = format,
                            useBranding = shopkeeperMode && brandingAvailable && useBranding,
                            action = action
                        )
                    )
                },
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier.weight(1.4f).height(48.dp)
            ) { Text(s.pdfGenerateButton, fontWeight = FontWeight.ExtraBold) }
        }
    ) {
        // ── সময়সীমা: চিপগুলো পাশাপাশি সাজানো, জায়গা না হলে নিচে নামে ──
        DialogSectionLabel(s.pdfPeriodLabel.removePrefix("📅").trim())
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(
                PdfPeriodOption.THIS_MONTH to s.pdfThisMonth,
                PdfPeriodOption.LAST_MONTH to s.pdfLastMonth,
                PdfPeriodOption.LAST_3_MONTHS to s.pdfLast3Months,
                PdfPeriodOption.CUSTOM to s.pdfCustomRange
            ).forEach { (opt, label) ->
                FilterChip(
                    selected = period == opt,
                    onClick = { period = opt },
                    shape = chipShape, colors = chipColors,
                    label = { Text(label, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        if (period == PdfPeriodOption.CUSTOM) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showFromPicker = true }, shape = chipShape, modifier = Modifier.weight(1f)) {
                    Text(customFrom?.let { UnitConverter.dateShort(it, s.code) } ?: s.pdfFromDateLabel)
                }
                OutlinedButton(onClick = { showToPicker = true }, shape = chipShape, modifier = Modifier.weight(1f)) {
                    Text(customTo?.let { UnitConverter.dateShort(it, s.code) } ?: s.pdfToDateLabel)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // ── দোকান / কাস্টমার ──
        DialogSectionLabel(s.pdfShopLabelOption.removePrefix("🏪").trim())
        Box {
            OutlinedButton(onClick = { shopMenuOpen = true }, shape = chipShape, modifier = Modifier.fillMaxWidth()) {
                Text(shops.firstOrNull { it.id == selectedShopId }?.name ?: s.pdfAllShopsOption, fontWeight = FontWeight.Bold)
            }
            DropdownMenu(expanded = shopMenuOpen, onDismissRequest = { shopMenuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(s.pdfAllShopsOption) },
                    onClick = { selectedShopId = null; shopMenuOpen = false }
                )
                shops.forEach { shop ->
                    DropdownMenuItem(
                        text = { Text(shop.name) },
                        onClick = { selectedShopId = shop.id; shopMenuOpen = false }
                    )
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // ── কী কী দেখাবে (শুধু নির্দিষ্ট দোকান হলে প্রযোজ্য) ──
        if (selectedShopId != null) {
            DialogSectionLabel(s.pdfContentLabel.removePrefix("📝").trim())
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(
                    PdfContentScope.FULL to s.pdfContentFull,
                    PdfContentScope.SUMMARY_ONLY to s.pdfContentSummaryOnly,
                    PdfContentScope.TRANSACTIONS_ONLY to s.pdfContentTxnsOnly
                ).forEach { (opt, label) ->
                    FilterChip(
                        selected = scope == opt,
                        onClick = { scope = opt },
                        shape = chipShape, colors = chipColors,
                        label = { Text(label, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
        }

        // ── ⭐ দোকানদার হলে: দোকানের নাম/লোগো/ঠিকানা যোগ ──
        if (shopkeeperMode) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(c.ChipBg, RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (brandingAvailable) {
                    Text(s.pdfBrandingOption, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(checked = useBranding, onCheckedChange = { useBranding = it })
                } else {
                    Text(s.pdfBrandingMissing, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(18.dp))
        }

        // ── শেয়ার / সেভ / প্রিন্ট ──
        DialogSectionLabel(s.pdfActionLabel.removePrefix("📤").trim())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                Triple(PdfAction.SHARE, s.pdfActionShare, Icons.Default.Share),
                Triple(PdfAction.SAVE, s.pdfActionSave, Icons.Default.Download),
                Triple(PdfAction.PRINT, s.pdfActionPrint, Icons.Default.Print)
            ).forEach { (opt, label, ic) ->
                FilterChip(
                    selected = action == opt,
                    onClick = { action = opt },
                    shape = chipShape, colors = chipColors,
                    leadingIcon = { Icon(ic, null, modifier = Modifier.size(16.dp)) },
                    label = { Text(label, fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    if (showFromPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = customFrom)
        DatePickerDialog(
            onDismissRequest = { showFromPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    customFrom = state.selectedDateMillis
                    showFromPicker = false
                }) { Text(s.save) }
            },
            dismissButton = { TextButton(onClick = { showFromPicker = false }) { Text(s.cancel) } }
        ) { DatePicker(state = state) }
    }
    if (showToPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = customTo)
        DatePickerDialog(
            onDismissRequest = { showToPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    customTo = state.selectedDateMillis
                    showToPicker = false
                }) { Text(s.save) }
            },
            dismissButton = { TextButton(onClick = { showToPicker = false }) { Text(s.cancel) } }
        ) { DatePicker(state = state) }
    }
}
