package com.udharhisab.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TransactionItemDao {

    @Insert
    suspend fun insertAll(items: List<TransactionItemEntity>)

    /** ব্যাকআপ/রিস্টোরের জন্য — সব আইটেম, শপ-নির্বিশেষে */
    @Query("SELECT * FROM transaction_items")
    suspend fun getAllRaw(): List<TransactionItemEntity>

    @Query("DELETE FROM transaction_items")
    suspend fun deleteAll()

    @Query("SELECT * FROM transaction_items WHERE transactionId = :transactionId")
    suspend fun itemsOf(transactionId: Long): List<TransactionItemEntity>

    @Query("""
        DELETE FROM transaction_items
        WHERE transactionId IN (SELECT id FROM transactions WHERE shopId = :shopId)
    """)
    suspend fun deleteAllOfShop(shopId: Long)
}
