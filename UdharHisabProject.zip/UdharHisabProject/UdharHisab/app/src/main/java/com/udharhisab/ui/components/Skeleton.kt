package com.udharhisab.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * একটা "চকচকে" (shimmer) placeholder ব্লক — ডেটা লোড হওয়ার সময় দেখানো হয়।
 * Emoji/স্পিনারের বদলে ultra-modern স্কেলেটন প্যাটার্ন।
 */
@Composable
fun ShimmerBlock(
    modifier: Modifier = Modifier,
    height: Dp = 16.dp,
    corner: Dp = 6.dp
) {
    val c = LocalKhataColors.current
    val transition = rememberInfiniteTransition(label = "shimmer")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlpha"
    )
    androidx.compose.foundation.layout.Box(
        modifier
            .height(height)
            .clip(RoundedCornerShape(corner))
            .background(c.ChipBg.copy(alpha = alpha))
    )
}

/** একটা দোকান/লেনদেন সারির স্কেলেটন — Home ও History-তে ব্যবহৃত হয় */
@Composable
fun SkeletonRow(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = LocalKhataColors.current.Surface)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(LocalKhataColors.current.ChipBg)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ShimmerBlock(Modifier.fillMaxWidth(0.55f))
                ShimmerBlock(Modifier.fillMaxWidth(0.3f), height = 12.dp)
            }
            Spacer(Modifier.width(12.dp))
            ShimmerBlock(Modifier.width(60.dp), height = 16.dp)
        }
    }
}

/** পরপর কয়েকটা [SkeletonRow] — লিস্ট স্ক্রিনের প্রথম লোডে দেখানো হয় */
@Composable
fun SkeletonList(modifier: Modifier = Modifier, count: Int = 4) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(count) { SkeletonRow() }
    }
}

/** এম্পটি-স্টেটের আইকনকে নরম বৃত্তাকার ব্যাকগ্রাউন্ডে বসায় — ক্যাটাগরি-অ্যাভাটারের সাথে সামঞ্জস্যপূর্ণ */
@Composable
fun EmptyStateIcon(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val c = LocalKhataColors.current
    androidx.compose.foundation.layout.Box(
        Modifier
            .size(88.dp)
            .clip(CircleShape)
            .background(c.ChipBg),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            icon,
            contentDescription = null,
            tint = c.Primary,
            modifier = Modifier.size(38.dp)
        )
    }
}
@Composable
fun SkeletonHeroCard(modifier: Modifier = Modifier) {
    val c = LocalKhataColors.current
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = c.ChipBg)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ShimmerBlock(Modifier.fillMaxWidth(0.4f), height = 13.dp)
            ShimmerBlock(Modifier.fillMaxWidth(0.5f), height = 30.dp)
            ShimmerBlock(Modifier.fillMaxWidth(0.35f), height = 13.dp)
        }
    }
}
