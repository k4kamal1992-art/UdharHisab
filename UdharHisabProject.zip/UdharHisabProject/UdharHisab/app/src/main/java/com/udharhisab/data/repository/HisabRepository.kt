package com.udharhisab.data.repository

import com.udharhisab.data.local.AppDatabase
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopProductEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.data.local.TransactionEntity

class HisabRepository(private val db: AppDatabase) {

    private val shopDao = db.shopDao()
    private val txnDao = db.transactionDao()
    private val productDao = db.shopProductDao()

    // ── দোকান ──
    fun shopsWithBalance() = shopDao.shopsWithBalance()
    fun archivedShops() = shopDao.archivedShops()
    fun settledShops() = shopDao.settledShops()
    fun shopByIdFlow(id: Long) = shopDao.shopByIdFlow(id)

    suspend fun shopOnce(id: Long): ShopEntity? = shopDao.shopById(id)
    suspend fun balanceOnce(shopId: Long): Double = shopDao.balanceOf(shopId) ?: 0.0

    /** ⭐ language: নতুন দোকানে ধরন-ভিত্তিক ডিফল্ট প্রোডাক্ট লিস্ট কোন ভাষায় বসবে */
    suspend fun insertShop(name: String, phone: String?, shopType: ShopType, language: String = "bn"): Long {
        val id = shopDao.insert(
            ShopEntity(
                name = name.trim(),
                phone = phone?.ifBlank { null },
                shopType = shopType.key
            )
        )
        shopDao.touch(id, System.currentTimeMillis())

        // ⭐ ধরন-ভিত্তিক ডিফল্ট প্রোডাক্ট সাজেশন সিড করুন (দাম ছাড়া — প্রথম এন্ট্রিতে দাম বসবে)
        val defaults = DefaultProducts.forType(shopType, language).map { productName ->
            ShopProductEntity(shopId = id, name = productName)
        }
        if (defaults.isNotEmpty()) productDao.insertAllIfAbsent(defaults)

        return id
    }

    suspend fun updateShop(shopId: Long, name: String, phone: String?, shopType: ShopType) =
        shopDao.updateShop(shopId, name.trim(), phone?.ifBlank { null }, shopType.key)

    suspend fun archiveShop(shopId: Long) = shopDao.archive(shopId)
    suspend fun restoreShop(shopId: Long) = shopDao.restore(shopId)

    /** ⭐ পার্মানেন্ট ডিলিট — দোকান + সব লেনদেন */
    suspend fun deleteShopPermanently(shopId: Long) {
        txnDao.deleteAllOfShop(shopId)
        shopDao.shopById(shopId)?.let { } // শুধু এক্সিস্টেন্স চেক (ঐচ্ছিক)
        // ShopDao-তে DELETE কোয়েরি:
        deleteShopRow(shopId)
    }

    private suspend fun deleteShopRow(shopId: Long) {
        // ShopDao.deletePermanently কল
        shopDao.deletePermanently(shopId)
    }

    // ── লেনদেন ──
    fun txnsOf(shopId: Long) = txnDao.txnsOf(shopId)
    suspend fun txnsOnce(shopId: Long) = txnDao.txnsOnce(shopId)
    suspend fun allTxnsOnce() = txnDao.allTxnsOnce()

    /** ⭐ লেনদেন ইনসার্ট + দোকানের lastUsedAt টাচ (হোম সর্টের জন্য) +
     *  প্রোডাক্টের নাম/দাম থাকলে এই দোকানের জন্য মনে রাখা (পরের বার অটো-ফিল হবে) */
    suspend fun insertTxn(txn: TransactionEntity): Long {
        val id = txnDao.insert(txn)
        shopDao.touch(txn.shopId, System.currentTimeMillis())
        rememberProductPrice(txn)
        return id
    }

    private suspend fun rememberProductPrice(txn: TransactionEntity) {
        val name = txn.productName?.trim()
        if (name.isNullOrBlank() || txn.unitPrice == null) return
        productDao.upsert(
            ShopProductEntity(
                shopId = txn.shopId,
                name = name,
                lastUnit = txn.unit,
                lastUnitPrice = txn.unitPrice
            )
        )
    }

    // ── প্রোডাক্ট সাজেশন (দোকান-ভিত্তিক) ──
    fun shopProducts(shopId: Long) = productDao.forShop(shopId)

    /** ⭐ হিস্ট্রি স্ক্রিন — সব লেনদেন + দোকানের নাম */
    fun allTxnsWithShop() = txnDao.allTxnsWithShop()

    /** ⭐ Reports */
    fun periodTotals(fromTime: Long) = txnDao.periodTotals(fromTime)
    fun shopReportRows(fromTime: Long) = txnDao.shopReportRows(fromTime)
    fun recentPayments(fromTime: Long, limit: Int = 10) = txnDao.recentPayments(fromTime, limit)

    suspend fun softDeleteTxn(txnId: Long) = txnDao.softDelete(txnId)
    suspend fun undoDeleteTxn(txnId: Long) = txnDao.undoDelete(txnId)

    // ── রিমাইন্ডার ──
    suspend fun dueForReminder(reminderDays: Int): List<Pair<ShopEntity, Double>> {
        val cutoff = System.currentTimeMillis() - reminderDays * 24L * 60 * 60 * 1000
        return shopDao.shopsDueForReminder(cutoff).map {
            it to (shopDao.balanceOf(it.id) ?: 0.0)
        }
    }
}
