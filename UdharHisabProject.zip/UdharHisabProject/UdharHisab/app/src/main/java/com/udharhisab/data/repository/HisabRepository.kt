package com.udharhisab.data.repository

import com.udharhisab.data.local.AppDatabase
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.NoteEntity
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopProductEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionItemEntity

/** ⭐ "পণ্য অনুযায়ী" মোডে একটা নতুন লাইন-আইটেম সেভ করার জন্য হালকা ইনপুট */
data class NewTxnItem(
    val productName: String,
    val quantity: Double?,
    val unit: String?,
    val unitPrice: Double?,
    val amount: Double
)

class HisabRepository(private val db: AppDatabase) {

    private val shopDao = db.shopDao()
    private val txnDao = db.transactionDao()
    private val productDao = db.shopProductDao()
    private val itemDao = db.transactionItemDao()
    private val noteDao = db.noteDao()

    // ── নোট ──
    fun observeNotes() = noteDao.observeAll()
    fun searchNotes(query: String) = noteDao.search(query)
    suspend fun noteById(id: Long) = noteDao.getById(id)
    suspend fun saveNote(note: NoteEntity): Long =
        if (note.id == 0L) noteDao.insert(note) else { noteDao.update(note); note.id }
    suspend fun deleteNote(note: NoteEntity) = noteDao.delete(note)

    // ── দোকান ──
    fun shopsWithBalance() = shopDao.shopsWithBalance()
    fun archivedShops() = shopDao.archivedShops()
    fun settledShops() = shopDao.settledShops()
    fun shopByIdFlow(id: Long) = shopDao.shopByIdFlow(id)

    suspend fun shopOnce(id: Long): ShopEntity? = shopDao.shopById(id)
    suspend fun balanceOnce(shopId: Long): Double = shopDao.balanceOf(shopId) ?: 0.0

    /** ⭐ language: নতুন দোকানে ধরন-ভিত্তিক ডিফল্ট প্রোডাক্ট লিস্ট কোন ভাষায় বসবে */
    suspend fun insertShop(name: String, phone: String?, shopType: ShopType, language: String = "bn"): Long {
        val id = shopDao.insert(
            ShopEntity(
                name = name.trim(),
                phone = phone?.ifBlank { null },
                shopType = shopType.key
            )
        )
        shopDao.touch(id, System.currentTimeMillis())

        // ⭐ ধরন-ভিত্তিক ডিফল্ট প্রোডাক্ট সাজেশন সিড করুন (দাম ছাড়া — প্রথম এন্ট্রিতে দাম বসবে)
        val defaults = DefaultProducts.forType(shopType, language).map { productName ->
            ShopProductEntity(shopId = id, name = productName)
        }
        if (defaults.isNotEmpty()) productDao.insertAllIfAbsent(defaults)

        return id
    }

    suspend fun updateShop(shopId: Long, name: String, phone: String?, shopType: ShopType) =
        shopDao.updateShop(shopId, name.trim(), phone?.ifBlank { null }, shopType.key)

    suspend fun archiveShop(shopId: Long) = shopDao.archive(shopId)
    suspend fun restoreShop(shopId: Long) = shopDao.restore(shopId)

    /** ⭐ পার্মানেন্ট ডিলিট — দোকান + সব লেনদেন + তাদের সব পণ্য-আইটেম */
    suspend fun deleteShopPermanently(shopId: Long) {
        itemDao.deleteAllOfShop(shopId)
        txnDao.deleteAllOfShop(shopId)
        shopDao.deletePermanently(shopId)
    }

    // ── লেনদেন ──

    /** ⭐ শপ ডিটেইল স্ক্রিন — সব লেনদেন + প্রতিটার পণ্য-আইটেম (থাকলে), রিয়েক্টিভ */
    fun txnsWithItemsOf(shopId: Long) = txnDao.txnsWithItemsOf(shopId)

    /** PDF-এর জন্য — শুধু একবার */
    suspend fun txnsWithItemsOnce(shopId: Long) = txnDao.txnsWithItemsOnce(shopId)

    /**
     * ⭐ "ধার নিলাম" — সরাসরি টাকা (items খালি) অথবা একাধিক পণ্য (items ভর্তি)।
     * পণ্য থাকলে প্রতিটার দাম এই দোকানের জন্য মনে রাখা হয় (পরের বার অটো-ফিল)।
     */
    suspend fun insertCredit(shopId: Long, items: List<NewTxnItem>, directAmount: Double?, note: String?): Long {
        val total = if (items.isNotEmpty()) items.sumOf { it.amount } else (directAmount ?: 0.0)
        val txnId = txnDao.insert(
            TransactionEntity(
                shopId = shopId,
                amount = total,
                type = TransactionEntity.TYPE_CREDIT,
                note = note?.ifBlank { null }
            )
        )
        if (items.isNotEmpty()) {
            itemDao.insertAll(items.map {
                TransactionItemEntity(
                    transactionId = txnId,
                    productName = it.productName,
                    quantity = it.quantity,
                    unit = it.unit,
                    unitPrice = it.unitPrice,
                    amount = it.amount
                )
            })
            items.forEach { rememberProductPrice(shopId, it.productName, it.unit, it.unitPrice) }
        }
        shopDao.touch(shopId, System.currentTimeMillis())
        return txnId
    }

    /** ⭐ "জমা দিলাম" — শুধু টাকা, কোনো পণ্য-আইটেম নেই */
    suspend fun insertPayment(shopId: Long, amount: Double, paymentMethod: String?, note: String?): Long {
        val txnId = txnDao.insert(
            TransactionEntity(
                shopId = shopId,
                amount = amount,
                type = TransactionEntity.TYPE_PAYMENT,
                paymentMethod = paymentMethod,
                note = note?.ifBlank { null }
            )
        )
        shopDao.touch(shopId, System.currentTimeMillis())
        return txnId
    }

    private suspend fun rememberProductPrice(shopId: Long, name: String, unit: String?, unitPrice: Double?) {
        val trimmed = name.trim()
        if (trimmed.isBlank() || unitPrice == null) return
        productDao.upsert(
            ShopProductEntity(shopId = shopId, name = trimmed, lastUnit = unit, lastUnitPrice = unitPrice)
        )
    }

    // ── প্রোডাক্ট সাজেশন (দোকান-ভিত্তিক) ──
    fun shopProducts(shopId: Long) = productDao.forShop(shopId)

    /** ⭐ হিস্ট্রি স্ক্রিন — সব লেনদেন + দোকানের নাম */
    fun allTxnsWithShop() = txnDao.allTxnsWithShop()

    /** ⭐ Reports */
    fun periodTotals(fromTime: Long) = txnDao.periodTotals(fromTime)
    fun shopReportRows(fromTime: Long) = txnDao.shopReportRows(fromTime)
    fun recentPayments(fromTime: Long, limit: Int = 10) = txnDao.recentPayments(fromTime, limit)

    // ── ⭐ PDF রিপোর্ট (তারিখ-সীমাবদ্ধ) ──
    suspend fun txnsWithItemsInRange(shopId: Long, fromTime: Long, toTime: Long) =
        txnDao.txnsWithItemsInRange(shopId, fromTime, toTime)

    suspend fun shopReportRowsInRange(fromTime: Long, toTime: Long) =
        txnDao.shopReportRowsInRange(fromTime, toTime)

    suspend fun earliestTxnDate(shopId: Long) = txnDao.earliestTxnDate(shopId)

    suspend fun softDeleteTxn(txnId: Long) = txnDao.softDelete(txnId)
    suspend fun undoDeleteTxn(txnId: Long) = txnDao.undoDelete(txnId)

    // ── রিমাইন্ডার ──
    suspend fun dueForReminder(reminderDays: Int): List<Pair<ShopEntity, Double>> {
        val cutoff = System.currentTimeMillis() - reminderDays * 24L * 60 * 60 * 1000
        return shopDao.shopsDueForReminder(cutoff).map {
            it to (shopDao.balanceOf(it.id) ?: 0.0)
        }
    }

    // ── ব্যাকআপ ও রিস্টোর (লোকাল JSON) ──

    /** সব দোকান, লেনদেন, লাইন-আইটেম আর প্রোডাক্ট — এক JSON স্ট্রিং-এ */
    suspend fun exportBackupJson(): String {
        val shops = shopDao.getAllRaw()
        val txns = txnDao.getAllRaw()
        val items = itemDao.getAllRaw()
        val products = productDao.getAllRaw()
        val notes = noteDao.getAllRaw()

        val root = org.json.JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        root.put("shops", org.json.JSONArray().apply {
            shops.forEach {
                put(org.json.JSONObject().apply {
                    put("id", it.id); put("name", it.name)
                    put("phone", it.phone ?: org.json.JSONObject.NULL)
                    put("shopType", it.shopType); put("isArchived", it.isArchived)
                    put("lastUsedAt", it.lastUsedAt); put("createdAt", it.createdAt)
                })
            }
        })
        root.put("transactions", org.json.JSONArray().apply {
            txns.forEach {
                put(org.json.JSONObject().apply {
                    put("id", it.id); put("shopId", it.shopId); put("amount", it.amount)
                    put("type", it.type); put("date", it.date)
                    put("paymentMethod", it.paymentMethod ?: org.json.JSONObject.NULL)
                    put("note", it.note ?: org.json.JSONObject.NULL)
                    put("isDeleted", it.isDeleted)
                    put("deletedAt", it.deletedAt ?: org.json.JSONObject.NULL)
                })
            }
        })
        root.put("items", org.json.JSONArray().apply {
            items.forEach {
                put(org.json.JSONObject().apply {
                    put("id", it.id); put("transactionId", it.transactionId)
                    put("productName", it.productName)
                    put("quantity", it.quantity ?: org.json.JSONObject.NULL)
                    put("unit", it.unit ?: org.json.JSONObject.NULL)
                    put("unitPrice", it.unitPrice ?: org.json.JSONObject.NULL)
                    put("amount", it.amount)
                })
            }
        })
        root.put("products", org.json.JSONArray().apply {
            products.forEach {
                put(org.json.JSONObject().apply {
                    put("id", it.id); put("shopId", it.shopId); put("name", it.name)
                    put("lastUnit", it.lastUnit ?: org.json.JSONObject.NULL)
                    put("lastUnitPrice", it.lastUnitPrice ?: org.json.JSONObject.NULL)
                    put("updatedAt", it.updatedAt)
                })
            }
        })
        root.put("notes", org.json.JSONArray().apply {
            notes.forEach {
                put(org.json.JSONObject().apply {
                    put("id", it.id); put("title", it.title); put("content", it.content)
                    put("createdAt", it.createdAt); put("updatedAt", it.updatedAt)
                })
            }
        })
        return root.toString()
    }

    /** ⚠️ বর্তমান সব ডেটা মুছে JSON ব্যাকআপ থেকে replace করে */
    suspend fun restoreFromBackupJson(json: String) {
        val root = org.json.JSONObject(json)

        val shopsArr = root.getJSONArray("shops")
        val shops = (0 until shopsArr.length()).map { i ->
            val o = shopsArr.getJSONObject(i)
            ShopEntity(
                id = o.getLong("id"),
                name = o.getString("name"),
                phone = if (o.isNull("phone")) null else o.getString("phone"),
                shopType = o.getString("shopType"),
                isArchived = o.getBoolean("isArchived"),
                lastUsedAt = o.getLong("lastUsedAt"),
                createdAt = o.getLong("createdAt")
            )
        }
        val txnsArr = root.getJSONArray("transactions")
        val txns = (0 until txnsArr.length()).map { i ->
            val o = txnsArr.getJSONObject(i)
            TransactionEntity(
                id = o.getLong("id"),
                shopId = o.getLong("shopId"),
                amount = o.getDouble("amount"),
                type = o.getString("type"),
                date = o.getLong("date"),
                paymentMethod = if (o.isNull("paymentMethod")) null else o.getString("paymentMethod"),
                note = if (o.isNull("note")) null else o.getString("note"),
                isDeleted = o.getBoolean("isDeleted"),
                deletedAt = if (o.isNull("deletedAt")) null else o.getLong("deletedAt")
            )
        }
        val itemsArr = root.getJSONArray("items")
        val items = (0 until itemsArr.length()).map { i ->
            val o = itemsArr.getJSONObject(i)
            TransactionItemEntity(
                id = o.getLong("id"),
                transactionId = o.getLong("transactionId"),
                productName = o.getString("productName"),
                quantity = if (o.isNull("quantity")) null else o.getDouble("quantity"),
                unit = if (o.isNull("unit")) null else o.getString("unit"),
                unitPrice = if (o.isNull("unitPrice")) null else o.getDouble("unitPrice"),
                amount = o.getDouble("amount")
            )
        }
        val productsArr = root.getJSONArray("products")
        val products = (0 until productsArr.length()).map { i ->
            val o = productsArr.getJSONObject(i)
            ShopProductEntity(
                id = o.getLong("id"),
                shopId = o.getLong("shopId"),
                name = o.getString("name"),
                lastUnit = if (o.isNull("lastUnit")) null else o.getString("lastUnit"),
                lastUnitPrice = if (o.isNull("lastUnitPrice")) null else o.getDouble("lastUnitPrice"),
                updatedAt = o.getLong("updatedAt")
            )
        }
        // পুরোনো ব্যাকআপ ফাইলে "notes" নাও থাকতে পারে — optJSONArray দিয়ে নিরাপদে হ্যান্ডল
        val notesArr = root.optJSONArray("notes")
        val notes = if (notesArr != null) (0 until notesArr.length()).map { i ->
            val o = notesArr.getJSONObject(i)
            NoteEntity(
                id = o.getLong("id"),
                title = o.getString("title"),
                content = o.optString("content", ""),
                createdAt = o.getLong("createdAt"),
                updatedAt = o.getLong("updatedAt")
            )
        } else emptyList()

        // ── ফরেন-কি নিরাপদ ক্রমে মোছা: সন্তান আগে, বাবা পরে ──
        itemDao.deleteAll()
        txnDao.deleteAllRows()
        productDao.deleteAll()
        shopDao.deleteAll()
        noteDao.deleteAll()

        // ── আবার বসানো: বাবা আগে, সন্তান পরে — আইডি অবিকল রেখে ──
        shopDao.insertAll(shops)
        txnDao.insertAll(txns)
        itemDao.insertAll(items)
        productDao.insertAll(products)
        noteDao.insertAll(notes)
    }
}
