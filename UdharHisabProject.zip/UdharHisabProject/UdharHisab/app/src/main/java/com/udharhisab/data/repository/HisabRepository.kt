package com.udharhisab.data.repository

import com.udharhisab.data.local.AppDatabase
import com.udharhisab.data.local.DefaultProducts
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopProductEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionItemEntity

/** ⭐ "পণ্য অনুযায়ী" মোডে একটা নতুন লাইন-আইটেম সেভ করার জন্য হালকা ইনপুট */
data class NewTxnItem(
    val productName: String,
    val quantity: Double?,
    val unit: String?,
    val unitPrice: Double?,
    val amount: Double
)

class HisabRepository(private val db: AppDatabase) {

    private val shopDao = db.shopDao()
    private val txnDao = db.transactionDao()
    private val productDao = db.shopProductDao()
    private val itemDao = db.transactionItemDao()

    // ── দোকান ──
    fun shopsWithBalance() = shopDao.shopsWithBalance()
    fun archivedShops() = shopDao.archivedShops()
    fun settledShops() = shopDao.settledShops()
    fun shopByIdFlow(id: Long) = shopDao.shopByIdFlow(id)

    suspend fun shopOnce(id: Long): ShopEntity? = shopDao.shopById(id)
    suspend fun balanceOnce(shopId: Long): Double = shopDao.balanceOf(shopId) ?: 0.0

    /** ⭐ language: নতুন দোকানে ধরন-ভিত্তিক ডিফল্ট প্রোডাক্ট লিস্ট কোন ভাষায় বসবে */
    suspend fun insertShop(name: String, phone: String?, shopType: ShopType, language: String = "bn"): Long {
        val id = shopDao.insert(
            ShopEntity(
                name = name.trim(),
                phone = phone?.ifBlank { null },
                shopType = shopType.key
            )
        )
        shopDao.touch(id, System.currentTimeMillis())

        // ⭐ ধরন-ভিত্তিক ডিফল্ট প্রোডাক্ট সাজেশন সিড করুন (দাম ছাড়া — প্রথম এন্ট্রিতে দাম বসবে)
        val defaults = DefaultProducts.forType(shopType, language).map { productName ->
            ShopProductEntity(shopId = id, name = productName)
        }
        if (defaults.isNotEmpty()) productDao.insertAllIfAbsent(defaults)

        return id
    }

    suspend fun updateShop(shopId: Long, name: String, phone: String?, shopType: ShopType) =
        shopDao.updateShop(shopId, name.trim(), phone?.ifBlank { null }, shopType.key)

    suspend fun archiveShop(shopId: Long) = shopDao.archive(shopId)
    suspend fun restoreShop(shopId: Long) = shopDao.restore(shopId)

    /** ⭐ পার্মানেন্ট ডিলিট — দোকান + সব লেনদেন + তাদের সব পণ্য-আইটেম */
    suspend fun deleteShopPermanently(shopId: Long) {
        itemDao.deleteAllOfShop(shopId)
        txnDao.deleteAllOfShop(shopId)
        shopDao.deletePermanently(shopId)
    }

    // ── লেনদেন ──

    /** ⭐ শপ ডিটেইল স্ক্রিন — সব লেনদেন + প্রতিটার পণ্য-আইটেম (থাকলে), রিয়েক্টিভ */
    fun txnsWithItemsOf(shopId: Long) = txnDao.txnsWithItemsOf(shopId)

    /** PDF-এর জন্য — শুধু একবার */
    suspend fun txnsWithItemsOnce(shopId: Long) = txnDao.txnsWithItemsOnce(shopId)

    /**
     * ⭐ "ধার নিলাম" — সরাসরি টাকা (items খালি) অথবা একাধিক পণ্য (items ভর্তি)।
     * পণ্য থাকলে প্রতিটার দাম এই দোকানের জন্য মনে রাখা হয় (পরের বার অটো-ফিল)।
     */
    suspend fun insertCredit(shopId: Long, items: List<NewTxnItem>, directAmount: Double?, note: String?): Long {
        val total = if (items.isNotEmpty()) items.sumOf { it.amount } else (directAmount ?: 0.0)
        val txnId = txnDao.insert(
            TransactionEntity(
                shopId = shopId,
                amount = total,
                type = TransactionEntity.TYPE_CREDIT,
                note = note?.ifBlank { null }
            )
        )
        if (items.isNotEmpty()) {
            itemDao.insertAll(items.map {
                TransactionItemEntity(
                    transactionId = txnId,
                    productName = it.productName,
                    quantity = it.quantity,
                    unit = it.unit,
                    unitPrice = it.unitPrice,
                    amount = it.amount
                )
            })
            items.forEach { rememberProductPrice(shopId, it.productName, it.unit, it.unitPrice) }
        }
        shopDao.touch(shopId, System.currentTimeMillis())
        return txnId
    }

    /** ⭐ "জমা দিলাম" — শুধু টাকা, কোনো পণ্য-আইটেম নেই */
    suspend fun insertPayment(shopId: Long, amount: Double, paymentMethod: String?, note: String?): Long {
        val txnId = txnDao.insert(
            TransactionEntity(
                shopId = shopId,
                amount = amount,
                type = TransactionEntity.TYPE_PAYMENT,
                paymentMethod = paymentMethod,
                note = note?.ifBlank { null }
            )
        )
        shopDao.touch(shopId, System.currentTimeMillis())
        return txnId
    }

    private suspend fun rememberProductPrice(shopId: Long, name: String, unit: String?, unitPrice: Double?) {
        val trimmed = name.trim()
        if (trimmed.isBlank() || unitPrice == null) return
        productDao.upsert(
            ShopProductEntity(shopId = shopId, name = trimmed, lastUnit = unit, lastUnitPrice = unitPrice)
        )
    }

    // ── প্রোডাক্ট সাজেশন (দোকান-ভিত্তিক) ──
    fun shopProducts(shopId: Long) = productDao.forShop(shopId)

    /** ⭐ হিস্ট্রি স্ক্রিন — সব লেনদেন + দোকানের নাম */
    fun allTxnsWithShop() = txnDao.allTxnsWithShop()

    /** ⭐ Reports */
    fun periodTotals(fromTime: Long) = txnDao.periodTotals(fromTime)
    fun shopReportRows(fromTime: Long) = txnDao.shopReportRows(fromTime)
    fun recentPayments(fromTime: Long, limit: Int = 10) = txnDao.recentPayments(fromTime, limit)

    // ── ⭐ PDF রিপোর্ট (তারিখ-সীমাবদ্ধ) ──
    suspend fun txnsWithItemsInRange(shopId: Long, fromTime: Long, toTime: Long) =
        txnDao.txnsWithItemsInRange(shopId, fromTime, toTime)

    suspend fun shopReportRowsInRange(fromTime: Long, toTime: Long) =
        txnDao.shopReportRowsInRange(fromTime, toTime)

    suspend fun earliestTxnDate(shopId: Long) = txnDao.earliestTxnDate(shopId)

    suspend fun softDeleteTxn(txnId: Long) = txnDao.softDelete(txnId)
    suspend fun undoDeleteTxn(txnId: Long) = txnDao.undoDelete(txnId)

    // ── রিমাইন্ডার ──
    suspend fun dueForReminder(reminderDays: Int): List<Pair<ShopEntity, Double>> {
        val cutoff = System.currentTimeMillis() - reminderDays * 24L * 60 * 60 * 1000
        return shopDao.shopsDueForReminder(cutoff).map {
            it to (shopDao.balanceOf(it.id) ?: 0.0)
        }
    }
}
