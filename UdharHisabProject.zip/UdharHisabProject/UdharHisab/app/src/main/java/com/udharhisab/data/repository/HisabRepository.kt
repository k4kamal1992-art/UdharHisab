package com.udharhisab.data.repository

import com.udharhisab.data.local.AppDatabase
import com.udharhisab.data.local.ShopEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.data.local.ShopWithBalance
import com.udharhisab.data.local.TransactionEntity

class HisabRepository(private val db: AppDatabase) {

    private val shopDao = db.shopDao
    private val txnDao = db.transactionDao

    // ── দোকান ──
    fun shopsWithBalance() = shopDao.shopsWithBalance()
    fun archivedShops() = shopDao.archivedShops()
    fun settledShops() = shopDao.settledShops()
    fun shopByIdFlow(id: Long) = shopDao.shopByIdFlow(id)

    suspend fun shopOnce(id: Long): ShopEntity? = shopDao.shopById(id)
    suspend fun balanceOnce(shopId: Long): Double = shopDao.balanceOf(shopId) ?: 0.0

    suspend fun insertShop(name: String, phone: String?, shopType: ShopType): Long {
        val id = shopDao.insert(
            ShopEntity(
                name = name.trim(),
                phone = phone?.ifBlank { null },
                shopType = shopType.key
            )
        )
        shopDao.touch(id, System.currentTimeMillis())
        return id
    }

    suspend fun updateShop(shopId: Long, name: String, phone: String?, shopType: ShopType) =
        shopDao.updateShop(shopId, name.trim(), phone?.ifBlank { null }, shopType.key)

    suspend fun archiveShop(shopId: Long) = shopDao.archive(shopId)
    suspend fun restoreShop(shopId: Long) = shopDao.restore(shopId)

    /** ⭐ পার্মানেন্ট ডিলিট — দোকান + সব লেনদেন */
    suspend fun deleteShopPermanently(shopId: Long) {
        txnDao.deleteAllOfShop(shopId)
        shopDao.shopById(shopId)?.let { } // শুধু এক্সিস্টেন্স চেক (ঐচ্ছিক)
        // ShopDao-তে DELETE কোয়েরি:
        deleteShopRow(shopId)
    }

    private suspend fun deleteShopRow(shopId: Long) {
        // ShopDao.deletePermanently কল
        shopDao.deletePermanently(shopId)
    }

    // ── লেনদেন ──
    fun txnsOf(shopId: Long) = txnDao.txnsOf(shopId)
    suspend fun txnsOnce(shopId: Long) = txnDao.txnsOnce(shopId)
    suspend fun allTxnsOnce() = txnDao.allTxnsOnce()

    /** ⭐ লেনদেন ইনসার্ট + দোকানের lastUsedAt টাচ (হোম সর্টের জন্য) */
    suspend fun insertTxn(txn: TransactionEntity): Long {
        val id = txnDao.insert(txn)
        shopDao.touch(txn.shopId, System.currentTimeMillis())
        return id
    }

    suspend fun softDeleteTxn(txnId: Long) = txnDao.softDelete(txnId)
    suspend fun undoDeleteTxn(txnId: Long) = txnDao.undoDelete(txnId)

    // ── রিমাইন্ডার ──
    suspend fun dueForReminder(reminderDays: Int): List<Pair<ShopEntity, Double>> {
        val cutoff = System.currentTimeMillis() - reminderDays * 24L * 60 * 60 * 1000
        return shopDao.shopsDueForReminder(cutoff).map {
            it to (shopDao.balanceOf(it.id) ?: 0.0)
        }
    }
}
