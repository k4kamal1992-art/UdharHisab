package com.udharhisab.ui.strings

import androidx.compose.runtime.staticCompositionLocalOf
import com.udharhisab.data.local.ShopType

/**
 * ⭐ App-wide UI স্ট্রিং — ভাষা অনুযায়ী [BengaliStrings] / [EnglishStrings]
 * ব্যবহার করুন কম্পোজেবলে: LocalStrings.current.xxx
 */
interface AppStrings {
    // ── ভাষা কোড (UnitConverter.dateShort ইত্যাদি নন-কম্পোজেবল হেল্পারে পাস করার জন্য) ──
    val code: String

    // ── Home ──
    val homeHeadline: String
    val history: String
    val settings: String
    val totalDueLabel: String
    val searchPlaceholder: String
    val filterAll: String
    val settledLabel: String
    val noShopsYetTitle: String
    val noShopsYetSubtitle: String
    val addFirstShopButton: String
    val newShop: String

    // ── Shop types ──
    val shopTypeTea: String
    val shopTypeHardwareElectric: String
    val shopTypeKirana: String
    val shopTypeVegetable: String
    val shopTypeFishMeat: String
    val shopTypeBakerySweets: String
    val shopTypePharmacy: String
    val shopTypeCosmetics: String
    val shopTypeStationery: String
    val shopTypeXeroxPrinting: String
    val shopTypeWood: String
    val shopTypeGarments: String
    val shopTypeOther: String

    // ── Common ──
    val back: String
    val cancel: String
    val save: String

    // ── Add shop ──
    val shopNameLabel: String
    val shopNamePlaceholder: String
    val phoneLabel: String
    val shopTypeLabel: String
    val saveShopButton: String
    val errorNameRequired: String
    val errorTypeRequired: String

    // ── Shop detail ──
    val dueLabel: String
    val noTransactionsYet: String
    val creditButton: String
    val paymentButton: String
    val pdfExport: String
    val archive: String
    val deleteShopAction: String
    val archiveConfirmTitle: String
    val archiveConfirmText: String
    val deleteConfirmTitle: String
    val deleteConfirmText: String
    val yesDelete: String
    val yesArchive: String
    val txnDeletedSnackbar: String
    val undo: String
    val pdfFailPrefix: String
    val shareKhata: String
    val creditFallback: String
    val paymentFallback: String
    val deleteTxnAction: String

    // ── Entry sheet ──
    val productNameLabel: String
    val quantityLabel: String
    val unitLabel: String
    val pricePerUnitLabel: String
    val totalPrefix: String
    val noteLabel: String
    val cash: String
    val bkash: String
    val bank: String
    val invalidAmountError: String

    // ── CFT calculator ──
    val cftCalculatorTitle: String
    val lengthLabel: String
    val widthLabel: String
    val heightLabel: String
    val rateLabel: String
    val applyToEntryButton: String

    // ── Settings ──
    val settingsTitle: String
    val security: String
    val pinLockOn: String
    val pinLockOff: String
    val changePin: String
    val reminderTitle: String
    val reminderDesc: String
    val about: String
    val aboutLine: String
    val versionLine: String
    val setPinTitle: String
    val newPinLabel: String
    val confirmPinLabel: String
    val pinSetupError: String
    val removePinTitle: String
    val removePinText: String
    val yesTurnOff: String
    val no: String
    val languageTitle: String
    val languageBengaliOption: String
    val languageEnglishOption: String

    // ── History ──
    val noArchivedShops: String
    val noSettledShops: String

    // ── Lock screen ──
    val setupPinTitle: String
    val unlockPinTitle: String
    val pinLabel: String
    val pinDigitsError: String
    val pinsDontMatchError: String
    val wrongPinError: String
    val savePinButton: String
    val unlockButton: String

    // ── PDF ──
    val pdfHeaderTitle: String
    val pdfFullKhataSuffix: String
    val pdfShopLabel: String
    val pdfPhoneLabel: String
    val pdfCreatedLabel: String
    val pdfColDate: String
    val pdfColDesc: String
    val pdfTotalCredit: String
    val pdfTotalPayment: String
    val pdfCurrentDue: String
    val pdfFooter: String
}

object BengaliStrings : AppStrings {
    override val code = "bn"
    override val homeHeadline = "ধার হিসাব"
    override val history = "হিস্ট্রি"
    override val settings = "সেটিংস"
    override val totalDueLabel = "মোট বাকি আছে"
    override val searchPlaceholder = "দোকান/ফোন খুঁজুন..."
    override val filterAll = "সব"
    override val settledLabel = "পরিশোধিত"
    override val noShopsYetTitle = "কোনো দোকান নেই এখনো"
    override val noShopsYetSubtitle = "প্রথম দোকান যোগ করে খাতা শুরু করুন"
    override val addFirstShopButton = "🏪 প্রথম দোকান যোগ করুন"
    override val newShop = "নতুন দোকান"

    override val shopTypeTea = "চায়ের দোকান"
    override val shopTypeHardwareElectric = "হার্ডওয়্যার ও ইলেকট্রিক"
    override val shopTypeKirana = "মুদি দোকান"
    override val shopTypeVegetable = "কাঁচাবাজার/সবজি"
    override val shopTypeFishMeat = "মাছ ও মাংস"
    override val shopTypeBakerySweets = "বেকারি ও মিষ্টি"
    override val shopTypePharmacy = "ওষুধের দোকান"
    override val shopTypeCosmetics = "প্রসাধন সামগ্রী"
    override val shopTypeStationery = "স্টেশনারি"
    override val shopTypeXeroxPrinting = "জেরক্স ও প্রিন্টিং"
    override val shopTypeWood = "কাঠের দোকান"
    override val shopTypeGarments = "পোশাক"
    override val shopTypeOther = "অন্যান্য"

    override val back = "ফিরে যান"
    override val cancel = "বাতিল"
    override val save = "সেভ করুন"

    override val shopNameLabel = "দোকানের নাম *"
    override val shopNamePlaceholder = "যেমন: কাঠ মহল"
    override val phoneLabel = "ফোন নম্বর (ঐচ্ছিক)"
    override val shopTypeLabel = "দোকানের ধরন *"
    override val saveShopButton = "দোকান সেভ করুন"
    override val errorNameRequired = "দোকানের নাম লিখুন"
    override val errorTypeRequired = "দোকানের ধরন বেছে নিন"

    override val dueLabel = "বাকি আছে"
    override val noTransactionsYet = "এখনো কোনো লেনদেন নেই"
    override val creditButton = "🔴 ধার নিলাম"
    override val paymentButton = "🟢 জমা দিলাম"
    override val pdfExport = "PDF এক্সপোর্ট"
    override val archive = "আর্কাইভ"
    override val deleteShopAction = "দোকান ডিলিট করুন"
    override val archiveConfirmTitle = "দোকান আর্কাইভ করবেন?"
    override val archiveConfirmText = "আর্কাইভ করলে হোম লিস্ট থেকে সরে যাবে — হিস্ট্রিতে পাবেন।"
    override val deleteConfirmTitle = "দোকান স্থায়ীভাবে ডিলিট করবেন?"
    override val deleteConfirmText = "এই দোকান আর এর সব লেনদেন চিরতরে মুছে যাবে। এটি আর ফিরে পাওয়া যাবে না। আর্কাইভ করলে বরং হিস্ট্রিতে থেকে যেত — নিশ্চিত হয়ে এগোন।"
    override val yesDelete = "হ্যাঁ, ডিলিট করুন"
    override val yesArchive = "আর্কাইভ"
    override val txnDeletedSnackbar = "লেনদেন মুছে ফেলা হয়েছে"
    override val undo = "আনডু"
    override val pdfFailPrefix = "PDF তৈরি ব্যর্থ: "
    override val shareKhata = "খাতা শেয়ার করুন"
    override val creditFallback = "ধার"
    override val paymentFallback = "জমা"
    override val deleteTxnAction = "মুছুন"

    override val productNameLabel = "পণ্যের নাম (ঐচ্ছিক)"
    override val quantityLabel = "পরিমাণ"
    override val unitLabel = "একক"
    override val pricePerUnitLabel = "দাম/একক"
    override val totalPrefix = "মোট: "
    override val noteLabel = "নোট (ঐচ্ছিক)"
    override val cash = "নগদ"
    override val bkash = "বিকাশ"
    override val bank = "ব্যাংক"
    override val invalidAmountError = "সঠিক টাকার পরিমাণ দিন"

    override val cftCalculatorTitle = "🪵 CFT ক্যালকুলেটর"
    override val lengthLabel = "দৈর্ঘ্য (ইঞ্চি)"
    override val widthLabel = "প্রস্থ"
    override val heightLabel = "উচ্চতা"
    override val rateLabel = "রেট /cft (৳)"
    override val applyToEntryButton = "হিসাব এন্ট্রিতে বসাও"

    override val settingsTitle = "সেটিংস"
    override val security = "নিরাপত্তা"
    override val pinLockOn = "PIN লক চালু আছে"
    override val pinLockOff = "PIN লক বন্ধ আছে"
    override val changePin = "PIN পরিবর্তন করুন"
    override val reminderTitle = "বকেয়া রিমাইন্ডার"
    override val reminderDesc = "প্রতিদিন বকেয়ার কথা মনে করিয়ে দেবে"
    override val about = "সম্পর্কে"
    override val aboutLine = "উধার হিসাব — দোকানের বাকির খাতা"
    override val versionLine = "সংস্করণ 1.0"
    override val setPinTitle = "PIN সেট করুন"
    override val newPinLabel = "নতুন PIN"
    override val confirmPinLabel = "PIN আবার লিখুন"
    override val pinSetupError = "PIN মিলছে না (কমপক্ষে ৪ ডিজিট)"
    override val removePinTitle = "PIN লক বন্ধ করবেন?"
    override val removePinText = "অ্যাপ খোলার সময় আর PIN চাওয়া হবে না।"
    override val yesTurnOff = "হ্যাঁ, বন্ধ করুন"
    override val no = "না"
    override val languageTitle = "ভাষা"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val noArchivedShops = "আর্কাইভ করা দোকান নেই"
    override val noSettledShops = "পরিশোধিত দোকান নেই"

    override val setupPinTitle = "৪-ডিজিটের পিন সেট করুন"
    override val unlockPinTitle = "পিন দিয়ে আনলক করুন"
    override val pinLabel = "পিন"
    override val pinDigitsError = "৪ ডিজিট দিন"
    override val pinsDontMatchError = "দুটো পিন মিলছে না"
    override val wrongPinError = "ভুল পিন — আবার চেষ্টা করুন"
    override val savePinButton = "পিন সেভ করুন"
    override val unlockButton = "আনলক"

    override val pdfHeaderTitle = "খাতা — ধার হিসাব"
    override val pdfFullKhataSuffix = "পূর্ণ খাতা"
    override val pdfShopLabel = "দোকান: "
    override val pdfPhoneLabel = "ফোন: "
    override val pdfCreatedLabel = "তৈরি: "
    override val pdfColDate = "তারিখ"
    override val pdfColDesc = "বিবরণ"
    override val pdfTotalCredit = "মোট ধার:"
    override val pdfTotalPayment = "মোট জমা:"
    override val pdfCurrentDue = "বর্তমান বাকি:"
    override val pdfFooter = "ধার হিসাব অ্যাপ দিয়ে তৈরি"
}

object EnglishStrings : AppStrings {
    override val code = "en"
    override val homeHeadline = "Udhar Hisab"
    override val history = "History"
    override val settings = "Settings"
    override val totalDueLabel = "Total due"
    override val searchPlaceholder = "Search shop/phone..."
    override val filterAll = "All"
    override val settledLabel = "Settled"
    override val noShopsYetTitle = "No shops yet"
    override val noShopsYetSubtitle = "Add your first shop to start your khata"
    override val addFirstShopButton = "🏪 Add first shop"
    override val newShop = "New shop"

    override val shopTypeTea = "Tea shop"
    override val shopTypeHardwareElectric = "Hardware & Electric"
    override val shopTypeKirana = "Grocery shop"
    override val shopTypeVegetable = "Vegetable market"
    override val shopTypeFishMeat = "Fish & meat"
    override val shopTypeBakerySweets = "Bakery & sweets"
    override val shopTypePharmacy = "Pharmacy"
    override val shopTypeCosmetics = "Cosmetics & toiletries"
    override val shopTypeStationery = "Stationery"
    override val shopTypeXeroxPrinting = "Xerox & printing"
    override val shopTypeWood = "Wood shop"
    override val shopTypeGarments = "Garments"
    override val shopTypeOther = "Other"

    override val back = "Back"
    override val cancel = "Cancel"
    override val save = "Save"

    override val shopNameLabel = "Shop name *"
    override val shopNamePlaceholder = "e.g. Wood Mahal"
    override val phoneLabel = "Phone number (optional)"
    override val shopTypeLabel = "Shop type *"
    override val saveShopButton = "Save shop"
    override val errorNameRequired = "Enter the shop name"
    override val errorTypeRequired = "Choose a shop type"

    override val dueLabel = "Due"
    override val noTransactionsYet = "No transactions yet"
    override val creditButton = "🔴 Credit taken"
    override val paymentButton = "🟢 Payment given"
    override val pdfExport = "Export PDF"
    override val archive = "Archive"
    override val deleteShopAction = "Delete shop"
    override val archiveConfirmTitle = "Archive this shop?"
    override val archiveConfirmText = "It'll be removed from the home list — you can still find it in History."
    override val deleteConfirmTitle = "Permanently delete this shop?"
    override val deleteConfirmText = "This shop and all its transactions will be deleted forever and cannot be recovered. Archiving instead would keep it in History — please confirm before continuing."
    override val yesDelete = "Yes, delete"
    override val yesArchive = "Archive"
    override val txnDeletedSnackbar = "Transaction deleted"
    override val undo = "Undo"
    override val pdfFailPrefix = "PDF generation failed: "
    override val shareKhata = "Share khata"
    override val creditFallback = "Credit"
    override val paymentFallback = "Payment"
    override val deleteTxnAction = "Delete"

    override val productNameLabel = "Product name (optional)"
    override val quantityLabel = "Quantity"
    override val unitLabel = "Unit"
    override val pricePerUnitLabel = "Price/unit"
    override val totalPrefix = "Total: "
    override val noteLabel = "Note (optional)"
    override val cash = "Cash"
    override val bkash = "bKash"
    override val bank = "Bank"
    override val invalidAmountError = "Enter a valid amount"

    override val cftCalculatorTitle = "🪵 CFT calculator"
    override val lengthLabel = "Length (in)"
    override val widthLabel = "Width"
    override val heightLabel = "Height"
    override val rateLabel = "Rate /cft (৳)"
    override val applyToEntryButton = "Apply to entry"

    override val settingsTitle = "Settings"
    override val security = "Security"
    override val pinLockOn = "PIN lock is on"
    override val pinLockOff = "PIN lock is off"
    override val changePin = "Change PIN"
    override val reminderTitle = "Due reminders"
    override val reminderDesc = "Reminds you about dues every day"
    override val about = "About"
    override val aboutLine = "Udhar Hisab — a shop credit ledger"
    override val versionLine = "Version 1.0"
    override val setPinTitle = "Set PIN"
    override val newPinLabel = "New PIN"
    override val confirmPinLabel = "Re-enter PIN"
    override val pinSetupError = "PINs don't match (at least 4 digits)"
    override val removePinTitle = "Turn off PIN lock?"
    override val removePinText = "You won't be asked for a PIN when opening the app anymore."
    override val yesTurnOff = "Yes, turn off"
    override val no = "No"
    override val languageTitle = "Language"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val noArchivedShops = "No archived shops"
    override val noSettledShops = "No settled shops"

    override val setupPinTitle = "Set a 4-digit PIN"
    override val unlockPinTitle = "Unlock with PIN"
    override val pinLabel = "PIN"
    override val pinDigitsError = "Enter 4 digits"
    override val pinsDontMatchError = "PINs don't match"
    override val wrongPinError = "Wrong PIN — try again"
    override val savePinButton = "Save PIN"
    override val unlockButton = "Unlock"

    override val pdfHeaderTitle = "Khata — Udhar Hisab"
    override val pdfFullKhataSuffix = "Full khata"
    override val pdfShopLabel = "Shop: "
    override val pdfPhoneLabel = "Phone: "
    override val pdfCreatedLabel = "Created: "
    override val pdfColDate = "Date"
    override val pdfColDesc = "Description"
    override val pdfTotalCredit = "Total credit:"
    override val pdfTotalPayment = "Total payment:"
    override val pdfCurrentDue = "Current due:"
    override val pdfFooter = "Made with Udhar Hisab app"
}

/** ভাষা কোড ("bn"/"en") → স্ট্রিং সেট */
fun stringsFor(languageCode: String): AppStrings =
    if (languageCode == "en") EnglishStrings else BengaliStrings

val LocalStrings = staticCompositionLocalOf<AppStrings> { BengaliStrings }

/** ShopType-এর অনুবাদিত নাম */
fun ShopType.displayName(strings: AppStrings): String = when (this) {
    ShopType.TEA -> strings.shopTypeTea
    ShopType.HARDWARE_ELECTRIC -> strings.shopTypeHardwareElectric
    ShopType.KIRANA -> strings.shopTypeKirana
    ShopType.VEGETABLE -> strings.shopTypeVegetable
    ShopType.FISH_MEAT -> strings.shopTypeFishMeat
    ShopType.BAKERY_SWEETS -> strings.shopTypeBakerySweets
    ShopType.PHARMACY -> strings.shopTypePharmacy
    ShopType.COSMETICS -> strings.shopTypeCosmetics
    ShopType.STATIONERY -> strings.shopTypeStationery
    ShopType.XEROX_PRINTING -> strings.shopTypeXeroxPrinting
    ShopType.WOOD -> strings.shopTypeWood
    ShopType.GARMENTS -> strings.shopTypeGarments
    ShopType.OTHER -> strings.shopTypeOther
}
