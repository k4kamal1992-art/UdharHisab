package com.udharhisab.ui.strings

import androidx.compose.runtime.staticCompositionLocalOf
import com.udharhisab.data.local.ShopType

/** হেল্প সেন্টারের একটা প্রশ্ন-উত্তর */
data class FaqItem(val question: String, val answer: String)

/**
 * ⭐ App-wide UI স্ট্রিং — ভাষা অনুযায়ী [BengaliStrings] / [EnglishStrings]
 * ব্যবহার করুন কম্পোজেবলে: LocalStrings.current.xxx
 */
interface AppStrings {
    // ── ভাষা কোড (UnitConverter.dateShort ইত্যাদি নন-কম্পোজেবল হেল্পারে পাস করার জন্য) ──
    val code: String
    val moreAdFree: String
    val moreHintAdFree: String
    val adFreeDialogTitle: String
    val adFreeDialogMessage: String
    val adFreeBuyButton: String
    val adFreeRestoreButton: String
    val adFreeActiveLabel: String
    val adFreeUnavailable: String
    val adSponsoredLabel: String
    val moreAdPrivacy: String
    val moreHintAdPrivacy: String
    val faqItems: List<FaqItem>
    val helpCenterTitle: String
    val helpSearchPlaceholder: String
    val noFaqResultsMessage: String

    // ── Home ──
    val homeHeadline: String
    val history: String
    val settings: String
    val totalDueLabel: String
    val thisMonthCreditLabel: String
    val thisMonthPaymentLabel: String
    val searchPlaceholder: String
    val filterAll: String
    val settledLabel: String
    val noShopsYetTitle: String
    val noShopsYetSubtitle: String
    val addFirstShopButton: String
    val newShop: String

    // ── Shop types ──
    val shopTypeTea: String
    val shopTypeHardwareElectric: String
    val shopTypeKirana: String
    val shopTypeVegetable: String
    val shopTypeFishMeat: String
    val shopTypeBakerySweets: String
    val shopTypePharmacy: String
    val shopTypeCosmetics: String
    val shopTypeStationery: String
    val shopTypeXeroxPrinting: String
    val shopTypeWood: String
    val shopTypeGarments: String
    val shopTypeOther: String

    // ── Common ──
    val back: String
    val cancel: String
    val save: String

    // ── Add shop ──
    val shopNameLabel: String
    val shopNamePlaceholder: String
    val phoneLabel: String
    val shopTypeLabel: String
    val saveShopButton: String
    val errorNameRequired: String
    val errorTypeRequired: String

    // ── Shop detail ──
    val dueLabel: String
    val noTransactionsYet: String
    val creditButton: String
    val paymentButton: String
    val pdfExport: String
    val archive: String
    val deleteShopAction: String
    val archiveConfirmTitle: String
    val archiveConfirmText: String
    val deleteConfirmTitle: String
    val deleteConfirmText: String
    val yesDelete: String
    val yesArchive: String
    val txnDeletedSnackbar: String
    val undo: String
    val pdfFailPrefix: String
    val shareKhata: String
    val creditFallback: String
    val paymentFallback: String
    val deleteTxnAction: String

    // ── Entry sheet ──
    val productNameLabel: String
    val quantityLabel: String
    val unitLabel: String
    val pricePerUnitLabel: String
    val totalPrefix: String
    val amountLabel: String
    val orEnterAmountLabel: String
    val noteLabel: String
    val cash: String
    val bkash: String
    val bank: String
    val invalidAmountError: String

    // ── CFT calculator ──
    val cftCalculatorTitle: String
    val lengthLabel: String
    val widthLabel: String
    val heightLabel: String
    val rateLabel: String
    val applyToEntryButton: String

    // ── Settings ──
    val settingsTitle: String
    val security: String
    val pinLockOn: String
    val pinLockOff: String
    val changePin: String
    val reminderTitle: String
    val reminderDesc: String
    val about: String
    val aboutLine: String
    val aboutDescription: String
    val aboutTagline: String
    val versionLine: String
    val setPinTitle: String
    val newPinLabel: String
    val confirmPinLabel: String
    val pinSetupError: String
    val removePinTitle: String
    val removePinText: String
    val yesTurnOff: String
    val no: String
    val languageTitle: String
    val languageBengaliOption: String
    val languageEnglishOption: String

    // ── More: Notification bottom sheet ──
    val notifSheetTitle: String
    val notifSheetSubtitle: String
    val notifDueReminderOption: String
    val notifWeeklySummaryOption: String
    val notifAppNewsOption: String

    // ── More: Language / Theme sheet subtitles ──
    val langSheetSubtitle: String
    val themeSheetSubtitle: String
    val moreHintBackupRestore: String
    val notesTitle: String
    val notesSearchPlaceholder: String
    val addNoteButton: String
    val noNotesYetTitle: String
    val noNotesYetSubtitle: String
    val deleteNoteConfirmTitle: String
    val deleteNoteConfirmMessage: String
    val noteTitlePlaceholder: String
    val noteContentPlaceholder: String
    val untitledNote: String
    val notificationInboxTitle: String
    val moreNotificationHistory: String
    val moreHintNotificationHistory: String
    val noNotificationsYetTitle: String
    val noNotificationsYetSubtitle: String
    val notifCreditMessage: String
    val notifPaymentMessage: String
    val moreQuickCalculator: String
    val moreHintQuickCalculator: String
    val calcGeneralTab: String
    val calcPercentTab: String
    val calcConversionTab: String
    val calcComingSoonInTab: String
    val percentOfTitle: String
    val percentOfValueLabel: String
    val percentOfPercentLabel: String
    val percentIsWhatTitle: String
    val percentIsWhatXLabel: String
    val percentIsWhatYLabel: String
    val percentChangeTitle: String
    val percentChangeBaseLabel: String
    val percentChangePercentLabel: String
    val increaseOption: String
    val decreaseOption: String
    val resultLabel: String
    val weightCategory: String
    val lengthCategory: String
    val volumeCategory: String
    val fromLabel: String
    val toLabel: String
    val enterValueHint: String
    val backupNowButton: String
    val backupNowHint: String
    val restoreButton: String
    val restoreShopAction: String
    val restoreHint: String
    val lastBackupLabel: String
    val noBackupYetLabel: String
    val backupSuccessMessage: String
    val backupFailPrefix: String
    val restoreConfirmTitle: String
    val restoreConfirmMessage: String
    val restoreSuccessMessage: String
    val restoreFailPrefix: String
    val dataSafeNote: String
    val moreHintExportShare: String
    val moreHintNotifications: String
    val moreHintLanguage: String
    val moreUserMode: String
    val moreHintUserMode: String
    val moreHintSecurityPrivacy: String
    val moreHintAppearance: String
    val moreHintRateFeedback: String
    val moreHintAbout: String

    // ── Security & Privacy page ──
    val securityPrivacyTitle: String
    val pinSectionTitle: String
    val pinSectionDesc: String
    val fingerprintTitle: String
    val fingerprintDesc: String
    val fingerprintUnavailable: String
    val lockImmediatelyTitle: String
    val lockImmediatelyDesc: String

    // ── Rating & Feedback page ──
    val rateTitle: String
    val rateSubtitle: String
    val rateStarsPrompt: String
    val rateThanksMessage: String
    val feedbackPromptLow: String
    val feedbackPlaceholder: String
    val feedbackSubmit: String
    val feedbackThanks: String

    // ── About page ──
    val aboutPageTitle: String
    val aboutVersionPrefix: String
    val aboutDeveloperLabel: String
    val aboutDeveloperName: String
    val aboutPrivacyPolicy: String
    val privacyPolicyEffectiveDate: String
    val privacyPolicyBody: String
    val aboutShareApp: String
    val aboutShareText: String

    // ── History ──
    val noArchivedShops: String
    val noSettledShops: String

    // ── Lock screen ──
    val setupPinTitle: String
    val unlockPinTitle: String
    val pinLabel: String
    val pinDigitsError: String
    val pinsDontMatchError: String
    val wrongPinError: String
    val savePinButton: String
    val unlockButton: String

    // ── PDF ──
    val pdfHeaderTitle: String
    val pdfFullKhataSuffix: String
    val pdfShopLabel: String
    val pdfPhoneLabel: String
    val pdfCreatedLabel: String
    val pdfColDate: String
    val pdfColDesc: String
    val pdfTotalCredit: String
    val pdfTotalPayment: String
    val pdfCurrentDue: String
    val pdfFooter: String

    // ── Bottom nav ──
    val navHome: String
    val navHistory: String
    val navReports: String
    val navMore: String

    // ── Transaction history (new History tab) ──
    val historyFilterAllShops: String
    val historyFilterAllTypes: String
    val historyFilterCreditOnly: String
    val historyFilterPaymentOnly: String
    val historyNoTxnsFound: String
    val viewArchivedAction: String

    // ── Reports ──
    val reportsTitle: String
    val periodLabel: String
    val period7d: String
    val period15d: String
    val period30d: String
    val period3m: String
    val period1y: String
    val reportTotalCredit: String
    val reportTotalPayment: String
    val reportCurrentDue: String
    val reportTxnCount: String
    val reportChartTitle: String
    val reportShopWiseTitle: String
    val reportAgingTitle: String
    val reportAging0to7: String
    val reportAging7to15: String
    val reportAging15to30: String
    val reportAging30plus: String
    val reportRecentPaymentsTitle: String
    val reportNoData: String
    val reportSmartSummaryPrefix: String

    // ── More ──
    val moreTitle: String
    val moreBackupRestore: String
    val moreExportShare: String
    val moreNotifications: String
    val moreLanguage: String
    val moreSecurityPrivacy: String
    val moreAppearance: String
    val moreRateFeedback: String
    val moreAbout: String
    val comingSoonMessage: String

    // ── Appearance (Settings) ──
    val appearanceTitle: String
    val themeLight: String
    val themeDark: String
    val themeSystem: String

    // ── Credit entry screen (নতুন পূর্ণ-স্ক্রিন) ──
    val creditPageTitle: String
    val accountingTypeLabel: String
    val directMoneyMode: String
    val productMode: String
    val directMoneyAmountLabel: String
    val previousDueLabel: String
    val newCreditLabel: String
    val newTotalDueLabel: String
    val addCreditButton: String
    val addMoreProductButton: String
    val totalNewCreditLabel: String
    val editAction: String
    val itemsCountSuffix: String

    // ── Payment entry screen (নতুন পূর্ণ-স্ক্রিন) ──
    val paymentPageTitle: String
    val currentDueLabel: String
    val howMuchPaymentLabel: String
    val fullPaymentButton: String
    val dueAfterPaymentLabel: String
    val addPaymentButton: String
    val overpaymentBlockedMessage: String
    val fullyPaidCelebration: String

    // ── Timber calculator (কাঠের হিসাব) ──
    val woodCalculatorTitle: String
    val woodTypeLabel: String
    val sawnWoodOption: String
    val roundWoodOption: String
    val lengthFtLabel: String
    val widthInLabel: String
    val thicknessInLabel: String
    val girthInLabel: String
    val pieceCountLabel: String
    val perPieceCftLabel: String
    val totalWoodCftLabel: String
    val perCftPriceLabel: String
    val totalWoodValueLabel: String
    val addWoodCalcButton: String
    val woodNameLabel: String
    val addMoreWoodProductButton: String
    val addedItemsHeader: String

    // ── PDF অপশন ডায়ালগ ──
    val pdfOptionsTitle: String
    val pdfPeriodLabel: String
    val pdfThisMonth: String
    val pdfLastMonth: String
    val pdfLast3Months: String
    val pdfCustomRange: String
    val pdfShopLabelOption: String
    val pdfAllShopsOption: String
    val pdfContentLabel: String
    val pdfContentFull: String
    val pdfContentSummaryOnly: String
    val pdfContentTxnsOnly: String
    val pdfFormatLabel: String
    val pdfFormatA4: String
    val pdfFormatReceipt: String
    val pdfGenerateButton: String
    val pdfFromDateLabel: String
    val pdfToDateLabel: String

    // ── PDF-এ আঁকা কনটেন্ট ──
    val pdfReportNumberLabel: String
    val pdfShopBoxLabel: String
    val pdfDateBoxLabel: String
    val pdfDaysOfRecordsSuffix: String
    val pdfWeeklyChartTitle: String
    val pdfFinalDueLabel: String
    val pdfShopSignatureLabel: String
    val pdfCustomerSignatureLabel: String
    val pdfAllShopsReportTitle: String
    val pdfPageLabel: String

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    val moreShopProfile: String
    val moreHintShopProfile: String
    val shopProfileTitle: String
    val shopProfileIntro: String
    val shopBusinessNameLabel: String
    val shopBusinessAddressLabel: String
    val shopBusinessPhoneLabel: String
    val countryCodeLabel: String
    val shopLogoLabel: String
    val shopLogoPick: String
    val shopLogoRemove: String
    val promptAfterEntryLabel: String
    val saveProfileButton: String
    val profileSavedMessage: String
    val errorShopNameForPdf: String
    val reminderSendAction: String
    val reminderDialogTitle: String
    val reminderDialogSubtitle: String
    val reminderMessageLabel: String
    val reminderWhatsapp: String
    val reminderSms: String
    val reminderSkip: String
    val reminderNoPhone: String
    val reminderAppMissing: String
    val reminderShopFallback: String
    val reminderMsgDue: String
    val reminderMsgCredit: String
    val reminderMsgPayment: String
    val reminderMsgSettled: String
    val pdfActionLabel: String
    val pdfActionShare: String
    val pdfActionSave: String
    val pdfActionPrint: String
    val pdfBrandingOption: String
    val pdfBrandingMissing: String
    val pdfSavedMessage: String
    val pdfSaveFailed: String

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    val setupRoleTitle: String
    val setupProfileTitle: String
    val setupProfileSubtitle: String
    val setupContinue: String
    val setupSkip: String
    val setupFinish: String

    val pickFromContacts: String

    val pdfColQtyPrice: String
    val pdfColItemTotal: String

    val pdfWoodSawn: String
    val pdfWoodRound: String
    val pdfWoodFormula: String
    val pdfWoodTotalWord: String

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    val pdfMemoTitle: String
    val pdfMemoSubtitle: String
    val pdfBillNo: String
    val pdfDateTitle: String
    val pdfPeriodTitle: String
    val pdfSeller: String
    val pdfBuyer: String
    val pdfAddressLabel: String
    val pdfColSl: String
    val pdfColPieces: String
    val pdfColCft: String
    val pdfColRate: String
    val pdfColAmountRs: String
    val pdfColQty: String
    val pdfColUnitPrice: String
    val pdfSecSawn: String
    val pdfSecRound: String
    val pdfSecOther: String
    val pdfSecCashCredit: String
    val pdfSecPayments: String
    val pdfBadgeSawn: String
    val pdfBadgeRound: String
    val pdfSawnTotal: String
    val pdfRoundTotal: String
    val pdfTableTotal: String
    val pdfSumBill: String
    val pdfSumPaid: String
    val pdfSumDue: String
    val pdfWordsTitle: String
    val pdfSellerSign: String
    val pdfSellerSignSub: String
    val pdfBuyerSign: String
    val pdfBuyerSignSub: String
    val pdfMemoFooter: String

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    val pdfSummaryTitle: String
    val moveShopAction: String
    val moveShopTitle: String
    val moveToShopkeeperMsg: String
    val moveToCustomerMsg: String
    val moveShopConfirm: String
}

object BengaliStrings : AppStrings {
    override val code = "bn"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "বিজ্ঞাপনমুক্ত করুন"
    override val moreHintAdFree = "একবার কিনুন, আর বিজ্ঞাপন দেখবেন না"
    override val adFreeDialogTitle = "বিজ্ঞাপনমুক্ত অ্যাপ"
    override val adFreeDialogMessage = "একবার টাকা দিলে সব বিজ্ঞাপন চিরতরে বন্ধ হয়ে যাবে। অ্যাপ উন্নয়নে সাহায্যের জন্য ধন্যবাদ!"
    override val adFreeBuyButton = "কিনুন"
    override val adFreeRestoreButton = "আগের কেনা ফিরিয়ে আনুন"
    override val adFreeActiveLabel = "আপনার অ্যাপ বিজ্ঞাপনমুক্ত ✓"
    override val adFreeUnavailable = "এখন কেনা যাচ্ছে না — একটু পরে আবার চেষ্টা করুন"
    override val adSponsoredLabel = "বিজ্ঞাপন"
    override val moreAdPrivacy = "বিজ্ঞাপনের পছন্দ"
    override val moreHintAdPrivacy = "কোন ধরনের বিজ্ঞাপন দেখবেন তা ঠিক করুন"
    override val helpCenterTitle = "সাহায্য কেন্দ্র"
    override val helpSearchPlaceholder = "প্রশ্ন খুঁজুন..."
    override val noFaqResultsMessage = "কোনো মিল পাওয়া যায়নি"
    override val faqItems = listOf(
        FaqItem(
            "কিভাবে নতুন দোকান যোগ করব?",
            "হোম স্ক্রিনের নিচে '+' বাটনে ট্যাপ করুন, দোকানের নাম, ফোন নম্বর (ঐচ্ছিক) আর ধরন দিয়ে 'সংরক্ষণ করুন' চাপুন।"
        ),
        FaqItem(
            "কিভাবে ধার নেব বা পরিশোধ করব?",
            "দোকানের বিস্তারিত পেজে গিয়ে 'ধার নিন' বা 'পরিশোধ' বাটনে ট্যাপ করুন, টাকার পরিমাণ দিয়ে যোগ করুন।"
        ),
        FaqItem(
            "বায়োমেট্রিক লক কিভাবে চালু/বন্ধ করব?",
            "আরও → নিরাপত্তা ও গোপনীয়তা পেজে গিয়ে 'বায়োমেট্রিক লক' টগল করুন। ডিভাইসে ফিঙ্গারপ্রিন্ট/ফেস আনলক সেট করা থাকতে হবে।"
        ),
        FaqItem(
            "ডেটা ব্যাকআপ কিভাবে নেব?",
            "আরও → ব্যাকআপ ও রিস্টোর পেজে গিয়ে 'এখনই ব্যাকআপ নিন' চাপুন। একটা JSON ফাইল তৈরি হবে, যেটা আপনি ফোনে বা ক্লাউডে সংরক্ষণ করতে পারবেন।"
        ),
        FaqItem(
            "ব্যাকআপ থেকে ডেটা কিভাবে ফিরিয়ে আনব?",
            "আরও → ব্যাকআপ ও রিস্টোর পেজে 'ব্যাকআপ থেকে রিস্টোর করুন' চাপুন, আগের JSON ফাইল বেছে নিন। এটি বর্তমান সব ডেটা মুছে ব্যাকআপ দিয়ে replace করবে, তাই সাবধানে করুন।"
        ),
        FaqItem(
            "একটা দোকান মুছে ফেললে কি আবার ফিরে পাব?",
            "আর্কাইভ করলে দোকানটা হিস্ট্রিতে থেকে যায়, পরে চাইলে ফিরিয়ে আনতে পারবেন। কিন্তু স্থায়ীভাবে ডিলিট করলে আর ফেরানো যাবে না।"
        ),
        FaqItem(
            "রিপোর্ট PDF কিভাবে বানাব?",
            "আরও পেজে 'ব্যাকআপ ও এক্সপোর্ট'-এর পাশে থাকা এক্সপোর্ট অপশনে গিয়ে দোকান আর সময়সীমা বেছে PDF তৈরি করুন, তারপর শেয়ার করুন।"
        ),
        FaqItem(
            "অ্যাপের ভাষা কিভাবে বদলাব?",
            "আরও → ভাষা নির্বাচন পেজে গিয়ে বাংলা বা English বেছে 'সংরক্ষণ করুন' চাপুন।"
        )
    )
    override val homeHeadline = "উধার হিসাব"
    override val history = "হিস্ট্রি"
    override val settings = "সেটিংস"
    override val totalDueLabel = "মোট বাকি আছে"
    override val thisMonthCreditLabel = "এ মাসে বাকি"
    override val thisMonthPaymentLabel = "এ মাসে জমা"
    override val searchPlaceholder = "দোকান/ফোন খুঁজুন..."
    override val filterAll = "সব"
    override val settledLabel = "পরিশোধিত"
    override val noShopsYetTitle = "কোনো দোকান নেই এখনো"
    override val noShopsYetSubtitle = "প্রথম দোকান যোগ করে খাতা শুরু করুন"
    override val addFirstShopButton = "প্রথম দোকান যোগ করুন"
    override val newShop = "নতুন দোকান"

    override val shopTypeTea = "চায়ের দোকান"
    override val shopTypeHardwareElectric = "হার্ডওয়্যার ও ইলেকট্রিক"
    override val shopTypeKirana = "মুদি দোকান"
    override val shopTypeVegetable = "কাঁচাবাজার/সবজি"
    override val shopTypeFishMeat = "মাছ ও মাংস"
    override val shopTypeBakerySweets = "বেকারি ও মিষ্টি"
    override val shopTypePharmacy = "ওষুধের দোকান"
    override val shopTypeCosmetics = "প্রসাধন সামগ্রী"
    override val shopTypeStationery = "স্টেশনারি"
    override val shopTypeXeroxPrinting = "জেরক্স ও প্রিন্টিং"
    override val shopTypeWood = "কাঠের দোকান"
    override val shopTypeGarments = "পোশাক"
    override val shopTypeOther = "অন্যান্য"

    override val back = "ফিরে যান"
    override val cancel = "বাতিল"
    override val save = "সেভ করুন"

    override val shopNameLabel = "দোকানের নাম *"
    override val shopNamePlaceholder = "যেমন: কাঠ মহল"
    override val phoneLabel = "ফোন নম্বর (ঐচ্ছিক)"
    override val shopTypeLabel = "দোকানের ধরন *"
    override val saveShopButton = "দোকান সেভ করুন"
    override val errorNameRequired = "দোকানের নাম লিখুন"
    override val errorTypeRequired = "দোকানের ধরন বেছে নিন"

    override val dueLabel = "বাকি আছে"
    override val noTransactionsYet = "এখনো কোনো লেনদেন নেই"
    override val creditButton = "ধার নিলাম"
    override val paymentButton = "জমা দিলাম"
    override val pdfExport = "PDF এক্সপোর্ট"
    override val archive = "আর্কাইভ"
    override val deleteShopAction = "দোকান ডিলিট করুন"
    override val archiveConfirmTitle = "দোকান আর্কাইভ করবেন?"
    override val archiveConfirmText = "আর্কাইভ করলে হোম লিস্ট থেকে সরে যাবে — হিস্ট্রিতে পাবেন।"
    override val deleteConfirmTitle = "দোকান স্থায়ীভাবে ডিলিট করবেন?"
    override val deleteConfirmText = "এই দোকান আর এর সব লেনদেন চিরতরে মুছে যাবে। এটি আর ফিরে পাওয়া যাবে না। আর্কাইভ করলে বরং হিস্ট্রিতে থেকে যেত — নিশ্চিত হয়ে এগোন।"
    override val yesDelete = "হ্যাঁ, ডিলিট করুন"
    override val yesArchive = "আর্কাইভ"
    override val txnDeletedSnackbar = "লেনদেন মুছে ফেলা হয়েছে"
    override val undo = "আনডু"
    override val pdfFailPrefix = "PDF তৈরি ব্যর্থ: "
    override val shareKhata = "খাতা শেয়ার করুন"
    override val creditFallback = "ধার"
    override val paymentFallback = "জমা"
    override val deleteTxnAction = "মুছুন"

    override val productNameLabel = "পণ্যের নাম (ঐচ্ছিক)"
    override val quantityLabel = "পরিমাণ"
    override val unitLabel = "একক"
    override val pricePerUnitLabel = "দাম/একক"
    override val totalPrefix = "মোট: "
    override val amountLabel = "কত টাকা জমা দিলেন"
    override val orEnterAmountLabel = "অথবা সরাসরি টাকার পরিমাণ লিখুন"
    override val noteLabel = "নোট (ঐচ্ছিক)"
    override val cash = "নগদ"
    override val bkash = "বিকাশ"
    override val bank = "ব্যাংক"
    override val invalidAmountError = "সঠিক টাকার পরিমাণ দিন"

    override val cftCalculatorTitle = "CFT ক্যালকুলেটর"
    override val lengthLabel = "দৈর্ঘ্য (ইঞ্চি)"
    override val widthLabel = "প্রস্থ"
    override val heightLabel = "উচ্চতা"
    override val rateLabel = "রেট /cft (৳)"
    override val applyToEntryButton = "হিসাব এন্ট্রিতে বসাও"

    override val settingsTitle = "সেটিংস"
    override val security = "নিরাপত্তা"
    override val pinLockOn = "PIN লক চালু আছে"
    override val pinLockOff = "PIN লক বন্ধ আছে"
    override val changePin = "PIN পরিবর্তন করুন"
    override val reminderTitle = "বকেয়া রিমাইন্ডার"
    override val reminderDesc = "প্রতিদিন বকেয়ার কথা মনে করিয়ে দেবে"
    override val about = "সম্পর্কে"
    override val aboutLine = "উধার হিসাব — দোকানের বাকির খাতা"
    override val aboutDescription = "UdharHisab হলো দোকানের ধার-পাওনা ও লেনদেনের হিসাব সহজ, দ্রুত এবং সুশৃঙ্খলভাবে পরিচালনা করার জন্য তৈরি একটি স্মার্ট হিসাব অ্যাপ। বিভিন্ন দোকানে আপনার কত টাকা ধার আছে, কোথায় কত টাকা পরিশোধ করেছেন এবং কোন লেনদেন কখন হয়েছে—সবকিছু এক জায়গায় সুন্দরভাবে সংরক্ষণ ও পরিচালনা করতে পারবেন।\n\nঅ্যাপটির মাধ্যমে আপনি সহজেই দোকান যোগ করতে, ধার ও পরিশোধের হিসাব রাখতে, লেনদেনের ইতিহাস দেখতে, মোট বাকি ও পরিশোধের পরিমাণ জানতে এবং বিস্তারিত রিপোর্ট তৈরি করতে পারবেন। পাশাপাশি Search, Filter, Backup & Restore, App Lock, Biometric Security, Dark Mode ও Notification-এর মতো সুবিধা আপনার হিসাব ব্যবস্থাপনাকে আরও সহজ ও নিরাপদ করে।\n\nUdharHisab-এর লক্ষ্য হলো—জটিল খাতা বা কাগজের হিসাবকে একটি সহজ, আধুনিক ও নির্ভরযোগ্য ডিজিটাল ব্যবস্থায় নিয়ে আসা।"
    override val aboutTagline = "UdharHisab — সহজ হিসাব, নিশ্চিন্ত থাকুন।"
    override val versionLine = "সংস্করণ 1.0"
    override val setPinTitle = "PIN সেট করুন"
    override val newPinLabel = "নতুন PIN"
    override val confirmPinLabel = "PIN আবার লিখুন"
    override val pinSetupError = "PIN মিলছে না (কমপক্ষে 4 ডিজিট)"
    override val removePinTitle = "PIN লক বন্ধ করবেন?"
    override val removePinText = "অ্যাপ খোলার সময় আর PIN চাওয়া হবে না।"
    override val yesTurnOff = "হ্যাঁ, বন্ধ করুন"
    override val no = "না"
    override val languageTitle = "ভাষা"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "নোটিফিকেশন"
    override val notifSheetSubtitle = "কোন রিমাইন্ডার চান?"
    override val notifDueReminderOption = "বাকি পরিশোধ রিমাইন্ডার"
    override val notifWeeklySummaryOption = "সাপ্তাহিক হিসাব সারাংশ"
    override val notifAppNewsOption = "অ্যাপ নিউজ ও আপডেট"

    override val langSheetSubtitle = "অ্যাপ কোন ভাষায় চলবে?"
    override val themeSheetSubtitle = "কোন থিম পছন্দ?"

    override val securityPrivacyTitle = "নিরাপত্তা ও প্রাইভেসি"
    override val pinSectionTitle = "PIN লক"
    override val pinSectionDesc = "অ্যাপ খুললে PIN চাইবে"
    override val fingerprintTitle = "ফিঙ্গারপ্রিন্ট লক"
    override val fingerprintDesc = "PIN-এর বদলে আঙুলের ছাপ দিয়ে আনলক করুন"
    override val fingerprintUnavailable = "এই ফোনে ফিঙ্গারপ্রিন্ট সেন্সর পাওয়া যায়নি"
    override val lockImmediatelyTitle = "সাথে সাথে লক করুন"
    override val lockImmediatelyDesc = "অ্যাপ থেকে বের হয়ে আবার ঢুকলেই লক লাগবে"

    override val rateTitle = "রেটিং ও ফিডব্যাক"
    override val rateSubtitle = "উধার হিসাব আপনার কেমন লাগছে?"
    override val rateStarsPrompt = "তারা দিয়ে রেট করুন"
    override val rateThanksMessage = "ধন্যবাদ! Play Store-এ নিয়ে যাচ্ছি…"
    override val feedbackPromptLow = "কী ভালো লাগেনি? আমাদের জানান"
    override val feedbackPlaceholder = "আপনার মতামত লিখুন…"
    override val feedbackSubmit = "পাঠান"
    override val feedbackThanks = "ধন্যবাদ, আপনার মতামত পৌঁছে গেছে"

    override val aboutPageTitle = "উধার হিসাব সম্পর্কে"
    override val aboutVersionPrefix = "সংস্করণ"
    override val aboutDeveloperLabel = "ডেভেলপার"
    override val aboutDeveloperName = "উধার হিসাব টিম"
    override val aboutPrivacyPolicy = "প্রাইভেসি পলিসি"
    override val privacyPolicyEffectiveDate = "কার্যকর তারিখ: 13 সেপ্টেম্বর 2026"
    override val privacyPolicyBody = """UdharHisab আপনার দোকানের ধার-পাওনা ও লেনদেনের হিসাব সহজভাবে পরিচালনা করার জন্য তৈরি একটি personal finance/ledger application। আপনার গোপনীয়তা আমাদের কাছে গুরুত্বপূর্ণ।

1. আমরা কোন তথ্য সংগ্রহ করি

UdharHisab ব্যবহারের সময় আপনি যে তথ্যগুলো নিজে অ্যাপে প্রবেশ করান, যেমন:
• দোকানের নাম
• মোবাইল নম্বর
• দোকানের ঠিকানা বা অন্যান্য বিবরণ
• ধার ও পরিশোধের পরিমাণ
• লেনদেনের তারিখ, সময় ও নোট

2. আপনার তথ্য কীভাবে ব্যবহার করা হয়

এই তথ্যগুলো শুধুমাত্র আপনার হিসাব সংরক্ষণ, দেখানো এবং পরিচালনার উদ্দেশ্যে ব্যবহার করা হয়। আপনার অনুমতি ছাড়া আপনার ব্যক্তিগত হিসাবের তথ্য কোনো বিজ্ঞাপনদাতা বা তৃতীয় পক্ষের কাছে বিক্রি বা শেয়ার করা হবে না।

3. Data Storage

আপনার হিসাবের তথ্য অ্যাপের প্রয়োজন অনুযায়ী আপনার ডিভাইসে সংরক্ষিত হতে পারে। আপনি Backup & Restore সুবিধা ব্যবহার করলে backup-এর তথ্য নির্বাচিত storage/cloud service-এর মাধ্যমে সংরক্ষিত হতে পারে।

4. App Security

আপনার হিসাবের তথ্য সুরক্ষিত রাখতে App Lock, PIN এবং Biometric Authentication-এর মতো নিরাপত্তা সুবিধা প্রদান করা হতে পারে।

5. তথ্য শেয়ার করা

আইনগত প্রয়োজন ছাড়া আপনার ব্যক্তিগত হিসাবের তথ্য আমরা তৃতীয় পক্ষের কাছে বিক্রি, ভাড়া বা বাণিজ্যিকভাবে শেয়ার করি না।

6. আপনার নিয়ন্ত্রণ

আপনি অ্যাপের মধ্যে সংরক্ষিত আপনার তথ্য দেখতে, পরিবর্তন করতে বা প্রয়োজন অনুযায়ী মুছে ফেলতে পারবেন।

7. Third-Party Services

অ্যাপের কিছু সুবিধার জন্য তৃতীয় পক্ষের service ব্যবহার করা হলে তাদের নিজস্ব Privacy Policy প্রযোজ্য হতে পারে।

8. শিশুদের গোপনীয়তা

UdharHisab শিশুদের ব্যক্তিগত তথ্য সংগ্রহ করার উদ্দেশ্যে তৈরি নয়।

9. Privacy Policy পরিবর্তন

প্রয়োজনে আমরা এই Privacy Policy পরিবর্তন বা আপডেট করতে পারি। নতুন Policy এই পেজে প্রকাশ করা হবে।

10. যোগাযোগ

Privacy Policy বা আপনার তথ্য সম্পর্কিত কোনো প্রশ্ন থাকলে আমাদের সঙ্গে যোগাযোগ করুন।

UdharHisab
সহজ হিসাব, নিশ্চিন্ত থাকুন।"""
    override val aboutShareApp = "শেয়ার করুন"
    override val aboutShareText = "উধার হিসাব — দোকানের বাকির খাতা অ্যাপটা ব্যবহার করে দেখুন!"

    override val noArchivedShops = "আর্কাইভ করা দোকান নেই"
    override val noSettledShops = "পরিশোধিত দোকান নেই"

    override val setupPinTitle = "4-ডিজিটের পিন সেট করুন"
    override val unlockPinTitle = "পিন দিয়ে আনলক করুন"
    override val pinLabel = "পিন"
    override val pinDigitsError = "4 ডিজিট দিন"
    override val pinsDontMatchError = "দুটো পিন মিলছে না"
    override val wrongPinError = "ভুল পিন — আবার চেষ্টা করুন"
    override val savePinButton = "পিন সেভ করুন"
    override val unlockButton = "আনলক"

    override val pdfHeaderTitle = "খাতা — উধার হিসাব"
    override val pdfFullKhataSuffix = "পূর্ণ খাতা"
    override val pdfShopLabel = "দোকান: "
    override val pdfPhoneLabel = "ফোন: "
    override val pdfCreatedLabel = "তৈরি: "
    override val pdfColDate = "তারিখ/সময়"
    override val pdfColDesc = "বিবরণ"
    override val pdfTotalCredit = "মোট ধার:"
    override val pdfTotalPayment = "মোট জমা:"
    override val pdfCurrentDue = "বর্তমান বাকি:"
    override val pdfFooter = "ধার হিসাব অ্যাপ দিয়ে তৈরি"

    override val navHome = "হোম"
    override val navHistory = "হিস্ট্রি"
    override val navReports = "রিপোর্ট"
    override val navMore = "আরও"

    override val historyFilterAllShops = "সব দোকান"
    override val historyFilterAllTypes = "সব"
    override val historyFilterCreditOnly = "শুধু ধার"
    override val historyFilterPaymentOnly = "শুধু পরিশোধ"
    override val historyNoTxnsFound = "কোনো লেনদেন পাওয়া যায়নি"
    override val viewArchivedAction = "আর্কাইভ করা দোকান দেখুন"

    override val reportsTitle = "রিপোর্ট"
    override val periodLabel = "সময়"
    override val period7d = "গত 7 দিন"
    override val period15d = "গত 15 দিন"
    override val period30d = "গত 30 দিন"
    override val period3m = "গত 3 মাস"
    override val period1y = "এই বছর"
    override val reportTotalCredit = "মোট ধার"
    override val reportTotalPayment = "মোট পরিশোধ"
    override val reportCurrentDue = "বর্তমান মোট বাকি"
    override val reportTxnCount = "লেনদেনের সংখ্যা"
    override val reportChartTitle = "ধার বনাম পরিশোধ"
    override val reportShopWiseTitle = "দোকানভিত্তিক বাকি"
    override val reportAgingTitle = "পুরনো বাকি"
    override val reportAging0to7 = "0–7 দিন"
    override val reportAging7to15 = "7–15 দিন"
    override val reportAging15to30 = "15–30 দিন"
    override val reportAging30plus = "30+ দিন"
    override val reportRecentPaymentsTitle = "সাম্প্রতিক পরিশোধ"
    override val reportNoData = "এই সময়ে কোনো তথ্য নেই"
    override val reportSmartSummaryPrefix = "এই সময়ে আপনি"

    override val moreTitle = "আরও"
    override val moreBackupRestore = "ব্যাকআপ ও রিস্টোর"
    override val moreHintBackupRestore = "ডেটা নিরাপদ রাখুন"
    override val notesTitle = "নোট"
    override val notesSearchPlaceholder = "নোট খুঁজুন..."
    override val addNoteButton = "নতুন নোট"
    override val noNotesYetTitle = "এখনো কোনো নোট নেই"
    override val noNotesYetSubtitle = "বাজারের তালিকা, রিমাইন্ডার — যা খুশি লিখে রাখুন"
    override val deleteNoteConfirmTitle = "নোট মুছে ফেলবেন?"
    override val deleteNoteConfirmMessage = "এই নোটটি স্থায়ীভাবে মুছে যাবে।"
    override val noteTitlePlaceholder = "শিরোনাম"
    override val noteContentPlaceholder = "লিখুন..."
    override val untitledNote = "শিরোনামহীন নোট"
    override val notificationInboxTitle = "নোটিফিকেশন"
    override val moreNotificationHistory = "নোটিফিকেশন হিস্ট্রি"
    override val moreHintNotificationHistory = "সাম্প্রতিক কার্যকলাপ দেখুন"
    override val noNotificationsYetTitle = "এখনো কোনো নোটিফিকেশন নেই"
    override val noNotificationsYetSubtitle = "ধার/পরিশোধ করলে এখানে দেখতে পাবেন"
    override val notifCreditMessage = "%1\$s থেকে %2\$s ধার নেওয়া হয়েছে"
    override val notifPaymentMessage = "%1\$s-কে %2\$s পরিশোধ করা হয়েছে"
    override val moreQuickCalculator = "কুইক ক্যালকুলেটর"
    override val moreHintQuickCalculator = "দ্রুত হিসাব করুন"
    override val calcGeneralTab = "সাধারণ"
    override val calcPercentTab = "শতকরা"
    override val calcConversionTab = "রূপান্তর"
    override val calcComingSoonInTab = "শীঘ্রই আসছে"
    override val percentOfTitle = "সংখ্যার শতকরা কত"
    override val percentOfValueLabel = "সংখ্যা"
    override val percentOfPercentLabel = "শতকরা (%)"
    override val percentIsWhatTitle = "একটি সংখ্যা আরেকটির শতকরা কত"
    override val percentIsWhatXLabel = "এই সংখ্যা"
    override val percentIsWhatYLabel = "এর শতকরা"
    override val percentChangeTitle = "শতকরা বৃদ্ধি/হ্রাস"
    override val percentChangeBaseLabel = "মূল সংখ্যা"
    override val percentChangePercentLabel = "শতকরা (%)"
    override val increaseOption = "বৃদ্ধি"
    override val decreaseOption = "হ্রাস"
    override val resultLabel = "ফলাফল"
    override val weightCategory = "ওজন"
    override val lengthCategory = "দৈর্ঘ্য"
    override val volumeCategory = "আয়তন"
    override val fromLabel = "থেকে"
    override val toLabel = "এ"
    override val enterValueHint = "মান লিখুন"
    override val backupNowButton = "এখনই ব্যাকআপ নিন"
    override val backupNowHint = "JSON ফাইলে সব দোকান ও লেনদেন সংরক্ষণ করুন"
    override val restoreButton = "ব্যাকআপ থেকে রিস্টোর করুন"
    override val restoreShopAction = "ফিরিয়ে আনুন"
    override val restoreHint = "আগের JSON ব্যাকআপ ফাইল থেকে ডেটা ফিরিয়ে আনুন"
    override val lastBackupLabel = "শেষ ব্যাকআপ"
    override val noBackupYetLabel = "এখনো কোনো ব্যাকআপ নেওয়া হয়নি"
    override val backupSuccessMessage = "ব্যাকআপ তৈরি হয়েছে"
    override val backupFailPrefix = "ব্যাকআপ ব্যর্থ: "
    override val restoreConfirmTitle = "রিস্টোর করবেন?"
    override val restoreConfirmMessage = "এটি বর্তমান সব দোকান ও লেনদেন মুছে ফেলে ব্যাকআপ ফাইলের ডেটা দিয়ে replace করবে। এই কাজ ফেরানো যাবে না।"
    override val restoreSuccessMessage = "রিস্টোর সম্পন্ন হয়েছে"
    override val restoreFailPrefix = "রিস্টোর ব্যর্থ: "
    override val dataSafeNote = "আপনার ডেটা শুধু এই ফোনেই থাকে — ব্যাকআপ ফাইল আপনি নিজে সংরক্ষণ করুন"
    override val moreExportShare = "এক্সপোর্ট ও শেয়ার"
    override val moreHintExportShare = "PDF ও ফাইল পাঠান"
    override val moreNotifications = "নোটিফিকেশন"
    override val moreHintNotifications = "রিমাইন্ডার চালু/বন্ধ করুন"
    override val moreLanguage = "ভাষা"
    override val moreHintLanguage = "আপনার পছন্দের ভাষা বেছে নিন"
    override val moreUserMode = "আমি কে"
    override val moreHintUserMode = "গ্রাহক নাকি দোকানদার"
    override val moreSecurityPrivacy = "নিরাপত্তা ও প্রাইভেসি"
    override val moreHintSecurityPrivacy = "PIN ও ফিঙ্গারপ্রিন্ট লক"
    override val moreAppearance = "অ্যাপের চেহারা"
    override val moreHintAppearance = "লাইট, ডার্ক বা সিস্টেম"
    override val moreRateFeedback = "রেটিং ও ফিডব্যাক"
    override val moreHintRateFeedback = "মতামত জানান"
    override val moreAbout = "উধার হিসাব সম্পর্কে"
    override val moreHintAbout = "ভার্সন ও ডেভেলপার"
    override val comingSoonMessage = "শীঘ্রই আসছে"

    override val appearanceTitle = "অ্যাপের চেহারা"
    override val themeLight = "লাইট"
    override val themeDark = "ডার্ক"
    override val themeSystem = "সিস্টেম ডিফল্ট"

    override val creditPageTitle = "ধার নিলাম"
    override val accountingTypeLabel = "হিসাবের ধরন"
    override val directMoneyMode = "সরাসরি টাকা"
    override val productMode = "পণ্য অনুযায়ী"
    override val directMoneyAmountLabel = "কত টাকা ধার নিলেন?"
    override val previousDueLabel = "আগের বাকি"
    override val newCreditLabel = "নতুন ধার"
    override val newTotalDueLabel = "নতুন মোট বাকি"
    override val addCreditButton = "ধার যোগ করুন"
    override val addMoreProductButton = "+ আরও পণ্য যোগ করুন"
    override val totalNewCreditLabel = "মোট নতুন ধার"
    override val editAction = "সম্পাদনা"
    override val itemsCountSuffix = "টি পণ্য"

    override val paymentPageTitle = "টাকা জমা"
    override val currentDueLabel = "বর্তমান বাকি"
    override val howMuchPaymentLabel = "কত টাকা জমা দেবেন?"
    override val fullPaymentButton = "সম্পূর্ণ পরিশোধ"
    override val dueAfterPaymentLabel = "জমা দেওয়ার পর বাকি"
    override val addPaymentButton = "জমা দিন"
    override val overpaymentBlockedMessage = "বর্তমান বাকির চেয়ে বেশি জমা দেওয়া যাবে না"
    override val fullyPaidCelebration = "সম্পূর্ণ পরিশোধ হয়ে যাবে"

    override val woodCalculatorTitle = "কাঠের হিসাব"
    override val woodTypeLabel = "কাঠের ধরন"
    override val sawnWoodOption = "চেরাই কাঠ"
    override val roundWoodOption = "গোল কাঠ"
    override val lengthFtLabel = "দৈর্ঘ্য (ফুট)"
    override val widthInLabel = "প্রস্থ (ইঞ্চি)"
    override val thicknessInLabel = "পুরত্ব (ইঞ্চি)"
    override val girthInLabel = "গোলবেড়ি (ইঞ্চি)"
    override val pieceCountLabel = "পিস সংখ্যা"
    override val perPieceCftLabel = "প্রতি পিস"
    override val totalWoodCftLabel = "মোট কাঠ"
    override val perCftPriceLabel = "প্রতি CFT দাম (₹)"
    override val totalWoodValueLabel = "মোট মূল্য"
    override val addWoodCalcButton = "এই কাঠের হিসাব যোগ করুন"
    override val woodNameLabel = "পণ্যের নাম"
    override val addMoreWoodProductButton = "+ আরও কাঠ/পণ্য যোগ করুন"
    override val addedItemsHeader = "যোগ করা পণ্য/কাঠ"

    override val pdfOptionsTitle = "PDF অপশন"
    override val pdfPeriodLabel = "সময়সীমা"
    override val pdfThisMonth = "এই মাস"
    override val pdfLastMonth = "গত মাস"
    override val pdfLast3Months = "গত 3 মাস"
    override val pdfCustomRange = "কাস্টম তারিখ"
    override val pdfShopLabelOption = "দোকান"
    override val pdfAllShopsOption = "সব দোকান"
    override val pdfContentLabel = "কী কী দেখাবে"
    override val pdfContentFull = "সব (লেনদেন + সারাংশ + সিগনেচার)"
    override val pdfContentSummaryOnly = "শুধু সারাংশ"
    override val pdfContentTxnsOnly = "শুধু লেনদেন"
    override val pdfFormatLabel = "ফরম্যাট"
    override val pdfFormatA4 = "A4 রিপোর্ট"
    override val pdfFormatReceipt = "রিসিট (58mm)"
    override val pdfGenerateButton = "PDF বানাও"
    override val pdfFromDateLabel = "শুরুর তারিখ"
    override val pdfToDateLabel = "শেষ তারিখ"

    override val pdfReportNumberLabel = "রিপোর্ট নং"
    override val pdfShopBoxLabel = "দোকান"
    override val pdfDateBoxLabel = "তারিখ"
    override val pdfDaysOfRecordsSuffix = "দিনের হিসাব"
    override val pdfWeeklyChartTitle = "সাপ্তাহিক ধার (লাল) ও পরিশোধ (সবুজ)"
    override val pdfFinalDueLabel = "বর্তমান বাকি"
    override val pdfShopSignatureLabel = "দোকানদারের স্বাক্ষর"
    override val pdfCustomerSignatureLabel = "ক্রেতার স্বাক্ষর"
    override val pdfAllShopsReportTitle = "সব দোকানের সারাংশ — উধার হিসাব"
    override val pdfPageLabel = "পৃষ্ঠা"

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    override val moreShopProfile = "দোকানের প্রোফাইল"
    override val moreHintShopProfile = "নাম, লোগো, ঠিকানা, রিমাইন্ডার"
    override val shopProfileTitle = "দোকানের প্রোফাইল"
    override val shopProfileIntro = "এই তথ্য PDF ইনভয়েসে আর গ্রাহককে পাঠানো বার্তায় ব্যবহার হবে"
    override val shopBusinessNameLabel = "দোকানের নাম"
    override val shopBusinessAddressLabel = "দোকানের ঠিকানা"
    override val shopBusinessPhoneLabel = "দোকানের ফোন নম্বর"
    override val countryCodeLabel = "দেশের কোড (যেমন 91)"
    override val shopLogoLabel = "দোকানের লোগো"
    override val shopLogoPick = "লোগো বাছুন"
    override val shopLogoRemove = "লোগো সরান"
    override val promptAfterEntryLabel = "এন্ট্রির পর গ্রাহককে জানানোর অপশন দেখান"
    override val saveProfileButton = "প্রোফাইল সেভ করুন"
    override val profileSavedMessage = "প্রোফাইল সেভ হয়েছে"
    override val errorShopNameForPdf = "PDF-এ ব্যবহারের জন্য দোকানের নাম দিন"
    override val reminderSendAction = "রিমাইন্ডার পাঠান"
    override val reminderDialogTitle = "গ্রাহককে জানান"
    override val reminderDialogSubtitle = "বার্তা এডিট করে WhatsApp বা SMS-এ পাঠান"
    override val reminderMessageLabel = "বার্তা"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "এখন না"
    override val reminderNoPhone = "গ্রাহকের ফোন নম্বর নেই"
    override val reminderAppMissing = "অ্যাপ খোলা যায়নি"
    override val reminderShopFallback = "আমাদের দোকান"
    override val reminderMsgDue = "নমস্কার %1\$s, %2\$s এর খাতায় আপনার মোট বাকি %3\$s। অনুগ্রহ করে সময়মতো পরিশোধ করবেন। ধন্যবাদ।"
    override val reminderMsgCredit = "নমস্কার %1\$s, %2\$s এর খাতায় আপনার নতুন বাকি যোগ হয়েছে। মোট বাকি: %3\$s।"
    override val reminderMsgPayment = "নমস্কার %1\$s, আপনার জমা পেয়েছি। ধন্যবাদ! %2\$s এর খাতায় বর্তমান বাকি: %3\$s।"
    override val reminderMsgSettled = "নমস্কার %1\$s, আপনার সব বাকি পরিশোধ হয়েছে। ধন্যবাদ! — %2\$s"
    override val pdfActionLabel = "📤 কী করবেন"
    override val pdfActionShare = "শেয়ার"
    override val pdfActionSave = "সেভ"
    override val pdfActionPrint = "প্রিন্ট"
    override val pdfBrandingOption = "আমার দোকানের নাম, লোগো ও ঠিকানা যোগ করুন"
    override val pdfBrandingMissing = "দোকানের নাম দেওয়া নেই — আরও → দোকানের প্রোফাইল-এ গিয়ে যোগ করুন"
    override val pdfSavedMessage = "PDF সেভ হয়েছে"
    override val pdfSaveFailed = "PDF সেভ করা যায়নি"

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    override val setupRoleTitle = "আপনি অ্যাপটা কীভাবে ব্যবহার করবেন?"
    override val setupProfileTitle = "আপনার দোকানের তথ্য"
    override val setupProfileSubtitle = "পরে আরও → দোকানের প্রোফাইল থেকে বদলাতে পারবেন"
    override val setupContinue = "চালিয়ে যান"
    override val setupSkip = "এখন না, পরে করব"
    override val setupFinish = "শুরু করুন"

    override val pickFromContacts = "কন্টাক্ট থেকে নম্বর নিন"

    // ── ⭐ PDF: পণ্যভিত্তিক হিসাবের কলাম ──
    override val pdfColQtyPrice = "পরিমাণ × দাম"
    override val pdfColItemTotal = "পণ্যের টাকা"

    // ── ⭐ PDF: কাঠের সম্পূর্ণ মাপ ──
    override val pdfWoodSawn = "চেরাই কাঠ"
    override val pdfWoodRound = "গোল কাঠ"
    override val pdfWoodFormula = "সূত্র"
    override val pdfWoodTotalWord = "মোট"

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    override val pdfMemoTitle = "ক্যাশ মেমো"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "বিল নং / Bill No"
    override val pdfDateTitle = "তারিখ / Date"
    override val pdfPeriodTitle = "সময়কাল / Period"
    override val pdfSeller = "বিক্রেতা / Seller"
    override val pdfBuyer = "ক্রেতা / Buyer"
    override val pdfAddressLabel = "ঠিকানা: "
    override val pdfColSl = "ক্রম"
    override val pdfColPieces = "পিস"
    override val pdfColCft = "CFT"
    override val pdfColRate = "রেট (₹/CFT)"
    override val pdfColAmountRs = "মোট (₹)"
    override val pdfColQty = "পরিমাণ"
    override val pdfColUnitPrice = "দর (₹)"
    override val pdfSecSawn = "চেরাই কাঠ / Sawn Timber"
    override val pdfSecRound = "গোল কাঠ / Round Log"
    override val pdfSecOther = "অন্যান্য পণ্য / Other Items"
    override val pdfSecCashCredit = "নগদ বাকি / Cash Credit"
    override val pdfSecPayments = "জমা / পরিশোধ / Payments"
    override val pdfBadgeSawn = "চেরাই"
    override val pdfBadgeRound = "গোল"
    override val pdfSawnTotal = "চেরাই কাঠ মোট:"
    override val pdfRoundTotal = "গোল কাঠ মোট:"
    override val pdfTableTotal = "মোট:"
    override val pdfSumBill = "মোট বিলের পরিমাণ"
    override val pdfSumPaid = "জমা / পরিশোধ"
    override val pdfSumDue = "বর্তমান বাকি"
    override val pdfWordsTitle = "টাকা কথায় / Amount in Words:"
    override val pdfSellerSign = "বিক্রেতার স্বাক্ষর ও সীল"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "ক্রেতার স্বাক্ষর"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "এটি কম্পিউটার তৈরি বিল। স্বাক্ষর ছাড়া বৈধ নয়।"

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    override val pdfSummaryTitle = "সারাংশ রিপোর্ট"
    override val moveShopAction = "অন্য তালিকায় সরান"
    override val moveShopTitle = "অন্য তালিকায় সরাবেন?"
    override val moveToShopkeeperMsg = "এই এন্ট্রি \"আমি দোকানদার\" তালিকায় (আপনার কাস্টমার হিসেবে) চলে যাবে। লেনদেনের অঙ্ক একই থাকবে, শুধু শব্দ বদলাবে — যেমন \"ধার নিলাম\" হবে \"বাকিতে দিলাম\"।"
    override val moveToCustomerMsg = "এই এন্ট্রি \"আমি গ্রাহক\" তালিকায় (যে দোকান থেকে আপনি ধার নেন) চলে যাবে। লেনদেনের অঙ্ক একই থাকবে, শুধু শব্দ বদলাবে — যেমন \"বাকিতে দিলাম\" হবে \"ধার নিলাম\"।"
    override val moveShopConfirm = "সরান"
}

object EnglishStrings : AppStrings {
    override val code = "en"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "Remove ads"
    override val moreHintAdFree = "Buy once, never see ads again"
    override val adFreeDialogTitle = "Ad-free app"
    override val adFreeDialogMessage = "Pay once and all ads are removed forever. Thank you for supporting the app!"
    override val adFreeBuyButton = "Buy"
    override val adFreeRestoreButton = "Restore purchase"
    override val adFreeActiveLabel = "Your app is ad-free ✓"
    override val adFreeUnavailable = "Purchase unavailable right now — please try again later"
    override val adSponsoredLabel = "Ad"
    override val moreAdPrivacy = "Ad preferences"
    override val moreHintAdPrivacy = "Choose the kind of ads you see"
    override val helpCenterTitle = "Help Center"
    override val helpSearchPlaceholder = "Search questions..."
    override val noFaqResultsMessage = "No matches found"
    override val faqItems = listOf(
        FaqItem(
            "How do I add a new shop?",
            "Tap the '+' button on Home, enter the shop's name, phone (optional) and type, then tap Save."
        ),
        FaqItem(
            "How do I record a credit or a payment?",
            "Open the shop's detail page and tap 'Add credit' or 'Payment', enter the amount, and confirm."
        ),
        FaqItem(
            "How do I turn biometric lock on or off?",
            "Go to More → Security & Privacy and toggle 'Biometric lock'. Your device needs fingerprint or face unlock set up."
        ),
        FaqItem(
            "How do I back up my data?",
            "Go to More → Backup & Restore and tap 'Backup now'. This creates a JSON file you can save to your phone or the cloud."
        ),
        FaqItem(
            "How do I restore from a backup?",
            "Go to More → Backup & Restore and tap 'Restore from backup', then pick your JSON file. This replaces all current data, so be careful."
        ),
        FaqItem(
            "If I delete a shop, can I get it back?",
            "Archiving keeps it in History so you can bring it back later. Permanent deletion cannot be undone."
        ),
        FaqItem(
            "How do I generate a PDF report?",
            "From the More page, use the export option next to Backup & Restore, pick a shop and date range, then share the PDF."
        ),
        FaqItem(
            "How do I change the app's language?",
            "Go to More → Language, choose Bengali or English, and tap Save."
        )
    )
    override val homeHeadline = "Udhar Hisab"
    override val history = "History"
    override val settings = "Settings"
    override val totalDueLabel = "Total due"
    override val thisMonthCreditLabel = "This month's due"
    override val thisMonthPaymentLabel = "This month's received"
    override val searchPlaceholder = "Search shop/phone..."
    override val filterAll = "All"
    override val settledLabel = "Settled"
    override val noShopsYetTitle = "No shops yet"
    override val noShopsYetSubtitle = "Add your first shop to start your khata"
    override val addFirstShopButton = "Add first shop"
    override val newShop = "New shop"

    override val shopTypeTea = "Tea shop"
    override val shopTypeHardwareElectric = "Hardware & Electric"
    override val shopTypeKirana = "Grocery shop"
    override val shopTypeVegetable = "Vegetable market"
    override val shopTypeFishMeat = "Fish & meat"
    override val shopTypeBakerySweets = "Bakery & sweets"
    override val shopTypePharmacy = "Pharmacy"
    override val shopTypeCosmetics = "Cosmetics & toiletries"
    override val shopTypeStationery = "Stationery"
    override val shopTypeXeroxPrinting = "Xerox & printing"
    override val shopTypeWood = "Wood shop"
    override val shopTypeGarments = "Garments"
    override val shopTypeOther = "Other"

    override val back = "Back"
    override val cancel = "Cancel"
    override val save = "Save"

    override val shopNameLabel = "Shop name *"
    override val shopNamePlaceholder = "e.g. Wood Mahal"
    override val phoneLabel = "Phone number (optional)"
    override val shopTypeLabel = "Shop type *"
    override val saveShopButton = "Save shop"
    override val errorNameRequired = "Enter the shop name"
    override val errorTypeRequired = "Choose a shop type"

    override val dueLabel = "Due"
    override val noTransactionsYet = "No transactions yet"
    override val creditButton = "Credit taken"
    override val paymentButton = "Payment given"
    override val pdfExport = "Export PDF"
    override val archive = "Archive"
    override val deleteShopAction = "Delete shop"
    override val archiveConfirmTitle = "Archive this shop?"
    override val archiveConfirmText = "It'll be removed from the home list — you can still find it in History."
    override val deleteConfirmTitle = "Permanently delete this shop?"
    override val deleteConfirmText = "This shop and all its transactions will be deleted forever and cannot be recovered. Archiving instead would keep it in History — please confirm before continuing."
    override val yesDelete = "Yes, delete"
    override val yesArchive = "Archive"
    override val txnDeletedSnackbar = "Transaction deleted"
    override val undo = "Undo"
    override val pdfFailPrefix = "PDF generation failed: "
    override val shareKhata = "Share khata"
    override val creditFallback = "Credit"
    override val paymentFallback = "Payment"
    override val deleteTxnAction = "Delete"

    override val productNameLabel = "Product name (optional)"
    override val quantityLabel = "Quantity"
    override val unitLabel = "Unit"
    override val pricePerUnitLabel = "Price/unit"
    override val totalPrefix = "Total: "
    override val amountLabel = "Amount paid"
    override val orEnterAmountLabel = "Or enter the amount directly"
    override val noteLabel = "Note (optional)"
    override val cash = "Cash"
    override val bkash = "bKash"
    override val bank = "Bank"
    override val invalidAmountError = "Enter a valid amount"

    override val cftCalculatorTitle = "CFT calculator"
    override val lengthLabel = "Length (in)"
    override val widthLabel = "Width"
    override val heightLabel = "Height"
    override val rateLabel = "Rate /cft (৳)"
    override val applyToEntryButton = "Apply to entry"

    override val settingsTitle = "Settings"
    override val security = "Security"
    override val pinLockOn = "PIN lock is on"
    override val pinLockOff = "PIN lock is off"
    override val changePin = "Change PIN"
    override val reminderTitle = "Due reminders"
    override val reminderDesc = "Reminds you about dues every day"
    override val about = "About"
    override val aboutLine = "Udhar Hisab — a shop credit ledger"
    override val aboutDescription = "UdharHisab is a smart accounting app built to help you manage shop credit, dues, and transactions easily, quickly, and in an organized way. How much you owe at different shops, where you've made payments, and when each transaction happened — everything can be neatly stored and managed in one place.\n\nWith this app, you can easily add shops, keep track of credit and payments, view transaction history, check your total dues and payments, and generate detailed reports. Features like Search, Filter, Backup & Restore, App Lock, Biometric Security, Dark Mode, and Notifications make managing your accounts even easier and safer.\n\nUdharHisab's goal is to bring the complexity of paper ledgers into a simple, modern, and reliable digital system."
    override val aboutTagline = "UdharHisab — Simple accounting, stay worry-free."
    override val versionLine = "Version 1.0"
    override val setPinTitle = "Set PIN"
    override val newPinLabel = "New PIN"
    override val confirmPinLabel = "Re-enter PIN"
    override val pinSetupError = "PINs don't match (at least 4 digits)"
    override val removePinTitle = "Turn off PIN lock?"
    override val removePinText = "You won't be asked for a PIN when opening the app anymore."
    override val yesTurnOff = "Yes, turn off"
    override val no = "No"
    override val languageTitle = "Language"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "Notifications"
    override val notifSheetSubtitle = "Which reminders do you want?"
    override val notifDueReminderOption = "Due payment reminder"
    override val notifWeeklySummaryOption = "Weekly summary"
    override val notifAppNewsOption = "App news & updates"

    override val langSheetSubtitle = "Which language should the app use?"
    override val themeSheetSubtitle = "Which theme do you prefer?"

    override val securityPrivacyTitle = "Security & Privacy"
    override val pinSectionTitle = "PIN lock"
    override val pinSectionDesc = "Ask for a PIN when the app opens"
    override val fingerprintTitle = "Fingerprint lock"
    override val fingerprintDesc = "Unlock with your fingerprint instead of the PIN"
    override val fingerprintUnavailable = "No fingerprint sensor found on this phone"
    override val lockImmediatelyTitle = "Lock immediately"
    override val lockImmediatelyDesc = "Lock again as soon as you return to the app"

    override val rateTitle = "Rating & Feedback"
    override val rateSubtitle = "How's Udhar Hisab working for you?"
    override val rateStarsPrompt = "Tap to rate"
    override val rateThanksMessage = "Thanks! Taking you to the Play Store…"
    override val feedbackPromptLow = "What didn't you like? Let us know"
    override val feedbackPlaceholder = "Write your feedback…"
    override val feedbackSubmit = "Send"
    override val feedbackThanks = "Thanks, your feedback has been sent"

    override val aboutPageTitle = "About Udhar Hisab"
    override val aboutVersionPrefix = "Version"
    override val aboutDeveloperLabel = "Developer"
    override val aboutDeveloperName = "Udhar Hisab Team"
    override val aboutPrivacyPolicy = "Privacy Policy"
    override val privacyPolicyEffectiveDate = "Effective date: September 13, 2026"
    override val privacyPolicyBody = """UdharHisab is a personal finance/ledger application built to help you manage your shop credit, dues, and transactions simply and easily. Your privacy matters to us.

1. Information we collect

Information you enter into the app yourself while using UdharHisab, such as:
• Shop name
• Mobile number
• Shop address or other details
• Credit and payment amounts
• Transaction date, time, and notes

2. How your information is used

This information is used solely to store, display, and manage your accounts. Your personal ledger data will not be sold or shared with any advertiser or third party without your permission.

3. Data storage

Your account data may be stored on your device as needed by the app. If you use the Backup & Restore feature, your backup data may be stored via the storage/cloud service you choose.

4. App security

Security features such as App Lock, PIN, and Biometric Authentication may be provided to help keep your account data safe.

5. Sharing information

We do not sell, rent, or commercially share your personal ledger data with third parties, except where required by law.

6. Your control

You can view, change, or delete your data stored within the app whenever you need to.

7. Third-party services

If any third-party services are used for certain features of the app, their own Privacy Policy may apply.

8. Children's privacy

UdharHisab is not designed to knowingly collect personal information from children.

9. Changes to this Privacy Policy

We may change or update this Privacy Policy as needed. Any new policy will be posted on this page.

10. Contact

If you have any questions about this Privacy Policy or your data, please contact us.

UdharHisab
Simple accounting, stay worry-free."""
    override val aboutShareApp = "Share"
    override val aboutShareText = "Udhar Hisab — try this shop credit ledger app!"

    override val noArchivedShops = "No archived shops"
    override val noSettledShops = "No settled shops"

    override val setupPinTitle = "Set a 4-digit PIN"
    override val unlockPinTitle = "Unlock with PIN"
    override val pinLabel = "PIN"
    override val pinDigitsError = "Enter 4 digits"
    override val pinsDontMatchError = "PINs don't match"
    override val wrongPinError = "Wrong PIN — try again"
    override val savePinButton = "Save PIN"
    override val unlockButton = "Unlock"

    override val pdfHeaderTitle = "Khata — Udhar Hisab"
    override val pdfFullKhataSuffix = "Full khata"
    override val pdfShopLabel = "Shop: "
    override val pdfPhoneLabel = "Phone: "
    override val pdfCreatedLabel = "Created: "
    override val pdfColDate = "Date/Time"
    override val pdfColDesc = "Description"
    override val pdfTotalCredit = "Total credit:"
    override val pdfTotalPayment = "Total payment:"
    override val pdfCurrentDue = "Current due:"
    override val pdfFooter = "Made with Udhar Hisab app"

    override val navHome = "Home"
    override val navHistory = "History"
    override val navReports = "Reports"
    override val navMore = "More"

    override val historyFilterAllShops = "All shops"
    override val historyFilterAllTypes = "All"
    override val historyFilterCreditOnly = "Due only"
    override val historyFilterPaymentOnly = "Paid only"
    override val historyNoTxnsFound = "No transactions found"
    override val viewArchivedAction = "View archived shops"

    override val reportsTitle = "Reports"
    override val periodLabel = "Period"
    override val period7d = "Last 7 days"
    override val period15d = "Last 15 days"
    override val period30d = "Last 30 days"
    override val period3m = "Last 3 months"
    override val period1y = "This year"
    override val reportTotalCredit = "Total credit"
    override val reportTotalPayment = "Total payment"
    override val reportCurrentDue = "Current total due"
    override val reportTxnCount = "Transactions"
    override val reportChartTitle = "Credit vs Payment"
    override val reportShopWiseTitle = "Due by shop"
    override val reportAgingTitle = "Outstanding age"
    override val reportAging0to7 = "0–7 days"
    override val reportAging7to15 = "7–15 days"
    override val reportAging15to30 = "15–30 days"
    override val reportAging30plus = "30+ days"
    override val reportRecentPaymentsTitle = "Recent payments"
    override val reportNoData = "No data for this period"
    override val reportSmartSummaryPrefix = "In this period you"

    override val moreTitle = "More"
    override val moreBackupRestore = "Backup & Restore"
    override val moreHintBackupRestore = "Keep your data safe"
    override val notesTitle = "Notes"
    override val notesSearchPlaceholder = "Search notes..."
    override val addNoteButton = "New note"
    override val noNotesYetTitle = "No notes yet"
    override val noNotesYetSubtitle = "Shopping lists, reminders — jot down anything"
    override val deleteNoteConfirmTitle = "Delete this note?"
    override val deleteNoteConfirmMessage = "This note will be permanently deleted."
    override val noteTitlePlaceholder = "Title"
    override val noteContentPlaceholder = "Write something..."
    override val untitledNote = "Untitled note"
    override val notificationInboxTitle = "Notifications"
    override val moreNotificationHistory = "Notification history"
    override val moreHintNotificationHistory = "See recent activity"
    override val noNotificationsYetTitle = "No notifications yet"
    override val noNotificationsYetSubtitle = "Record a credit or payment and it'll show up here"
    override val notifCreditMessage = "Credit of %2\$s taken from %1\$s"
    override val notifPaymentMessage = "Payment of %2\$s made to %1\$s"
    override val moreQuickCalculator = "Quick calculator"
    override val moreHintQuickCalculator = "Do quick math"
    override val calcGeneralTab = "General"
    override val calcPercentTab = "Percent"
    override val calcConversionTab = "Convert"
    override val calcComingSoonInTab = "Coming soon"
    override val percentOfTitle = "Percentage of a number"
    override val percentOfValueLabel = "Number"
    override val percentOfPercentLabel = "Percent (%)"
    override val percentIsWhatTitle = "What percent is one number of another"
    override val percentIsWhatXLabel = "This number"
    override val percentIsWhatYLabel = "of this"
    override val percentChangeTitle = "Percentage increase/decrease"
    override val percentChangeBaseLabel = "Base number"
    override val percentChangePercentLabel = "Percent (%)"
    override val increaseOption = "Increase"
    override val decreaseOption = "Decrease"
    override val resultLabel = "Result"
    override val weightCategory = "Weight"
    override val lengthCategory = "Length"
    override val volumeCategory = "Volume"
    override val fromLabel = "From"
    override val toLabel = "To"
    override val enterValueHint = "Enter value"
    override val backupNowButton = "Backup now"
    override val backupNowHint = "Save all shops and transactions to a JSON file"
    override val restoreButton = "Restore from backup"
    override val restoreShopAction = "Restore"
    override val restoreHint = "Bring back data from a previous JSON backup file"
    override val lastBackupLabel = "Last backup"
    override val noBackupYetLabel = "No backup taken yet"
    override val backupSuccessMessage = "Backup created"
    override val backupFailPrefix = "Backup failed: "
    override val restoreConfirmTitle = "Restore backup?"
    override val restoreConfirmMessage = "This will erase all current shops and transactions and replace them with the backup file's data. This cannot be undone."
    override val restoreSuccessMessage = "Restore complete"
    override val restoreFailPrefix = "Restore failed: "
    override val dataSafeNote = "Your data stays on this phone only — keep the backup file safe yourself"
    override val moreExportShare = "Export & Share"
    override val moreHintExportShare = "Send PDF & files"
    override val moreNotifications = "Notifications"
    override val moreHintNotifications = "Turn reminders on/off"
    override val moreLanguage = "Language"
    override val moreHintLanguage = "Choose your language"
    override val moreUserMode = "Who am I"
    override val moreHintUserMode = "Customer or shopkeeper"
    override val moreSecurityPrivacy = "Security & Privacy"
    override val moreHintSecurityPrivacy = "PIN & fingerprint lock"
    override val moreAppearance = "Appearance"
    override val moreHintAppearance = "Light, dark or system"
    override val moreRateFeedback = "Rate & Feedback"
    override val moreHintRateFeedback = "Share your feedback"
    override val moreAbout = "About Udhar Hisab"
    override val moreHintAbout = "Version & developer"
    override val comingSoonMessage = "Coming soon"

    override val appearanceTitle = "Appearance"
    override val themeLight = "Light"
    override val themeDark = "Dark"
    override val themeSystem = "System default"

    override val creditPageTitle = "Take credit"
    override val accountingTypeLabel = "Entry type"
    override val directMoneyMode = "Direct amount"
    override val productMode = "By product"
    override val directMoneyAmountLabel = "How much credit did you give?"
    override val previousDueLabel = "Previous due"
    override val newCreditLabel = "New credit"
    override val newTotalDueLabel = "New total due"
    override val addCreditButton = "Add credit"
    override val addMoreProductButton = "+ Add another product"
    override val totalNewCreditLabel = "Total new credit"
    override val editAction = "Edit"
    override val itemsCountSuffix = "items"

    override val paymentPageTitle = "Payment"
    override val currentDueLabel = "Current due"
    override val howMuchPaymentLabel = "How much are they paying?"
    override val fullPaymentButton = "Full payment"
    override val dueAfterPaymentLabel = "Due after payment"
    override val addPaymentButton = "Add payment"
    override val overpaymentBlockedMessage = "Can't pay more than the current due"
    override val fullyPaidCelebration = "This will fully settle the due"

    override val woodCalculatorTitle = "Timber calculator"
    override val woodTypeLabel = "Wood type"
    override val sawnWoodOption = "Sawn timber"
    override val roundWoodOption = "Round log"
    override val lengthFtLabel = "Length (ft)"
    override val widthInLabel = "Width (in)"
    override val thicknessInLabel = "Thickness (in)"
    override val girthInLabel = "Girth (in)"
    override val pieceCountLabel = "Piece count"
    override val perPieceCftLabel = "Per piece"
    override val totalWoodCftLabel = "Total wood"
    override val perCftPriceLabel = "Price per CFT (₹)"
    override val totalWoodValueLabel = "Total value"
    override val addWoodCalcButton = "Add this wood calculation"
    override val woodNameLabel = "Product name"
    override val addMoreWoodProductButton = "+ Add another wood/product"
    override val addedItemsHeader = "Added products/wood"

    override val pdfOptionsTitle = "PDF options"
    override val pdfPeriodLabel = "Period"
    override val pdfThisMonth = "This month"
    override val pdfLastMonth = "Last month"
    override val pdfLast3Months = "Last 3 months"
    override val pdfCustomRange = "Custom range"
    override val pdfShopLabelOption = "Shop"
    override val pdfAllShopsOption = "All shops"
    override val pdfContentLabel = "What to show"
    override val pdfContentFull = "Everything (transactions + summary + signatures)"
    override val pdfContentSummaryOnly = "Summary only"
    override val pdfContentTxnsOnly = "Transactions only"
    override val pdfFormatLabel = "Format"
    override val pdfFormatA4 = "A4 report"
    override val pdfFormatReceipt = "Receipt (58mm)"
    override val pdfGenerateButton = "Generate PDF"
    override val pdfFromDateLabel = "Start date"
    override val pdfToDateLabel = "End date"

    override val pdfReportNumberLabel = "Report no."
    override val pdfShopBoxLabel = "Shop"
    override val pdfDateBoxLabel = "Date"
    override val pdfDaysOfRecordsSuffix = "days of records"
    override val pdfWeeklyChartTitle = "Weekly credit (red) vs payment (green)"
    override val pdfFinalDueLabel = "Current due"
    override val pdfShopSignatureLabel = "Shopkeeper's signature"
    override val pdfCustomerSignatureLabel = "Customer's signature"
    override val pdfAllShopsReportTitle = "All shops summary — Udhar Hisab"
    override val pdfPageLabel = "Page"

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    override val moreShopProfile = "Shop profile"
    override val moreHintShopProfile = "Name, logo, address, reminders"
    override val shopProfileTitle = "Shop profile"
    override val shopProfileIntro = "This is used on your PDF invoices and in messages sent to customers"
    override val shopBusinessNameLabel = "Shop name"
    override val shopBusinessAddressLabel = "Shop address"
    override val shopBusinessPhoneLabel = "Shop phone number"
    override val countryCodeLabel = "Country code (e.g. 91)"
    override val shopLogoLabel = "Shop logo"
    override val shopLogoPick = "Choose logo"
    override val shopLogoRemove = "Remove logo"
    override val promptAfterEntryLabel = "Offer to notify the customer after an entry"
    override val saveProfileButton = "Save profile"
    override val profileSavedMessage = "Profile saved"
    override val errorShopNameForPdf = "Enter your shop name to use it on PDFs"
    override val reminderSendAction = "Send reminder"
    override val reminderDialogTitle = "Notify the customer"
    override val reminderDialogSubtitle = "Edit the message and send it by WhatsApp or SMS"
    override val reminderMessageLabel = "Message"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "Not now"
    override val reminderNoPhone = "This customer has no phone number"
    override val reminderAppMissing = "Could not open the app"
    override val reminderShopFallback = "our shop"
    override val reminderMsgDue = "Hello %1\$s, your total balance due at %2\$s is %3\$s. Please pay on time. Thank you."
    override val reminderMsgCredit = "Hello %1\$s, a new credit entry was added to your account at %2\$s. Total due: %3\$s."
    override val reminderMsgPayment = "Hello %1\$s, we received your payment. Thank you! Current due at %2\$s: %3\$s."
    override val reminderMsgSettled = "Hello %1\$s, your dues are fully settled. Thank you! — %2\$s"
    override val pdfActionLabel = "📤 What to do"
    override val pdfActionShare = "Share"
    override val pdfActionSave = "Save"
    override val pdfActionPrint = "Print"
    override val pdfBrandingOption = "Add my shop name, logo and address"
    override val pdfBrandingMissing = "No shop name set — add it under More → Shop profile"
    override val pdfSavedMessage = "PDF saved"
    override val pdfSaveFailed = "Could not save the PDF"

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    override val setupRoleTitle = "How will you use the app?"
    override val setupProfileTitle = "Your shop details"
    override val setupProfileSubtitle = "You can change this later under More → Shop profile"
    override val setupContinue = "Continue"
    override val setupSkip = "Not now, I'll do it later"
    override val setupFinish = "Get started"

    override val pickFromContacts = "Pick from contacts"

    // ── ⭐ PDF: পণ্যভিত্তিক হিসাবের কলাম ──
    override val pdfColQtyPrice = "Qty × Price"
    override val pdfColItemTotal = "Item total"

    // ── ⭐ PDF: কাঠের সম্পূর্ণ মাপ ──
    override val pdfWoodSawn = "Sawn timber"
    override val pdfWoodRound = "Round timber"
    override val pdfWoodFormula = "Formula"
    override val pdfWoodTotalWord = "Total"

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    override val pdfMemoTitle = "Cash Memo"
    override val pdfMemoSubtitle = "Bill of Supply"
    override val pdfBillNo = "Bill No"
    override val pdfDateTitle = "Date"
    override val pdfPeriodTitle = "Period"
    override val pdfSeller = "Seller"
    override val pdfBuyer = "Buyer"
    override val pdfAddressLabel = "Address: "
    override val pdfColSl = "Sl"
    override val pdfColPieces = "Pcs"
    override val pdfColCft = "CFT"
    override val pdfColRate = "Rate (₹/CFT)"
    override val pdfColAmountRs = "Total (₹)"
    override val pdfColQty = "Quantity"
    override val pdfColUnitPrice = "Rate (₹)"
    override val pdfSecSawn = "Sawn Timber"
    override val pdfSecRound = "Round Log"
    override val pdfSecOther = "Other Items"
    override val pdfSecCashCredit = "Cash Credit"
    override val pdfSecPayments = "Payments"
    override val pdfBadgeSawn = "Sawn"
    override val pdfBadgeRound = "Round"
    override val pdfSawnTotal = "Sawn timber total:"
    override val pdfRoundTotal = "Round log total:"
    override val pdfTableTotal = "Total:"
    override val pdfSumBill = "Total Bill"
    override val pdfSumPaid = "Paid"
    override val pdfSumDue = "Balance Due"
    override val pdfWordsTitle = "Amount in Words:"
    override val pdfSellerSign = "Seller Signature & Seal"
    override val pdfSellerSignSub = ""
    override val pdfBuyerSign = "Buyer Signature"
    override val pdfBuyerSignSub = ""
    override val pdfMemoFooter = "This is a computer generated bill. Not valid without signature."

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    override val pdfSummaryTitle = "Summary Report"
    override val moveShopAction = "Move to the other list"
    override val moveShopTitle = "Move to the other list?"
    override val moveToShopkeeperMsg = "This entry will move to your \"I am a shopkeeper\" list (as your customer). Amounts stay the same; only the wording changes."
    override val moveToCustomerMsg = "This entry will move to your \"I am a customer\" list (a shop you buy from on credit). Amounts stay the same; only the wording changes."
    override val moveShopConfirm = "Move"
}

object HindiStrings : AppStrings {
    override val code = "hi"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "विज्ञापन हटाएँ"
    override val moreHintAdFree = "एक बार खरीदें, फिर विज्ञापन नहीं"
    override val adFreeDialogTitle = "विज्ञापन-मुक्त ऐप"
    override val adFreeDialogMessage = "एक बार भुगतान करने पर सभी विज्ञापन हमेशा के लिए बंद हो जाएँगे। ऐप का साथ देने के लिए धन्यवाद!"
    override val adFreeBuyButton = "खरीदें"
    override val adFreeRestoreButton = "पिछली खरीद वापस लाएँ"
    override val adFreeActiveLabel = "आपका ऐप विज्ञापन-मुक्त है ✓"
    override val adFreeUnavailable = "अभी खरीदना संभव नहीं — बाद में फिर कोशिश करें"
    override val adSponsoredLabel = "विज्ञापन"
    override val moreAdPrivacy = "विज्ञापन की पसंद"
    override val moreHintAdPrivacy = "तय करें कि आप किस तरह के विज्ञापन देखें"
    override val helpCenterTitle = "सहायता केंद्र"
    override val helpSearchPlaceholder = "सवाल खोजें..."
    override val noFaqResultsMessage = "कोई मेल नहीं मिला"
    override val faqItems = listOf(
        FaqItem(
            "नई दुकान कैसे जोड़ें?",
            "होम स्क्रीन पर '+' बटन दबाएं, दुकान का नाम, फ़ोन नंबर (वैकल्पिक) और प्रकार भरें, फिर 'सेव करें' दबाएं।"
        ),
        FaqItem(
            "उधार या भुगतान कैसे दर्ज करें?",
            "दुकान के विवरण पेज पर जाएं और 'उधार लें' या 'भुगतान' दबाएं, राशि डालें और पुष्टि करें।"
        ),
        FaqItem(
            "बायोमेट्रिक लॉक कैसे चालू/बंद करें?",
            "अधिक → सुरक्षा व गोपनीयता पेज पर जाकर 'बायोमेट्रिक लॉक' टॉगल करें। फ़ोन में फिंगरप्रिंट/फेस अनलॉक सेट होना ज़रूरी है।"
        ),
        FaqItem(
            "डेटा बैकअप कैसे लें?",
            "अधिक → बैकअप व रिस्टोर पेज पर जाकर 'अभी बैकअप लें' दबाएं। एक JSON फ़ाइल बनेगी जिसे आप फ़ोन या क्लाउड में सेव कर सकते हैं।"
        ),
        FaqItem(
            "बैकअप से डेटा कैसे वापस लाएं?",
            "अधिक → बैकअप व रिस्टोर पेज पर 'बैकअप से रिस्टोर करें' दबाएं, अपनी JSON फ़ाइल चुनें। इससे मौजूदा सारा डेटा मिटकर बैकअप से बदल जाएगा, इसलिए सावधानी बरतें।"
        ),
        FaqItem(
            "दुकान डिलीट करने पर क्या वापस मिल सकती है?",
            "आर्काइव करने पर दुकान History में रहती है, बाद में वापस लाई जा सकती है। स्थायी रूप से डिलीट करने पर यह हमेशा के लिए चली जाती है।"
        ),
        FaqItem(
            "PDF रिपोर्ट कैसे बनाएं?",
            "अधिक पेज पर बैकअप व रिस्टोर के पास एक्सपोर्ट विकल्प से दुकान और समय-सीमा चुनकर PDF बनाएं, फिर शेयर करें।"
        ),
        FaqItem(
            "ऐप की भाषा कैसे बदलें?",
            "अधिक → भाषा पेज पर जाकर बांग्ला, अंग्रेज़ी या हिंदी चुनें और 'सेव करें' दबाएं।"
        )
    )
    override val homeHeadline = "उधार हिसाब"
    override val history = "हिस्ट्री"
    override val settings = "सेटिंग्स"
    override val totalDueLabel = "कुल बकाया"
    override val thisMonthCreditLabel = "इस महीने का बकाया"
    override val thisMonthPaymentLabel = "इस महीने मिला भुगतान"
    override val searchPlaceholder = "दुकान/फ़ोन खोजें..."
    override val filterAll = "सभी"
    override val settledLabel = "चुकता"
    override val noShopsYetTitle = "अभी कोई दुकान नहीं"
    override val noShopsYetSubtitle = "अपना खाता शुरू करने के लिए पहली दुकान जोड़ें"
    override val addFirstShopButton = "पहली दुकान जोड़ें"
    override val newShop = "नई दुकान"

    override val shopTypeTea = "चाय की दुकान"
    override val shopTypeHardwareElectric = "हार्डवेयर व इलेक्ट्रिक"
    override val shopTypeKirana = "किराना दुकान"
    override val shopTypeVegetable = "सब्ज़ी बाज़ार"
    override val shopTypeFishMeat = "मछली व मांस"
    override val shopTypeBakerySweets = "बेकरी व मिठाई"
    override val shopTypePharmacy = "फार्मेसी"
    override val shopTypeCosmetics = "कॉस्मेटिक्स व टॉयलेटरीज़"
    override val shopTypeStationery = "स्टेशनरी"
    override val shopTypeXeroxPrinting = "ज़ेरॉक्स व प्रिंटिंग"
    override val shopTypeWood = "लकड़ी की दुकान"
    override val shopTypeGarments = "गारमेंट्स"
    override val shopTypeOther = "अन्य"

    override val back = "वापस"
    override val cancel = "रद्द करें"
    override val save = "सेव करें"

    override val shopNameLabel = "दुकान का नाम *"
    override val shopNamePlaceholder = "जैसे: वुड महल"
    override val phoneLabel = "फ़ोन नंबर (वैकल्पिक)"
    override val shopTypeLabel = "दुकान का प्रकार *"
    override val saveShopButton = "दुकान सेव करें"
    override val errorNameRequired = "दुकान का नाम भरें"
    override val errorTypeRequired = "दुकान का प्रकार चुनें"

    override val dueLabel = "बकाया"
    override val noTransactionsYet = "अभी कोई लेनदेन नहीं"
    override val creditButton = "उधार लिया"
    override val paymentButton = "भुगतान किया"
    override val pdfExport = "PDF एक्सपोर्ट करें"
    override val archive = "आर्काइव"
    override val deleteShopAction = "दुकान डिलीट करें"
    override val archiveConfirmTitle = "इस दुकान को आर्काइव करें?"
    override val archiveConfirmText = "यह होम लिस्ट से हट जाएगी — आप इसे History में पा सकते हैं।"
    override val deleteConfirmTitle = "दुकान स्थायी रूप से डिलीट करें?"
    override val deleteConfirmText = "यह दुकान और इसके सारे लेनदेन हमेशा के लिए मिट जाएंगे और वापस नहीं आएंगे। इसके बजाय आर्काइव करने पर यह History में रहेगी — आगे बढ़ने से पहले पुष्टि करें।"
    override val yesDelete = "हां, डिलीट करें"
    override val yesArchive = "आर्काइव करें"
    override val txnDeletedSnackbar = "लेनदेन डिलीट हुआ"
    override val undo = "वापस लाएं"
    override val pdfFailPrefix = "PDF बनाना असफल: "
    override val shareKhata = "खाता शेयर करें"
    override val creditFallback = "उधार"
    override val paymentFallback = "भुगतान"
    override val deleteTxnAction = "मिटाएं"

    override val productNameLabel = "उत्पाद का नाम (वैकल्पिक)"
    override val quantityLabel = "मात्रा"
    override val unitLabel = "इकाई"
    override val pricePerUnitLabel = "मूल्य/इकाई"
    override val totalPrefix = "कुल: "
    override val amountLabel = "भुगतान की गई राशि"
    override val orEnterAmountLabel = "या सीधे राशि डालें"
    override val noteLabel = "नोट (वैकल्पिक)"
    override val cash = "नकद"
    override val bkash = "बीकैश"
    override val bank = "बैंक"
    override val invalidAmountError = "सही राशि डालें"

    override val cftCalculatorTitle = "CFT कैलकुलेटर"
    override val lengthLabel = "लंबाई (इंच)"
    override val widthLabel = "चौड़ाई"
    override val heightLabel = "ऊंचाई"
    override val rateLabel = "दर /cft (৳)"
    override val applyToEntryButton = "एंट्री में लागू करें"

    override val settingsTitle = "सेटिंग्स"
    override val security = "सुरक्षा"
    override val pinLockOn = "पिन लॉक चालू है"
    override val pinLockOff = "पिन लॉक बंद है"
    override val changePin = "पिन बदलें"
    override val reminderTitle = "बकाया रिमाइंडर"
    override val reminderDesc = "हर दिन बकाया याद दिलाता है"
    override val about = "जानकारी"
    override val aboutLine = "उधार हिसाब — दुकान का उधार खाता"
    override val aboutDescription = "UdharHisab एक स्मार्ट अकाउंटिंग ऐप है जो दुकान के उधार, बकाया और लेनदेन को आसानी, तेज़ी और व्यवस्थित ढंग से संभालने के लिए बनाया गया है। अलग-अलग दुकानों में आपका कितना उधार बकाया है, कहां कितना भुगतान किया है, और कौन सा लेनदेन कब हुआ — सब कुछ एक ही जगह सुव्यवस्थित रूप से सेव और मैनेज किया जा सकता है।\n\nइस ऐप से आप आसानी से दुकान जोड़ सकते हैं, उधार व भुगतान का हिसाब रख सकते हैं, लेनदेन का इतिहास देख सकते हैं, कुल बकाया व भुगतान की जानकारी पा सकते हैं, और विस्तृत रिपोर्ट बना सकते हैं। साथ ही Search, Filter, Backup & Restore, App Lock, Biometric Security, Dark Mode और Notification जैसी सुविधाएं आपके हिसाब को और आसान व सुरक्षित बनाती हैं।\n\nUdharHisab का लक्ष्य है — जटिल कागज़ी बहीखाते को एक सरल, आधुनिक और भरोसेमंद डिजिटल व्यवस्था में लाना।"
    override val aboutTagline = "UdharHisab — आसान हिसाब, निश्चिंत रहें।"
    override val versionLine = "वर्शन 1.0"
    override val setPinTitle = "पिन सेट करें"
    override val newPinLabel = "नया पिन"
    override val confirmPinLabel = "पिन दोबारा डालें"
    override val pinSetupError = "पिन मेल नहीं खाते (कम से कम 4 अंक)"
    override val removePinTitle = "पिन लॉक बंद करें?"
    override val removePinText = "अब ऐप खोलते समय पिन नहीं मांगा जाएगा।"
    override val yesTurnOff = "हां, बंद करें"
    override val no = "नहीं"
    override val languageTitle = "भाषा"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "नोटिफिकेशन"
    override val notifSheetSubtitle = "आपको कौन से रिमाइंडर चाहिए?"
    override val notifDueReminderOption = "बकाया भुगतान रिमाइंडर"
    override val notifWeeklySummaryOption = "साप्ताहिक सारांश"
    override val notifAppNewsOption = "ऐप न्यूज़ व अपडेट्स"

    override val langSheetSubtitle = "ऐप किस भाषा में चलनी चाहिए?"
    override val themeSheetSubtitle = "आपको कौन-सी थीम पसंद है?"

    override val securityPrivacyTitle = "सुरक्षा व गोपनीयता"
    override val pinSectionTitle = "पिन लॉक"
    override val pinSectionDesc = "ऐप खुलते समय पिन मांगें"
    override val fingerprintTitle = "फिंगरप्रिंट लॉक"
    override val fingerprintDesc = "पिन की जगह फिंगरप्रिंट से अनलॉक करें"
    override val fingerprintUnavailable = "इस फ़ोन में फिंगरप्रिंट सेंसर नहीं मिला"
    override val lockImmediatelyTitle = "तुरंत लॉक करें"
    override val lockImmediatelyDesc = "ऐप पर वापस आते ही फिर से लॉक हो जाए"

    override val rateTitle = "रेटिंग व फीडबैक"
    override val rateSubtitle = "उधार हिसाब आपके लिए कैसा काम कर रहा है?"
    override val rateStarsPrompt = "रेट करने के लिए टैप करें"
    override val rateThanksMessage = "धन्यवाद! Play Store पर ले जा रहे हैं…"
    override val feedbackPromptLow = "आपको क्या पसंद नहीं आया? हमें बताएं"
    override val feedbackPlaceholder = "अपनी प्रतिक्रिया लिखें…"
    override val feedbackSubmit = "भेजें"
    override val feedbackThanks = "धन्यवाद, आपकी प्रतिक्रिया भेज दी गई है"

    override val aboutPageTitle = "उधार हिसाब के बारे में"
    override val aboutVersionPrefix = "वर्शन"
    override val aboutDeveloperLabel = "डेवलपर"
    override val aboutDeveloperName = "उधार हिसाब टीम"
    override val aboutPrivacyPolicy = "प्राइवेसी पॉलिसी"
    override val privacyPolicyEffectiveDate = "प्रभावी तिथि: 13 सितंबर 2026"
    override val privacyPolicyBody = """UdharHisab आपकी दुकान के उधार-बकाया और लेनदेन को आसानी से संभालने के लिए बनाया गया एक personal finance/ledger application है। आपकी गोपनीयता हमारे लिए महत्वपूर्ण है।

1. हम कौन-सी जानकारी लेते हैं

UdharHisab इस्तेमाल करते समय आप खुद जो जानकारी ऐप में डालते हैं, जैसे:
• दुकान का नाम
• मोबाइल नंबर
• दुकान का पता या अन्य विवरण
• उधार व भुगतान की राशि
• लेनदेन की तारीख, समय व नोट

2. आपकी जानकारी का उपयोग कैसे होता है

यह जानकारी केवल आपका हिसाब सेव करने, दिखाने और मैनेज करने के लिए इस्तेमाल होती है। आपकी अनुमति के बिना आपकी निजी हिसाब की जानकारी किसी विज्ञापनदाता या तीसरे पक्ष को नहीं बेची या साझा की जाएगी।

3. Data Storage

आपके हिसाब की जानकारी ऐप की ज़रूरत के अनुसार आपके डिवाइस में सेव हो सकती है। Backup & Restore सुविधा इस्तेमाल करने पर बैकअप की जानकारी आपके चुने गए storage/cloud service के ज़रिए सेव हो सकती है।

4. App Security

आपके हिसाब की जानकारी सुरक्षित रखने के लिए App Lock, PIN और Biometric Authentication जैसी सुरक्षा सुविधाएं दी जा सकती हैं।

5. जानकारी साझा करना

कानूनी ज़रूरत के अलावा हम आपकी निजी हिसाब की जानकारी किसी तीसरे पक्ष को न बेचते हैं, न किराए पर देते हैं, न व्यावसायिक रूप से साझा करते हैं।

6. आपका नियंत्रण

आप ऐप में सेव अपनी जानकारी कभी भी देख सकते हैं, बदल सकते हैं या ज़रूरत पड़ने पर मिटा सकते हैं।

7. Third-Party Services

ऐप की कुछ सुविधाओं के लिए तीसरे पक्ष की सेवा इस्तेमाल होने पर उनकी अपनी Privacy Policy लागू हो सकती है।

8. बच्चों की गोपनीयता

UdharHisab बच्चों की निजी जानकारी इकट्ठा करने के उद्देश्य से नहीं बनाया गया है।

9. Privacy Policy में बदलाव

ज़रूरत पड़ने पर हम इस Privacy Policy को बदल या अपडेट कर सकते हैं। नई Policy इसी पेज पर प्रकाशित की जाएगी।

10. संपर्क

Privacy Policy या अपनी जानकारी से जुड़ा कोई सवाल हो तो हमसे संपर्क करें।

UdharHisab
आसान हिसाब, निश्चिंत रहें।"""
    override val aboutShareApp = "शेयर करें"
    override val aboutShareText = "उधार हिसाब — यह दुकान उधार खाता ऐप आज़माएं!"

    override val noArchivedShops = "कोई आर्काइव की गई दुकान नहीं"
    override val noSettledShops = "कोई चुकता दुकान नहीं"

    override val setupPinTitle = "4 अंकों का पिन सेट करें"
    override val unlockPinTitle = "पिन से अनलॉक करें"
    override val pinLabel = "पिन"
    override val pinDigitsError = "4 अंक डालें"
    override val pinsDontMatchError = "पिन मेल नहीं खाते"
    override val wrongPinError = "गलत पिन — फिर कोशिश करें"
    override val savePinButton = "पिन सेव करें"
    override val unlockButton = "अनलॉक करें"

    override val pdfHeaderTitle = "खाता — उधार हिसाब"
    override val pdfFullKhataSuffix = "पूरा खाता"
    override val pdfShopLabel = "दुकान: "
    override val pdfPhoneLabel = "फ़ोन: "
    override val pdfCreatedLabel = "बनाया गया: "
    override val pdfColDate = "तारीख/समय"
    override val pdfColDesc = "विवरण"
    override val pdfTotalCredit = "कुल उधार:"
    override val pdfTotalPayment = "कुल भुगतान:"
    override val pdfCurrentDue = "मौजूदा बकाया:"
    override val pdfFooter = "उधार हिसाब ऐप से बनाया गया"

    override val navHome = "होम"
    override val navHistory = "हिस्ट्री"
    override val navReports = "रिपोर्ट"
    override val navMore = "अधिक"

    override val historyFilterAllShops = "सभी दुकानें"
    override val historyFilterAllTypes = "सभी"
    override val historyFilterCreditOnly = "सिर्फ़ बकाया"
    override val historyFilterPaymentOnly = "सिर्फ़ भुगतान"
    override val historyNoTxnsFound = "कोई लेनदेन नहीं मिला"
    override val viewArchivedAction = "आर्काइव दुकानें देखें"

    override val reportsTitle = "रिपोर्ट"
    override val periodLabel = "समय-सीमा"
    override val period7d = "पिछले 7 दिन"
    override val period15d = "पिछले 15 दिन"
    override val period30d = "पिछले 30 दिन"
    override val period3m = "पिछले 3 महीने"
    override val period1y = "इस साल"
    override val reportTotalCredit = "कुल उधार"
    override val reportTotalPayment = "कुल भुगतान"
    override val reportCurrentDue = "मौजूदा कुल बकाया"
    override val reportTxnCount = "लेनदेन"
    override val reportChartTitle = "उधार बनाम भुगतान"
    override val reportShopWiseTitle = "दुकान अनुसार बकाया"
    override val reportAgingTitle = "बकाया कितना पुराना"
    override val reportAging0to7 = "0–7 दिन"
    override val reportAging7to15 = "7–15 दिन"
    override val reportAging15to30 = "15–30 दिन"
    override val reportAging30plus = "30+ दिन"
    override val reportRecentPaymentsTitle = "हाल के भुगतान"
    override val reportNoData = "इस समय-सीमा में कोई डेटा नहीं"
    override val reportSmartSummaryPrefix = "इस समय-सीमा में आपने"

    override val moreTitle = "अधिक"
    override val moreBackupRestore = "बैकअप व रिस्टोर"
    override val moreHintBackupRestore = "अपना डेटा सुरक्षित रखें"
    override val notesTitle = "नोट्स"
    override val notesSearchPlaceholder = "नोट्स खोजें..."
    override val addNoteButton = "नया नोट"
    override val noNotesYetTitle = "अभी कोई नोट नहीं"
    override val noNotesYetSubtitle = "खरीदारी सूची, रिमाइंडर — कुछ भी लिख लें"
    override val deleteNoteConfirmTitle = "यह नोट डिलीट करें?"
    override val deleteNoteConfirmMessage = "यह नोट हमेशा के लिए मिट जाएगा।"
    override val noteTitlePlaceholder = "शीर्षक"
    override val noteContentPlaceholder = "कुछ लिखें..."
    override val untitledNote = "बिना शीर्षक का नोट"
    override val notificationInboxTitle = "नोटिफिकेशन"
    override val moreNotificationHistory = "नोटिफिकेशन हिस्ट्री"
    override val moreHintNotificationHistory = "हाल की गतिविधि देखें"
    override val noNotificationsYetTitle = "अभी कोई नोटिफिकेशन नहीं"
    override val noNotificationsYetSubtitle = "उधार या भुगतान दर्ज करें, यह यहां दिखेगा"
    override val notifCreditMessage = "%1\$s से %2\$s उधार लिया गया"
    override val notifPaymentMessage = "%1\$s को %2\$s भुगतान किया गया"
    override val moreQuickCalculator = "क्विक कैलकुलेटर"
    override val moreHintQuickCalculator = "तुरंत हिसाब करें"
    override val calcGeneralTab = "सामान्य"
    override val calcPercentTab = "प्रतिशत"
    override val calcConversionTab = "रूपांतरण"
    override val calcComingSoonInTab = "जल्द आ रहा है"
    override val percentOfTitle = "संख्या का प्रतिशत"
    override val percentOfValueLabel = "संख्या"
    override val percentOfPercentLabel = "प्रतिशत (%)"
    override val percentIsWhatTitle = "एक संख्या दूसरी की कितने प्रतिशत है"
    override val percentIsWhatXLabel = "यह संख्या"
    override val percentIsWhatYLabel = "इसका"
    override val percentChangeTitle = "प्रतिशत वृद्धि/कमी"
    override val percentChangeBaseLabel = "मूल संख्या"
    override val percentChangePercentLabel = "प्रतिशत (%)"
    override val increaseOption = "वृद्धि"
    override val decreaseOption = "कमी"
    override val resultLabel = "परिणाम"
    override val weightCategory = "वज़न"
    override val lengthCategory = "लंबाई"
    override val volumeCategory = "आयतन"
    override val fromLabel = "से"
    override val toLabel = "तक"
    override val enterValueHint = "मान डालें"
    override val backupNowButton = "अभी बैकअप लें"
    override val backupNowHint = "सभी दुकानें व लेनदेन JSON फ़ाइल में सेव करें"
    override val restoreButton = "बैकअप से रिस्टोर करें"
    override val restoreShopAction = "वापस लाएं"
    override val restoreHint = "पुरानी JSON बैकअप फ़ाइल से डेटा वापस लाएं"
    override val lastBackupLabel = "आख़िरी बैकअप"
    override val noBackupYetLabel = "अभी तक कोई बैकअप नहीं लिया गया"
    override val backupSuccessMessage = "बैकअप बन गया"
    override val backupFailPrefix = "बैकअप असफल: "
    override val restoreConfirmTitle = "रिस्टोर करें?"
    override val restoreConfirmMessage = "इससे मौजूदा सभी दुकानें व लेनदेन मिटकर बैकअप फ़ाइल के डेटा से बदल जाएंगे। यह वापस नहीं किया जा सकता।"
    override val restoreSuccessMessage = "रिस्टोर पूरा हुआ"
    override val restoreFailPrefix = "रिस्टोर असफल: "
    override val dataSafeNote = "आपका डेटा केवल इसी फ़ोन में रहता है — बैकअप फ़ाइल खुद सुरक्षित रखें"
    override val moreExportShare = "एक्सपोर्ट व शेयर"
    override val moreHintExportShare = "PDF व फ़ाइलें भेजें"
    override val moreNotifications = "नोटिफिकेशन"
    override val moreHintNotifications = "रिमाइंडर चालू/बंद करें"
    override val moreLanguage = "भाषा"
    override val moreHintLanguage = "अपनी भाषा चुनें"
    override val moreUserMode = "मैं कौन हूं"
    override val moreHintUserMode = "ग्राहक या दुकानदार"
    override val moreSecurityPrivacy = "सुरक्षा व गोपनीयता"
    override val moreHintSecurityPrivacy = "पिन व फिंगरप्रिंट लॉक"
    override val moreAppearance = "थीम"
    override val moreHintAppearance = "लाइट, डार्क या सिस्टम"
    override val moreRateFeedback = "रेटिंग व फीडबैक"
    override val moreHintRateFeedback = "अपनी राय बताएं"
    override val moreAbout = "उधार हिसाब के बारे में"
    override val moreHintAbout = "वर्शन व डेवलपर"
    override val comingSoonMessage = "जल्द आ रहा है"

    override val appearanceTitle = "थीम"
    override val themeLight = "लाइट"
    override val themeDark = "डार्क"
    override val themeSystem = "सिस्टम डिफ़ॉल्ट"

    override val creditPageTitle = "उधार लें"
    override val accountingTypeLabel = "एंट्री का प्रकार"
    override val directMoneyMode = "सीधी राशि"
    override val productMode = "उत्पाद अनुसार"
    override val directMoneyAmountLabel = "कितना उधार दिया?"
    override val previousDueLabel = "पिछला बकाया"
    override val newCreditLabel = "नया उधार"
    override val newTotalDueLabel = "नया कुल बकाया"
    override val addCreditButton = "उधार जोड़ें"
    override val addMoreProductButton = "+ एक और उत्पाद जोड़ें"
    override val totalNewCreditLabel = "कुल नया उधार"
    override val editAction = "बदलें"
    override val itemsCountSuffix = "आइटम"

    override val paymentPageTitle = "भुगतान"
    override val currentDueLabel = "मौजूदा बकाया"
    override val howMuchPaymentLabel = "कितना भुगतान कर रहे हैं?"
    override val fullPaymentButton = "पूरा भुगतान"
    override val dueAfterPaymentLabel = "भुगतान के बाद बकाया"
    override val addPaymentButton = "भुगतान जोड़ें"
    override val overpaymentBlockedMessage = "मौजूदा बकाया से ज़्यादा भुगतान नहीं हो सकता"
    override val fullyPaidCelebration = "इससे बकाया पूरी तरह चुक जाएगा"

    override val woodCalculatorTitle = "लकड़ी कैलकुलेटर"
    override val woodTypeLabel = "लकड़ी का प्रकार"
    override val sawnWoodOption = "चिरी हुई लकड़ी"
    override val roundWoodOption = "गोल लट्ठा"
    override val lengthFtLabel = "लंबाई (फुट)"
    override val widthInLabel = "चौड़ाई (इंच)"
    override val thicknessInLabel = "मोटाई (इंच)"
    override val girthInLabel = "घेरा (इंच)"
    override val pieceCountLabel = "टुकड़ों की संख्या"
    override val perPieceCftLabel = "प्रति टुकड़ा"
    override val totalWoodCftLabel = "कुल लकड़ी"
    override val perCftPriceLabel = "मूल्य प्रति CFT (₹)"
    override val totalWoodValueLabel = "कुल मूल्य"
    override val addWoodCalcButton = "यह लकड़ी हिसाब जोड़ें"
    override val woodNameLabel = "उत्पाद का नाम"
    override val addMoreWoodProductButton = "+ एक और लकड़ी/उत्पाद जोड़ें"
    override val addedItemsHeader = "जोड़े गए उत्पाद/लकड़ी"

    override val pdfOptionsTitle = "PDF विकल्प"
    override val pdfPeriodLabel = "समय-सीमा"
    override val pdfThisMonth = "इस महीने"
    override val pdfLastMonth = "पिछले महीने"
    override val pdfLast3Months = "पिछले 3 महीने"
    override val pdfCustomRange = "कस्टम रेंज"
    override val pdfShopLabelOption = "दुकान"
    override val pdfAllShopsOption = "सभी दुकानें"
    override val pdfContentLabel = "क्या दिखाएं"
    override val pdfContentFull = "सब कुछ (लेनदेन + सारांश + हस्ताक्षर)"
    override val pdfContentSummaryOnly = "सिर्फ़ सारांश"
    override val pdfContentTxnsOnly = "सिर्फ़ लेनदेन"
    override val pdfFormatLabel = "फ़ॉर्मैट"
    override val pdfFormatA4 = "A4 रिपोर्ट"
    override val pdfFormatReceipt = "रसीद (58mm)"
    override val pdfGenerateButton = "PDF बनाएं"
    override val pdfFromDateLabel = "शुरुआत की तारीख"
    override val pdfToDateLabel = "अंतिम तारीख"

    override val pdfReportNumberLabel = "रिपोर्ट नं."
    override val pdfShopBoxLabel = "दुकान"
    override val pdfDateBoxLabel = "तारीख"
    override val pdfDaysOfRecordsSuffix = "दिनों का रिकॉर्ड"
    override val pdfWeeklyChartTitle = "साप्ताहिक उधार (लाल) बनाम भुगतान (हरा)"
    override val pdfFinalDueLabel = "मौजूदा बकाया"
    override val pdfShopSignatureLabel = "दुकानदार के हस्ताक्षर"
    override val pdfCustomerSignatureLabel = "ग्राहक के हस्ताक्षर"
    override val pdfAllShopsReportTitle = "सभी दुकानों का सारांश — उधार हिसाब"
    override val pdfPageLabel = "पेज"

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    override val moreShopProfile = "दुकान की प्रोफ़ाइल"
    override val moreHintShopProfile = "नाम, लोगो, पता, रिमाइंडर"
    override val shopProfileTitle = "दुकान की प्रोफ़ाइल"
    override val shopProfileIntro = "यह जानकारी PDF इनवॉइस और ग्राहक को भेजे संदेशों में इस्तेमाल होगी"
    override val shopBusinessNameLabel = "दुकान का नाम"
    override val shopBusinessAddressLabel = "दुकान का पता"
    override val shopBusinessPhoneLabel = "दुकान का फ़ोन नंबर"
    override val countryCodeLabel = "देश का कोड (जैसे 91)"
    override val shopLogoLabel = "दुकान का लोगो"
    override val shopLogoPick = "लोगो चुनें"
    override val shopLogoRemove = "लोगो हटाएँ"
    override val promptAfterEntryLabel = "एंट्री के बाद ग्राहक को सूचित करने का विकल्प दिखाएँ"
    override val saveProfileButton = "प्रोफ़ाइल सेव करें"
    override val profileSavedMessage = "प्रोफ़ाइल सेव हो गई"
    override val errorShopNameForPdf = "PDF में इस्तेमाल के लिए दुकान का नाम दें"
    override val reminderSendAction = "रिमाइंडर भेजें"
    override val reminderDialogTitle = "ग्राहक को सूचित करें"
    override val reminderDialogSubtitle = "संदेश एडिट करके WhatsApp या SMS से भेजें"
    override val reminderMessageLabel = "संदेश"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "अभी नहीं"
    override val reminderNoPhone = "ग्राहक का फ़ोन नंबर नहीं है"
    override val reminderAppMissing = "ऐप नहीं खुल सका"
    override val reminderShopFallback = "हमारी दुकान"
    override val reminderMsgDue = "नमस्ते %1\$s, %2\$s के खाते में आपका कुल बकाया %3\$s है। कृपया समय पर भुगतान करें। धन्यवाद।"
    override val reminderMsgCredit = "नमस्ते %1\$s, %2\$s के खाते में आपका नया उधार जोड़ा गया है। कुल बकाया: %3\$s।"
    override val reminderMsgPayment = "नमस्ते %1\$s, आपका भुगतान मिल गया। धन्यवाद! %2\$s के खाते में वर्तमान बकाया: %3\$s।"
    override val reminderMsgSettled = "नमस्ते %1\$s, आपका पूरा बकाया चुकता हो गया है। धन्यवाद! — %2\$s"
    override val pdfActionLabel = "📤 क्या करना है"
    override val pdfActionShare = "शेयर"
    override val pdfActionSave = "सेव"
    override val pdfActionPrint = "प्रिंट"
    override val pdfBrandingOption = "मेरी दुकान का नाम, लोगो और पता जोड़ें"
    override val pdfBrandingMissing = "दुकान का नाम नहीं दिया गया — अधिक → दुकान की प्रोफ़ाइल में जाकर जोड़ें"
    override val pdfSavedMessage = "PDF सेव हो गई"
    override val pdfSaveFailed = "PDF सेव नहीं हो सकी"

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    override val setupRoleTitle = "आप ऐप का उपयोग कैसे करेंगे?"
    override val setupProfileTitle = "आपकी दुकान की जानकारी"
    override val setupProfileSubtitle = "बाद में अधिक → दुकान की प्रोफ़ाइल से बदल सकते हैं"
    override val setupContinue = "आगे बढ़ें"
    override val setupSkip = "अभी नहीं, बाद में करूँगा"
    override val setupFinish = "शुरू करें"

    override val pickFromContacts = "संपर्कों से नंबर चुनें"

    // ── ⭐ PDF: পণ্যভিত্তিক হিসাবের কলাম ──
    override val pdfColQtyPrice = "मात्रा × दाम"
    override val pdfColItemTotal = "आइटम का कुल"

    // ── ⭐ PDF: কাঠের সম্পূর্ণ মাপ ──
    override val pdfWoodSawn = "चिरी लकड़ी"
    override val pdfWoodRound = "गोल लट्ठा"
    override val pdfWoodFormula = "सूत्र"
    override val pdfWoodTotalWord = "कुल"

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    override val pdfMemoTitle = "कैश मेमो"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "बिल नं. / Bill No"
    override val pdfDateTitle = "दिनांक / Date"
    override val pdfPeriodTitle = "अवधि / Period"
    override val pdfSeller = "विक्रेता / Seller"
    override val pdfBuyer = "क्रेता / Buyer"
    override val pdfAddressLabel = "पता: "
    override val pdfColSl = "क्र."
    override val pdfColPieces = "पीस"
    override val pdfColCft = "CFT"
    override val pdfColRate = "रेट (₹/CFT)"
    override val pdfColAmountRs = "कुल (₹)"
    override val pdfColQty = "मात्रा"
    override val pdfColUnitPrice = "दर (₹)"
    override val pdfSecSawn = "चिरी लकड़ी / Sawn Timber"
    override val pdfSecRound = "गोल लट्ठा / Round Log"
    override val pdfSecOther = "अन्य सामान / Other Items"
    override val pdfSecCashCredit = "नकद उधार / Cash Credit"
    override val pdfSecPayments = "जमा / भुगतान / Payments"
    override val pdfBadgeSawn = "चिरी"
    override val pdfBadgeRound = "गोल"
    override val pdfSawnTotal = "चिरी लकड़ी कुल:"
    override val pdfRoundTotal = "गोल लट्ठा कुल:"
    override val pdfTableTotal = "कुल:"
    override val pdfSumBill = "कुल बिल"
    override val pdfSumPaid = "जमा / भुगतान"
    override val pdfSumDue = "बकाया"
    override val pdfWordsTitle = "राशि शब्दों में / Amount in Words:"
    override val pdfSellerSign = "विक्रेता के हस्ताक्षर व मुहर"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "क्रेता के हस्ताक्षर"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "यह कंप्यूटर निर्मित बिल है। हस्ताक्षर के बिना मान्य नहीं।"

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    override val pdfSummaryTitle = "सारांश रिपोर्ट"
    override val moveShopAction = "दूसरी सूची में ले जाएँ"
    override val moveShopTitle = "दूसरी सूची में ले जाएँ?"
    override val moveToShopkeeperMsg = "यह एंट्री \"मैं दुकानदार हूँ\" सूची में (आपके ग्राहक के रूप में) चली जाएगी। रकम वही रहेगी, केवल शब्द बदलेंगे।"
    override val moveToCustomerMsg = "यह एंट्री \"मैं ग्राहक हूँ\" सूची में (जिस दुकान से आप उधार लेते हैं) चली जाएगी। रकम वही रहेगी, केवल शब्द बदलेंगे।"
    override val moveShopConfirm = "ले जाएँ"
}

/** ⭐ মারাঠি (मराठी) */
object MarathiStrings : AppStrings {
    override val code = "mr"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "जाहिराती काढा"
    override val moreHintAdFree = "एकदा खरेदी करा, पुन्हा जाहिराती नाहीत"
    override val adFreeDialogTitle = "जाहिरातमुक्त ॲप"
    override val adFreeDialogMessage = "एकदा पैसे दिल्यावर सर्व जाहिराती कायमच्या बंद होतील. ॲपला पाठिंबा दिल्याबद्दल धन्यवाद!"
    override val adFreeBuyButton = "खरेदी करा"
    override val adFreeRestoreButton = "आधीची खरेदी परत आणा"
    override val adFreeActiveLabel = "तुमचे ॲप जाहिरातमुक्त आहे ✓"
    override val adFreeUnavailable = "सध्या खरेदी करता येत नाही — नंतर पुन्हा प्रयत्न करा"
    override val adSponsoredLabel = "जाहिरात"
    override val moreAdPrivacy = "जाहिरातींची निवड"
    override val moreHintAdPrivacy = "तुम्हाला कोणत्या प्रकारच्या जाहिराती दिसाव्यात ते ठरवा"
    override val helpCenterTitle = "मदत केंद्र"
    override val helpSearchPlaceholder = "प्रश्न शोधा..."
    override val noFaqResultsMessage = "काहीही सापडले नाही"
    override val homeHeadline = "उधार हिशेब"
    override val history = "इतिहास"
    override val settings = "सेटिंग्ज"
    override val totalDueLabel = "एकूण बाकी"
    override val thisMonthCreditLabel = "या महिन्याची बाकी"
    override val thisMonthPaymentLabel = "या महिन्यात मिळाले"
    override val searchPlaceholder = "दुकान/फोन शोधा..."
    override val filterAll = "सर्व"
    override val settledLabel = "चुकते"
    override val noShopsYetTitle = "अजून कोणतेही दुकान नाही"
    override val noShopsYetSubtitle = "खाते सुरू करण्यासाठी पहिले दुकान जोडा"
    override val addFirstShopButton = "पहिले दुकान जोडा"
    override val newShop = "नवीन दुकान"
    override val shopTypeTea = "चहाचे दुकान"
    override val shopTypeHardwareElectric = "हार्डवेअर व इलेक्ट्रिक"
    override val shopTypeKirana = "किराणा दुकान"
    override val shopTypeVegetable = "भाजीचे दुकान"
    override val shopTypeFishMeat = "मासे व मटण"
    override val shopTypeBakerySweets = "बेकरी व मिठाई"
    override val shopTypePharmacy = "औषधाचे दुकान"
    override val shopTypeCosmetics = "सौंदर्य प्रसाधने"
    override val shopTypeStationery = "स्टेशनरी"
    override val shopTypeXeroxPrinting = "झेरॉक्स व प्रिंटिंग"
    override val shopTypeWood = "लाकडाचे दुकान"
    override val shopTypeGarments = "कपड्यांचे दुकान"
    override val shopTypeOther = "इतर"
    override val back = "मागे"
    override val cancel = "रद्द करा"
    override val save = "सेव्ह करा"
    override val shopNameLabel = "दुकानाचे नाव *"
    override val shopNamePlaceholder = "उदा. लाकूड महाल"
    override val phoneLabel = "फोन नंबर (ऐच्छिक)"
    override val shopTypeLabel = "दुकानाचा प्रकार *"
    override val saveShopButton = "दुकान सेव्ह करा"
    override val errorNameRequired = "दुकानाचे नाव लिहा"
    override val errorTypeRequired = "दुकानाचा प्रकार निवडा"
    override val dueLabel = "बाकी"
    override val noTransactionsYet = "अजून कोणताही व्यवहार नाही"
    override val creditButton = "उधार घेतले"
    override val paymentButton = "पैसे भरले"
    override val pdfExport = "PDF एक्सपोर्ट"
    override val archive = "आर्काइव्ह"
    override val deleteShopAction = "दुकान हटवा"
    override val archiveConfirmTitle = "हे दुकान आर्काइव्ह करायचे?"
    override val archiveConfirmText = "ते होमच्या यादीतून निघून जाईल — इतिहासात तरीही दिसेल."
    override val deleteConfirmTitle = "हे दुकान कायमचे हटवायचे?"
    override val deleteConfirmText = "हे दुकान आणि त्याचे सर्व व्यवहार कायमचे हटवले जातील आणि परत मिळणार नाहीत. आर्काइव्ह केल्यास ते इतिहासात राहील — पुढे जाण्यापूर्वी नक्की विचार करा."
    override val yesDelete = "होय, हटवा"
    override val yesArchive = "आर्काइव्ह करा"
    override val txnDeletedSnackbar = "व्यवहार हटवला"
    override val undo = "पूर्ववत करा"
    override val pdfFailPrefix = "PDF तयार होऊ शकली नाही: "
    override val shareKhata = "खाते शेअर करा"
    override val creditFallback = "उधार"
    override val paymentFallback = "जमा"
    override val deleteTxnAction = "हटवा"
    override val productNameLabel = "वस्तूचे नाव (ऐच्छिक)"
    override val quantityLabel = "प्रमाण"
    override val unitLabel = "एकक"
    override val pricePerUnitLabel = "दर/एकक"
    override val totalPrefix = "एकूण: "
    override val amountLabel = "भरलेली रक्कम"
    override val orEnterAmountLabel = "किंवा थेट रक्कम लिहा"
    override val noteLabel = "टीप (ऐच्छिक)"
    override val cash = "रोख"
    override val bkash = "bKash"
    override val bank = "बँक"
    override val invalidAmountError = "योग्य रक्कम लिहा"
    override val cftCalculatorTitle = "CFT कॅल्क्युलेटर"
    override val lengthLabel = "लांबी (इंच)"
    override val widthLabel = "रुंदी"
    override val heightLabel = "उंची"
    override val rateLabel = "दर /cft (₹)"
    override val applyToEntryButton = "एंट्रीमध्ये जोडा"
    override val settingsTitle = "सेटिंग्ज"
    override val security = "सुरक्षा"
    override val pinLockOn = "PIN लॉक चालू आहे"
    override val pinLockOff = "PIN लॉक बंद आहे"
    override val changePin = "PIN बदला"
    override val reminderTitle = "बाकीची आठवण"
    override val reminderDesc = "रोज बाकीची आठवण करून देते"
    override val about = "माहिती"
    override val aboutLine = "उधार हिशेब — दुकानाचे उधार खाते"
    override val aboutDescription = "उधार हिशेब हे एक स्मार्ट हिशेब ॲप आहे, जे तुम्हाला दुकानातील उधार, बाकी आणि व्यवहार सहज, जलद आणि व्यवस्थित सांभाळण्यास मदत करते. कोणत्या दुकानात किती बाकी आहे, कुठे पैसे भरले आणि कोणता व्यवहार कधी झाला — सर्व काही एकाच ठिकाणी नीट जतन करून ठेवता येते.\n\nया ॲपमध्ये तुम्ही सहज दुकाने जोडू शकता, उधार आणि जमा नोंदवू शकता, व्यवहारांचा इतिहास पाहू शकता, एकूण बाकी व जमा तपासू शकता आणि तपशीलवार रिपोर्ट तयार करू शकता. शोध, फिल्टर, बॅकअप व रिस्टोअर, ॲप लॉक, बायोमेट्रिक सुरक्षा, डार्क मोड आणि नोटिफिकेशन यांसारख्या सुविधांमुळे हिशेब सांभाळणे आणखी सोपे आणि सुरक्षित होते.\n\nकागदी वहीतील गुंतागुंत सोप्या, आधुनिक आणि विश्वासार्ह डिजिटल पद्धतीत आणणे हे उधार हिशेबचे ध्येय आहे."
    override val aboutTagline = "उधार हिशेब — सोपा हिशेब, निश्चिंत रहा."
    override val versionLine = "आवृत्ती 1.0"
    override val setPinTitle = "PIN सेट करा"
    override val newPinLabel = "नवीन PIN"
    override val confirmPinLabel = "PIN पुन्हा लिहा"
    override val pinSetupError = "PIN जुळत नाहीत (किमान 4 अंक)"
    override val removePinTitle = "PIN लॉक बंद करायचे?"
    override val removePinText = "आता ॲप उघडताना PIN विचारला जाणार नाही."
    override val yesTurnOff = "होय, बंद करा"
    override val no = "नाही"
    override val languageTitle = "भाषा"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "नोटिफिकेशन"
    override val notifSheetSubtitle = "तुम्हाला कोणत्या आठवणी हव्या आहेत?"
    override val notifDueReminderOption = "बाकी भरण्याची आठवण"
    override val notifWeeklySummaryOption = "साप्ताहिक सारांश"
    override val notifAppNewsOption = "ॲपच्या बातम्या आणि अपडेट"
    override val langSheetSubtitle = "ॲप कोणत्या भाषेत चालवायचे?"
    override val themeSheetSubtitle = "तुम्हाला कोणती थीम आवडते?"
    override val securityPrivacyTitle = "सुरक्षा आणि गोपनीयता"
    override val pinSectionTitle = "PIN लॉक"
    override val pinSectionDesc = "ॲप उघडताना PIN विचारा"
    override val fingerprintTitle = "फिंगरप्रिंट लॉक"
    override val fingerprintDesc = "PIN ऐवजी फिंगरप्रिंटने उघडा"
    override val fingerprintUnavailable = "या फोनमध्ये फिंगरप्रिंट सेन्सर सापडला नाही"
    override val lockImmediatelyTitle = "लगेच लॉक करा"
    override val lockImmediatelyDesc = "ॲपमध्ये परत येताच पुन्हा लॉक होईल"
    override val rateTitle = "रेटिंग आणि अभिप्राय"
    override val rateSubtitle = "उधार हिशेब तुम्हाला कसा वाटतो?"
    override val rateStarsPrompt = "रेटिंग देण्यासाठी टॅप करा"
    override val rateThanksMessage = "धन्यवाद! तुम्हाला Play Store वर नेत आहोत…"
    override val feedbackPromptLow = "तुम्हाला काय आवडले नाही? आम्हाला सांगा"
    override val feedbackPlaceholder = "तुमचा अभिप्राय लिहा…"
    override val feedbackSubmit = "पाठवा"
    override val feedbackThanks = "धन्यवाद, तुमचा अभिप्राय पाठवला गेला"
    override val aboutPageTitle = "उधार हिशेब बद्दल"
    override val aboutVersionPrefix = "आवृत्ती"
    override val aboutDeveloperLabel = "डेव्हलपर"
    override val aboutDeveloperName = "उधार हिशेब टीम"
    override val aboutPrivacyPolicy = "गोपनीयता धोरण"
    override val privacyPolicyEffectiveDate = "प्रभावी दिनांक: 13 सप्टेंबर 2026"
    override val aboutShareApp = "शेअर करा"
    override val aboutShareText = "उधार हिशेब — दुकानाच्या उधार खात्याचे हे ॲप वापरून पहा!"
    override val noArchivedShops = "आर्काइव्ह केलेले दुकान नाही"
    override val noSettledShops = "चुकते झालेले दुकान नाही"
    override val setupPinTitle = "4 अंकी PIN सेट करा"
    override val unlockPinTitle = "PIN ने उघडा"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 अंक लिहा"
    override val pinsDontMatchError = "PIN जुळत नाहीत"
    override val wrongPinError = "PIN चुकीचा आहे — पुन्हा प्रयत्न करा"
    override val savePinButton = "PIN सेव्ह करा"
    override val unlockButton = "उघडा"
    override val pdfHeaderTitle = "खाते — उधार हिशेब"
    override val pdfFullKhataSuffix = "पूर्ण खाते"
    override val pdfShopLabel = "दुकान: "
    override val pdfPhoneLabel = "फोन: "
    override val pdfCreatedLabel = "तयार केले: "
    override val pdfColDate = "तारीख/वेळ"
    override val pdfColDesc = "तपशील"
    override val pdfTotalCredit = "एकूण उधार:"
    override val pdfTotalPayment = "एकूण जमा:"
    override val pdfCurrentDue = "सध्याची बाकी:"
    override val pdfFooter = "उधार हिशेब ॲपमधून तयार केले"
    override val navHome = "होम"
    override val navHistory = "इतिहास"
    override val navReports = "रिपोर्ट"
    override val navMore = "अधिक"
    override val historyFilterAllShops = "सर्व दुकाने"
    override val historyFilterAllTypes = "सर्व"
    override val historyFilterCreditOnly = "फक्त उधार"
    override val historyFilterPaymentOnly = "फक्त जमा"
    override val historyNoTxnsFound = "एकही व्यवहार सापडला नाही"
    override val viewArchivedAction = "आर्काइव्ह केलेली दुकाने पहा"
    override val reportsTitle = "रिपोर्ट"
    override val periodLabel = "कालावधी"
    override val period7d = "मागील 7 दिवस"
    override val period15d = "मागील 15 दिवस"
    override val period30d = "मागील 30 दिवस"
    override val period3m = "मागील 3 महिने"
    override val period1y = "या वर्षी"
    override val reportTotalCredit = "एकूण उधार"
    override val reportTotalPayment = "एकूण जमा"
    override val reportCurrentDue = "सध्याची एकूण बाकी"
    override val reportTxnCount = "व्यवहार"
    override val reportChartTitle = "उधार विरुद्ध जमा"
    override val reportShopWiseTitle = "दुकानानुसार बाकी"
    override val reportAgingTitle = "बाकीचे वय"
    override val reportAging0to7 = "0–7 दिवस"
    override val reportAging7to15 = "7–15 दिवस"
    override val reportAging15to30 = "15–30 दिवस"
    override val reportAging30plus = "30+ दिवस"
    override val reportRecentPaymentsTitle = "अलीकडील जमा"
    override val reportNoData = "या कालावधीची माहिती नाही"
    override val reportSmartSummaryPrefix = "या कालावधीत तुम्ही"
    override val moreTitle = "अधिक"
    override val moreBackupRestore = "बॅकअप व रिस्टोअर"
    override val moreHintBackupRestore = "तुमचा डेटा सुरक्षित ठेवा"
    override val notesTitle = "नोट्स"
    override val notesSearchPlaceholder = "नोट्स शोधा..."
    override val addNoteButton = "नवीन नोट"
    override val noNotesYetTitle = "अजून कोणत्याही नोट्स नाहीत"
    override val noNotesYetSubtitle = "खरेदीची यादी, आठवणी — काहीही लिहून ठेवा"
    override val deleteNoteConfirmTitle = "ही नोट हटवायची?"
    override val deleteNoteConfirmMessage = "ही नोट कायमची हटवली जाईल."
    override val noteTitlePlaceholder = "शीर्षक"
    override val noteContentPlaceholder = "काहीतरी लिहा..."
    override val untitledNote = "शीर्षक नसलेली नोट"
    override val notificationInboxTitle = "नोटिफिकेशन"
    override val moreNotificationHistory = "नोटिफिकेशन इतिहास"
    override val moreHintNotificationHistory = "अलीकडील हालचाली पहा"
    override val noNotificationsYetTitle = "अजून कोणतेही नोटिफिकेशन नाही"
    override val noNotificationsYetSubtitle = "उधार किंवा जमा नोंदवल्यावर ते इथे दिसेल"
    override val notifCreditMessage = "%1\$s कडून %2\$s उधार घेतले"
    override val notifPaymentMessage = "%1\$s ला %2\$s जमा केले"
    override val moreQuickCalculator = "क्विक कॅल्क्युलेटर"
    override val moreHintQuickCalculator = "झटपट हिशेब करा"
    override val calcGeneralTab = "सामान्य"
    override val calcPercentTab = "टक्के"
    override val calcConversionTab = "रूपांतर"
    override val calcComingSoonInTab = "लवकरच येत आहे"
    override val percentOfTitle = "एखाद्या संख्येचे टक्के"
    override val percentOfValueLabel = "संख्या"
    override val percentOfPercentLabel = "टक्के (%)"
    override val percentIsWhatTitle = "एक संख्या दुसरीच्या किती टक्के"
    override val percentIsWhatXLabel = "ही संख्या"
    override val percentIsWhatYLabel = "याच्या"
    override val percentChangeTitle = "टक्के वाढ/घट"
    override val percentChangeBaseLabel = "मूळ संख्या"
    override val percentChangePercentLabel = "टक्के (%)"
    override val increaseOption = "वाढ"
    override val decreaseOption = "घट"
    override val resultLabel = "निकाल"
    override val weightCategory = "वजन"
    override val lengthCategory = "लांबी"
    override val volumeCategory = "आकारमान"
    override val fromLabel = "पासून"
    override val toLabel = "पर्यंत"
    override val enterValueHint = "किंमत लिहा"
    override val backupNowButton = "आता बॅकअप घ्या"
    override val backupNowHint = "सर्व दुकाने आणि व्यवहार JSON फाइलमध्ये सेव्ह करा"
    override val restoreButton = "बॅकअपमधून रिस्टोअर करा"
    override val restoreShopAction = "रिस्टोअर"
    override val restoreHint = "जुन्या JSON बॅकअप फाइलमधून डेटा परत आणा"
    override val lastBackupLabel = "शेवटचा बॅकअप"
    override val noBackupYetLabel = "अजून बॅकअप घेतलेला नाही"
    override val backupSuccessMessage = "बॅकअप तयार झाला"
    override val backupFailPrefix = "बॅकअप अयशस्वी: "
    override val restoreConfirmTitle = "बॅकअप रिस्टोअर करायचा?"
    override val restoreConfirmMessage = "यामुळे सध्याची सर्व दुकाने आणि व्यवहार पुसले जातील आणि बॅकअप फाइलचा डेटा येईल. हे पूर्ववत करता येणार नाही."
    override val restoreSuccessMessage = "रिस्टोअर पूर्ण झाले"
    override val restoreFailPrefix = "रिस्टोअर अयशस्वी: "
    override val dataSafeNote = "तुमचा डेटा फक्त या फोनमध्येच राहतो — बॅकअप फाइल स्वतः सुरक्षित ठेवा"
    override val moreExportShare = "एक्सपोर्ट व शेअर"
    override val moreHintExportShare = "PDF व फाइल्स पाठवा"
    override val moreNotifications = "नोटिफिकेशन"
    override val moreHintNotifications = "आठवणी चालू/बंद करा"
    override val moreLanguage = "भाषा"
    override val moreHintLanguage = "तुमची भाषा निवडा"
    override val moreUserMode = "मी कोण"
    override val moreHintUserMode = "ग्राहक किंवा दुकानदार"
    override val moreSecurityPrivacy = "सुरक्षा आणि गोपनीयता"
    override val moreHintSecurityPrivacy = "PIN व फिंगरप्रिंट लॉक"
    override val moreAppearance = "दिसणे"
    override val moreHintAppearance = "लाईट, डार्क किंवा सिस्टम"
    override val moreRateFeedback = "रेटिंग आणि अभिप्राय"
    override val moreHintRateFeedback = "तुमचे मत सांगा"
    override val moreAbout = "उधार हिशेब बद्दल"
    override val moreHintAbout = "आवृत्ती व डेव्हलपर"
    override val comingSoonMessage = "लवकरच येत आहे"
    override val appearanceTitle = "दिसणे"
    override val themeLight = "लाईट"
    override val themeDark = "डार्क"
    override val themeSystem = "सिस्टम डिफॉल्ट"
    override val creditPageTitle = "उधार घ्या"
    override val accountingTypeLabel = "एंट्रीचा प्रकार"
    override val directMoneyMode = "थेट रक्कम"
    override val productMode = "वस्तूनुसार"
    override val directMoneyAmountLabel = "किती उधार दिले?"
    override val previousDueLabel = "मागील बाकी"
    override val newCreditLabel = "नवीन उधार"
    override val newTotalDueLabel = "नवीन एकूण बाकी"
    override val addCreditButton = "उधार जोडा"
    override val addMoreProductButton = "+ आणखी वस्तू जोडा"
    override val totalNewCreditLabel = "एकूण नवीन उधार"
    override val editAction = "बदला"
    override val itemsCountSuffix = "वस्तू"
    override val paymentPageTitle = "जमा"
    override val currentDueLabel = "सध्याची बाकी"
    override val howMuchPaymentLabel = "किती जमा करत आहात?"
    override val fullPaymentButton = "पूर्ण रक्कम"
    override val dueAfterPaymentLabel = "जमा केल्यानंतर बाकी"
    override val addPaymentButton = "जमा जोडा"
    override val overpaymentBlockedMessage = "सध्याच्या बाकीपेक्षा जास्त जमा करता येत नाही"
    override val fullyPaidCelebration = "यामुळे पूर्ण बाकी चुकती होईल"
    override val woodCalculatorTitle = "लाकूड कॅल्क्युलेटर"
    override val woodTypeLabel = "लाकडाचा प्रकार"
    override val sawnWoodOption = "कापलेले लाकूड"
    override val roundWoodOption = "गोल ओंडका"
    override val lengthFtLabel = "लांबी (फूट)"
    override val widthInLabel = "रुंदी (इंच)"
    override val thicknessInLabel = "जाडी (इंच)"
    override val girthInLabel = "घेर (इंच)"
    override val pieceCountLabel = "तुकड्यांची संख्या"
    override val perPieceCftLabel = "प्रति तुकडा"
    override val totalWoodCftLabel = "एकूण लाकूड"
    override val perCftPriceLabel = "प्रति CFT दर (₹)"
    override val totalWoodValueLabel = "एकूण किंमत"
    override val addWoodCalcButton = "हा लाकडाचा हिशेब जोडा"
    override val woodNameLabel = "वस्तूचे नाव"
    override val addMoreWoodProductButton = "+ आणखी लाकूड/वस्तू जोडा"
    override val addedItemsHeader = "जोडलेल्या वस्तू/लाकूड"
    override val pdfOptionsTitle = "PDF पर्याय"
    override val pdfPeriodLabel = "कालावधी"
    override val pdfThisMonth = "हा महिना"
    override val pdfLastMonth = "मागील महिना"
    override val pdfLast3Months = "मागील 3 महिने"
    override val pdfCustomRange = "स्वतःच्या तारखा"
    override val pdfShopLabelOption = "दुकान"
    override val pdfAllShopsOption = "सर्व दुकाने"
    override val pdfContentLabel = "काय दाखवायचे"
    override val pdfContentFull = "सर्व काही (व्यवहार + सारांश + स्वाक्षरी)"
    override val pdfContentSummaryOnly = "फक्त सारांश"
    override val pdfContentTxnsOnly = "फक्त व्यवहार"
    override val pdfFormatLabel = "फॉरमॅट"
    override val pdfFormatA4 = "A4 रिपोर्ट"
    override val pdfFormatReceipt = "पावती (58mm)"
    override val pdfGenerateButton = "PDF तयार करा"
    override val pdfFromDateLabel = "सुरुवातीची तारीख"
    override val pdfToDateLabel = "शेवटची तारीख"
    override val pdfReportNumberLabel = "रिपोर्ट क्र."
    override val pdfShopBoxLabel = "दुकान"
    override val pdfDateBoxLabel = "तारीख"
    override val pdfDaysOfRecordsSuffix = "दिवसांचा रेकॉर्ड"
    override val pdfWeeklyChartTitle = "साप्ताहिक उधार (लाल) विरुद्ध जमा (हिरवा)"
    override val pdfFinalDueLabel = "सध्याची बाकी"
    override val pdfShopSignatureLabel = "दुकानदाराची स्वाक्षरी"
    override val pdfCustomerSignatureLabel = "ग्राहकाची स्वाक्षरी"
    override val pdfAllShopsReportTitle = "सर्व दुकानांचा सारांश — उधार हिशेब"
    override val pdfPageLabel = "पान"
    override val moreShopProfile = "दुकानाचे प्रोफाइल"
    override val moreHintShopProfile = "नाव, लोगो, पत्ता, आठवण"
    override val shopProfileTitle = "दुकानाचे प्रोफाइल"
    override val shopProfileIntro = "ही माहिती PDF इनव्हॉइसमध्ये आणि ग्राहकाला पाठवलेल्या संदेशांमध्ये वापरली जाईल"
    override val shopBusinessNameLabel = "दुकानाचे नाव"
    override val shopBusinessAddressLabel = "दुकानाचा पत्ता"
    override val shopBusinessPhoneLabel = "दुकानाचा फोन नंबर"
    override val countryCodeLabel = "देश कोड (उदा. 91)"
    override val shopLogoLabel = "दुकानाचा लोगो"
    override val shopLogoPick = "लोगो निवडा"
    override val shopLogoRemove = "लोगो काढा"
    override val promptAfterEntryLabel = "एंट्रीनंतर ग्राहकाला कळवण्याचा पर्याय दाखवा"
    override val saveProfileButton = "प्रोफाइल सेव्ह करा"
    override val profileSavedMessage = "प्रोफाइल सेव्ह झाले"
    override val errorShopNameForPdf = "PDF मध्ये वापरण्यासाठी दुकानाचे नाव द्या"
    override val reminderSendAction = "आठवण पाठवा"
    override val reminderDialogTitle = "ग्राहकाला कळवा"
    override val reminderDialogSubtitle = "संदेश बदलून WhatsApp किंवा SMS ने पाठवा"
    override val reminderMessageLabel = "संदेश"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "आता नाही"
    override val reminderNoPhone = "या ग्राहकाचा फोन नंबर नाही"
    override val reminderAppMissing = "ॲप उघडता आले नाही"
    override val reminderShopFallback = "आमचे दुकान"
    override val reminderMsgDue = "नमस्कार %1\$s, %2\$s च्या खात्यात तुमची एकूण बाकी %3\$s आहे. कृपया वेळेवर भरा. धन्यवाद."
    override val reminderMsgCredit = "नमस्कार %1\$s, %2\$s च्या खात्यात तुमचे नवीन उधार जोडले गेले आहे. एकूण बाकी: %3\$s."
    override val reminderMsgPayment = "नमस्कार %1\$s, तुमचे पैसे मिळाले. धन्यवाद! %2\$s च्या खात्यात सध्याची बाकी: %3\$s."
    override val reminderMsgSettled = "नमस्कार %1\$s, तुमची सर्व बाकी चुकती झाली आहे. धन्यवाद! — %2\$s"
    override val pdfActionLabel = "📤 काय करायचे"
    override val pdfActionShare = "शेअर"
    override val pdfActionSave = "सेव्ह"
    override val pdfActionPrint = "प्रिंट"
    override val pdfBrandingOption = "माझ्या दुकानाचे नाव, लोगो आणि पत्ता जोडा"
    override val pdfBrandingMissing = "दुकानाचे नाव दिलेले नाही — अधिक → दुकानाचे प्रोफाइल मध्ये जाऊन जोडा"
    override val pdfSavedMessage = "PDF सेव्ह झाली"
    override val pdfSaveFailed = "PDF सेव्ह करता आली नाही"
    override val setupRoleTitle = "तुम्ही ॲप कसे वापराल?"
    override val setupProfileTitle = "तुमच्या दुकानाची माहिती"
    override val setupProfileSubtitle = "नंतर अधिक → दुकानाचे प्रोफाइल मधून बदलता येईल"
    override val setupContinue = "पुढे जा"
    override val setupSkip = "आता नको, नंतर करेन"
    override val setupFinish = "सुरू करा"
    override val pickFromContacts = "संपर्कांमधून नंबर निवडा"
    override val pdfColQtyPrice = "प्रमाण × दर"
    override val pdfColItemTotal = "वस्तूची रक्कम"
    override val pdfWoodSawn = "कापलेले लाकूड"
    override val pdfWoodRound = "गोल ओंडका"
    override val pdfWoodFormula = "सूत्र"
    override val pdfWoodTotalWord = "एकूण"
    override val pdfMemoTitle = "कॅश मेमो"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "बिल क्र. / Bill No"
    override val pdfDateTitle = "दिनांक / Date"
    override val pdfPeriodTitle = "कालावधी / Period"
    override val pdfSeller = "विक्रेता / Seller"
    override val pdfBuyer = "खरेदीदार / Buyer"
    override val pdfAddressLabel = "पत्ता: "
    override val pdfColSl = "अ.क्र."
    override val pdfColPieces = "नग"
    override val pdfColCft = "CFT"
    override val pdfColRate = "दर (₹/CFT)"
    override val pdfColAmountRs = "एकूण (₹)"
    override val pdfColQty = "प्रमाण"
    override val pdfColUnitPrice = "दर (₹)"
    override val pdfSecSawn = "कापलेले लाकूड / Sawn Timber"
    override val pdfSecRound = "गोल ओंडका / Round Log"
    override val pdfSecOther = "इतर वस्तू / Other Items"
    override val pdfSecCashCredit = "रोख उधार / Cash Credit"
    override val pdfSecPayments = "जमा / Payments"
    override val pdfBadgeSawn = "कापलेले"
    override val pdfBadgeRound = "गोल"
    override val pdfSawnTotal = "कापलेल्या लाकडाचे एकूण:"
    override val pdfRoundTotal = "गोल ओंडक्याचे एकूण:"
    override val pdfTableTotal = "एकूण:"
    override val pdfSumBill = "एकूण बिल"
    override val pdfSumPaid = "जमा"
    override val pdfSumDue = "बाकी"
    override val pdfWordsTitle = "रक्कम अक्षरी / Amount in Words:"
    override val pdfSellerSign = "विक्रेत्याची स्वाक्षरी व शिक्का"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "खरेदीदाराची स्वाक्षरी"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "हे संगणकाद्वारे तयार केलेले बिल आहे. स्वाक्षरीशिवाय वैध नाही."
    override val pdfSummaryTitle = "सारांश रिपोर्ट"
    override val moveShopAction = "दुसऱ्या यादीत हलवा"
    override val moveShopTitle = "दुसऱ्या यादीत हलवायचे?"
    override val moveToShopkeeperMsg = "ही एंट्री \"मी दुकानदार\" यादीत (तुमचा ग्राहक म्हणून) जाईल. रकमा तशाच राहतील, फक्त शब्द बदलतील."
    override val moveToCustomerMsg = "ही एंट्री \"मी ग्राहक\" यादीत (ज्या दुकानातून तुम्ही उधार घेता) जाईल. रकमा तशाच राहतील, फक्त शब्द बदलतील."
    override val moveShopConfirm = "हलवा"
    override val faqItems = listOf(
        FaqItem("नवीन दुकान कशी जोडायची?", "होम पानावरील '+' बटण दाबा, दुकानाचे नाव, फोन (ऐच्छिक) आणि प्रकार लिहा, मग 'सेव्ह करा' दाबा."),
        FaqItem("उधार किंवा जमा कसे नोंदवायचे?", "दुकानाचे पान उघडा आणि 'उधार घेतले' किंवा 'पैसे भरले' दाबा, रक्कम लिहा आणि निश्चित करा."),
        FaqItem("बायोमेट्रिक लॉक कसे चालू/बंद करायचे?", "अधिक → सुरक्षा आणि गोपनीयता मध्ये जाऊन 'बायोमेट्रिक लॉक' चालू/बंद करा. तुमच्या फोनमध्ये फिंगरप्रिंट किंवा फेस अनलॉक सेट असणे आवश्यक आहे."),
        FaqItem("डेटाचा बॅकअप कसा घ्यायचा?", "अधिक → बॅकअप व रिस्टोअर मध्ये जाऊन 'आता बॅकअप घ्या' दाबा. यातून एक JSON फाइल तयार होते, जी तुम्ही फोनमध्ये किंवा क्लाउडमध्ये सेव्ह करू शकता."),
        FaqItem("बॅकअपमधून डेटा परत कसा आणायचा?", "अधिक → बॅकअप व रिस्टोअर मध्ये जाऊन 'बॅकअपमधून रिस्टोअर करा' दाबा आणि तुमची JSON फाइल निवडा. यामुळे सध्याचा सर्व डेटा बदलतो, म्हणून काळजी घ्या."),
        FaqItem("दुकान हटवले तर परत मिळेल का?", "आर्काइव्ह केल्यास ते इतिहासात राहते आणि नंतर परत आणता येते. कायमचे हटवल्यास ते परत मिळत नाही."),
        FaqItem("PDF रिपोर्ट कसा बनवायचा?", "'अधिक' पानावर बॅकअप व रिस्टोअरच्या शेजारी एक्सपोर्टचा पर्याय आहे, दुकान आणि कालावधी निवडा आणि PDF शेअर करा."),
        FaqItem("ॲपची भाषा कशी बदलायची?", "अधिक → भाषा मध्ये जाऊन तुमची भाषा निवडा आणि 'सेव्ह करा' दाबा.")
    )
    override val privacyPolicyBody = """उधार हिशेब हे एक वैयक्तिक आर्थिक/खातेवही ॲप आहे, जे तुम्हाला दुकानातील उधार, बाकी आणि व्यवहार सोप्या पद्धतीने सांभाळण्यास मदत करते. तुमची गोपनीयता आमच्यासाठी महत्त्वाची आहे.

1. आम्ही गोळा करत असलेली माहिती

उधार हिशेब वापरताना तुम्ही स्वतः ॲपमध्ये भरलेली माहिती, जसे की:
• दुकानाचे नाव
• मोबाईल नंबर
• दुकानाचा पत्ता किंवा इतर तपशील
• उधार आणि जमा रकमा
• व्यवहाराची तारीख, वेळ आणि टीप

2. माहितीचा वापर

ही माहिती फक्त तुमचे हिशेब साठवण्यासाठी, दाखवण्यासाठी आणि सांभाळण्यासाठी वापरली जाते. तुमचा वैयक्तिक खातेवही डेटा तुमच्या परवानगीशिवाय कोणत्याही जाहिरातदाराला किंवा तिसऱ्या पक्षाला विकला किंवा शेअर केला जाणार नाही.

3. डेटा साठवण

तुमचा हिशेब डेटा ॲपच्या गरजेनुसार तुमच्या डिव्हाइसवर साठवला जाऊ शकतो. तुम्ही बॅकअप व रिस्टोअर सुविधा वापरल्यास, तुमचा बॅकअप डेटा तुम्ही निवडलेल्या स्टोरेज/क्लाउड सेवेद्वारे साठवला जाऊ शकतो.

4. ॲप सुरक्षा

तुमचा हिशेब डेटा सुरक्षित ठेवण्यासाठी ॲप लॉक, PIN आणि बायोमेट्रिक ऑथेंटिकेशन यांसारख्या सुरक्षा सुविधा दिल्या जाऊ शकतात.

5. माहिती शेअर करणे

कायद्याने आवश्यक असेल त्याशिवाय आम्ही तुमचा वैयक्तिक खातेवही डेटा तिसऱ्या पक्षांना विकत नाही, भाड्याने देत नाही किंवा व्यावसायिक कारणांसाठी शेअर करत नाही.

6. तुमचे नियंत्रण

ॲपमध्ये साठवलेला तुमचा डेटा तुम्ही केव्हाही पाहू, बदलू किंवा हटवू शकता.

7. तिसऱ्या पक्षाच्या सेवा

ॲपच्या काही सुविधांसाठी तिसऱ्या पक्षाच्या सेवा वापरल्या गेल्यास, त्यांचे स्वतःचे गोपनीयता धोरण लागू होऊ शकते.

8. मुलांची गोपनीयता

उधार हिशेब जाणूनबुजून मुलांकडून वैयक्तिक माहिती गोळा करण्यासाठी बनवलेले नाही.

9. या गोपनीयता धोरणातील बदल

आम्ही गरजेनुसार हे गोपनीयता धोरण बदलू किंवा अद्ययावत करू शकतो. कोणतेही नवीन धोरण या पानावर प्रकाशित केले जाईल.

10. संपर्क

या गोपनीयता धोरणाबद्दल किंवा तुमच्या डेटाबद्दल काही प्रश्न असल्यास कृपया आमच्याशी संपर्क साधा.

उधार हिशेब
सोपा हिशेब, निश्चिंत रहा."""
}

/** ⭐ গুজরাটি (ગુજરાતી) */
object GujaratiStrings : AppStrings {
    override val code = "gu"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "જાહેરાતો દૂર કરો"
    override val moreHintAdFree = "એકવાર ખરીદો, ફરી જાહેરાત નહીં"
    override val adFreeDialogTitle = "જાહેરાતમુક્ત એપ"
    override val adFreeDialogMessage = "એકવાર પૈસા આપશો તો બધી જાહેરાતો કાયમ માટે બંધ થઈ જશે. એપને સહકાર આપવા બદલ આભાર!"
    override val adFreeBuyButton = "ખરીદો"
    override val adFreeRestoreButton = "અગાઉની ખરીદી પાછી લાવો"
    override val adFreeActiveLabel = "તમારી એપ જાહેરાતમુક્ત છે ✓"
    override val adFreeUnavailable = "હમણાં ખરીદી શક્ય નથી — પછી ફરી પ્રયાસ કરો"
    override val adSponsoredLabel = "જાહેરાત"
    override val moreAdPrivacy = "જાહેરાતની પસંદગી"
    override val moreHintAdPrivacy = "તમને કેવી જાહેરાતો દેખાય તે નક્કી કરો"
    override val helpCenterTitle = "સહાય કેન્દ્ર"
    override val helpSearchPlaceholder = "પ્રશ્નો શોધો..."
    override val noFaqResultsMessage = "કંઈ મળ્યું નથી"
    override val homeHeadline = "ઉધાર હિસાબ"
    override val history = "ઇતિહાસ"
    override val settings = "સેટિંગ્સ"
    override val totalDueLabel = "કુલ બાકી"
    override val thisMonthCreditLabel = "આ મહિનાની બાકી"
    override val thisMonthPaymentLabel = "આ મહિને મળ્યા"
    override val searchPlaceholder = "દુકાન/ફોન શોધો..."
    override val filterAll = "બધા"
    override val settledLabel = "ચૂકતે"
    override val noShopsYetTitle = "હજી કોઈ દુકાન નથી"
    override val noShopsYetSubtitle = "ખાતું શરૂ કરવા પહેલી દુકાન ઉમેરો"
    override val addFirstShopButton = "પહેલી દુકાન ઉમેરો"
    override val newShop = "નવી દુકાન"
    override val shopTypeTea = "ચાની દુકાન"
    override val shopTypeHardwareElectric = "હાર્ડવેર અને ઇલેક્ટ્રિક"
    override val shopTypeKirana = "કરિયાણાની દુકાન"
    override val shopTypeVegetable = "શાકભાજીની દુકાન"
    override val shopTypeFishMeat = "માછલી અને માંસ"
    override val shopTypeBakerySweets = "બેકરી અને મીઠાઈ"
    override val shopTypePharmacy = "દવાની દુકાન"
    override val shopTypeCosmetics = "કોસ્મેટિક્સ"
    override val shopTypeStationery = "સ્ટેશનરી"
    override val shopTypeXeroxPrinting = "ઝેરોક્સ અને પ્રિન્ટિંગ"
    override val shopTypeWood = "લાકડાની દુકાન"
    override val shopTypeGarments = "કપડાંની દુકાન"
    override val shopTypeOther = "અન્ય"
    override val back = "પાછા"
    override val cancel = "રદ કરો"
    override val save = "સેવ કરો"
    override val shopNameLabel = "દુકાનનું નામ *"
    override val shopNamePlaceholder = "દા.ત. લાકડું મહેલ"
    override val phoneLabel = "ફોન નંબર (વૈકલ્પિક)"
    override val shopTypeLabel = "દુકાનનો પ્રકાર *"
    override val saveShopButton = "દુકાન સેવ કરો"
    override val errorNameRequired = "દુકાનનું નામ લખો"
    override val errorTypeRequired = "દુકાનનો પ્રકાર પસંદ કરો"
    override val dueLabel = "બાકી"
    override val noTransactionsYet = "હજી કોઈ વ્યવહાર નથી"
    override val creditButton = "ઉધાર લીધું"
    override val paymentButton = "ચૂકવણી કરી"
    override val pdfExport = "PDF એક્સપોર્ટ"
    override val archive = "આર્કાઇવ"
    override val deleteShopAction = "દુકાન કાઢી નાખો"
    override val archiveConfirmTitle = "આ દુકાન આર્કાઇવ કરવી છે?"
    override val archiveConfirmText = "તે હોમની યાદીમાંથી હટી જશે — ઇતિહાસમાં હજી પણ મળશે."
    override val deleteConfirmTitle = "આ દુકાન કાયમ માટે કાઢી નાખવી છે?"
    override val deleteConfirmText = "આ દુકાન અને તેના બધા વ્યવહારો કાયમ માટે કાઢી નંખાશે અને પાછા મળશે નહીં. આર્કાઇવ કરશો તો તે ઇતિહાસમાં રહેશે — આગળ વધતાં પહેલાં ચોક્કસ વિચારો."
    override val yesDelete = "હા, કાઢી નાખો"
    override val yesArchive = "આર્કાઇવ કરો"
    override val txnDeletedSnackbar = "વ્યવહાર કાઢી નાખ્યો"
    override val undo = "પાછું લાવો"
    override val pdfFailPrefix = "PDF બની શકી નહીં: "
    override val shareKhata = "ખાતું શેર કરો"
    override val creditFallback = "ઉધાર"
    override val paymentFallback = "જમા"
    override val deleteTxnAction = "કાઢી નાખો"
    override val productNameLabel = "વસ્તુનું નામ (વૈકલ્પિક)"
    override val quantityLabel = "જથ્થો"
    override val unitLabel = "એકમ"
    override val pricePerUnitLabel = "ભાવ/એકમ"
    override val totalPrefix = "કુલ: "
    override val amountLabel = "ચૂકવેલી રકમ"
    override val orEnterAmountLabel = "અથવા સીધી રકમ લખો"
    override val noteLabel = "નોંધ (વૈકલ્પિક)"
    override val cash = "રોકડ"
    override val bkash = "bKash"
    override val bank = "બેંક"
    override val invalidAmountError = "સાચી રકમ લખો"
    override val cftCalculatorTitle = "CFT કેલ્ક્યુલેટર"
    override val lengthLabel = "લંબાઈ (ઇંચ)"
    override val widthLabel = "પહોળાઈ"
    override val heightLabel = "ઊંચાઈ"
    override val rateLabel = "ભાવ /cft (₹)"
    override val applyToEntryButton = "એન્ટ્રીમાં ઉમેરો"
    override val settingsTitle = "સેટિંગ્સ"
    override val security = "સુરક્ષા"
    override val pinLockOn = "PIN લોક ચાલુ છે"
    override val pinLockOff = "PIN લોક બંધ છે"
    override val changePin = "PIN બદલો"
    override val reminderTitle = "બાકીની યાદ"
    override val reminderDesc = "રોજ બાકીની યાદ અપાવે છે"
    override val about = "માહિતી"
    override val aboutLine = "ઉધાર હિસાબ — દુકાનનું ઉધાર ખાતું"
    override val aboutDescription = "ઉધાર હિસાબ એક સ્માર્ટ હિસાબ એપ છે, જે તમને દુકાનનું ઉધાર, બાકી અને વ્યવહારો સરળતાથી, ઝડપથી અને વ્યવસ્થિત રીતે સંભાળવામાં મદદ કરે છે. કઈ દુકાનમાં કેટલી બાકી છે, ક્યાં પૈસા ચૂકવ્યા અને કયો વ્યવહાર ક્યારે થયો — બધું એક જ જગ્યાએ સરસ રીતે સાચવી શકાય છે.\n\nઆ એપમાં તમે સહેલાઈથી દુકાનો ઉમેરી શકો છો, ઉધાર અને જમા નોંધી શકો છો, વ્યવહારોનો ઇતિહાસ જોઈ શકો છો, કુલ બાકી અને જમા તપાસી શકો છો અને વિગતવાર રિપોર્ટ બનાવી શકો છો. સર્ચ, ફિલ્ટર, બેકઅપ અને રિસ્ટોર, એપ લોક, બાયોમેટ્રિક સુરક્ષા, ડાર્ક મોડ અને નોટિફિકેશન જેવી સુવિધાઓથી હિસાબ સંભાળવો વધુ સરળ અને સુરક્ષિત બને છે.\n\nકાગળની ચોપડીની ગૂંચવણને સરળ, આધુનિક અને ભરોસાપાત્ર ડિજિટલ પદ્ધતિમાં લાવવી એ ઉધાર હિસાબનું લક્ષ્ય છે."
    override val aboutTagline = "ઉધાર હિસાબ — સરળ હિસાબ, નિશ્ચિંત રહો."
    override val versionLine = "વર્ઝન 1.0"
    override val setPinTitle = "PIN સેટ કરો"
    override val newPinLabel = "નવો PIN"
    override val confirmPinLabel = "PIN ફરી લખો"
    override val pinSetupError = "PIN મેળ ખાતા નથી (ઓછામાં ઓછા 4 અંક)"
    override val removePinTitle = "PIN લોક બંધ કરવું છે?"
    override val removePinText = "હવે એપ ખોલતી વખતે PIN પૂછવામાં આવશે નહીં."
    override val yesTurnOff = "હા, બંધ કરો"
    override val no = "ના"
    override val languageTitle = "ભાષા"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "નોટિફિકેશન"
    override val notifSheetSubtitle = "તમને કઈ યાદ અપાવવાની જોઈએ છે?"
    override val notifDueReminderOption = "બાકી ચૂકવવાની યાદ"
    override val notifWeeklySummaryOption = "સાપ્તાહિક સારાંશ"
    override val notifAppNewsOption = "એપના સમાચાર અને અપડેટ"
    override val langSheetSubtitle = "એપ કઈ ભાષામાં ચલાવવી છે?"
    override val themeSheetSubtitle = "તમને કઈ થીમ ગમે છે?"
    override val securityPrivacyTitle = "સુરક્ષા અને ગોપનીયતા"
    override val pinSectionTitle = "PIN લોક"
    override val pinSectionDesc = "એપ ખોલતી વખતે PIN પૂછો"
    override val fingerprintTitle = "ફિંગરપ્રિન્ટ લોક"
    override val fingerprintDesc = "PIN ની જગ્યાએ ફિંગરપ્રિન્ટથી ખોલો"
    override val fingerprintUnavailable = "આ ફોનમાં ફિંગરપ્રિન્ટ સેન્સર મળ્યું નથી"
    override val lockImmediatelyTitle = "તરત લોક કરો"
    override val lockImmediatelyDesc = "એપમાં પાછા આવતા જ ફરી લોક થઈ જશે"
    override val rateTitle = "રેટિંગ અને પ્રતિભાવ"
    override val rateSubtitle = "ઉધાર હિસાબ તમને કેવી લાગે છે?"
    override val rateStarsPrompt = "રેટિંગ આપવા ટેપ કરો"
    override val rateThanksMessage = "આભાર! તમને Play Store પર લઈ જઈ રહ્યા છીએ…"
    override val feedbackPromptLow = "તમને શું ગમ્યું નહીં? અમને જણાવો"
    override val feedbackPlaceholder = "તમારો પ્રતિભાવ લખો…"
    override val feedbackSubmit = "મોકલો"
    override val feedbackThanks = "આભાર, તમારો પ્રતિભાવ મોકલાઈ ગયો"
    override val aboutPageTitle = "ઉધાર હિસાબ વિશે"
    override val aboutVersionPrefix = "વર્ઝન"
    override val aboutDeveloperLabel = "ડેવલપર"
    override val aboutDeveloperName = "ઉધાર હિસાબ ટીમ"
    override val aboutPrivacyPolicy = "ગોપનીયતા નીતિ"
    override val privacyPolicyEffectiveDate = "અમલની તારીખ: 13 સપ્ટેમ્બર 2026"
    override val aboutShareApp = "શેર કરો"
    override val aboutShareText = "ઉધાર હિસાબ — દુકાનના ઉધાર ખાતાની આ એપ અજમાવો!"
    override val noArchivedShops = "આર્કાઇવ કરેલી દુકાન નથી"
    override val noSettledShops = "ચૂકતે થયેલી દુકાન નથી"
    override val setupPinTitle = "4 અંકનો PIN સેટ કરો"
    override val unlockPinTitle = "PIN થી ખોલો"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 અંક લખો"
    override val pinsDontMatchError = "PIN મેળ ખાતા નથી"
    override val wrongPinError = "PIN ખોટો છે — ફરી પ્રયાસ કરો"
    override val savePinButton = "PIN સેવ કરો"
    override val unlockButton = "ખોલો"
    override val pdfHeaderTitle = "ખાતું — ઉધાર હિસાબ"
    override val pdfFullKhataSuffix = "સંપૂર્ણ ખાતું"
    override val pdfShopLabel = "દુકાન: "
    override val pdfPhoneLabel = "ફોન: "
    override val pdfCreatedLabel = "બનાવ્યું: "
    override val pdfColDate = "તારીખ/સમય"
    override val pdfColDesc = "વિગત"
    override val pdfTotalCredit = "કુલ ઉધાર:"
    override val pdfTotalPayment = "કુલ જમા:"
    override val pdfCurrentDue = "હાલની બાકી:"
    override val pdfFooter = "ઉધાર હિસાબ એપ દ્વારા બનાવેલ"
    override val navHome = "હોમ"
    override val navHistory = "ઇતિહાસ"
    override val navReports = "રિપોર્ટ"
    override val navMore = "વધુ"
    override val historyFilterAllShops = "બધી દુકાનો"
    override val historyFilterAllTypes = "બધા"
    override val historyFilterCreditOnly = "ફક્ત ઉધાર"
    override val historyFilterPaymentOnly = "ફક્ત જમા"
    override val historyNoTxnsFound = "કોઈ વ્યવહાર મળ્યો નથી"
    override val viewArchivedAction = "આર્કાઇવ કરેલી દુકાનો જુઓ"
    override val reportsTitle = "રિપોર્ટ"
    override val periodLabel = "સમયગાળો"
    override val period7d = "છેલ્લા 7 દિવસ"
    override val period15d = "છેલ્લા 15 દિવસ"
    override val period30d = "છેલ્લા 30 દિવસ"
    override val period3m = "છેલ્લા 3 મહિના"
    override val period1y = "આ વર્ષ"
    override val reportTotalCredit = "કુલ ઉધાર"
    override val reportTotalPayment = "કુલ જમા"
    override val reportCurrentDue = "હાલની કુલ બાકી"
    override val reportTxnCount = "વ્યવહાર"
    override val reportChartTitle = "ઉધાર વિરુદ્ધ જમા"
    override val reportShopWiseTitle = "દુકાન મુજબ બાકી"
    override val reportAgingTitle = "બાકીની ઉંમર"
    override val reportAging0to7 = "0–7 દિવસ"
    override val reportAging7to15 = "7–15 દિવસ"
    override val reportAging15to30 = "15–30 દિવસ"
    override val reportAging30plus = "30+ દિવસ"
    override val reportRecentPaymentsTitle = "તાજેતરની જમા"
    override val reportNoData = "આ સમયગાળાની માહિતી નથી"
    override val reportSmartSummaryPrefix = "આ સમયગાળામાં તમે"
    override val moreTitle = "વધુ"
    override val moreBackupRestore = "બેકઅપ અને રિસ્ટોર"
    override val moreHintBackupRestore = "તમારો ડેટા સુરક્ષિત રાખો"
    override val notesTitle = "નોંધો"
    override val notesSearchPlaceholder = "નોંધો શોધો..."
    override val addNoteButton = "નવી નોંધ"
    override val noNotesYetTitle = "હજી કોઈ નોંધ નથી"
    override val noNotesYetSubtitle = "ખરીદીની યાદી, યાદ — કંઈ પણ લખી રાખો"
    override val deleteNoteConfirmTitle = "આ નોંધ કાઢી નાખવી છે?"
    override val deleteNoteConfirmMessage = "આ નોંધ કાયમ માટે કાઢી નંખાશે."
    override val noteTitlePlaceholder = "શીર્ષક"
    override val noteContentPlaceholder = "કંઈક લખો..."
    override val untitledNote = "શીર્ષક વગરની નોંધ"
    override val notificationInboxTitle = "નોટિફિકેશન"
    override val moreNotificationHistory = "નોટિફિકેશન ઇતિહાસ"
    override val moreHintNotificationHistory = "તાજેતરની પ્રવૃત્તિ જુઓ"
    override val noNotificationsYetTitle = "હજી કોઈ નોટિફિકેશન નથી"
    override val noNotificationsYetSubtitle = "ઉધાર કે જમા નોંધશો તો અહીં દેખાશે"
    override val notifCreditMessage = "%1\$s પાસેથી %2\$s ઉધાર લીધું"
    override val notifPaymentMessage = "%1\$s ને %2\$s જમા કર્યા"
    override val moreQuickCalculator = "ક્વિક કેલ્ક્યુલેટર"
    override val moreHintQuickCalculator = "ઝટપટ હિસાબ કરો"
    override val calcGeneralTab = "સામાન્ય"
    override val calcPercentTab = "ટકા"
    override val calcConversionTab = "રૂપાંતર"
    override val calcComingSoonInTab = "જલદી આવી રહ્યું છે"
    override val percentOfTitle = "કોઈ સંખ્યાના ટકા"
    override val percentOfValueLabel = "સંખ્યા"
    override val percentOfPercentLabel = "ટકા (%)"
    override val percentIsWhatTitle = "એક સંખ્યા બીજી સંખ્યાના કેટલા ટકા"
    override val percentIsWhatXLabel = "આ સંખ્યા"
    override val percentIsWhatYLabel = "આના"
    override val percentChangeTitle = "ટકાવારી વધારો/ઘટાડો"
    override val percentChangeBaseLabel = "મૂળ સંખ્યા"
    override val percentChangePercentLabel = "ટકા (%)"
    override val increaseOption = "વધારો"
    override val decreaseOption = "ઘટાડો"
    override val resultLabel = "પરિણામ"
    override val weightCategory = "વજન"
    override val lengthCategory = "લંબાઈ"
    override val volumeCategory = "કદ"
    override val fromLabel = "થી"
    override val toLabel = "સુધી"
    override val enterValueHint = "કિંમત લખો"
    override val backupNowButton = "હમણાં બેકઅપ લો"
    override val backupNowHint = "બધી દુકાનો અને વ્યવહારો JSON ફાઇલમાં સેવ કરો"
    override val restoreButton = "બેકઅપમાંથી રિસ્ટોર કરો"
    override val restoreShopAction = "રિસ્ટોર"
    override val restoreHint = "જૂની JSON બેકઅપ ફાઇલમાંથી ડેટા પાછો લાવો"
    override val lastBackupLabel = "છેલ્લો બેકઅપ"
    override val noBackupYetLabel = "હજી બેકઅપ લીધો નથી"
    override val backupSuccessMessage = "બેકઅપ બની ગયો"
    override val backupFailPrefix = "બેકઅપ નિષ્ફળ: "
    override val restoreConfirmTitle = "બેકઅપ રિસ્ટોર કરવો છે?"
    override val restoreConfirmMessage = "આનાથી હાલની બધી દુકાનો અને વ્યવહારો ભૂંસાઈ જશે અને બેકઅપ ફાઇલનો ડેટા આવશે. આ પાછું ફેરવી શકાશે નહીં."
    override val restoreSuccessMessage = "રિસ્ટોર પૂર્ણ થયું"
    override val restoreFailPrefix = "રિસ્ટોર નિષ્ફળ: "
    override val dataSafeNote = "તમારો ડેટા ફક્ત આ ફોનમાં જ રહે છે — બેકઅપ ફાઇલ જાતે સુરક્ષિત રાખો"
    override val moreExportShare = "એક્સપોર્ટ અને શેર"
    override val moreHintExportShare = "PDF અને ફાઇલો મોકલો"
    override val moreNotifications = "નોટિફિકેશન"
    override val moreHintNotifications = "યાદ ચાલુ/બંધ કરો"
    override val moreLanguage = "ભાષા"
    override val moreHintLanguage = "તમારી ભાષા પસંદ કરો"
    override val moreUserMode = "હું કોણ"
    override val moreHintUserMode = "ગ્રાહક કે દુકાનદાર"
    override val moreSecurityPrivacy = "સુરક્ષા અને ગોપનીયતા"
    override val moreHintSecurityPrivacy = "PIN અને ફિંગરપ્રિન્ટ લોક"
    override val moreAppearance = "દેખાવ"
    override val moreHintAppearance = "લાઇટ, ડાર્ક કે સિસ્ટમ"
    override val moreRateFeedback = "રેટિંગ અને પ્રતિભાવ"
    override val moreHintRateFeedback = "તમારો અભિપ્રાય આપો"
    override val moreAbout = "ઉધાર હિસાબ વિશે"
    override val moreHintAbout = "વર્ઝન અને ડેવલપર"
    override val comingSoonMessage = "જલદી આવી રહ્યું છે"
    override val appearanceTitle = "દેખાવ"
    override val themeLight = "લાઇટ"
    override val themeDark = "ડાર્ક"
    override val themeSystem = "સિસ્ટમ ડિફોલ્ટ"
    override val creditPageTitle = "ઉધાર લો"
    override val accountingTypeLabel = "એન્ટ્રીનો પ્રકાર"
    override val directMoneyMode = "સીધી રકમ"
    override val productMode = "વસ્તુ મુજબ"
    override val directMoneyAmountLabel = "કેટલું ઉધાર આપ્યું?"
    override val previousDueLabel = "પાછલી બાકી"
    override val newCreditLabel = "નવું ઉધાર"
    override val newTotalDueLabel = "નવી કુલ બાકી"
    override val addCreditButton = "ઉધાર ઉમેરો"
    override val addMoreProductButton = "+ બીજી વસ્તુ ઉમેરો"
    override val totalNewCreditLabel = "કુલ નવું ઉધાર"
    override val editAction = "બદલો"
    override val itemsCountSuffix = "વસ્તુ"
    override val paymentPageTitle = "જમા"
    override val currentDueLabel = "હાલની બાકી"
    override val howMuchPaymentLabel = "કેટલા જમા કરો છો?"
    override val fullPaymentButton = "પૂરી રકમ"
    override val dueAfterPaymentLabel = "જમા પછી બાકી"
    override val addPaymentButton = "જમા ઉમેરો"
    override val overpaymentBlockedMessage = "હાલની બાકી કરતાં વધુ જમા થઈ શકતું નથી"
    override val fullyPaidCelebration = "આનાથી પૂરી બાકી ચૂકતે થઈ જશે"
    override val woodCalculatorTitle = "લાકડાનું કેલ્ક્યુલેટર"
    override val woodTypeLabel = "લાકડાનો પ્રકાર"
    override val sawnWoodOption = "કાપેલું લાકડું"
    override val roundWoodOption = "ગોળ લઠ્ઠો"
    override val lengthFtLabel = "લંબાઈ (ફૂટ)"
    override val widthInLabel = "પહોળાઈ (ઇંચ)"
    override val thicknessInLabel = "જાડાઈ (ઇંચ)"
    override val girthInLabel = "ઘેરાવો (ઇંચ)"
    override val pieceCountLabel = "ટુકડાની સંખ્યા"
    override val perPieceCftLabel = "પ્રતિ ટુકડો"
    override val totalWoodCftLabel = "કુલ લાકડું"
    override val perCftPriceLabel = "પ્રતિ CFT ભાવ (₹)"
    override val totalWoodValueLabel = "કુલ કિંમત"
    override val addWoodCalcButton = "આ લાકડાનો હિસાબ ઉમેરો"
    override val woodNameLabel = "વસ્તુનું નામ"
    override val addMoreWoodProductButton = "+ બીજું લાકડું/વસ્તુ ઉમેરો"
    override val addedItemsHeader = "ઉમેરેલી વસ્તુ/લાકડું"
    override val pdfOptionsTitle = "PDF વિકલ્પો"
    override val pdfPeriodLabel = "સમયગાળો"
    override val pdfThisMonth = "આ મહિનો"
    override val pdfLastMonth = "ગયો મહિનો"
    override val pdfLast3Months = "છેલ્લા 3 મહિના"
    override val pdfCustomRange = "પોતાની તારીખો"
    override val pdfShopLabelOption = "દુકાન"
    override val pdfAllShopsOption = "બધી દુકાનો"
    override val pdfContentLabel = "શું બતાવવું"
    override val pdfContentFull = "બધું (વ્યવહાર + સારાંશ + સહી)"
    override val pdfContentSummaryOnly = "ફક્ત સારાંશ"
    override val pdfContentTxnsOnly = "ફક્ત વ્યવહાર"
    override val pdfFormatLabel = "ફોર્મેટ"
    override val pdfFormatA4 = "A4 રિપોર્ટ"
    override val pdfFormatReceipt = "રસીદ (58mm)"
    override val pdfGenerateButton = "PDF બનાવો"
    override val pdfFromDateLabel = "શરૂઆતની તારીખ"
    override val pdfToDateLabel = "છેલ્લી તારીખ"
    override val pdfReportNumberLabel = "રિપોર્ટ નં."
    override val pdfShopBoxLabel = "દુકાન"
    override val pdfDateBoxLabel = "તારીખ"
    override val pdfDaysOfRecordsSuffix = "દિવસનો રેકોર્ડ"
    override val pdfWeeklyChartTitle = "સાપ્તાહિક ઉધાર (લાલ) વિરુદ્ધ જમા (લીલો)"
    override val pdfFinalDueLabel = "હાલની બાકી"
    override val pdfShopSignatureLabel = "દુકાનદારની સહી"
    override val pdfCustomerSignatureLabel = "ગ્રાહકની સહી"
    override val pdfAllShopsReportTitle = "બધી દુકાનોનો સારાંશ — ઉધાર હિસાબ"
    override val pdfPageLabel = "પાનું"
    override val moreShopProfile = "દુકાનની પ્રોફાઇલ"
    override val moreHintShopProfile = "નામ, લોગો, સરનામું, યાદ"
    override val shopProfileTitle = "દુકાનની પ્રોફાઇલ"
    override val shopProfileIntro = "આ માહિતી PDF ઇનવોઇસમાં અને ગ્રાહકને મોકલાતા સંદેશાઓમાં વપરાશે"
    override val shopBusinessNameLabel = "દુકાનનું નામ"
    override val shopBusinessAddressLabel = "દુકાનનું સરનામું"
    override val shopBusinessPhoneLabel = "દુકાનનો ફોન નંબર"
    override val countryCodeLabel = "દેશનો કોડ (દા.ત. 91)"
    override val shopLogoLabel = "દુકાનનો લોગો"
    override val shopLogoPick = "લોગો પસંદ કરો"
    override val shopLogoRemove = "લોગો હટાવો"
    override val promptAfterEntryLabel = "એન્ટ્રી પછી ગ્રાહકને જણાવવાનો વિકલ્પ બતાવો"
    override val saveProfileButton = "પ્રોફાઇલ સેવ કરો"
    override val profileSavedMessage = "પ્રોફાઇલ સેવ થઈ"
    override val errorShopNameForPdf = "PDF માં વાપરવા દુકાનનું નામ આપો"
    override val reminderSendAction = "યાદ મોકલો"
    override val reminderDialogTitle = "ગ્રાહકને જણાવો"
    override val reminderDialogSubtitle = "સંદેશ બદલીને WhatsApp કે SMS થી મોકલો"
    override val reminderMessageLabel = "સંદેશ"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "હમણાં નહીં"
    override val reminderNoPhone = "આ ગ્રાહકનો ફોન નંબર નથી"
    override val reminderAppMissing = "એપ ખોલી શકાઈ નથી"
    override val reminderShopFallback = "અમારી દુકાન"
    override val reminderMsgDue = "નમસ્તે %1\$s, %2\$s ના ખાતામાં તમારી કુલ બાકી %3\$s છે. કૃપા કરી સમયસર ચૂકવો. આભાર."
    override val reminderMsgCredit = "નમસ્તે %1\$s, %2\$s ના ખાતામાં તમારું નવું ઉધાર ઉમેરાયું છે. કુલ બાકી: %3\$s."
    override val reminderMsgPayment = "નમસ્તે %1\$s, તમારી ચૂકવણી મળી ગઈ. આભાર! %2\$s ના ખાતામાં હાલની બાકી: %3\$s."
    override val reminderMsgSettled = "નમસ્તે %1\$s, તમારી બધી બાકી ચૂકતે થઈ ગઈ છે. આભાર! — %2\$s"
    override val pdfActionLabel = "📤 શું કરવું"
    override val pdfActionShare = "શેર"
    override val pdfActionSave = "સેવ"
    override val pdfActionPrint = "પ્રિન્ટ"
    override val pdfBrandingOption = "મારી દુકાનનું નામ, લોગો અને સરનામું ઉમેરો"
    override val pdfBrandingMissing = "દુકાનનું નામ આપેલું નથી — વધુ → દુકાનની પ્રોફાઇલ માં જઈને ઉમેરો"
    override val pdfSavedMessage = "PDF સેવ થઈ"
    override val pdfSaveFailed = "PDF સેવ થઈ શકી નથી"
    override val setupRoleTitle = "તમે એપનો ઉપયોગ કેવી રીતે કરશો?"
    override val setupProfileTitle = "તમારી દુકાનની માહિતી"
    override val setupProfileSubtitle = "પછીથી વધુ → દુકાનની પ્રોફાઇલ માંથી બદલી શકાશે"
    override val setupContinue = "આગળ વધો"
    override val setupSkip = "હમણાં નહીં, પછી કરીશ"
    override val setupFinish = "શરૂ કરો"
    override val pickFromContacts = "સંપર્કોમાંથી નંબર પસંદ કરો"
    override val pdfColQtyPrice = "જથ્થો × ભાવ"
    override val pdfColItemTotal = "વસ્તુની રકમ"
    override val pdfWoodSawn = "કાપેલું લાકડું"
    override val pdfWoodRound = "ગોળ લઠ્ઠો"
    override val pdfWoodFormula = "સૂત્ર"
    override val pdfWoodTotalWord = "કુલ"
    override val pdfMemoTitle = "કેશ મેમો"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "બિલ નં. / Bill No"
    override val pdfDateTitle = "તારીખ / Date"
    override val pdfPeriodTitle = "સમયગાળો / Period"
    override val pdfSeller = "વેચનાર / Seller"
    override val pdfBuyer = "ખરીદનાર / Buyer"
    override val pdfAddressLabel = "સરનામું: "
    override val pdfColSl = "ક્રમ"
    override val pdfColPieces = "નંગ"
    override val pdfColCft = "CFT"
    override val pdfColRate = "ભાવ (₹/CFT)"
    override val pdfColAmountRs = "કુલ (₹)"
    override val pdfColQty = "જથ્થો"
    override val pdfColUnitPrice = "ભાવ (₹)"
    override val pdfSecSawn = "કાપેલું લાકડું / Sawn Timber"
    override val pdfSecRound = "ગોળ લઠ્ઠો / Round Log"
    override val pdfSecOther = "અન્ય વસ્તુઓ / Other Items"
    override val pdfSecCashCredit = "રોકડ ઉધાર / Cash Credit"
    override val pdfSecPayments = "જમા / Payments"
    override val pdfBadgeSawn = "કાપેલું"
    override val pdfBadgeRound = "ગોળ"
    override val pdfSawnTotal = "કાપેલા લાકડાનું કુલ:"
    override val pdfRoundTotal = "ગોળ લઠ્ઠાનું કુલ:"
    override val pdfTableTotal = "કુલ:"
    override val pdfSumBill = "કુલ બિલ"
    override val pdfSumPaid = "જમા"
    override val pdfSumDue = "બાકી"
    override val pdfWordsTitle = "રકમ શબ્દોમાં / Amount in Words:"
    override val pdfSellerSign = "વેચનારની સહી અને સિક્કો"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "ખરીદનારની સહી"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "આ કમ્પ્યુટર દ્વારા બનાવેલું બિલ છે. સહી વગર માન્ય નથી."
    override val pdfSummaryTitle = "સારાંશ રિપોર્ટ"
    override val moveShopAction = "બીજી યાદીમાં ખસેડો"
    override val moveShopTitle = "બીજી યાદીમાં ખસેડવી છે?"
    override val moveToShopkeeperMsg = "આ એન્ટ્રી \"હું દુકાનદાર\" યાદીમાં (તમારા ગ્રાહક તરીકે) જશે. રકમો એ જ રહેશે, ફક્ત શબ્દો બદલાશે."
    override val moveToCustomerMsg = "આ એન્ટ્રી \"હું ગ્રાહક\" યાદીમાં (જે દુકાનેથી તમે ઉધાર લો છો) જશે. રકમો એ જ રહેશે, ફક્ત શબ્દો બદલાશે."
    override val moveShopConfirm = "ખસેડો"
    override val faqItems = listOf(
        FaqItem("નવી દુકાન કેવી રીતે ઉમેરવી?", "હોમ પરનું '+' બટન દબાવો, દુકાનનું નામ, ફોન (વૈકલ્પિક) અને પ્રકાર લખો, પછી 'સેવ કરો' દબાવો."),
        FaqItem("ઉધાર કે જમા કેવી રીતે નોંધવું?", "દુકાનનું પેજ ખોલો અને 'ઉધાર લીધું' કે 'ચૂકવણી કરી' દબાવો, રકમ લખો અને પુષ્ટિ કરો."),
        FaqItem("બાયોમેટ્રિક લોક કેવી રીતે ચાલુ/બંધ કરવો?", "વધુ → સુરક્ષા અને ગોપનીયતા માં જઈને 'બાયોમેટ્રિક લોક' ચાલુ/બંધ કરો. તમારા ફોનમાં ફિંગરપ્રિન્ટ કે ફેસ અનલોક સેટ હોવું જરૂરી છે."),
        FaqItem("ડેટાનો બેકઅપ કેવી રીતે લેવો?", "વધુ → બેકઅપ અને રિસ્ટોર માં જઈને 'હમણાં બેકઅપ લો' દબાવો. આનાથી એક JSON ફાઇલ બને છે, જે તમે ફોનમાં કે ક્લાઉડમાં સેવ કરી શકો."),
        FaqItem("બેકઅપમાંથી ડેટા કેવી રીતે પાછો લાવવો?", "વધુ → બેકઅપ અને રિસ્ટોર માં જઈને 'બેકઅપમાંથી રિસ્ટોર કરો' દબાવો અને તમારી JSON ફાઇલ પસંદ કરો. આનાથી હાલનો બધો ડેટા બદલાઈ જાય છે, તેથી સાવચેત રહો."),
        FaqItem("દુકાન કાઢી નાખું તો પાછી મળશે?", "આર્કાઇવ કરશો તો તે ઇતિહાસમાં રહે છે અને પછી પાછી લાવી શકાય છે. કાયમ માટે કાઢી નાખ્યા પછી પાછી મળતી નથી."),
        FaqItem("PDF રિપોર્ટ કેવી રીતે બનાવવો?", "'વધુ' પેજ પર બેકઅપ અને રિસ્ટોરની બાજુમાં એક્સપોર્ટનો વિકલ્પ છે, દુકાન અને તારીખની શ્રેણી પસંદ કરો અને PDF શેર કરો."),
        FaqItem("એપની ભાષા કેવી રીતે બદલવી?", "વધુ → ભાષા માં જઈને તમારી ભાષા પસંદ કરો અને 'સેવ કરો' દબાવો.")
    )
    override val privacyPolicyBody = """ઉધાર હિસાબ એક વ્યક્તિગત નાણાકીય/ખાતાવહી એપ છે, જે તમને દુકાનનું ઉધાર, બાકી અને વ્યવહારો સરળ રીતે સંભાળવામાં મદદ કરે છે. તમારી ગોપનીયતા અમારા માટે મહત્વની છે.

1. અમે એકત્ર કરતી માહિતી

ઉધાર હિસાબ વાપરતી વખતે તમે જાતે એપમાં ભરેલી માહિતી, જેમ કે:
• દુકાનનું નામ
• મોબાઇલ નંબર
• દુકાનનું સરનામું કે અન્ય વિગતો
• ઉધાર અને જમા રકમો
• વ્યવહારની તારીખ, સમય અને નોંધ

2. માહિતીનો ઉપયોગ

આ માહિતી ફક્ત તમારા હિસાબ સાચવવા, બતાવવા અને સંભાળવા માટે વપરાય છે. તમારો વ્યક્તિગત ખાતાવહી ડેટા તમારી પરવાનગી વિના કોઈ જાહેરાતકર્તા કે ત્રીજા પક્ષને વેચવામાં કે શેર કરવામાં આવશે નહીં.

3. ડેટા સંગ્રહ

તમારો હિસાબ ડેટા એપની જરૂરિયાત મુજબ તમારા ડિવાઇસ પર સાચવવામાં આવી શકે છે. તમે બેકઅપ અને રિસ્ટોર સુવિધા વાપરો તો તમારો બેકઅપ ડેટા તમે પસંદ કરેલી સ્ટોરેજ/ક્લાઉડ સેવામાં સાચવી શકાય છે.

4. એપ સુરક્ષા

તમારો હિસાબ ડેટા સુરક્ષિત રાખવા એપ લોક, PIN અને બાયોમેટ્રિક પ્રમાણીકરણ જેવી સુરક્ષા સુવિધાઓ આપી શકાય છે.

5. માહિતી શેર કરવી

કાયદા દ્વારા જરૂરી હોય તે સિવાય અમે તમારો વ્યક્તિગત ખાતાવહી ડેટા ત્રીજા પક્ષને વેચતા નથી, ભાડે આપતા નથી કે વ્યાવસાયિક હેતુ માટે શેર કરતા નથી.

6. તમારું નિયંત્રણ

એપમાં સાચવેલો તમારો ડેટા તમે ગમે ત્યારે જોઈ, બદલી કે કાઢી શકો છો.

7. ત્રીજા પક્ષની સેવાઓ

એપની કેટલીક સુવિધાઓ માટે ત્રીજા પક્ષની સેવાઓ વપરાય તો તેમની પોતાની ગોપનીયતા નીતિ લાગુ થઈ શકે છે.

8. બાળકોની ગોપનીયતા

ઉધાર હિસાબ જાણીજોઈને બાળકો પાસેથી વ્યક્તિગત માહિતી એકત્ર કરવા માટે બનાવાયેલ નથી.

9. આ ગોપનીયતા નીતિમાં ફેરફાર

અમે જરૂર મુજબ આ ગોપનીયતા નીતિ બદલી કે અપડેટ કરી શકીએ છીએ. કોઈ પણ નવી નીતિ આ પેજ પર પ્રકાશિત કરવામાં આવશે.

10. સંપર્ક

આ ગોપનીયતા નીતિ કે તમારા ડેટા વિશે કોઈ પ્રશ્ન હોય તો કૃપા કરી અમારો સંપર્ક કરો.

ઉધાર હિસાબ
સરળ હિસાબ, નિશ્ચિંત રહો."""
}

/** ⭐ তামিল (தமிழ்) */
object TamilStrings : AppStrings {
    override val code = "ta"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "விளம்பரங்களை நீக்கு"
    override val moreHintAdFree = "ஒருமுறை வாங்குங்கள், இனி விளம்பரம் இல்லை"
    override val adFreeDialogTitle = "விளம்பரமில்லாச் செயலி"
    override val adFreeDialogMessage = "ஒருமுறை செலுத்தினால் எல்லா விளம்பரங்களும் என்றென்றும் நின்றுவிடும். செயலியை ஆதரித்ததற்கு நன்றி!"
    override val adFreeBuyButton = "வாங்கு"
    override val adFreeRestoreButton = "முந்தைய வாங்குதலை மீட்டெடு"
    override val adFreeActiveLabel = "உங்கள் செயலி விளம்பரமில்லாதது ✓"
    override val adFreeUnavailable = "இப்போது வாங்க முடியவில்லை — பிறகு முயலுங்கள்"
    override val adSponsoredLabel = "விளம்பரம்"
    override val moreAdPrivacy = "விளம்பர விருப்பங்கள்"
    override val moreHintAdPrivacy = "நீங்கள் காணும் விளம்பர வகையைத் தேர்ந்தெடுங்கள்"
    override val helpCenterTitle = "உதவி மையம்"
    override val helpSearchPlaceholder = "கேள்விகளைத் தேடுங்கள்..."
    override val noFaqResultsMessage = "எதுவும் கிடைக்கவில்லை"
    override val homeHeadline = "உதார் ஹிசாப்"
    override val history = "வரலாறு"
    override val settings = "அமைப்புகள்"
    override val totalDueLabel = "மொத்த நிலுவை"
    override val thisMonthCreditLabel = "இந்த மாத நிலுவை"
    override val thisMonthPaymentLabel = "இந்த மாதம் வந்தது"
    override val searchPlaceholder = "கடை/தொலைபேசி தேடுங்கள்..."
    override val filterAll = "அனைத்தும்"
    override val settledLabel = "தீர்ந்தது"
    override val noShopsYetTitle = "இன்னும் கடை எதுவும் இல்லை"
    override val noShopsYetSubtitle = "கணக்கைத் தொடங்க முதல் கடையைச் சேர்க்கவும்"
    override val addFirstShopButton = "முதல் கடையைச் சேர்க்கவும்"
    override val newShop = "புதிய கடை"
    override val shopTypeTea = "தேநீர் கடை"
    override val shopTypeHardwareElectric = "ஹார்டுவேர் & மின்சாரம்"
    override val shopTypeKirana = "மளிகைக் கடை"
    override val shopTypeVegetable = "காய்கறிக் கடை"
    override val shopTypeFishMeat = "மீன் & இறைச்சி"
    override val shopTypeBakerySweets = "பேக்கரி & இனிப்புகள்"
    override val shopTypePharmacy = "மருந்துக் கடை"
    override val shopTypeCosmetics = "அழகு சாதனங்கள்"
    override val shopTypeStationery = "எழுதுபொருள்"
    override val shopTypeXeroxPrinting = "ஜெராக்ஸ் & அச்சு"
    override val shopTypeWood = "மரக் கடை"
    override val shopTypeGarments = "துணிக் கடை"
    override val shopTypeOther = "மற்றவை"
    override val back = "பின்"
    override val cancel = "ரத்து"
    override val save = "சேமி"
    override val shopNameLabel = "கடையின் பெயர் *"
    override val shopNamePlaceholder = "எ.கா. மர மஹால்"
    override val phoneLabel = "தொலைபேசி எண் (விருப்பம்)"
    override val shopTypeLabel = "கடை வகை *"
    override val saveShopButton = "கடையைச் சேமி"
    override val errorNameRequired = "கடையின் பெயரை எழுதுங்கள்"
    override val errorTypeRequired = "கடை வகையைத் தேர்ந்தெடுங்கள்"
    override val dueLabel = "நிலுவை"
    override val noTransactionsYet = "இன்னும் பரிவர்த்தனை இல்லை"
    override val creditButton = "கடன் வாங்கினேன்"
    override val paymentButton = "பணம் செலுத்தினேன்"
    override val pdfExport = "PDF ஏற்றுமதி"
    override val archive = "காப்பகம்"
    override val deleteShopAction = "கடையை நீக்கு"
    override val archiveConfirmTitle = "இந்தக் கடையைக் காப்பகப்படுத்தவா?"
    override val archiveConfirmText = "முகப்புப் பட்டியலிலிருந்து நீங்கும் — வரலாற்றில் இன்னும் இருக்கும்."
    override val deleteConfirmTitle = "இந்தக் கடையை நிரந்தரமாக நீக்கவா?"
    override val deleteConfirmText = "இந்தக் கடையும் அதன் அனைத்துப் பரிவர்த்தனைகளும் நிரந்தரமாக நீக்கப்படும்; மீட்க முடியாது. காப்பகப்படுத்தினால் வரலாற்றில் இருக்கும் — தொடர்வதற்கு முன் உறுதி செய்யுங்கள்."
    override val yesDelete = "ஆம், நீக்கு"
    override val yesArchive = "காப்பகப்படுத்து"
    override val txnDeletedSnackbar = "பரிவர்த்தனை நீக்கப்பட்டது"
    override val undo = "செயல்தவிர்"
    override val pdfFailPrefix = "PDF உருவாக்க முடியவில்லை: "
    override val shareKhata = "கணக்கைப் பகிர்"
    override val creditFallback = "கடன்"
    override val paymentFallback = "வரவு"
    override val deleteTxnAction = "நீக்கு"
    override val productNameLabel = "பொருளின் பெயர் (விருப்பம்)"
    override val quantityLabel = "அளவு"
    override val unitLabel = "அலகு"
    override val pricePerUnitLabel = "விலை/அலகு"
    override val totalPrefix = "மொத்தம்: "
    override val amountLabel = "செலுத்திய தொகை"
    override val orEnterAmountLabel = "அல்லது நேரடியாகத் தொகையை எழுதுங்கள்"
    override val noteLabel = "குறிப்பு (விருப்பம்)"
    override val cash = "ரொக்கம்"
    override val bkash = "bKash"
    override val bank = "வங்கி"
    override val invalidAmountError = "சரியான தொகையை எழுதுங்கள்"
    override val cftCalculatorTitle = "CFT கால்குலேட்டர்"
    override val lengthLabel = "நீளம் (அங்குலம்)"
    override val widthLabel = "அகலம்"
    override val heightLabel = "உயரம்"
    override val rateLabel = "விலை /cft (₹)"
    override val applyToEntryButton = "பதிவில் சேர்"
    override val settingsTitle = "அமைப்புகள்"
    override val security = "பாதுகாப்பு"
    override val pinLockOn = "PIN பூட்டு இயங்குகிறது"
    override val pinLockOff = "PIN பூட்டு நிறுத்தப்பட்டுள்ளது"
    override val changePin = "PIN மாற்று"
    override val reminderTitle = "நிலுவை நினைவூட்டல்"
    override val reminderDesc = "தினமும் நிலுவையை நினைவூட்டும்"
    override val about = "பற்றி"
    override val aboutLine = "உதார் ஹிசாப் — கடை கடன் கணக்கு"
    override val aboutDescription = "உதார் ஹிசாப் என்பது கடையின் கடன், நிலுவை மற்றும் பரிவர்த்தனைகளை எளிதாகவும் விரைவாகவும் ஒழுங்காகவும் நிர்வகிக்க உதவும் ஒரு ஸ்மார்ட் கணக்கு செயலி. எந்தக் கடையில் எவ்வளவு நிலுவை, எங்கே பணம் செலுத்தினீர்கள், எந்தப் பரிவர்த்தனை எப்போது நடந்தது — எல்லாவற்றையும் ஒரே இடத்தில் அழகாகச் சேமிக்கலாம்.\n\nஇந்தச் செயலியில் கடைகளைச் சேர்க்கலாம், கடன் மற்றும் வரவைப் பதிவு செய்யலாம், பரிவர்த்தனை வரலாற்றைப் பார்க்கலாம், மொத்த நிலுவை மற்றும் வரவைச் சரிபார்க்கலாம், விரிவான அறிக்கைகளை உருவாக்கலாம். தேடல், வடிகட்டி, காப்புப்பிரதி & மீட்பு, செயலி பூட்டு, பயோமெட்ரிக் பாதுகாப்பு, டார்க் மோடு, அறிவிப்புகள் போன்ற வசதிகள் கணக்கு நிர்வாகத்தை இன்னும் எளிதாகவும் பாதுகாப்பாகவும் ஆக்குகின்றன.\n\nகாகிதக் கணக்குப் புத்தகத்தின் சிக்கலை எளிய, நவீன, நம்பகமான டிஜிட்டல் முறைக்குக் கொண்டுவருவதே உதார் ஹிசாப்பின் நோக்கம்."
    override val aboutTagline = "உதார் ஹிசாப் — எளிய கணக்கு, கவலையின்றி இருங்கள்."
    override val versionLine = "பதிப்பு 1.0"
    override val setPinTitle = "PIN அமை"
    override val newPinLabel = "புதிய PIN"
    override val confirmPinLabel = "PIN ஐ மீண்டும் எழுதுங்கள்"
    override val pinSetupError = "PIN பொருந்தவில்லை (குறைந்தது 4 இலக்கங்கள்)"
    override val removePinTitle = "PIN பூட்டை நிறுத்தவா?"
    override val removePinText = "இனி செயலியைத் திறக்கும்போது PIN கேட்கப்படாது."
    override val yesTurnOff = "ஆம், நிறுத்து"
    override val no = "இல்லை"
    override val languageTitle = "மொழி"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "அறிவிப்புகள்"
    override val notifSheetSubtitle = "எந்த நினைவூட்டல்கள் வேண்டும்?"
    override val notifDueReminderOption = "நிலுவை செலுத்த நினைவூட்டல்"
    override val notifWeeklySummaryOption = "வாராந்திரச் சுருக்கம்"
    override val notifAppNewsOption = "செயலி செய்திகள் & புதுப்பிப்புகள்"
    override val langSheetSubtitle = "செயலி எந்த மொழியில் இயங்க வேண்டும்?"
    override val themeSheetSubtitle = "உங்களுக்கு எந்தத் தீம் பிடிக்கும்?"
    override val securityPrivacyTitle = "பாதுகாப்பு & தனியுரிமை"
    override val pinSectionTitle = "PIN பூட்டு"
    override val pinSectionDesc = "செயலி திறக்கும்போது PIN கேள்"
    override val fingerprintTitle = "கைரேகைப் பூட்டு"
    override val fingerprintDesc = "PIN க்குப் பதிலாகக் கைரேகையால் திற"
    override val fingerprintUnavailable = "இந்தத் தொலைபேசியில் கைரேகை சென்சார் இல்லை"
    override val lockImmediatelyTitle = "உடனே பூட்டு"
    override val lockImmediatelyDesc = "செயலிக்குத் திரும்பியவுடன் மீண்டும் பூட்டப்படும்"
    override val rateTitle = "மதிப்பீடு & கருத்து"
    override val rateSubtitle = "உதார் ஹிசாப் உங்களுக்கு எப்படி இருக்கிறது?"
    override val rateStarsPrompt = "மதிப்பிட தட்டவும்"
    override val rateThanksMessage = "நன்றி! Play Store க்கு அழைத்துச் செல்கிறோம்…"
    override val feedbackPromptLow = "உங்களுக்கு என்ன பிடிக்கவில்லை? எங்களிடம் சொல்லுங்கள்"
    override val feedbackPlaceholder = "உங்கள் கருத்தை எழுதுங்கள்…"
    override val feedbackSubmit = "அனுப்பு"
    override val feedbackThanks = "நன்றி, உங்கள் கருத்து அனுப்பப்பட்டது"
    override val aboutPageTitle = "உதார் ஹிசாப் பற்றி"
    override val aboutVersionPrefix = "பதிப்பு"
    override val aboutDeveloperLabel = "உருவாக்குநர்"
    override val aboutDeveloperName = "உதார் ஹிசாப் குழு"
    override val aboutPrivacyPolicy = "தனியுரிமைக் கொள்கை"
    override val privacyPolicyEffectiveDate = "நடைமுறை தேதி: 13 செப்டம்பர் 2026"
    override val aboutShareApp = "பகிர்"
    override val aboutShareText = "உதார் ஹிசாப் — கடை கடன் கணக்குச் செயலியை முயன்று பாருங்கள்!"
    override val noArchivedShops = "காப்பகப்படுத்திய கடை இல்லை"
    override val noSettledShops = "தீர்ந்த கடை இல்லை"
    override val setupPinTitle = "4 இலக்க PIN அமையுங்கள்"
    override val unlockPinTitle = "PIN மூலம் திற"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 இலக்கங்களை எழுதுங்கள்"
    override val pinsDontMatchError = "PIN பொருந்தவில்லை"
    override val wrongPinError = "PIN தவறு — மீண்டும் முயலுங்கள்"
    override val savePinButton = "PIN ஐச் சேமி"
    override val unlockButton = "திற"
    override val pdfHeaderTitle = "கணக்கு — உதார் ஹிசாப்"
    override val pdfFullKhataSuffix = "முழுக் கணக்கு"
    override val pdfShopLabel = "கடை: "
    override val pdfPhoneLabel = "தொலைபேசி: "
    override val pdfCreatedLabel = "உருவாக்கியது: "
    override val pdfColDate = "தேதி/நேரம்"
    override val pdfColDesc = "விவரம்"
    override val pdfTotalCredit = "மொத்தக் கடன்:"
    override val pdfTotalPayment = "மொத்த வரவு:"
    override val pdfCurrentDue = "தற்போதைய நிலுவை:"
    override val pdfFooter = "உதார் ஹிசாப் செயலியால் உருவாக்கப்பட்டது"
    override val navHome = "முகப்பு"
    override val navHistory = "வரலாறு"
    override val navReports = "அறிக்கை"
    override val navMore = "மேலும்"
    override val historyFilterAllShops = "அனைத்துக் கடைகள்"
    override val historyFilterAllTypes = "அனைத்தும்"
    override val historyFilterCreditOnly = "கடன் மட்டும்"
    override val historyFilterPaymentOnly = "வரவு மட்டும்"
    override val historyNoTxnsFound = "பரிவர்த்தனை எதுவும் கிடைக்கவில்லை"
    override val viewArchivedAction = "காப்பகப்படுத்திய கடைகளைப் பார்"
    override val reportsTitle = "அறிக்கை"
    override val periodLabel = "காலம்"
    override val period7d = "கடந்த 7 நாட்கள்"
    override val period15d = "கடந்த 15 நாட்கள்"
    override val period30d = "கடந்த 30 நாட்கள்"
    override val period3m = "கடந்த 3 மாதங்கள்"
    override val period1y = "இந்த ஆண்டு"
    override val reportTotalCredit = "மொத்தக் கடன்"
    override val reportTotalPayment = "மொத்த வரவு"
    override val reportCurrentDue = "தற்போதைய மொத்த நிலுவை"
    override val reportTxnCount = "பரிவர்த்தனைகள்"
    override val reportChartTitle = "கடன் vs வரவு"
    override val reportShopWiseTitle = "கடை வாரியாக நிலுவை"
    override val reportAgingTitle = "நிலுவையின் வயது"
    override val reportAging0to7 = "0–7 நாட்கள்"
    override val reportAging7to15 = "7–15 நாட்கள்"
    override val reportAging15to30 = "15–30 நாட்கள்"
    override val reportAging30plus = "30+ நாட்கள்"
    override val reportRecentPaymentsTitle = "சமீபத்திய வரவுகள்"
    override val reportNoData = "இந்தக் காலத்திற்குத் தகவல் இல்லை"
    override val reportSmartSummaryPrefix = "இந்தக் காலத்தில் நீங்கள்"
    override val moreTitle = "மேலும்"
    override val moreBackupRestore = "காப்புப்பிரதி & மீட்பு"
    override val moreHintBackupRestore = "உங்கள் தரவைப் பாதுகாப்பாக வையுங்கள்"
    override val notesTitle = "குறிப்புகள்"
    override val notesSearchPlaceholder = "குறிப்புகளைத் தேடுங்கள்..."
    override val addNoteButton = "புதிய குறிப்பு"
    override val noNotesYetTitle = "இன்னும் குறிப்புகள் இல்லை"
    override val noNotesYetSubtitle = "பொருள் பட்டியல், நினைவூட்டல் — எதையும் எழுதி வையுங்கள்"
    override val deleteNoteConfirmTitle = "இந்தக் குறிப்பை நீக்கவா?"
    override val deleteNoteConfirmMessage = "இந்தக் குறிப்பு நிரந்தரமாக நீக்கப்படும்."
    override val noteTitlePlaceholder = "தலைப்பு"
    override val noteContentPlaceholder = "ஏதாவது எழுதுங்கள்..."
    override val untitledNote = "தலைப்பில்லாக் குறிப்பு"
    override val notificationInboxTitle = "அறிவிப்புகள்"
    override val moreNotificationHistory = "அறிவிப்பு வரலாறு"
    override val moreHintNotificationHistory = "சமீபத்திய செயல்பாடுகளைப் பார்"
    override val noNotificationsYetTitle = "இன்னும் அறிவிப்புகள் இல்லை"
    override val noNotificationsYetSubtitle = "கடன் அல்லது வரவைப் பதிவு செய்தால் இங்கே தெரியும்"
    override val notifCreditMessage = "%1\$s இடமிருந்து %2\$s கடன் வாங்கப்பட்டது"
    override val notifPaymentMessage = "%1\$s க்கு %2\$s செலுத்தப்பட்டது"
    override val moreQuickCalculator = "விரைவு கால்குலேட்டர்"
    override val moreHintQuickCalculator = "உடனடிக் கணக்கு செய்யுங்கள்"
    override val calcGeneralTab = "பொது"
    override val calcPercentTab = "சதவீதம்"
    override val calcConversionTab = "மாற்றம்"
    override val calcComingSoonInTab = "விரைவில் வரும்"
    override val percentOfTitle = "ஒரு எண்ணின் சதவீதம்"
    override val percentOfValueLabel = "எண்"
    override val percentOfPercentLabel = "சதவீதம் (%)"
    override val percentIsWhatTitle = "ஓர் எண் மற்றொன்றின் எத்தனை சதவீதம்"
    override val percentIsWhatXLabel = "இந்த எண்"
    override val percentIsWhatYLabel = "இதில்"
    override val percentChangeTitle = "சதவீத உயர்வு/குறைவு"
    override val percentChangeBaseLabel = "அடிப்படை எண்"
    override val percentChangePercentLabel = "சதவீதம் (%)"
    override val increaseOption = "உயர்வு"
    override val decreaseOption = "குறைவு"
    override val resultLabel = "முடிவு"
    override val weightCategory = "எடை"
    override val lengthCategory = "நீளம்"
    override val volumeCategory = "கொள்ளளவு"
    override val fromLabel = "இருந்து"
    override val toLabel = "வரை"
    override val enterValueHint = "மதிப்பை எழுதுங்கள்"
    override val backupNowButton = "இப்போதே காப்புப்பிரதி எடு"
    override val backupNowHint = "அனைத்துக் கடைகளையும் பரிவர்த்தனைகளையும் JSON கோப்பில் சேமி"
    override val restoreButton = "காப்புப்பிரதியிலிருந்து மீட்டெடு"
    override val restoreShopAction = "மீட்டெடு"
    override val restoreHint = "பழைய JSON காப்புப்பிரதிக் கோப்பிலிருந்து தரவை மீட்டெடுங்கள்"
    override val lastBackupLabel = "கடைசிக் காப்புப்பிரதி"
    override val noBackupYetLabel = "இன்னும் காப்புப்பிரதி எடுக்கவில்லை"
    override val backupSuccessMessage = "காப்புப்பிரதி உருவாக்கப்பட்டது"
    override val backupFailPrefix = "காப்புப்பிரதி தோல்வி: "
    override val restoreConfirmTitle = "காப்புப்பிரதியை மீட்டெடுக்கவா?"
    override val restoreConfirmMessage = "இது தற்போதைய அனைத்துக் கடைகளையும் பரிவர்த்தனைகளையும் அழித்து, காப்புக் கோப்பின் தரவால் மாற்றும். இதைத் திரும்பப் பெற முடியாது."
    override val restoreSuccessMessage = "மீட்பு முடிந்தது"
    override val restoreFailPrefix = "மீட்பு தோல்வி: "
    override val dataSafeNote = "உங்கள் தரவு இந்தத் தொலைபேசியில் மட்டுமே இருக்கும் — காப்புக் கோப்பை நீங்களே பாதுகாப்பாக வையுங்கள்"
    override val moreExportShare = "ஏற்றுமதி & பகிர்வு"
    override val moreHintExportShare = "PDF மற்றும் கோப்புகளை அனுப்புங்கள்"
    override val moreNotifications = "அறிவிப்புகள்"
    override val moreHintNotifications = "நினைவூட்டல்களை இயக்கு/நிறுத்து"
    override val moreLanguage = "மொழி"
    override val moreHintLanguage = "உங்கள் மொழியைத் தேர்ந்தெடுங்கள்"
    override val moreUserMode = "நான் யார்"
    override val moreHintUserMode = "வாடிக்கையாளர் அல்லது கடைக்காரர்"
    override val moreSecurityPrivacy = "பாதுகாப்பு & தனியுரிமை"
    override val moreHintSecurityPrivacy = "PIN & கைரேகைப் பூட்டு"
    override val moreAppearance = "தோற்றம்"
    override val moreHintAppearance = "ஒளி, இருள் அல்லது அமைப்பு"
    override val moreRateFeedback = "மதிப்பீடு & கருத்து"
    override val moreHintRateFeedback = "உங்கள் கருத்தைச் சொல்லுங்கள்"
    override val moreAbout = "உதார் ஹிசாப் பற்றி"
    override val moreHintAbout = "பதிப்பு & உருவாக்குநர்"
    override val comingSoonMessage = "விரைவில் வரும்"
    override val appearanceTitle = "தோற்றம்"
    override val themeLight = "ஒளி"
    override val themeDark = "இருள்"
    override val themeSystem = "கணினி இயல்புநிலை"
    override val creditPageTitle = "கடன் வாங்கு"
    override val accountingTypeLabel = "பதிவு வகை"
    override val directMoneyMode = "நேரடித் தொகை"
    override val productMode = "பொருள் வாரியாக"
    override val directMoneyAmountLabel = "எவ்வளவு கடன் கொடுத்தீர்கள்?"
    override val previousDueLabel = "முந்தைய நிலுவை"
    override val newCreditLabel = "புதிய கடன்"
    override val newTotalDueLabel = "புதிய மொத்த நிலுவை"
    override val addCreditButton = "கடனைச் சேர்"
    override val addMoreProductButton = "+ மற்றொரு பொருளைச் சேர்"
    override val totalNewCreditLabel = "மொத்தப் புதிய கடன்"
    override val editAction = "திருத்து"
    override val itemsCountSuffix = "பொருட்கள்"
    override val paymentPageTitle = "வரவு"
    override val currentDueLabel = "தற்போதைய நிலுவை"
    override val howMuchPaymentLabel = "எவ்வளவு செலுத்துகிறார்கள்?"
    override val fullPaymentButton = "முழுத் தொகை"
    override val dueAfterPaymentLabel = "செலுத்திய பின் நிலுவை"
    override val addPaymentButton = "வரவைச் சேர்"
    override val overpaymentBlockedMessage = "தற்போதைய நிலுவையை விட அதிகமாகச் செலுத்த முடியாது"
    override val fullyPaidCelebration = "இது முழு நிலுவையையும் தீர்த்துவிடும்"
    override val woodCalculatorTitle = "மரக் கால்குலேட்டர்"
    override val woodTypeLabel = "மர வகை"
    override val sawnWoodOption = "அறுத்த மரம்"
    override val roundWoodOption = "உருளை மரக்கட்டை"
    override val lengthFtLabel = "நீளம் (அடி)"
    override val widthInLabel = "அகலம் (அங்குலம்)"
    override val thicknessInLabel = "தடிமன் (அங்குலம்)"
    override val girthInLabel = "சுற்றளவு (அங்குலம்)"
    override val pieceCountLabel = "துண்டுகளின் எண்ணிக்கை"
    override val perPieceCftLabel = "ஒரு துண்டுக்கு"
    override val totalWoodCftLabel = "மொத்த மரம்"
    override val perCftPriceLabel = "ஒரு CFT விலை (₹)"
    override val totalWoodValueLabel = "மொத்த மதிப்பு"
    override val addWoodCalcButton = "இந்த மரக் கணக்கைச் சேர்"
    override val woodNameLabel = "பொருளின் பெயர்"
    override val addMoreWoodProductButton = "+ மற்றொரு மரம்/பொருளைச் சேர்"
    override val addedItemsHeader = "சேர்த்த பொருட்கள்/மரம்"
    override val pdfOptionsTitle = "PDF விருப்பங்கள்"
    override val pdfPeriodLabel = "காலம்"
    override val pdfThisMonth = "இந்த மாதம்"
    override val pdfLastMonth = "கடந்த மாதம்"
    override val pdfLast3Months = "கடந்த 3 மாதங்கள்"
    override val pdfCustomRange = "சொந்தத் தேதிகள்"
    override val pdfShopLabelOption = "கடை"
    override val pdfAllShopsOption = "அனைத்துக் கடைகள்"
    override val pdfContentLabel = "எதைக் காட்ட வேண்டும்"
    override val pdfContentFull = "அனைத்தும் (பரிவர்த்தனை + சுருக்கம் + கையொப்பம்)"
    override val pdfContentSummaryOnly = "சுருக்கம் மட்டும்"
    override val pdfContentTxnsOnly = "பரிவர்த்தனைகள் மட்டும்"
    override val pdfFormatLabel = "வடிவம்"
    override val pdfFormatA4 = "A4 அறிக்கை"
    override val pdfFormatReceipt = "ரசீது (58mm)"
    override val pdfGenerateButton = "PDF உருவாக்கு"
    override val pdfFromDateLabel = "தொடக்கத் தேதி"
    override val pdfToDateLabel = "இறுதித் தேதி"
    override val pdfReportNumberLabel = "அறிக்கை எண்"
    override val pdfShopBoxLabel = "கடை"
    override val pdfDateBoxLabel = "தேதி"
    override val pdfDaysOfRecordsSuffix = "நாட்களின் பதிவு"
    override val pdfWeeklyChartTitle = "வாராந்திரக் கடன் (சிவப்பு) vs வரவு (பச்சை)"
    override val pdfFinalDueLabel = "தற்போதைய நிலுவை"
    override val pdfShopSignatureLabel = "கடைக்காரரின் கையொப்பம்"
    override val pdfCustomerSignatureLabel = "வாடிக்கையாளரின் கையொப்பம்"
    override val pdfAllShopsReportTitle = "அனைத்துக் கடைகளின் சுருக்கம் — உதார் ஹிசாப்"
    override val pdfPageLabel = "பக்கம்"
    override val moreShopProfile = "கடைச் சுயவிவரம்"
    override val moreHintShopProfile = "பெயர், லோகோ, முகவரி, நினைவூட்டல்"
    override val shopProfileTitle = "கடைச் சுயவிவரம்"
    override val shopProfileIntro = "இந்தத் தகவல் PDF விலைப்பட்டியலிலும் வாடிக்கையாளருக்கு அனுப்பும் செய்திகளிலும் பயன்படும்"
    override val shopBusinessNameLabel = "கடையின் பெயர்"
    override val shopBusinessAddressLabel = "கடையின் முகவரி"
    override val shopBusinessPhoneLabel = "கடையின் தொலைபேசி எண்"
    override val countryCodeLabel = "நாட்டுக் குறியீடு (எ.கா. 91)"
    override val shopLogoLabel = "கடையின் லோகோ"
    override val shopLogoPick = "லோகோவைத் தேர்ந்தெடு"
    override val shopLogoRemove = "லோகோவை நீக்கு"
    override val promptAfterEntryLabel = "பதிவுக்குப் பின் வாடிக்கையாளருக்குத் தெரிவிக்கும் விருப்பத்தைக் காட்டு"
    override val saveProfileButton = "சுயவிவரத்தைச் சேமி"
    override val profileSavedMessage = "சுயவிவரம் சேமிக்கப்பட்டது"
    override val errorShopNameForPdf = "PDF இல் பயன்படுத்தக் கடையின் பெயரைக் கொடுங்கள்"
    override val reminderSendAction = "நினைவூட்டல் அனுப்பு"
    override val reminderDialogTitle = "வாடிக்கையாளருக்குத் தெரிவி"
    override val reminderDialogSubtitle = "செய்தியைத் திருத்தி WhatsApp அல்லது SMS மூலம் அனுப்புங்கள்"
    override val reminderMessageLabel = "செய்தி"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "இப்போது வேண்டாம்"
    override val reminderNoPhone = "இந்த வாடிக்கையாளருக்குத் தொலைபேசி எண் இல்லை"
    override val reminderAppMissing = "செயலியைத் திறக்க முடியவில்லை"
    override val reminderShopFallback = "எங்கள் கடை"
    override val reminderMsgDue = "வணக்கம் %1\$s, %2\$s இல் உங்கள் மொத்த நிலுவை %3\$s. தயவுசெய்து சரியான நேரத்தில் செலுத்தவும். நன்றி."
    override val reminderMsgCredit = "வணக்கம் %1\$s, %2\$s இல் உங்கள் கணக்கில் புதிய கடன் சேர்க்கப்பட்டுள்ளது. மொத்த நிலுவை: %3\$s."
    override val reminderMsgPayment = "வணக்கம் %1\$s, உங்கள் பணம் கிடைத்தது. நன்றி! %2\$s இல் தற்போதைய நிலுவை: %3\$s."
    override val reminderMsgSettled = "வணக்கம் %1\$s, உங்கள் நிலுவை முழுவதும் தீர்ந்தது. நன்றி! — %2\$s"
    override val pdfActionLabel = "📤 என்ன செய்வது"
    override val pdfActionShare = "பகிர்"
    override val pdfActionSave = "சேமி"
    override val pdfActionPrint = "அச்சிடு"
    override val pdfBrandingOption = "என் கடையின் பெயர், லோகோ, முகவரியைச் சேர்"
    override val pdfBrandingMissing = "கடையின் பெயர் கொடுக்கப்படவில்லை — மேலும் → கடைச் சுயவிவரத்தில் சேர்க்கவும்"
    override val pdfSavedMessage = "PDF சேமிக்கப்பட்டது"
    override val pdfSaveFailed = "PDF ஐச் சேமிக்க முடியவில்லை"
    override val setupRoleTitle = "செயலியை எப்படிப் பயன்படுத்துவீர்கள்?"
    override val setupProfileTitle = "உங்கள் கடை விவரங்கள்"
    override val setupProfileSubtitle = "பின்னர் மேலும் → கடைச் சுயவிவரத்தில் மாற்றலாம்"
    override val setupContinue = "தொடர்க"
    override val setupSkip = "இப்போது வேண்டாம், பிறகு செய்கிறேன்"
    override val setupFinish = "தொடங்குங்கள்"
    override val pickFromContacts = "தொடர்புகளிலிருந்து எண்ணைத் தேர்ந்தெடு"
    override val pdfColQtyPrice = "அளவு × விலை"
    override val pdfColItemTotal = "பொருளின் தொகை"
    override val pdfWoodSawn = "அறுத்த மரம்"
    override val pdfWoodRound = "உருளை மரக்கட்டை"
    override val pdfWoodFormula = "சூத்திரம்"
    override val pdfWoodTotalWord = "மொத்தம்"
    override val pdfMemoTitle = "பண ரசீது"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "பில் எண் / Bill No"
    override val pdfDateTitle = "தேதி / Date"
    override val pdfPeriodTitle = "காலம் / Period"
    override val pdfSeller = "விற்பவர் / Seller"
    override val pdfBuyer = "வாங்குபவர் / Buyer"
    override val pdfAddressLabel = "முகவரி: "
    override val pdfColSl = "வ.எ."
    override val pdfColPieces = "எண்"
    override val pdfColCft = "CFT"
    override val pdfColRate = "விலை (₹/CFT)"
    override val pdfColAmountRs = "மொத்தம் (₹)"
    override val pdfColQty = "அளவு"
    override val pdfColUnitPrice = "விலை (₹)"
    override val pdfSecSawn = "அறுத்த மரம் / Sawn Timber"
    override val pdfSecRound = "உருளை மரக்கட்டை / Round Log"
    override val pdfSecOther = "மற்றப் பொருட்கள் / Other Items"
    override val pdfSecCashCredit = "ரொக்கக் கடன் / Cash Credit"
    override val pdfSecPayments = "வரவு / Payments"
    override val pdfBadgeSawn = "அறுத்தது"
    override val pdfBadgeRound = "உருளை"
    override val pdfSawnTotal = "அறுத்த மரம் மொத்தம்:"
    override val pdfRoundTotal = "உருளை மரக்கட்டை மொத்தம்:"
    override val pdfTableTotal = "மொத்தம்:"
    override val pdfSumBill = "மொத்தப் பில்"
    override val pdfSumPaid = "வரவு"
    override val pdfSumDue = "நிலுவை"
    override val pdfWordsTitle = "தொகை எழுத்தில் / Amount in Words:"
    override val pdfSellerSign = "விற்பவரின் கையொப்பம் & முத்திரை"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "வாங்குபவரின் கையொப்பம்"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "இது கணினியால் உருவாக்கப்பட்ட பில். கையொப்பம் இல்லாமல் செல்லாது."
    override val pdfSummaryTitle = "சுருக்க அறிக்கை"
    override val moveShopAction = "மற்றொரு பட்டியலுக்கு மாற்று"
    override val moveShopTitle = "மற்றொரு பட்டியலுக்கு மாற்றவா?"
    override val moveToShopkeeperMsg = "இந்தப் பதிவு \"நான் கடைக்காரர்\" பட்டியலுக்கு (உங்கள் வாடிக்கையாளராக) மாறும். தொகைகள் அப்படியே இருக்கும், சொற்கள் மட்டும் மாறும்."
    override val moveToCustomerMsg = "இந்தப் பதிவு \"நான் வாடிக்கையாளர்\" பட்டியலுக்கு (நீங்கள் கடன் வாங்கும் கடை) மாறும். தொகைகள் அப்படியே இருக்கும், சொற்கள் மட்டும் மாறும்."
    override val moveShopConfirm = "மாற்று"
    override val faqItems = listOf(
        FaqItem("புதிய கடையை எப்படிச் சேர்ப்பது?", "முகப்பில் உள்ள '+' பொத்தானைத் தட்டி, கடையின் பெயர், தொலைபேசி (விருப்பம்), வகையை எழுதி 'சேமி' தட்டுங்கள்."),
        FaqItem("கடன் அல்லது வரவை எப்படிப் பதிவு செய்வது?", "கடையின் பக்கத்தைத் திறந்து 'கடன் வாங்கினேன்' அல்லது 'பணம் செலுத்தினேன்' தட்டி, தொகையை எழுதி உறுதிசெய்யுங்கள்."),
        FaqItem("பயோமெட்ரிக் பூட்டை எப்படி இயக்குவது/நிறுத்துவது?", "மேலும் → பாதுகாப்பு & தனியுரிமைக்குச் சென்று 'பயோமெட்ரிக் பூட்டை' இயக்கவும்/நிறுத்தவும். உங்கள் தொலைபேசியில் கைரேகை அல்லது முக அன்லாக் அமைக்கப்பட்டிருக்க வேண்டும்."),
        FaqItem("தரவைக் காப்புப்பிரதி எடுப்பது எப்படி?", "மேலும் → காப்புப்பிரதி & மீட்புக்குச் சென்று 'இப்போதே காப்புப்பிரதி எடு' தட்டுங்கள். இது ஒரு JSON கோப்பை உருவாக்கும்; அதைத் தொலைபேசியிலோ மேகத்திலோ சேமிக்கலாம்."),
        FaqItem("காப்புப்பிரதியிலிருந்து மீட்பது எப்படி?", "மேலும் → காப்புப்பிரதி & மீட்புக்குச் சென்று 'காப்புப்பிரதியிலிருந்து மீட்டெடு' தட்டி உங்கள் JSON கோப்பைத் தேர்ந்தெடுங்கள். இது தற்போதைய தரவு அனைத்தையும் மாற்றும், எனவே கவனமாக இருங்கள்."),
        FaqItem("கடையை நீக்கினால் திரும்பப் பெற முடியுமா?", "காப்பகப்படுத்தினால் அது வரலாற்றில் இருக்கும், பின்னர் மீட்கலாம். நிரந்தரமாக நீக்கினால் திரும்பப் பெற முடியாது."),
        FaqItem("PDF அறிக்கையை எப்படி உருவாக்குவது?", "'மேலும்' பக்கத்தில் காப்புப்பிரதி & மீட்புக்கு அருகில் ஏற்றுமதி விருப்பம் உள்ளது; கடை மற்றும் தேதி வரம்பைத் தேர்ந்தெடுத்து PDF ஐப் பகிருங்கள்."),
        FaqItem("செயலியின் மொழியை மாற்றுவது எப்படி?", "மேலும் → மொழிக்குச் சென்று உங்கள் மொழியைத் தேர்ந்தெடுத்து 'சேமி' தட்டுங்கள்.")
    )
    override val privacyPolicyBody = """உதார் ஹிசாப் என்பது ஒரு தனிப்பட்ட நிதி/கணக்குப் புத்தகச் செயலி; கடையின் கடன், நிலுவை மற்றும் பரிவர்த்தனைகளை எளிதாக நிர்வகிக்க உதவுகிறது. உங்கள் தனியுரிமை எங்களுக்கு முக்கியம்.

1. நாங்கள் சேகரிக்கும் தகவல்

உதார் ஹிசாப்பைப் பயன்படுத்தும்போது நீங்களே செயலியில் உள்ளிடும் தகவல், எடுத்துக்காட்டாக:
• கடையின் பெயர்
• கைபேசி எண்
• கடையின் முகவரி அல்லது பிற விவரங்கள்
• கடன் மற்றும் வரவுத் தொகைகள்
• பரிவர்த்தனையின் தேதி, நேரம், குறிப்பு

2. தகவலின் பயன்பாடு

இந்தத் தகவல் உங்கள் கணக்குகளைச் சேமிக்கவும் காட்டவும் நிர்வகிக்கவும் மட்டுமே பயன்படுத்தப்படுகிறது. உங்கள் தனிப்பட்ட கணக்குப் புத்தகத் தரவு உங்கள் அனுமதியின்றி எந்த விளம்பரதாரருக்கோ மூன்றாம் தரப்பிற்கோ விற்கப்படாது அல்லது பகிரப்படாது.

3. தரவுச் சேமிப்பு

உங்கள் கணக்குத் தரவு செயலியின் தேவைக்கேற்ப உங்கள் சாதனத்தில் சேமிக்கப்படலாம். காப்புப்பிரதி & மீட்பு வசதியைப் பயன்படுத்தினால், நீங்கள் தேர்ந்தெடுத்த சேமிப்பகம்/மேகச் சேவையில் உங்கள் காப்புப்பிரதித் தரவு சேமிக்கப்படலாம்.

4. செயலிப் பாதுகாப்பு

உங்கள் கணக்குத் தரவைப் பாதுகாக்க செயலிப் பூட்டு, PIN, பயோமெட்ரிக் அங்கீகாரம் போன்ற பாதுகாப்பு வசதிகள் வழங்கப்படலாம்.

5. தகவலைப் பகிர்தல்

சட்டப்படி தேவைப்பட்டால் தவிர, உங்கள் தனிப்பட்ட கணக்குப் புத்தகத் தரவை நாங்கள் மூன்றாம் தரப்பிற்கு விற்பதோ வாடகைக்கு விடுவதோ வணிக நோக்கங்களுக்காகப் பகிர்வதோ இல்லை.

6. உங்கள் கட்டுப்பாடு

செயலியில் சேமித்துள்ள உங்கள் தரவை எப்போது வேண்டுமானாலும் பார்க்கலாம், மாற்றலாம் அல்லது நீக்கலாம்.

7. மூன்றாம் தரப்புச் சேவைகள்

செயலியின் சில வசதிகளுக்கு மூன்றாம் தரப்புச் சேவைகள் பயன்படுத்தப்பட்டால், அவற்றின் சொந்தத் தனியுரிமைக் கொள்கை பொருந்தலாம்.

8. குழந்தைகளின் தனியுரிமை

உதார் ஹிசாப் குழந்தைகளிடமிருந்து தெரிந்தே தனிப்பட்ட தகவலைச் சேகரிக்க உருவாக்கப்படவில்லை.

9. இந்தத் தனியுரிமைக் கொள்கையில் மாற்றங்கள்

தேவைக்கேற்ப இந்தத் தனியுரிமைக் கொள்கையை நாங்கள் மாற்றலாம் அல்லது புதுப்பிக்கலாம். புதிய கொள்கை இந்தப் பக்கத்தில் வெளியிடப்படும்.

10. தொடர்பு

இந்தத் தனியுரிமைக் கொள்கை அல்லது உங்கள் தரவு பற்றிக் கேள்விகள் இருந்தால் தயவுசெய்து எங்களைத் தொடர்பு கொள்ளுங்கள்.

உதார் ஹிசாப்
எளிய கணக்கு, கவலையின்றி இருங்கள்."""
}


/** Telugu (తెలుగు) */
object TeluguStrings : AppStrings {
    override val code = "te"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "ప్రకటనలు తొలగించు"
    override val moreHintAdFree = "ఒకసారి కొనండి, ఇక ప్రకటనలు ఉండవు"
    override val adFreeDialogTitle = "ప్రకటనలు లేని యాప్"
    override val adFreeDialogMessage = "ఒకసారి చెల్లిస్తే అన్ని ప్రకటనలు శాశ్వతంగా ఆగిపోతాయి. యాప్‌కు మద్దతు ఇచ్చినందుకు ధన్యవాదాలు!"
    override val adFreeBuyButton = "కొను"
    override val adFreeRestoreButton = "మునుపటి కొనుగోలును తిరిగి తెండి"
    override val adFreeActiveLabel = "మీ యాప్ ప్రకటనలు లేనిది ✓"
    override val adFreeUnavailable = "ప్రస్తుతం కొనలేరు — తర్వాత మళ్లీ ప్రయత్నించండి"
    override val adSponsoredLabel = "ప్రకటన"
    override val moreAdPrivacy = "ప్రకటన ప్రాధాన్యతలు"
    override val moreHintAdPrivacy = "మీరు ఏ రకమైన ప్రకటనలు చూడాలో ఎంచుకోండి"
    override val helpCenterTitle = "సహాయ కేంద్రం"
    override val helpSearchPlaceholder = "ప్రశ్నలను వెతకండి..."
    override val noFaqResultsMessage = "ఏమీ దొరకలేదు"
    override val homeHeadline = "ఉధార్ హిసాబ్"
    override val history = "చరిత్ర"
    override val settings = "సెట్టింగ్‌లు"
    override val totalDueLabel = "మొత్తం బాకీ"
    override val thisMonthCreditLabel = "ఈ నెల బాకీ"
    override val thisMonthPaymentLabel = "ఈ నెల వచ్చింది"
    override val searchPlaceholder = "దుకాణం/ఫోన్ వెతకండి..."
    override val filterAll = "అన్నీ"
    override val settledLabel = "తీరింది"
    override val noShopsYetTitle = "ఇంకా దుకాణాలు లేవు"
    override val noShopsYetSubtitle = "ఖాతా ప్రారంభించడానికి మొదటి దుకాణాన్ని జోడించండి"
    override val addFirstShopButton = "మొదటి దుకాణాన్ని జోడించండి"
    override val newShop = "కొత్త దుకాణం"
    override val shopTypeTea = "టీ దుకాణం"
    override val shopTypeHardwareElectric = "హార్డ్‌వేర్ & ఎలక్ట్రిక్"
    override val shopTypeKirana = "కిరాణా దుకాణం"
    override val shopTypeVegetable = "కూరగాయల దుకాణం"
    override val shopTypeFishMeat = "చేపలు & మాంసం"
    override val shopTypeBakerySweets = "బేకరీ & స్వీట్లు"
    override val shopTypePharmacy = "మందుల దుకాణం"
    override val shopTypeCosmetics = "సౌందర్య సాధనాలు"
    override val shopTypeStationery = "స్టేషనరీ"
    override val shopTypeXeroxPrinting = "జిరాక్స్ & ప్రింటింగ్"
    override val shopTypeWood = "కలప దుకాణం"
    override val shopTypeGarments = "బట్టల దుకాణం"
    override val shopTypeOther = "ఇతరాలు"
    override val back = "వెనుకకు"
    override val cancel = "రద్దు"
    override val save = "సేవ్ చేయి"
    override val shopNameLabel = "దుకాణం పేరు *"
    override val shopNamePlaceholder = "ఉదా. కలప మహల్"
    override val phoneLabel = "ఫోన్ నంబర్ (ఐచ్ఛికం)"
    override val shopTypeLabel = "దుకాణం రకం *"
    override val saveShopButton = "దుకాణాన్ని సేవ్ చేయి"
    override val errorNameRequired = "దుకాణం పేరు రాయండి"
    override val errorTypeRequired = "దుకాణం రకాన్ని ఎంచుకోండి"
    override val dueLabel = "బాకీ"
    override val noTransactionsYet = "ఇంకా లావాదేవీలు లేవు"
    override val creditButton = "అప్పు తీసుకున్నాను"
    override val paymentButton = "డబ్బు చెల్లించాను"
    override val pdfExport = "PDF ఎగుమతి"
    override val archive = "ఆర్కైవ్"
    override val deleteShopAction = "దుకాణాన్ని తొలగించు"
    override val archiveConfirmTitle = "ఈ దుకాణాన్ని ఆర్కైవ్ చేయాలా?"
    override val archiveConfirmText = "ఇది హోమ్ జాబితా నుండి తొలగిపోతుంది — చరిత్రలో ఇంకా ఉంటుంది."
    override val deleteConfirmTitle = "ఈ దుకాణాన్ని శాశ్వతంగా తొలగించాలా?"
    override val deleteConfirmText = "ఈ దుకాణం మరియు దాని అన్ని లావాదేవీలు శాశ్వతంగా తొలగించబడతాయి, తిరిగి రావు. ఆర్కైవ్ చేస్తే చరిత్రలో ఉంటుంది — ముందుకు వెళ్లే ముందు జాగ్రత్తగా ఆలోచించండి."
    override val yesDelete = "అవును, తొలగించు"
    override val yesArchive = "ఆర్కైవ్ చేయి"
    override val txnDeletedSnackbar = "లావాదేవీ తొలగించబడింది"
    override val undo = "రద్దు చేయి"
    override val pdfFailPrefix = "PDF తయారు కాలేదు: "
    override val shareKhata = "ఖాతాను షేర్ చేయి"
    override val creditFallback = "అప్పు"
    override val paymentFallback = "జమ"
    override val deleteTxnAction = "తొలగించు"
    override val productNameLabel = "వస్తువు పేరు (ఐచ్ఛికం)"
    override val quantityLabel = "పరిమాణం"
    override val unitLabel = "యూనిట్"
    override val pricePerUnitLabel = "ధర/యూనిట్"
    override val totalPrefix = "మొత్తం: "
    override val amountLabel = "చెల్లించిన మొత్తం"
    override val orEnterAmountLabel = "లేదా నేరుగా మొత్తం రాయండి"
    override val noteLabel = "గమనిక (ఐచ్ఛికం)"
    override val cash = "నగదు"
    override val bkash = "bKash"
    override val bank = "బ్యాంకు"
    override val invalidAmountError = "సరైన మొత్తాన్ని రాయండి"
    override val cftCalculatorTitle = "CFT కాలిక్యులేటర్"
    override val lengthLabel = "పొడవు (అంగుళాలు)"
    override val widthLabel = "వెడల్పు"
    override val heightLabel = "ఎత్తు"
    override val rateLabel = "ధర /cft (₹)"
    override val applyToEntryButton = "ఎంట్రీకి జోడించు"
    override val settingsTitle = "సెట్టింగ్‌లు"
    override val security = "భద్రత"
    override val pinLockOn = "PIN లాక్ ఆన్‌లో ఉంది"
    override val pinLockOff = "PIN లాక్ ఆఫ్‌లో ఉంది"
    override val changePin = "PIN మార్చు"
    override val reminderTitle = "బాకీ రిమైండర్"
    override val reminderDesc = "ప్రతిరోజూ బాకీని గుర్తు చేస్తుంది"
    override val about = "గురించి"
    override val aboutLine = "ఉధార్ హిసాబ్ — దుకాణం అప్పుల ఖాతా"
    override val aboutDescription = "ఉధార్ హిసాబ్ అనేది దుకాణంలోని అప్పులు, బాకీలు మరియు లావాదేవీలను సులభంగా, వేగంగా, క్రమబద్ధంగా నిర్వహించడంలో సహాయపడే స్మార్ట్ హిసాబ్ యాప్. ఏ దుకాణంలో ఎంత బాకీ ఉంది, ఎక్కడ డబ్బు చెల్లించారు, ఏ లావాదేవీ ఎప్పుడు జరిగింది — ప్రతిదీ ఒకే చోట చక్కగా భద్రపరచుకోవచ్చు.\n\nఈ యాప్‌లో మీరు సులభంగా దుకాణాలను జోడించవచ్చు, అప్పు మరియు జమను నమోదు చేయవచ్చు, లావాదేవీల చరిత్ర చూడవచ్చు, మొత్తం బాకీ మరియు జమను తనిఖీ చేయవచ్చు, వివరణాత్మక నివేదికలు తయారు చేయవచ్చు. శోధన, ఫిల్టర్, బ్యాకప్ & రీస్టోర్, యాప్ లాక్, బయోమెట్రిక్ భద్రత, డార్క్ మోడ్, నోటిఫికేషన్‌ల వంటి సౌకర్యాలు హిసాబ్ నిర్వహణను మరింత సులభం, సురక్షితం చేస్తాయి.\n\nకాగితపు పుస్తకాల గందరగోళాన్ని సరళమైన, ఆధునిక, నమ్మకమైన డిజిటల్ పద్ధతిలోకి తీసుకురావడమే ఉధార్ హిసాబ్ లక్ష్యం."
    override val aboutTagline = "ఉధార్ హిసాబ్ — సులభమైన హిసాబ్, నిశ్చింతగా ఉండండి."
    override val versionLine = "వెర్షన్ 1.0"
    override val setPinTitle = "PIN సెట్ చేయండి"
    override val newPinLabel = "కొత్త PIN"
    override val confirmPinLabel = "PINను మళ్లీ రాయండి"
    override val pinSetupError = "PINలు సరిపోలలేదు (కనీసం 4 అంకెలు)"
    override val removePinTitle = "PIN లాక్ ఆఫ్ చేయాలా?"
    override val removePinText = "ఇకపై యాప్ తెరిచేటప్పుడు PIN అడగబడదు."
    override val yesTurnOff = "అవును, ఆఫ్ చేయి"
    override val no = "కాదు"
    override val languageTitle = "భాష"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "నోటిఫికేషన్‌లు"
    override val notifSheetSubtitle = "మీకు ఏ రిమైండర్‌లు కావాలి?"
    override val notifDueReminderOption = "బాకీ చెల్లింపు రిమైండర్"
    override val notifWeeklySummaryOption = "వారపు సారాంశం"
    override val notifAppNewsOption = "యాప్ వార్తలు & అప్‌డేట్‌లు"
    override val langSheetSubtitle = "యాప్‌ను ఏ భాషలో వాడాలి?"
    override val themeSheetSubtitle = "మీకు ఏ థీమ్ ఇష్టం?"
    override val securityPrivacyTitle = "భద్రత & గోప్యత"
    override val pinSectionTitle = "PIN లాక్"
    override val pinSectionDesc = "యాప్ తెరిచేటప్పుడు PIN అడుగు"
    override val fingerprintTitle = "ఫింగర్‌ప్రింట్ లాక్"
    override val fingerprintDesc = "PIN బదులు ఫింగర్‌ప్రింట్‌తో తెరవండి"
    override val fingerprintUnavailable = "ఈ ఫోన్‌లో ఫింగర్‌ప్రింట్ సెన్సార్ లేదు"
    override val lockImmediatelyTitle = "వెంటనే లాక్ చేయి"
    override val lockImmediatelyDesc = "యాప్‌కు తిరిగి రాగానే మళ్లీ లాక్ అవుతుంది"
    override val rateTitle = "రేటింగ్ & అభిప్రాయం"
    override val rateSubtitle = "ఉధార్ హిసాబ్ మీకు ఎలా అనిపిస్తోంది?"
    override val rateStarsPrompt = "రేటింగ్ ఇవ్వడానికి నొక్కండి"
    override val rateThanksMessage = "ధన్యవాదాలు! మిమ్మల్ని Play Storeకు తీసుకెళ్తున్నాం…"
    override val feedbackPromptLow = "మీకు ఏది నచ్చలేదు? మాకు చెప్పండి"
    override val feedbackPlaceholder = "మీ అభిప్రాయాన్ని రాయండి…"
    override val feedbackSubmit = "పంపు"
    override val feedbackThanks = "ధన్యవాదాలు, మీ అభిప్రాయం పంపబడింది"
    override val aboutPageTitle = "ఉధార్ హిసాబ్ గురించి"
    override val aboutVersionPrefix = "వెర్షన్"
    override val aboutDeveloperLabel = "డెవలపర్"
    override val aboutDeveloperName = "ఉధార్ హిసాబ్ బృందం"
    override val aboutPrivacyPolicy = "గోప్యతా విధానం"
    override val privacyPolicyEffectiveDate = "అమలు తేదీ: 13 సెప్టెంబర్ 2026"
    override val aboutShareApp = "షేర్ చేయి"
    override val aboutShareText = "ఉధార్ హిసాబ్ — దుకాణం అప్పుల ఖాతా యాప్‌ను ప్రయత్నించండి!"
    override val noArchivedShops = "ఆర్కైవ్ చేసిన దుకాణాలు లేవు"
    override val noSettledShops = "తీరిన దుకాణాలు లేవు"
    override val setupPinTitle = "4 అంకెల PIN సెట్ చేయండి"
    override val unlockPinTitle = "PINతో తెరవండి"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 అంకెలు రాయండి"
    override val pinsDontMatchError = "PINలు సరిపోలలేదు"
    override val wrongPinError = "PIN తప్పు — మళ్లీ ప్రయత్నించండి"
    override val savePinButton = "PIN సేవ్ చేయి"
    override val unlockButton = "తెరువు"
    override val pdfHeaderTitle = "ఖాతా — ఉధార్ హిసాబ్"
    override val pdfFullKhataSuffix = "పూర్తి ఖాతా"
    override val pdfShopLabel = "దుకాణం: "
    override val pdfPhoneLabel = "ఫోన్: "
    override val pdfCreatedLabel = "తయారైనది: "
    override val pdfColDate = "తేదీ/సమయం"
    override val pdfColDesc = "వివరం"
    override val pdfTotalCredit = "మొత్తం అప్పు:"
    override val pdfTotalPayment = "మొత్తం జమ:"
    override val pdfCurrentDue = "ప్రస్తుత బాకీ:"
    override val pdfFooter = "ఉధార్ హిసాబ్ యాప్ ద్వారా తయారైంది"
    override val navHome = "హోమ్"
    override val navHistory = "చరిత్ర"
    override val navReports = "నివేదిక"
    override val navMore = "మరిన్ని"
    override val historyFilterAllShops = "అన్ని దుకాణాలు"
    override val historyFilterAllTypes = "అన్నీ"
    override val historyFilterCreditOnly = "అప్పు మాత్రమే"
    override val historyFilterPaymentOnly = "జమ మాత్రమే"
    override val historyNoTxnsFound = "లావాదేవీలు ఏవీ దొరకలేదు"
    override val viewArchivedAction = "ఆర్కైవ్ చేసిన దుకాణాలను చూడండి"
    override val reportsTitle = "నివేదిక"
    override val periodLabel = "కాలం"
    override val period7d = "గత 7 రోజులు"
    override val period15d = "గత 15 రోజులు"
    override val period30d = "గత 30 రోజులు"
    override val period3m = "గత 3 నెలలు"
    override val period1y = "ఈ సంవత్సరం"
    override val reportTotalCredit = "మొత్తం అప్పు"
    override val reportTotalPayment = "మొత్తం జమ"
    override val reportCurrentDue = "ప్రస్తుత మొత్తం బాకీ"
    override val reportTxnCount = "లావాదేవీలు"
    override val reportChartTitle = "అప్పు vs జమ"
    override val reportShopWiseTitle = "దుకాణం వారీగా బాకీ"
    override val reportAgingTitle = "బాకీ వయస్సు"
    override val reportAging0to7 = "0–7 రోజులు"
    override val reportAging7to15 = "7–15 రోజులు"
    override val reportAging15to30 = "15–30 రోజులు"
    override val reportAging30plus = "30+ రోజులు"
    override val reportRecentPaymentsTitle = "ఇటీవలి జమలు"
    override val reportNoData = "ఈ కాలానికి సమాచారం లేదు"
    override val reportSmartSummaryPrefix = "ఈ కాలంలో మీరు"
    override val moreTitle = "మరిన్ని"
    override val moreBackupRestore = "బ్యాకప్ & రీస్టోర్"
    override val moreHintBackupRestore = "మీ డేటాను భద్రంగా ఉంచండి"
    override val notesTitle = "నోట్స్"
    override val notesSearchPlaceholder = "నోట్స్ వెతకండి..."
    override val addNoteButton = "కొత్త నోట్"
    override val noNotesYetTitle = "ఇంకా నోట్స్ లేవు"
    override val noNotesYetSubtitle = "కొనుగోళ్ల జాబితా, రిమైండర్లు — ఏదైనా రాసి ఉంచండి"
    override val deleteNoteConfirmTitle = "ఈ నోట్‌ను తొలగించాలా?"
    override val deleteNoteConfirmMessage = "ఈ నోట్ శాశ్వతంగా తొలగించబడుతుంది."
    override val noteTitlePlaceholder = "శీర్షిక"
    override val noteContentPlaceholder = "ఏదైనా రాయండి..."
    override val untitledNote = "శీర్షిక లేని నోట్"
    override val notificationInboxTitle = "నోటిఫికేషన్‌లు"
    override val moreNotificationHistory = "నోటిఫికేషన్ చరిత్ర"
    override val moreHintNotificationHistory = "ఇటీవలి కార్యకలాపాలు చూడండి"
    override val noNotificationsYetTitle = "ఇంకా నోటిఫికేషన్‌లు లేవు"
    override val noNotificationsYetSubtitle = "అప్పు లేదా జమ నమోదు చేస్తే ఇక్కడ కనిపిస్తుంది"
    override val notifCreditMessage = "%1\$s నుండి %2\$s అప్పు తీసుకున్నారు"
    override val notifPaymentMessage = "%1\$sకి %2\$s జమ చేశారు"
    override val moreQuickCalculator = "క్విక్ కాలిక్యులేటర్"
    override val moreHintQuickCalculator = "త్వరగా లెక్కలు వేయండి"
    override val calcGeneralTab = "సాధారణ"
    override val calcPercentTab = "శాతం"
    override val calcConversionTab = "మార్పిడి"
    override val calcComingSoonInTab = "త్వరలో వస్తోంది"
    override val percentOfTitle = "ఒక సంఖ్యలో శాతం"
    override val percentOfValueLabel = "సంఖ్య"
    override val percentOfPercentLabel = "శాతం (%)"
    override val percentIsWhatTitle = "ఒక సంఖ్య మరొక దానిలో ఎంత శాతం"
    override val percentIsWhatXLabel = "ఈ సంఖ్య"
    override val percentIsWhatYLabel = "దీనిలో"
    override val percentChangeTitle = "శాతం పెరుగుదల/తగ్గుదల"
    override val percentChangeBaseLabel = "మూల సంఖ్య"
    override val percentChangePercentLabel = "శాతం (%)"
    override val increaseOption = "పెరుగుదల"
    override val decreaseOption = "తగ్గుదల"
    override val resultLabel = "ఫలితం"
    override val weightCategory = "బరువు"
    override val lengthCategory = "పొడవు"
    override val volumeCategory = "పరిమాణం"
    override val fromLabel = "నుండి"
    override val toLabel = "వరకు"
    override val enterValueHint = "విలువ రాయండి"
    override val backupNowButton = "ఇప్పుడే బ్యాకప్ తీసుకోండి"
    override val backupNowHint = "అన్ని దుకాణాలు, లావాదేవీలను JSON ఫైల్‌లో సేవ్ చేయండి"
    override val restoreButton = "బ్యాకప్ నుండి రీస్టోర్ చేయండి"
    override val restoreShopAction = "రీస్టోర్"
    override val restoreHint = "పాత JSON బ్యాకప్ ఫైల్ నుండి డేటాను తిరిగి తెచ్చుకోండి"
    override val lastBackupLabel = "చివరి బ్యాకప్"
    override val noBackupYetLabel = "ఇంకా బ్యాకప్ తీసుకోలేదు"
    override val backupSuccessMessage = "బ్యాకప్ తయారైంది"
    override val backupFailPrefix = "బ్యాకప్ విఫలమైంది: "
    override val restoreConfirmTitle = "బ్యాకప్‌ను రీస్టోర్ చేయాలా?"
    override val restoreConfirmMessage = "ఇది ప్రస్తుత అన్ని దుకాణాలు, లావాదేవీలను తుడిచి బ్యాకప్ ఫైల్ డేటాతో మారుస్తుంది. దీన్ని వెనక్కి తీసుకోలేరు."
    override val restoreSuccessMessage = "రీస్టోర్ పూర్తయింది"
    override val restoreFailPrefix = "రీస్టోర్ విఫలమైంది: "
    override val dataSafeNote = "మీ డేటా ఈ ఫోన్‌లో మాత్రమే ఉంటుంది — బ్యాకప్ ఫైల్‌ను మీరే భద్రంగా ఉంచుకోండి"
    override val moreExportShare = "ఎగుమతి & షేర్"
    override val moreHintExportShare = "PDF, ఫైళ్లను పంపండి"
    override val moreNotifications = "నోటిఫికేషన్‌లు"
    override val moreHintNotifications = "రిమైండర్లు ఆన్/ఆఫ్ చేయండి"
    override val moreLanguage = "భాష"
    override val moreHintLanguage = "మీ భాషను ఎంచుకోండి"
    override val moreUserMode = "నేను ఎవరు"
    override val moreHintUserMode = "కస్టమర్ లేదా దుకాణదారు"
    override val moreSecurityPrivacy = "భద్రత & గోప్యత"
    override val moreHintSecurityPrivacy = "PIN & ఫింగర్‌ప్రింట్ లాక్"
    override val moreAppearance = "రూపం"
    override val moreHintAppearance = "లైట్, డార్క్ లేదా సిస్టమ్"
    override val moreRateFeedback = "రేటింగ్ & అభిప్రాయం"
    override val moreHintRateFeedback = "మీ అభిప్రాయం చెప్పండి"
    override val moreAbout = "ఉధార్ హిసాబ్ గురించి"
    override val moreHintAbout = "వెర్షన్ & డెవలపర్"
    override val comingSoonMessage = "త్వరలో వస్తోంది"
    override val appearanceTitle = "రూపం"
    override val themeLight = "లైట్"
    override val themeDark = "డార్క్"
    override val themeSystem = "సిస్టమ్ డిఫాల్ట్"
    override val creditPageTitle = "అప్పు తీసుకో"
    override val accountingTypeLabel = "ఎంట్రీ రకం"
    override val directMoneyMode = "నేరుగా మొత్తం"
    override val productMode = "వస్తువు వారీగా"
    override val directMoneyAmountLabel = "ఎంత అప్పు ఇచ్చారు?"
    override val previousDueLabel = "మునుపటి బాకీ"
    override val newCreditLabel = "కొత్త అప్పు"
    override val newTotalDueLabel = "కొత్త మొత్తం బాకీ"
    override val addCreditButton = "అప్పు జోడించు"
    override val addMoreProductButton = "+ మరో వస్తువు జోడించు"
    override val totalNewCreditLabel = "మొత్తం కొత్త అప్పు"
    override val editAction = "మార్చు"
    override val itemsCountSuffix = "వస్తువులు"
    override val paymentPageTitle = "జమ"
    override val currentDueLabel = "ప్రస్తుత బాకీ"
    override val howMuchPaymentLabel = "ఎంత జమ చేస్తున్నారు?"
    override val fullPaymentButton = "పూర్తి మొత్తం"
    override val dueAfterPaymentLabel = "జమ తర్వాత బాకీ"
    override val addPaymentButton = "జమ జోడించు"
    override val overpaymentBlockedMessage = "ప్రస్తుత బాకీ కంటే ఎక్కువ జమ చేయలేరు"
    override val fullyPaidCelebration = "ఇది పూర్తి బాకీని తీర్చేస్తుంది"
    override val woodCalculatorTitle = "కలప కాలిక్యులేటర్"
    override val woodTypeLabel = "కలప రకం"
    override val sawnWoodOption = "కోసిన కలప"
    override val roundWoodOption = "గుండ్రని దుంగ"
    override val lengthFtLabel = "పొడవు (అడుగులు)"
    override val widthInLabel = "వెడల్పు (అంగుళాలు)"
    override val thicknessInLabel = "మందం (అంగుళాలు)"
    override val girthInLabel = "చుట్టుకొలత (అంగుళాలు)"
    override val pieceCountLabel = "ముక్కల సంఖ్య"
    override val perPieceCftLabel = "ఒక్కో ముక్కకు"
    override val totalWoodCftLabel = "మొత్తం కలప"
    override val perCftPriceLabel = "ఒక్కో CFT ధర (₹)"
    override val totalWoodValueLabel = "మొత్తం విలువ"
    override val addWoodCalcButton = "ఈ కలప లెక్కను జోడించు"
    override val woodNameLabel = "వస్తువు పేరు"
    override val addMoreWoodProductButton = "+ మరో కలప/వస్తువు జోడించు"
    override val addedItemsHeader = "జోడించిన వస్తువులు/కలప"
    override val pdfOptionsTitle = "PDF ఎంపికలు"
    override val pdfPeriodLabel = "కాలం"
    override val pdfThisMonth = "ఈ నెల"
    override val pdfLastMonth = "గత నెల"
    override val pdfLast3Months = "గత 3 నెలలు"
    override val pdfCustomRange = "సొంత తేదీలు"
    override val pdfShopLabelOption = "దుకాణం"
    override val pdfAllShopsOption = "అన్ని దుకాణాలు"
    override val pdfContentLabel = "ఏమి చూపాలి"
    override val pdfContentFull = "అన్నీ (లావాదేవీలు + సారాంశం + సంతకం)"
    override val pdfContentSummaryOnly = "సారాంశం మాత్రమే"
    override val pdfContentTxnsOnly = "లావాదేవీలు మాత్రమే"
    override val pdfFormatLabel = "ఫార్మాట్"
    override val pdfFormatA4 = "A4 నివేదిక"
    override val pdfFormatReceipt = "రసీదు (58mm)"
    override val pdfGenerateButton = "PDF తయారు చేయి"
    override val pdfFromDateLabel = "ప్రారంభ తేదీ"
    override val pdfToDateLabel = "చివరి తేదీ"
    override val pdfReportNumberLabel = "నివేదిక సంఖ్య"
    override val pdfShopBoxLabel = "దుకాణం"
    override val pdfDateBoxLabel = "తేదీ"
    override val pdfDaysOfRecordsSuffix = "రోజుల రికార్డు"
    override val pdfWeeklyChartTitle = "వారపు అప్పు (ఎరుపు) vs జమ (ఆకుపచ్చ)"
    override val pdfFinalDueLabel = "ప్రస్తుత బాకీ"
    override val pdfShopSignatureLabel = "దుకాణదారు సంతకం"
    override val pdfCustomerSignatureLabel = "కస్టమర్ సంతకం"
    override val pdfAllShopsReportTitle = "అన్ని దుకాణాల సారాంశం — ఉధార్ హిసాబ్"
    override val pdfPageLabel = "పేజీ"
    override val moreShopProfile = "దుకాణం ప్రొఫైల్"
    override val moreHintShopProfile = "పేరు, లోగో, చిరునామా, రిమైండర్"
    override val shopProfileTitle = "దుకాణం ప్రొఫైల్"
    override val shopProfileIntro = "ఈ సమాచారం PDF ఇన్‌వాయిస్‌లలో, కస్టమర్‌కు పంపే సందేశాలలో వాడబడుతుంది"
    override val shopBusinessNameLabel = "దుకాణం పేరు"
    override val shopBusinessAddressLabel = "దుకాణం చిరునామా"
    override val shopBusinessPhoneLabel = "దుకాణం ఫోన్ నంబర్"
    override val countryCodeLabel = "దేశ కోడ్ (ఉదా. 91)"
    override val shopLogoLabel = "దుకాణం లోగో"
    override val shopLogoPick = "లోగో ఎంచుకోండి"
    override val shopLogoRemove = "లోగో తొలగించండి"
    override val promptAfterEntryLabel = "ఎంట్రీ తర్వాత కస్టమర్‌కు తెలిపే ఎంపిక చూపించు"
    override val saveProfileButton = "ప్రొఫైల్ సేవ్ చేయి"
    override val profileSavedMessage = "ప్రొఫైల్ సేవ్ అయింది"
    override val errorShopNameForPdf = "PDFలో వాడడానికి దుకాణం పేరు ఇవ్వండి"
    override val reminderSendAction = "రిమైండర్ పంపు"
    override val reminderDialogTitle = "కస్టమర్‌కు తెలియజేయండి"
    override val reminderDialogSubtitle = "సందేశాన్ని మార్చి WhatsApp లేదా SMS ద్వారా పంపండి"
    override val reminderMessageLabel = "సందేశం"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "ఇప్పుడు కాదు"
    override val reminderNoPhone = "ఈ కస్టమర్‌కు ఫోన్ నంబర్ లేదు"
    override val reminderAppMissing = "యాప్ తెరవలేకపోయాం"
    override val reminderShopFallback = "మా దుకాణం"
    override val reminderMsgDue = "నమస్కారం %1\$s, %2\$s ఖాతాలో మీ మొత్తం బాకీ %3\$s. దయచేసి సమయానికి చెల్లించండి. ధన్యవాదాలు."
    override val reminderMsgCredit = "నమస్కారం %1\$s, %2\$s ఖాతాలో మీ కొత్త అప్పు జోడించబడింది. మొత్తం బాకీ: %3\$s."
    override val reminderMsgPayment = "నమస్కారం %1\$s, మీ డబ్బు అందింది. ధన్యవాదాలు! %2\$s ఖాతాలో ప్రస్తుత బాకీ: %3\$s."
    override val reminderMsgSettled = "నమస్కారం %1\$s, మీ బాకీ అంతా తీరింది. ధన్యవాదాలు! — %2\$s"
    override val pdfActionLabel = "📤 ఏం చేయాలి"
    override val pdfActionShare = "షేర్"
    override val pdfActionSave = "సేవ్"
    override val pdfActionPrint = "ప్రింట్"
    override val pdfBrandingOption = "నా దుకాణం పేరు, లోగో, చిరునామా జోడించు"
    override val pdfBrandingMissing = "దుకాణం పేరు ఇవ్వలేదు — మరిన్ని → దుకాణం ప్రొఫైల్‌లో జోడించండి"
    override val pdfSavedMessage = "PDF సేవ్ అయింది"
    override val pdfSaveFailed = "PDF సేవ్ చేయలేకపోయాం"
    override val setupRoleTitle = "మీరు యాప్‌ను ఎలా వాడతారు?"
    override val setupProfileTitle = "మీ దుకాణం వివరాలు"
    override val setupProfileSubtitle = "తర్వాత మరిన్ని → దుకాణం ప్రొఫైల్‌లో మార్చవచ్చు"
    override val setupContinue = "కొనసాగించు"
    override val setupSkip = "ఇప్పుడు కాదు, తర్వాత చేస్తాను"
    override val setupFinish = "ప్రారంభించు"
    override val pickFromContacts = "కాంటాక్ట్‌ల నుండి నంబర్ ఎంచుకోండి"
    override val pdfColQtyPrice = "పరిమాణం × ధర"
    override val pdfColItemTotal = "వస్తువు మొత్తం"
    override val pdfWoodSawn = "కోసిన కలప"
    override val pdfWoodRound = "గుండ్రని దుంగ"
    override val pdfWoodFormula = "సూత్రం"
    override val pdfWoodTotalWord = "మొత్తం"
    override val pdfMemoTitle = "క్యాష్ మెమో"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "బిల్ నం. / Bill No"
    override val pdfDateTitle = "తేదీ / Date"
    override val pdfPeriodTitle = "కాలం / Period"
    override val pdfSeller = "అమ్మకందారు / Seller"
    override val pdfBuyer = "కొనుగోలుదారు / Buyer"
    override val pdfAddressLabel = "చిరునామా: "
    override val pdfColSl = "క్ర.సం."
    override val pdfColPieces = "సంఖ్య"
    override val pdfColCft = "CFT"
    override val pdfColRate = "ధర (₹/CFT)"
    override val pdfColAmountRs = "మొత్తం (₹)"
    override val pdfColQty = "పరిమాణం"
    override val pdfColUnitPrice = "ధర (₹)"
    override val pdfSecSawn = "కోసిన కలప / Sawn Timber"
    override val pdfSecRound = "గుండ్రని దుంగ / Round Log"
    override val pdfSecOther = "ఇతర వస్తువులు / Other Items"
    override val pdfSecCashCredit = "నగదు అప్పు / Cash Credit"
    override val pdfSecPayments = "జమ / Payments"
    override val pdfBadgeSawn = "కోసినది"
    override val pdfBadgeRound = "గుండ్రని"
    override val pdfSawnTotal = "కోసిన కలప మొత్తం:"
    override val pdfRoundTotal = "గుండ్రని దుంగల మొత్తం:"
    override val pdfTableTotal = "మొత్తం:"
    override val pdfSumBill = "మొత్తం బిల్"
    override val pdfSumPaid = "జమ"
    override val pdfSumDue = "బాకీ"
    override val pdfWordsTitle = "మొత్తం అక్షరాల్లో / Amount in Words:"
    override val pdfSellerSign = "అమ్మకందారు సంతకం & ముద్ర"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "కొనుగోలుదారు సంతకం"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "ఇది కంప్యూటర్ తయారుచేసిన బిల్. సంతకం లేకుండా చెల్లదు."
    override val pdfSummaryTitle = "సారాంశ నివేదిక"
    override val moveShopAction = "మరో జాబితాకు తరలించు"
    override val moveShopTitle = "మరో జాబితాకు తరలించాలా?"
    override val moveToShopkeeperMsg = "ఈ ఎంట్రీ \"నేను దుకాణదారు\" జాబితాకు (మీ కస్టమర్‌గా) వెళ్తుంది. మొత్తాలు అలాగే ఉంటాయి, పదాలు మాత్రమే మారతాయి."
    override val moveToCustomerMsg = "ఈ ఎంట్రీ \"నేను కస్టమర్\" జాబితాకు (మీరు అప్పు తీసుకునే దుకాణం) వెళ్తుంది. మొత్తాలు అలాగే ఉంటాయి, పదాలు మాత్రమే మారతాయి."
    override val moveShopConfirm = "తరలించు"
    override val faqItems = listOf(
        FaqItem("కొత్త దుకాణాన్ని ఎలా జోడించాలి?", "హోమ్‌లోని '+' బటన్ నొక్కి, దుకాణం పేరు, ఫోన్ (ఐచ్ఛికం), రకం రాసి 'సేవ్ చేయి' నొక్కండి."),
        FaqItem("అప్పు లేదా జమను ఎలా నమోదు చేయాలి?", "దుకాణం పేజీ తెరిచి 'అప్పు తీసుకున్నాను' లేదా 'డబ్బు చెల్లించాను' నొక్కి, మొత్తం రాసి నిర్ధారించండి."),
        FaqItem("బయోమెట్రిక్ లాక్‌ను ఎలా ఆన్/ఆఫ్ చేయాలి?", "మరిన్ని → భద్రత & గోప్యతలో 'బయోమెట్రిక్ లాక్' ఆన్/ఆఫ్ చేయండి. మీ ఫోన్‌లో ఫింగర్‌ప్రింట్ లేదా ఫేస్ అన్‌లాక్ సెట్ చేసి ఉండాలి."),
        FaqItem("డేటా బ్యాకప్ ఎలా తీసుకోవాలి?", "మరిన్ని → బ్యాకప్ & రీస్టోర్‌లో 'ఇప్పుడే బ్యాకప్ తీసుకోండి' నొక్కండి. ఇది ఒక JSON ఫైల్ తయారు చేస్తుంది; దాన్ని ఫోన్‌లో లేదా క్లౌడ్‌లో సేవ్ చేయవచ్చు."),
        FaqItem("బ్యాకప్ నుండి ఎలా రీస్టోర్ చేయాలి?", "మరిన్ని → బ్యాకప్ & రీస్టోర్‌లో 'బ్యాకప్ నుండి రీస్టోర్ చేయండి' నొక్కి మీ JSON ఫైల్ ఎంచుకోండి. ఇది ప్రస్తుత డేటా అంతా మారుస్తుంది, కాబట్టి జాగ్రత్త."),
        FaqItem("దుకాణాన్ని తొలగిస్తే తిరిగి పొందగలమా?", "ఆర్కైవ్ చేస్తే అది చరిత్రలో ఉంటుంది, తర్వాత తిరిగి తేవచ్చు. శాశ్వతంగా తొలగిస్తే తిరిగి రాదు."),
        FaqItem("PDF నివేదిక ఎలా తయారు చేయాలి?", "'మరిన్ని' పేజీలో బ్యాకప్ & రీస్టోర్ పక్కన ఎగుమతి ఎంపిక ఉంది; దుకాణం, తేదీ పరిధి ఎంచుకుని PDF షేర్ చేయండి."),
        FaqItem("యాప్ భాషను ఎలా మార్చాలి?", "మరిన్ని → భాషలో మీ భాష ఎంచుకుని 'సేవ్ చేయి' నొక్కండి.")
    )
    override val privacyPolicyBody = """ఉధార్ హిసాబ్ అనేది దుకాణంలోని అప్పులు, బాకీలు, లావాదేవీలను సులభంగా నిర్వహించడంలో సహాయపడే వ్యక్తిగత ఆర్థిక/ఖాతా పుస్తక యాప్. మీ గోప్యత మాకు ముఖ్యం.

1. మేము సేకరించే సమాచారం

ఉధార్ హిసాబ్ వాడుతున్నప్పుడు మీరే యాప్‌లో నమోదు చేసే సమాచారం, ఉదాహరణకు:
• దుకాణం పేరు
• మొబైల్ నంబర్
• దుకాణం చిరునామా లేదా ఇతర వివరాలు
• అప్పు మరియు జమ మొత్తాలు
• లావాదేవీ తేదీ, సమయం, గమనిక

2. సమాచార వినియోగం

ఈ సమాచారం మీ హిసాబ్‌లను భద్రపరచడానికి, చూపించడానికి, నిర్వహించడానికి మాత్రమే ఉపయోగిస్తారు. మీ వ్యక్తిగత ఖాతా పుస్తక డేటాను మీ అనుమతి లేకుండా ఏ ప్రకటనదారుకూ, మూడవ పక్షానికీ అమ్మరు లేదా పంచరు.

3. డేటా నిల్వ

యాప్ అవసరానికి తగ్గట్టు మీ హిసాబ్ డేటా మీ పరికరంలో నిల్వ కావచ్చు. బ్యాకప్ & రీస్టోర్ సౌకర్యం వాడితే, మీరు ఎంచుకున్న స్టోరేజ్/క్లౌడ్ సేవలో బ్యాకప్ డేటా నిల్వ కావచ్చు.

4. యాప్ భద్రత

మీ హిసాబ్ డేటాను భద్రంగా ఉంచడానికి యాప్ లాక్, PIN, బయోమెట్రిక్ ధృవీకరణ వంటి భద్రతా సౌకర్యాలు అందించబడవచ్చు.

5. సమాచార పంపిణీ

చట్టప్రకారం అవసరమైతే తప్ప, మీ వ్యక్తిగత ఖాతా పుస్తక డేటాను మేము మూడవ పక్షాలకు అమ్మం, అద్దెకివ్వం, వాణిజ్య ప్రయోజనాల కోసం పంచం.

6. మీ నియంత్రణ

యాప్‌లో నిల్వ చేసిన మీ డేటాను మీరు ఎప్పుడైనా చూడవచ్చు, మార్చవచ్చు లేదా తొలగించవచ్చు.

7. మూడవ పక్ష సేవలు

యాప్‌లోని కొన్ని సౌకర్యాలకు మూడవ పక్ష సేవలు వాడితే, వాటి స్వంత గోప్యతా విధానం వర్తించవచ్చు.

8. పిల్లల గోప్యత

ఉధార్ హిసాబ్ ఉద్దేశపూర్వకంగా పిల్లల నుండి వ్యక్తిగత సమాచారాన్ని సేకరించడానికి రూపొందించబడలేదు.

9. ఈ గోప్యతా విధానంలో మార్పులు

అవసరాన్ని బట్టి ఈ గోప్యతా విధానాన్ని మేము మార్చవచ్చు లేదా నవీకరించవచ్చు. కొత్త విధానం ఈ పేజీలో ప్రచురించబడుతుంది.

10. సంప్రదింపు

ఈ గోప్యతా విధానం లేదా మీ డేటా గురించి ఏవైనా ప్రశ్నలుంటే దయచేసి మమ్మల్ని సంప్రదించండి.

ఉధార్ హిసాబ్
సులభమైన హిసాబ్, నిశ్చింతగా ఉండండి."""
}

/** Kannada (ಕನ್ನಡ) */
object KannadaStrings : AppStrings {
    override val code = "kn"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "ಜಾಹೀರಾತು ತೆಗೆಯಿರಿ"
    override val moreHintAdFree = "ಒಮ್ಮೆ ಖರೀದಿಸಿ, ಇನ್ನು ಜಾಹೀರಾತು ಇಲ್ಲ"
    override val adFreeDialogTitle = "ಜಾಹೀರಾತು ರಹಿತ ಆ್ಯಪ್"
    override val adFreeDialogMessage = "ಒಮ್ಮೆ ಹಣ ಪಾವತಿಸಿದರೆ ಎಲ್ಲಾ ಜಾಹೀರಾತುಗಳು ಶಾಶ್ವತವಾಗಿ ನಿಲ್ಲುತ್ತವೆ. ಆ್ಯಪ್‌ಗೆ ಬೆಂಬಲ ನೀಡಿದ್ದಕ್ಕೆ ಧನ್ಯವಾದಗಳು!"
    override val adFreeBuyButton = "ಖರೀದಿಸಿ"
    override val adFreeRestoreButton = "ಹಿಂದಿನ ಖರೀದಿ ಮರಳಿ ತನ್ನಿ"
    override val adFreeActiveLabel = "ನಿಮ್ಮ ಆ್ಯಪ್ ಜಾಹೀರಾತು ರಹಿತವಾಗಿದೆ ✓"
    override val adFreeUnavailable = "ಈಗ ಖರೀದಿಸಲಾಗದು — ನಂತರ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ"
    override val adSponsoredLabel = "ಜಾಹೀರಾತು"
    override val moreAdPrivacy = "ಜಾಹೀರಾತು ಆದ್ಯತೆಗಳು"
    override val moreHintAdPrivacy = "ನೀವು ಯಾವ ರೀತಿಯ ಜಾಹೀರಾತು ನೋಡಬೇಕೆಂದು ಆರಿಸಿ"
    override val helpCenterTitle = "ಸಹಾಯ ಕೇಂದ್ರ"
    override val helpSearchPlaceholder = "ಪ್ರಶ್ನೆಗಳನ್ನು ಹುಡುಕಿ..."
    override val noFaqResultsMessage = "ಏನೂ ಸಿಗಲಿಲ್ಲ"
    override val homeHeadline = "ಉಧಾರ್ ಹಿಸಾಬ್"
    override val history = "ಇತಿಹಾಸ"
    override val settings = "ಸೆಟ್ಟಿಂಗ್‌ಗಳು"
    override val totalDueLabel = "ಒಟ್ಟು ಬಾಕಿ"
    override val thisMonthCreditLabel = "ಈ ತಿಂಗಳ ಬಾಕಿ"
    override val thisMonthPaymentLabel = "ಈ ತಿಂಗಳು ಬಂದದ್ದು"
    override val searchPlaceholder = "ಅಂಗಡಿ/ಫೋನ್ ಹುಡುಕಿ..."
    override val filterAll = "ಎಲ್ಲಾ"
    override val settledLabel = "ತೀರಿದೆ"
    override val noShopsYetTitle = "ಇನ್ನೂ ಅಂಗಡಿಗಳಿಲ್ಲ"
    override val noShopsYetSubtitle = "ಖಾತೆ ಆರಂಭಿಸಲು ಮೊದಲ ಅಂಗಡಿಯನ್ನು ಸೇರಿಸಿ"
    override val addFirstShopButton = "ಮೊದಲ ಅಂಗಡಿಯನ್ನು ಸೇರಿಸಿ"
    override val newShop = "ಹೊಸ ಅಂಗಡಿ"
    override val shopTypeTea = "ಚಹಾ ಅಂಗಡಿ"
    override val shopTypeHardwareElectric = "ಹಾರ್ಡ್‌ವೇರ್ ಮತ್ತು ಎಲೆಕ್ಟ್ರಿಕ್"
    override val shopTypeKirana = "ಕಿರಾಣಿ ಅಂಗಡಿ"
    override val shopTypeVegetable = "ತರಕಾರಿ ಅಂಗಡಿ"
    override val shopTypeFishMeat = "ಮೀನು ಮತ್ತು ಮಾಂಸ"
    override val shopTypeBakerySweets = "ಬೇಕರಿ ಮತ್ತು ಸಿಹಿ"
    override val shopTypePharmacy = "ಔಷಧಿ ಅಂಗಡಿ"
    override val shopTypeCosmetics = "ಸೌಂದರ್ಯ ಸಾಮಗ್ರಿ"
    override val shopTypeStationery = "ಸ್ಟೇಷನರಿ"
    override val shopTypeXeroxPrinting = "ಜೆರಾಕ್ಸ್ ಮತ್ತು ಪ್ರಿಂಟಿಂಗ್"
    override val shopTypeWood = "ಮರದ ಅಂಗಡಿ"
    override val shopTypeGarments = "ಬಟ್ಟೆ ಅಂಗಡಿ"
    override val shopTypeOther = "ಇತರೆ"
    override val back = "ಹಿಂದೆ"
    override val cancel = "ರದ್ದುಮಾಡಿ"
    override val save = "ಉಳಿಸಿ"
    override val shopNameLabel = "ಅಂಗಡಿಯ ಹೆಸರು *"
    override val shopNamePlaceholder = "ಉದಾ. ಮರ ಮಹಲ್"
    override val phoneLabel = "ಫೋನ್ ಸಂಖ್ಯೆ (ಐಚ್ಛಿಕ)"
    override val shopTypeLabel = "ಅಂಗಡಿಯ ವಿಧ *"
    override val saveShopButton = "ಅಂಗಡಿಯನ್ನು ಉಳಿಸಿ"
    override val errorNameRequired = "ಅಂಗಡಿಯ ಹೆಸರನ್ನು ಬರೆಯಿರಿ"
    override val errorTypeRequired = "ಅಂಗಡಿಯ ವಿಧವನ್ನು ಆರಿಸಿ"
    override val dueLabel = "ಬಾಕಿ"
    override val noTransactionsYet = "ಇನ್ನೂ ವ್ಯವಹಾರಗಳಿಲ್ಲ"
    override val creditButton = "ಸಾಲ ತೆಗೆದುಕೊಂಡೆ"
    override val paymentButton = "ಹಣ ಪಾವತಿಸಿದೆ"
    override val pdfExport = "PDF ರಫ್ತು"
    override val archive = "ಆರ್ಕೈವ್"
    override val deleteShopAction = "ಅಂಗಡಿಯನ್ನು ಅಳಿಸಿ"
    override val archiveConfirmTitle = "ಈ ಅಂಗಡಿಯನ್ನು ಆರ್ಕೈವ್ ಮಾಡಬೇಕೇ?"
    override val archiveConfirmText = "ಇದು ಮುಖಪುಟದ ಪಟ್ಟಿಯಿಂದ ಹೋಗುತ್ತದೆ — ಇತಿಹಾಸದಲ್ಲಿ ಇನ್ನೂ ಇರುತ್ತದೆ."
    override val deleteConfirmTitle = "ಈ ಅಂಗಡಿಯನ್ನು ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಬೇಕೇ?"
    override val deleteConfirmText = "ಈ ಅಂಗಡಿ ಮತ್ತು ಅದರ ಎಲ್ಲಾ ವ್ಯವಹಾರಗಳು ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಲ್ಪಡುತ್ತವೆ, ಮರಳಿ ಬರುವುದಿಲ್ಲ. ಆರ್ಕೈವ್ ಮಾಡಿದರೆ ಇತಿಹಾಸದಲ್ಲಿ ಇರುತ್ತದೆ — ಮುಂದುವರಿಯುವ ಮೊದಲು ಚೆನ್ನಾಗಿ ಯೋಚಿಸಿ."
    override val yesDelete = "ಹೌದು, ಅಳಿಸಿ"
    override val yesArchive = "ಆರ್ಕೈವ್ ಮಾಡಿ"
    override val txnDeletedSnackbar = "ವ್ಯವಹಾರ ಅಳಿಸಲಾಗಿದೆ"
    override val undo = "ರದ್ದುಗೊಳಿಸಿ"
    override val pdfFailPrefix = "PDF ರಚಿಸಲಾಗಲಿಲ್ಲ: "
    override val shareKhata = "ಖಾತೆಯನ್ನು ಹಂಚಿಕೊಳ್ಳಿ"
    override val creditFallback = "ಸಾಲ"
    override val paymentFallback = "ಜಮಾ"
    override val deleteTxnAction = "ಅಳಿಸಿ"
    override val productNameLabel = "ವಸ್ತುವಿನ ಹೆಸರು (ಐಚ್ಛಿಕ)"
    override val quantityLabel = "ಪ್ರಮಾಣ"
    override val unitLabel = "ಘಟಕ"
    override val pricePerUnitLabel = "ಬೆಲೆ/ಘಟಕ"
    override val totalPrefix = "ಒಟ್ಟು: "
    override val amountLabel = "ಪಾವತಿಸಿದ ಮೊತ್ತ"
    override val orEnterAmountLabel = "ಅಥವಾ ನೇರವಾಗಿ ಮೊತ್ತ ಬರೆಯಿರಿ"
    override val noteLabel = "ಟಿಪ್ಪಣಿ (ಐಚ್ಛಿಕ)"
    override val cash = "ನಗದು"
    override val bkash = "bKash"
    override val bank = "ಬ್ಯಾಂಕ್"
    override val invalidAmountError = "ಸರಿಯಾದ ಮೊತ್ತವನ್ನು ಬರೆಯಿರಿ"
    override val cftCalculatorTitle = "CFT ಕ್ಯಾಲ್ಕುಲೇಟರ್"
    override val lengthLabel = "ಉದ್ದ (ಇಂಚು)"
    override val widthLabel = "ಅಗಲ"
    override val heightLabel = "ಎತ್ತರ"
    override val rateLabel = "ದರ /cft (₹)"
    override val applyToEntryButton = "ಎಂಟ್ರಿಗೆ ಸೇರಿಸಿ"
    override val settingsTitle = "ಸೆಟ್ಟಿಂಗ್‌ಗಳು"
    override val security = "ಭದ್ರತೆ"
    override val pinLockOn = "PIN ಲಾಕ್ ಆನ್ ಆಗಿದೆ"
    override val pinLockOff = "PIN ಲಾಕ್ ಆಫ್ ಆಗಿದೆ"
    override val changePin = "PIN ಬದಲಿಸಿ"
    override val reminderTitle = "ಬಾಕಿ ಜ್ಞಾಪನೆ"
    override val reminderDesc = "ಪ್ರತಿದಿನ ಬಾಕಿಯನ್ನು ನೆನಪಿಸುತ್ತದೆ"
    override val about = "ಬಗ್ಗೆ"
    override val aboutLine = "ಉಧಾರ್ ಹಿಸಾಬ್ — ಅಂಗಡಿಯ ಸಾಲದ ಖಾತೆ"
    override val aboutDescription = "ಉಧಾರ್ ಹಿಸಾಬ್ ಒಂದು ಸ್ಮಾರ್ಟ್ ಲೆಕ್ಕದ ಆ್ಯಪ್ ಆಗಿದ್ದು, ಅಂಗಡಿಯ ಸಾಲ, ಬಾಕಿ ಮತ್ತು ವ್ಯವಹಾರಗಳನ್ನು ಸುಲಭವಾಗಿ, ವೇಗವಾಗಿ, ವ್ಯವಸ್ಥಿತವಾಗಿ ನಿರ್ವಹಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ. ಯಾವ ಅಂಗಡಿಯಲ್ಲಿ ಎಷ್ಟು ಬಾಕಿ ಇದೆ, ಎಲ್ಲಿ ಹಣ ಪಾವತಿಸಲಾಗಿದೆ, ಯಾವ ವ್ಯವಹಾರ ಯಾವಾಗ ನಡೆಯಿತು — ಎಲ್ಲವನ್ನೂ ಒಂದೇ ಕಡೆ ಚೆನ್ನಾಗಿ ಉಳಿಸಿಕೊಳ್ಳಬಹುದು.\n\nಈ ಆ್ಯಪ್‌ನಲ್ಲಿ ನೀವು ಸುಲಭವಾಗಿ ಅಂಗಡಿಗಳನ್ನು ಸೇರಿಸಬಹುದು, ಸಾಲ ಮತ್ತು ಜಮಾ ದಾಖಲಿಸಬಹುದು, ವ್ಯವಹಾರಗಳ ಇತಿಹಾಸ ನೋಡಬಹುದು, ಒಟ್ಟು ಬಾಕಿ ಮತ್ತು ಜಮಾ ಪರಿಶೀಲಿಸಬಹುದು, ವಿವರವಾದ ವರದಿಗಳನ್ನು ರಚಿಸಬಹುದು. ಹುಡುಕಾಟ, ಫಿಲ್ಟರ್, ಬ್ಯಾಕಪ್ ಮತ್ತು ರಿಸ್ಟೋರ್, ಆ್ಯಪ್ ಲಾಕ್, ಬಯೋಮೆಟ್ರಿಕ್ ಭದ್ರತೆ, ಡಾರ್ಕ್ ಮೋಡ್, ಅಧಿಸೂಚನೆಗಳಂತಹ ಸೌಲಭ್ಯಗಳು ಲೆಕ್ಕ ನಿರ್ವಹಣೆಯನ್ನು ಇನ್ನಷ್ಟು ಸುಲಭ ಮತ್ತು ಸುರಕ್ಷಿತವಾಗಿಸುತ್ತವೆ.\n\nಕಾಗದದ ಪುಸ್ತಕದ ಗೊಂದಲವನ್ನು ಸರಳ, ಆಧುನಿಕ, ನಂಬಲರ್ಹ ಡಿಜಿಟಲ್ ವಿಧಾನಕ್ಕೆ ತರುವುದೇ ಉಧಾರ್ ಹಿಸಾಬ್‌ನ ಗುರಿ."
    override val aboutTagline = "ಉಧಾರ್ ಹಿಸಾಬ್ — ಸುಲಭ ಲೆಕ್ಕ, ನಿಶ್ಚಿಂತೆಯಿಂದಿರಿ."
    override val versionLine = "ಆವೃತ್ತಿ 1.0"
    override val setPinTitle = "PIN ಹೊಂದಿಸಿ"
    override val newPinLabel = "ಹೊಸ PIN"
    override val confirmPinLabel = "PIN ಅನ್ನು ಮತ್ತೆ ಬರೆಯಿರಿ"
    override val pinSetupError = "PIN ಹೊಂದಿಕೆಯಾಗುತ್ತಿಲ್ಲ (ಕನಿಷ್ಠ 4 ಅಂಕೆಗಳು)"
    override val removePinTitle = "PIN ಲಾಕ್ ಆಫ್ ಮಾಡಬೇಕೇ?"
    override val removePinText = "ಇನ್ನು ಮುಂದೆ ಆ್ಯಪ್ ತೆರೆಯುವಾಗ PIN ಕೇಳುವುದಿಲ್ಲ."
    override val yesTurnOff = "ಹೌದು, ಆಫ್ ಮಾಡಿ"
    override val no = "ಇಲ್ಲ"
    override val languageTitle = "ಭಾಷೆ"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "ಅಧಿಸೂಚನೆಗಳು"
    override val notifSheetSubtitle = "ನಿಮಗೆ ಯಾವ ಜ್ಞಾಪನೆಗಳು ಬೇಕು?"
    override val notifDueReminderOption = "ಬಾಕಿ ಪಾವತಿ ಜ್ಞಾಪನೆ"
    override val notifWeeklySummaryOption = "ವಾರದ ಸಾರಾಂಶ"
    override val notifAppNewsOption = "ಆ್ಯಪ್ ಸುದ್ದಿ ಮತ್ತು ಅಪ್‌ಡೇಟ್‌ಗಳು"
    override val langSheetSubtitle = "ಆ್ಯಪ್ ಅನ್ನು ಯಾವ ಭಾಷೆಯಲ್ಲಿ ಬಳಸಬೇಕು?"
    override val themeSheetSubtitle = "ನಿಮಗೆ ಯಾವ ಥೀಮ್ ಇಷ್ಟ?"
    override val securityPrivacyTitle = "ಭದ್ರತೆ ಮತ್ತು ಗೌಪ್ಯತೆ"
    override val pinSectionTitle = "PIN ಲಾಕ್"
    override val pinSectionDesc = "ಆ್ಯಪ್ ತೆರೆಯುವಾಗ PIN ಕೇಳಿ"
    override val fingerprintTitle = "ಫಿಂಗರ್‌ಪ್ರಿಂಟ್ ಲಾಕ್"
    override val fingerprintDesc = "PIN ಬದಲು ಫಿಂಗರ್‌ಪ್ರಿಂಟ್‌ನಿಂದ ತೆರೆಯಿರಿ"
    override val fingerprintUnavailable = "ಈ ಫೋನ್‌ನಲ್ಲಿ ಫಿಂಗರ್‌ಪ್ರಿಂಟ್ ಸೆನ್ಸರ್ ಇಲ್ಲ"
    override val lockImmediatelyTitle = "ತಕ್ಷಣ ಲಾಕ್ ಮಾಡಿ"
    override val lockImmediatelyDesc = "ಆ್ಯಪ್‌ಗೆ ಮರಳಿದ ತಕ್ಷಣ ಮತ್ತೆ ಲಾಕ್ ಆಗುತ್ತದೆ"
    override val rateTitle = "ರೇಟಿಂಗ್ ಮತ್ತು ಅಭಿಪ್ರಾಯ"
    override val rateSubtitle = "ಉಧಾರ್ ಹಿಸಾಬ್ ನಿಮಗೆ ಹೇಗೆ ಅನಿಸುತ್ತಿದೆ?"
    override val rateStarsPrompt = "ರೇಟಿಂಗ್ ನೀಡಲು ಒತ್ತಿ"
    override val rateThanksMessage = "ಧನ್ಯವಾದಗಳು! ನಿಮ್ಮನ್ನು Play Storeಗೆ ಕರೆದೊಯ್ಯುತ್ತಿದ್ದೇವೆ…"
    override val feedbackPromptLow = "ನಿಮಗೆ ಏನು ಇಷ್ಟವಾಗಲಿಲ್ಲ? ನಮಗೆ ತಿಳಿಸಿ"
    override val feedbackPlaceholder = "ನಿಮ್ಮ ಅಭಿಪ್ರಾಯ ಬರೆಯಿರಿ…"
    override val feedbackSubmit = "ಕಳುಹಿಸಿ"
    override val feedbackThanks = "ಧನ್ಯವಾದಗಳು, ನಿಮ್ಮ ಅಭಿಪ್ರಾಯ ಕಳುಹಿಸಲಾಗಿದೆ"
    override val aboutPageTitle = "ಉಧಾರ್ ಹಿಸಾಬ್ ಬಗ್ಗೆ"
    override val aboutVersionPrefix = "ಆವೃತ್ತಿ"
    override val aboutDeveloperLabel = "ಡೆವಲಪರ್"
    override val aboutDeveloperName = "ಉಧಾರ್ ಹಿಸಾಬ್ ತಂಡ"
    override val aboutPrivacyPolicy = "ಗೌಪ್ಯತಾ ನೀತಿ"
    override val privacyPolicyEffectiveDate = "ಜಾರಿ ದಿನಾಂಕ: 13 ಸೆಪ್ಟೆಂಬರ್ 2026"
    override val aboutShareApp = "ಹಂಚಿಕೊಳ್ಳಿ"
    override val aboutShareText = "ಉಧಾರ್ ಹಿಸಾಬ್ — ಅಂಗಡಿಯ ಸಾಲದ ಖಾತೆಯ ಈ ಆ್ಯಪ್ ಪ್ರಯತ್ನಿಸಿ!"
    override val noArchivedShops = "ಆರ್ಕೈವ್ ಮಾಡಿದ ಅಂಗಡಿಗಳಿಲ್ಲ"
    override val noSettledShops = "ತೀರಿದ ಅಂಗಡಿಗಳಿಲ್ಲ"
    override val setupPinTitle = "4 ಅಂಕೆಯ PIN ಹೊಂದಿಸಿ"
    override val unlockPinTitle = "PIN ಮೂಲಕ ತೆರೆಯಿರಿ"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 ಅಂಕೆಗಳನ್ನು ಬರೆಯಿರಿ"
    override val pinsDontMatchError = "PIN ಹೊಂದಿಕೆಯಾಗುತ್ತಿಲ್ಲ"
    override val wrongPinError = "PIN ತಪ್ಪು — ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ"
    override val savePinButton = "PIN ಉಳಿಸಿ"
    override val unlockButton = "ತೆರೆಯಿರಿ"
    override val pdfHeaderTitle = "ಖಾತೆ — ಉಧಾರ್ ಹಿಸಾಬ್"
    override val pdfFullKhataSuffix = "ಪೂರ್ಣ ಖಾತೆ"
    override val pdfShopLabel = "ಅಂಗಡಿ: "
    override val pdfPhoneLabel = "ಫೋನ್: "
    override val pdfCreatedLabel = "ರಚಿಸಿದ್ದು: "
    override val pdfColDate = "ದಿನಾಂಕ/ಸಮಯ"
    override val pdfColDesc = "ವಿವರ"
    override val pdfTotalCredit = "ಒಟ್ಟು ಸಾಲ:"
    override val pdfTotalPayment = "ಒಟ್ಟು ಜಮಾ:"
    override val pdfCurrentDue = "ಈಗಿನ ಬಾಕಿ:"
    override val pdfFooter = "ಉಧಾರ್ ಹಿಸಾಬ್ ಆ್ಯಪ್‌ನಿಂದ ರಚಿಸಲಾಗಿದೆ"
    override val navHome = "ಮುಖಪುಟ"
    override val navHistory = "ಇತಿಹಾಸ"
    override val navReports = "ವರದಿ"
    override val navMore = "ಇನ್ನಷ್ಟು"
    override val historyFilterAllShops = "ಎಲ್ಲಾ ಅಂಗಡಿಗಳು"
    override val historyFilterAllTypes = "ಎಲ್ಲಾ"
    override val historyFilterCreditOnly = "ಸಾಲ ಮಾತ್ರ"
    override val historyFilterPaymentOnly = "ಜಮಾ ಮಾತ್ರ"
    override val historyNoTxnsFound = "ಯಾವುದೇ ವ್ಯವಹಾರ ಸಿಗಲಿಲ್ಲ"
    override val viewArchivedAction = "ಆರ್ಕೈವ್ ಮಾಡಿದ ಅಂಗಡಿಗಳನ್ನು ನೋಡಿ"
    override val reportsTitle = "ವರದಿ"
    override val periodLabel = "ಅವಧಿ"
    override val period7d = "ಕಳೆದ 7 ದಿನಗಳು"
    override val period15d = "ಕಳೆದ 15 ದಿನಗಳು"
    override val period30d = "ಕಳೆದ 30 ದಿನಗಳು"
    override val period3m = "ಕಳೆದ 3 ತಿಂಗಳು"
    override val period1y = "ಈ ವರ್ಷ"
    override val reportTotalCredit = "ಒಟ್ಟು ಸಾಲ"
    override val reportTotalPayment = "ಒಟ್ಟು ಜಮಾ"
    override val reportCurrentDue = "ಈಗಿನ ಒಟ್ಟು ಬಾಕಿ"
    override val reportTxnCount = "ವ್ಯವಹಾರಗಳು"
    override val reportChartTitle = "ಸಾಲ vs ಜಮಾ"
    override val reportShopWiseTitle = "ಅಂಗಡಿವಾರು ಬಾಕಿ"
    override val reportAgingTitle = "ಬಾಕಿಯ ವಯಸ್ಸು"
    override val reportAging0to7 = "0–7 ದಿನಗಳು"
    override val reportAging7to15 = "7–15 ದಿನಗಳು"
    override val reportAging15to30 = "15–30 ದಿನಗಳು"
    override val reportAging30plus = "30+ ದಿನಗಳು"
    override val reportRecentPaymentsTitle = "ಇತ್ತೀಚಿನ ಜಮಾಗಳು"
    override val reportNoData = "ಈ ಅವಧಿಗೆ ಮಾಹಿತಿ ಇಲ್ಲ"
    override val reportSmartSummaryPrefix = "ಈ ಅವಧಿಯಲ್ಲಿ ನೀವು"
    override val moreTitle = "ಇನ್ನಷ್ಟು"
    override val moreBackupRestore = "ಬ್ಯಾಕಪ್ ಮತ್ತು ರಿಸ್ಟೋರ್"
    override val moreHintBackupRestore = "ನಿಮ್ಮ ಡೇಟಾವನ್ನು ಸುರಕ್ಷಿತವಾಗಿಡಿ"
    override val notesTitle = "ಟಿಪ್ಪಣಿಗಳು"
    override val notesSearchPlaceholder = "ಟಿಪ್ಪಣಿಗಳನ್ನು ಹುಡುಕಿ..."
    override val addNoteButton = "ಹೊಸ ಟಿಪ್ಪಣಿ"
    override val noNotesYetTitle = "ಇನ್ನೂ ಟಿಪ್ಪಣಿಗಳಿಲ್ಲ"
    override val noNotesYetSubtitle = "ಖರೀದಿ ಪಟ್ಟಿ, ನೆನಪುಗಳು — ಏನಾದರೂ ಬರೆದಿಡಿ"
    override val deleteNoteConfirmTitle = "ಈ ಟಿಪ್ಪಣಿಯನ್ನು ಅಳಿಸಬೇಕೇ?"
    override val deleteNoteConfirmMessage = "ಈ ಟಿಪ್ಪಣಿ ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಲ್ಪಡುತ್ತದೆ."
    override val noteTitlePlaceholder = "ಶೀರ್ಷಿಕೆ"
    override val noteContentPlaceholder = "ಏನಾದರೂ ಬರೆಯಿರಿ..."
    override val untitledNote = "ಶೀರ್ಷಿಕೆ ಇಲ್ಲದ ಟಿಪ್ಪಣಿ"
    override val notificationInboxTitle = "ಅಧಿಸೂಚನೆಗಳು"
    override val moreNotificationHistory = "ಅಧಿಸೂಚನೆ ಇತಿಹಾಸ"
    override val moreHintNotificationHistory = "ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆ ನೋಡಿ"
    override val noNotificationsYetTitle = "ಇನ್ನೂ ಅಧಿಸೂಚನೆಗಳಿಲ್ಲ"
    override val noNotificationsYetSubtitle = "ಸಾಲ ಅಥವಾ ಜಮಾ ದಾಖಲಿಸಿದರೆ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ"
    override val notifCreditMessage = "%1\$s ಅವರಿಂದ %2\$s ಸಾಲ ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ"
    override val notifPaymentMessage = "%1\$s ಅವರಿಗೆ %2\$s ಜಮಾ ಮಾಡಲಾಗಿದೆ"
    override val moreQuickCalculator = "ಕ್ವಿಕ್ ಕ್ಯಾಲ್ಕುಲೇಟರ್"
    override val moreHintQuickCalculator = "ತ್ವರಿತವಾಗಿ ಲೆಕ್ಕ ಮಾಡಿ"
    override val calcGeneralTab = "ಸಾಮಾನ್ಯ"
    override val calcPercentTab = "ಶೇಕಡಾ"
    override val calcConversionTab = "ಪರಿವರ್ತನೆ"
    override val calcComingSoonInTab = "ಶೀಘ್ರದಲ್ಲಿ ಬರಲಿದೆ"
    override val percentOfTitle = "ಒಂದು ಸಂಖ್ಯೆಯ ಶೇಕಡಾ"
    override val percentOfValueLabel = "ಸಂಖ್ಯೆ"
    override val percentOfPercentLabel = "ಶೇಕಡಾ (%)"
    override val percentIsWhatTitle = "ಒಂದು ಸಂಖ್ಯೆ ಇನ್ನೊಂದರ ಎಷ್ಟು ಶೇಕಡಾ"
    override val percentIsWhatXLabel = "ಈ ಸಂಖ್ಯೆ"
    override val percentIsWhatYLabel = "ಇದರಲ್ಲಿ"
    override val percentChangeTitle = "ಶೇಕಡಾ ಹೆಚ್ಚಳ/ಇಳಿಕೆ"
    override val percentChangeBaseLabel = "ಮೂಲ ಸಂಖ್ಯೆ"
    override val percentChangePercentLabel = "ಶೇಕಡಾ (%)"
    override val increaseOption = "ಹೆಚ್ಚಳ"
    override val decreaseOption = "ಇಳಿಕೆ"
    override val resultLabel = "ಫಲಿತಾಂಶ"
    override val weightCategory = "ತೂಕ"
    override val lengthCategory = "ಉದ್ದ"
    override val volumeCategory = "ಗಾತ್ರ"
    override val fromLabel = "ಇಂದ"
    override val toLabel = "ವರೆಗೆ"
    override val enterValueHint = "ಮೌಲ್ಯ ಬರೆಯಿರಿ"
    override val backupNowButton = "ಈಗಲೇ ಬ್ಯಾಕಪ್ ತೆಗೆದುಕೊಳ್ಳಿ"
    override val backupNowHint = "ಎಲ್ಲಾ ಅಂಗಡಿಗಳು ಮತ್ತು ವ್ಯವಹಾರಗಳನ್ನು JSON ಫೈಲ್‌ನಲ್ಲಿ ಉಳಿಸಿ"
    override val restoreButton = "ಬ್ಯಾಕಪ್‌ನಿಂದ ರಿಸ್ಟೋರ್ ಮಾಡಿ"
    override val restoreShopAction = "ರಿಸ್ಟೋರ್"
    override val restoreHint = "ಹಳೆಯ JSON ಬ್ಯಾಕಪ್ ಫೈಲ್‌ನಿಂದ ಡೇಟಾ ಮರಳಿ ತನ್ನಿ"
    override val lastBackupLabel = "ಕೊನೆಯ ಬ್ಯಾಕಪ್"
    override val noBackupYetLabel = "ಇನ್ನೂ ಬ್ಯಾಕಪ್ ತೆಗೆದಿಲ್ಲ"
    override val backupSuccessMessage = "ಬ್ಯಾಕಪ್ ರಚಿಸಲಾಗಿದೆ"
    override val backupFailPrefix = "ಬ್ಯಾಕಪ್ ವಿಫಲ: "
    override val restoreConfirmTitle = "ಬ್ಯಾಕಪ್ ರಿಸ್ಟೋರ್ ಮಾಡಬೇಕೇ?"
    override val restoreConfirmMessage = "ಇದು ಈಗಿನ ಎಲ್ಲಾ ಅಂಗಡಿಗಳು ಮತ್ತು ವ್ಯವಹಾರಗಳನ್ನು ಅಳಿಸಿ ಬ್ಯಾಕಪ್ ಫೈಲ್‌ನ ಡೇಟಾದಿಂದ ಬದಲಾಯಿಸುತ್ತದೆ. ಇದನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗದು."
    override val restoreSuccessMessage = "ರಿಸ್ಟೋರ್ ಪೂರ್ಣಗೊಂಡಿದೆ"
    override val restoreFailPrefix = "ರಿಸ್ಟೋರ್ ವಿಫಲ: "
    override val dataSafeNote = "ನಿಮ್ಮ ಡೇಟಾ ಈ ಫೋನ್‌ನಲ್ಲಿ ಮಾತ್ರ ಇರುತ್ತದೆ — ಬ್ಯಾಕಪ್ ಫೈಲ್ ಅನ್ನು ನೀವೇ ಸುರಕ್ಷಿತವಾಗಿಡಿ"
    override val moreExportShare = "ರಫ್ತು ಮತ್ತು ಹಂಚಿಕೆ"
    override val moreHintExportShare = "PDF ಮತ್ತು ಫೈಲ್‌ಗಳನ್ನು ಕಳುಹಿಸಿ"
    override val moreNotifications = "ಅಧಿಸೂಚನೆಗಳು"
    override val moreHintNotifications = "ಜ್ಞಾಪನೆಗಳನ್ನು ಆನ್/ಆಫ್ ಮಾಡಿ"
    override val moreLanguage = "ಭಾಷೆ"
    override val moreHintLanguage = "ನಿಮ್ಮ ಭಾಷೆಯನ್ನು ಆರಿಸಿ"
    override val moreUserMode = "ನಾನು ಯಾರು"
    override val moreHintUserMode = "ಗ್ರಾಹಕ ಅಥವಾ ಅಂಗಡಿಯವರು"
    override val moreSecurityPrivacy = "ಭದ್ರತೆ ಮತ್ತು ಗೌಪ್ಯತೆ"
    override val moreHintSecurityPrivacy = "PIN ಮತ್ತು ಫಿಂಗರ್‌ಪ್ರಿಂಟ್ ಲಾಕ್"
    override val moreAppearance = "ಸ್ವರೂಪ"
    override val moreHintAppearance = "ಲೈಟ್, ಡಾರ್ಕ್ ಅಥವಾ ಸಿಸ್ಟಂ"
    override val moreRateFeedback = "ರೇಟಿಂಗ್ ಮತ್ತು ಅಭಿಪ್ರಾಯ"
    override val moreHintRateFeedback = "ನಿಮ್ಮ ಅಭಿಪ್ರಾಯ ತಿಳಿಸಿ"
    override val moreAbout = "ಉಧಾರ್ ಹಿಸಾಬ್ ಬಗ್ಗೆ"
    override val moreHintAbout = "ಆವೃತ್ತಿ ಮತ್ತು ಡೆವಲಪರ್"
    override val comingSoonMessage = "ಶೀಘ್ರದಲ್ಲಿ ಬರಲಿದೆ"
    override val appearanceTitle = "ಸ್ವರೂಪ"
    override val themeLight = "ಲೈಟ್"
    override val themeDark = "ಡಾರ್ಕ್"
    override val themeSystem = "ಸಿಸ್ಟಂ ಡೀಫಾಲ್ಟ್"
    override val creditPageTitle = "ಸಾಲ ತೆಗೆದುಕೊಳ್ಳಿ"
    override val accountingTypeLabel = "ಎಂಟ್ರಿ ವಿಧ"
    override val directMoneyMode = "ನೇರ ಮೊತ್ತ"
    override val productMode = "ವಸ್ತುವಿನ ಪ್ರಕಾರ"
    override val directMoneyAmountLabel = "ಎಷ್ಟು ಸಾಲ ನೀಡಿದಿರಿ?"
    override val previousDueLabel = "ಹಿಂದಿನ ಬಾಕಿ"
    override val newCreditLabel = "ಹೊಸ ಸಾಲ"
    override val newTotalDueLabel = "ಹೊಸ ಒಟ್ಟು ಬಾಕಿ"
    override val addCreditButton = "ಸಾಲ ಸೇರಿಸಿ"
    override val addMoreProductButton = "+ ಇನ್ನೊಂದು ವಸ್ತು ಸೇರಿಸಿ"
    override val totalNewCreditLabel = "ಒಟ್ಟು ಹೊಸ ಸಾಲ"
    override val editAction = "ಬದಲಿಸಿ"
    override val itemsCountSuffix = "ವಸ್ತುಗಳು"
    override val paymentPageTitle = "ಜಮಾ"
    override val currentDueLabel = "ಈಗಿನ ಬಾಕಿ"
    override val howMuchPaymentLabel = "ಎಷ್ಟು ಜಮಾ ಮಾಡುತ್ತಿದ್ದೀರಿ?"
    override val fullPaymentButton = "ಪೂರ್ಣ ಮೊತ್ತ"
    override val dueAfterPaymentLabel = "ಜಮಾ ನಂತರ ಬಾಕಿ"
    override val addPaymentButton = "ಜಮಾ ಸೇರಿಸಿ"
    override val overpaymentBlockedMessage = "ಈಗಿನ ಬಾಕಿಗಿಂತ ಹೆಚ್ಚು ಜಮಾ ಮಾಡಲಾಗದು"
    override val fullyPaidCelebration = "ಇದರಿಂದ ಪೂರ್ಣ ಬಾಕಿ ತೀರುತ್ತದೆ"
    override val woodCalculatorTitle = "ಮರದ ಕ್ಯಾಲ್ಕುಲೇಟರ್"
    override val woodTypeLabel = "ಮರದ ವಿಧ"
    override val sawnWoodOption = "ಕೊಯ್ದ ಮರ"
    override val roundWoodOption = "ದುಂಡು ದಿಮ್ಮಿ"
    override val lengthFtLabel = "ಉದ್ದ (ಅಡಿ)"
    override val widthInLabel = "ಅಗಲ (ಇಂಚು)"
    override val thicknessInLabel = "ದಪ್ಪ (ಇಂಚು)"
    override val girthInLabel = "ಸುತ್ತಳತೆ (ಇಂಚು)"
    override val pieceCountLabel = "ತುಂಡುಗಳ ಸಂಖ್ಯೆ"
    override val perPieceCftLabel = "ಪ್ರತಿ ತುಂಡಿಗೆ"
    override val totalWoodCftLabel = "ಒಟ್ಟು ಮರ"
    override val perCftPriceLabel = "ಪ್ರತಿ CFT ಬೆಲೆ (₹)"
    override val totalWoodValueLabel = "ಒಟ್ಟು ಮೌಲ್ಯ"
    override val addWoodCalcButton = "ಈ ಮರದ ಲೆಕ್ಕ ಸೇರಿಸಿ"
    override val woodNameLabel = "ವಸ್ತುವಿನ ಹೆಸರು"
    override val addMoreWoodProductButton = "+ ಇನ್ನೊಂದು ಮರ/ವಸ್ತು ಸೇರಿಸಿ"
    override val addedItemsHeader = "ಸೇರಿಸಿದ ವಸ್ತುಗಳು/ಮರ"
    override val pdfOptionsTitle = "PDF ಆಯ್ಕೆಗಳು"
    override val pdfPeriodLabel = "ಅವಧಿ"
    override val pdfThisMonth = "ಈ ತಿಂಗಳು"
    override val pdfLastMonth = "ಕಳೆದ ತಿಂಗಳು"
    override val pdfLast3Months = "ಕಳೆದ 3 ತಿಂಗಳು"
    override val pdfCustomRange = "ನಿಮ್ಮ ದಿನಾಂಕಗಳು"
    override val pdfShopLabelOption = "ಅಂಗಡಿ"
    override val pdfAllShopsOption = "ಎಲ್ಲಾ ಅಂಗಡಿಗಳು"
    override val pdfContentLabel = "ಏನು ತೋರಿಸಬೇಕು"
    override val pdfContentFull = "ಎಲ್ಲವೂ (ವ್ಯವಹಾರ + ಸಾರಾಂಶ + ಸಹಿ)"
    override val pdfContentSummaryOnly = "ಸಾರಾಂಶ ಮಾತ್ರ"
    override val pdfContentTxnsOnly = "ವ್ಯವಹಾರಗಳು ಮಾತ್ರ"
    override val pdfFormatLabel = "ಸ್ವರೂಪ"
    override val pdfFormatA4 = "A4 ವರದಿ"
    override val pdfFormatReceipt = "ರಸೀದಿ (58mm)"
    override val pdfGenerateButton = "PDF ರಚಿಸಿ"
    override val pdfFromDateLabel = "ಆರಂಭ ದಿನಾಂಕ"
    override val pdfToDateLabel = "ಅಂತಿಮ ದಿನಾಂಕ"
    override val pdfReportNumberLabel = "ವರದಿ ಸಂ."
    override val pdfShopBoxLabel = "ಅಂಗಡಿ"
    override val pdfDateBoxLabel = "ದಿನಾಂಕ"
    override val pdfDaysOfRecordsSuffix = "ದಿನಗಳ ದಾಖಲೆ"
    override val pdfWeeklyChartTitle = "ವಾರದ ಸಾಲ (ಕೆಂಪು) vs ಜಮಾ (ಹಸಿರು)"
    override val pdfFinalDueLabel = "ಈಗಿನ ಬಾಕಿ"
    override val pdfShopSignatureLabel = "ಅಂಗಡಿಯವರ ಸಹಿ"
    override val pdfCustomerSignatureLabel = "ಗ್ರಾಹಕರ ಸಹಿ"
    override val pdfAllShopsReportTitle = "ಎಲ್ಲಾ ಅಂಗಡಿಗಳ ಸಾರಾಂಶ — ಉಧಾರ್ ಹಿಸಾಬ್"
    override val pdfPageLabel = "ಪುಟ"
    override val moreShopProfile = "ಅಂಗಡಿ ಪ್ರೊಫೈಲ್"
    override val moreHintShopProfile = "ಹೆಸರು, ಲೋಗೋ, ವಿಳಾಸ, ಜ್ಞಾಪನೆ"
    override val shopProfileTitle = "ಅಂಗಡಿ ಪ್ರೊಫೈಲ್"
    override val shopProfileIntro = "ಈ ಮಾಹಿತಿ PDF ಇನ್‌ವಾಯ್ಸ್‌ಗಳಲ್ಲಿ ಮತ್ತು ಗ್ರಾಹಕರಿಗೆ ಕಳುಹಿಸುವ ಸಂದೇಶಗಳಲ್ಲಿ ಬಳಕೆಯಾಗುತ್ತದೆ"
    override val shopBusinessNameLabel = "ಅಂಗಡಿಯ ಹೆಸರು"
    override val shopBusinessAddressLabel = "ಅಂಗಡಿಯ ವಿಳಾಸ"
    override val shopBusinessPhoneLabel = "ಅಂಗಡಿಯ ಫೋನ್ ಸಂಖ್ಯೆ"
    override val countryCodeLabel = "ದೇಶ ಕೋಡ್ (ಉದಾ. 91)"
    override val shopLogoLabel = "ಅಂಗಡಿಯ ಲೋಗೋ"
    override val shopLogoPick = "ಲೋಗೋ ಆರಿಸಿ"
    override val shopLogoRemove = "ಲೋಗೋ ತೆಗೆಯಿರಿ"
    override val promptAfterEntryLabel = "ಎಂಟ್ರಿ ನಂತರ ಗ್ರಾಹಕರಿಗೆ ತಿಳಿಸುವ ಆಯ್ಕೆ ತೋರಿಸಿ"
    override val saveProfileButton = "ಪ್ರೊಫೈಲ್ ಉಳಿಸಿ"
    override val profileSavedMessage = "ಪ್ರೊಫೈಲ್ ಉಳಿಸಲಾಗಿದೆ"
    override val errorShopNameForPdf = "PDFನಲ್ಲಿ ಬಳಸಲು ಅಂಗಡಿಯ ಹೆಸರು ನೀಡಿ"
    override val reminderSendAction = "ಜ್ಞಾಪನೆ ಕಳುಹಿಸಿ"
    override val reminderDialogTitle = "ಗ್ರಾಹಕರಿಗೆ ತಿಳಿಸಿ"
    override val reminderDialogSubtitle = "ಸಂದೇಶ ಬದಲಿಸಿ WhatsApp ಅಥವಾ SMS ಮೂಲಕ ಕಳುಹಿಸಿ"
    override val reminderMessageLabel = "ಸಂದೇಶ"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "ಈಗ ಬೇಡ"
    override val reminderNoPhone = "ಈ ಗ್ರಾಹಕರಿಗೆ ಫೋನ್ ಸಂಖ್ಯೆ ಇಲ್ಲ"
    override val reminderAppMissing = "ಆ್ಯಪ್ ತೆರೆಯಲಾಗಲಿಲ್ಲ"
    override val reminderShopFallback = "ನಮ್ಮ ಅಂಗಡಿ"
    override val reminderMsgDue = "ನಮಸ್ಕಾರ %1\$s, %2\$s ಖಾತೆಯಲ್ಲಿ ನಿಮ್ಮ ಒಟ್ಟು ಬಾಕಿ %3\$s. ದಯವಿಟ್ಟು ಸಮಯಕ್ಕೆ ಪಾವತಿಸಿ. ಧನ್ಯವಾದಗಳು."
    override val reminderMsgCredit = "ನಮಸ್ಕಾರ %1\$s, %2\$s ಖಾತೆಯಲ್ಲಿ ನಿಮ್ಮ ಹೊಸ ಸಾಲ ಸೇರಿಸಲಾಗಿದೆ. ಒಟ್ಟು ಬಾಕಿ: %3\$s."
    override val reminderMsgPayment = "ನಮಸ್ಕಾರ %1\$s, ನಿಮ್ಮ ಹಣ ತಲುಪಿದೆ. ಧನ್ಯವಾದಗಳು! %2\$s ಖಾತೆಯಲ್ಲಿ ಈಗಿನ ಬಾಕಿ: %3\$s."
    override val reminderMsgSettled = "ನಮಸ್ಕಾರ %1\$s, ನಿಮ್ಮ ಎಲ್ಲಾ ಬಾಕಿ ತೀರಿದೆ. ಧನ್ಯವಾದಗಳು! — %2\$s"
    override val pdfActionLabel = "📤 ಏನು ಮಾಡಬೇಕು"
    override val pdfActionShare = "ಹಂಚಿಕೊಳ್ಳಿ"
    override val pdfActionSave = "ಉಳಿಸಿ"
    override val pdfActionPrint = "ಪ್ರಿಂಟ್"
    override val pdfBrandingOption = "ನನ್ನ ಅಂಗಡಿಯ ಹೆಸರು, ಲೋಗೋ, ವಿಳಾಸ ಸೇರಿಸಿ"
    override val pdfBrandingMissing = "ಅಂಗಡಿಯ ಹೆಸರು ನೀಡಿಲ್ಲ — ಇನ್ನಷ್ಟು → ಅಂಗಡಿ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿ ಸೇರಿಸಿ"
    override val pdfSavedMessage = "PDF ಉಳಿಸಲಾಗಿದೆ"
    override val pdfSaveFailed = "PDF ಉಳಿಸಲಾಗಲಿಲ್ಲ"
    override val setupRoleTitle = "ನೀವು ಆ್ಯಪ್ ಅನ್ನು ಹೇಗೆ ಬಳಸುತ್ತೀರಿ?"
    override val setupProfileTitle = "ನಿಮ್ಮ ಅಂಗಡಿಯ ವಿವರಗಳು"
    override val setupProfileSubtitle = "ನಂತರ ಇನ್ನಷ್ಟು → ಅಂಗಡಿ ಪ್ರೊಫೈಲ್‌ನಲ್ಲಿ ಬದಲಿಸಬಹುದು"
    override val setupContinue = "ಮುಂದುವರಿಸಿ"
    override val setupSkip = "ಈಗ ಬೇಡ, ನಂತರ ಮಾಡುತ್ತೇನೆ"
    override val setupFinish = "ಪ್ರಾರಂಭಿಸಿ"
    override val pickFromContacts = "ಸಂಪರ್ಕಗಳಿಂದ ಸಂಖ್ಯೆ ಆರಿಸಿ"
    override val pdfColQtyPrice = "ಪ್ರಮಾಣ × ಬೆಲೆ"
    override val pdfColItemTotal = "ವಸ್ತುವಿನ ಮೊತ್ತ"
    override val pdfWoodSawn = "ಕೊಯ್ದ ಮರ"
    override val pdfWoodRound = "ದುಂಡು ದಿಮ್ಮಿ"
    override val pdfWoodFormula = "ಸೂತ್ರ"
    override val pdfWoodTotalWord = "ಒಟ್ಟು"
    override val pdfMemoTitle = "ಕ್ಯಾಶ್ ಮೆಮೊ"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "ಬಿಲ್ ಸಂ. / Bill No"
    override val pdfDateTitle = "ದಿನಾಂಕ / Date"
    override val pdfPeriodTitle = "ಅವಧಿ / Period"
    override val pdfSeller = "ಮಾರಾಟಗಾರ / Seller"
    override val pdfBuyer = "ಖರೀದಿದಾರ / Buyer"
    override val pdfAddressLabel = "ವಿಳಾಸ: "
    override val pdfColSl = "ಕ್ರ.ಸಂ."
    override val pdfColPieces = "ಸಂಖ್ಯೆ"
    override val pdfColCft = "CFT"
    override val pdfColRate = "ದರ (₹/CFT)"
    override val pdfColAmountRs = "ಒಟ್ಟು (₹)"
    override val pdfColQty = "ಪ್ರಮಾಣ"
    override val pdfColUnitPrice = "ದರ (₹)"
    override val pdfSecSawn = "ಕೊಯ್ದ ಮರ / Sawn Timber"
    override val pdfSecRound = "ದುಂಡು ದಿಮ್ಮಿ / Round Log"
    override val pdfSecOther = "ಇತರ ವಸ್ತುಗಳು / Other Items"
    override val pdfSecCashCredit = "ನಗದು ಸಾಲ / Cash Credit"
    override val pdfSecPayments = "ಜಮಾ / Payments"
    override val pdfBadgeSawn = "ಕೊಯ್ದದ್ದು"
    override val pdfBadgeRound = "ದುಂಡು"
    override val pdfSawnTotal = "ಕೊಯ್ದ ಮರದ ಒಟ್ಟು:"
    override val pdfRoundTotal = "ದುಂಡು ದಿಮ್ಮಿಯ ಒಟ್ಟು:"
    override val pdfTableTotal = "ಒಟ್ಟು:"
    override val pdfSumBill = "ಒಟ್ಟು ಬಿಲ್"
    override val pdfSumPaid = "ಜಮಾ"
    override val pdfSumDue = "ಬಾಕಿ"
    override val pdfWordsTitle = "ಮೊತ್ತ ಅಕ್ಷರಗಳಲ್ಲಿ / Amount in Words:"
    override val pdfSellerSign = "ಮಾರಾಟಗಾರರ ಸಹಿ ಮತ್ತು ಮುದ್ರೆ"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "ಖರೀದಿದಾರರ ಸಹಿ"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "ಇದು ಕಂಪ್ಯೂಟರ್ ರಚಿತ ಬಿಲ್. ಸಹಿ ಇಲ್ಲದೆ ಮಾನ್ಯವಲ್ಲ."
    override val pdfSummaryTitle = "ಸಾರಾಂಶ ವರದಿ"
    override val moveShopAction = "ಬೇರೆ ಪಟ್ಟಿಗೆ ಸರಿಸಿ"
    override val moveShopTitle = "ಬೇರೆ ಪಟ್ಟಿಗೆ ಸರಿಸಬೇಕೇ?"
    override val moveToShopkeeperMsg = "ಈ ಎಂಟ್ರಿ \"ನಾನು ಅಂಗಡಿಯವನು\" ಪಟ್ಟಿಗೆ (ನಿಮ್ಮ ಗ್ರಾಹಕರಾಗಿ) ಹೋಗುತ್ತದೆ. ಮೊತ್ತಗಳು ಅದೇ ಇರುತ್ತವೆ, ಪದಗಳು ಮಾತ್ರ ಬದಲಾಗುತ್ತವೆ."
    override val moveToCustomerMsg = "ಈ ಎಂಟ್ರಿ \"ನಾನು ಗ್ರಾಹಕ\" ಪಟ್ಟಿಗೆ (ನೀವು ಸಾಲ ತೆಗೆದುಕೊಳ್ಳುವ ಅಂಗಡಿ) ಹೋಗುತ್ತದೆ. ಮೊತ್ತಗಳು ಅದೇ ಇರುತ್ತವೆ, ಪದಗಳು ಮಾತ್ರ ಬದಲಾಗುತ್ತವೆ."
    override val moveShopConfirm = "ಸರಿಸಿ"
    override val faqItems = listOf(
        FaqItem("ಹೊಸ ಅಂಗಡಿಯನ್ನು ಹೇಗೆ ಸೇರಿಸುವುದು?", "ಮುಖಪುಟದ '+' ಬಟನ್ ಒತ್ತಿ, ಅಂಗಡಿಯ ಹೆಸರು, ಫೋನ್ (ಐಚ್ಛಿಕ), ವಿಧ ಬರೆದು 'ಉಳಿಸಿ' ಒತ್ತಿ."),
        FaqItem("ಸಾಲ ಅಥವಾ ಜಮಾ ಹೇಗೆ ದಾಖಲಿಸುವುದು?", "ಅಂಗಡಿಯ ಪುಟ ತೆರೆದು 'ಸಾಲ ತೆಗೆದುಕೊಂಡೆ' ಅಥವಾ 'ಹಣ ಪಾವತಿಸಿದೆ' ಒತ್ತಿ, ಮೊತ್ತ ಬರೆದು ದೃಢೀಕರಿಸಿ."),
        FaqItem("ಬಯೋಮೆಟ್ರಿಕ್ ಲಾಕ್ ಹೇಗೆ ಆನ್/ಆಫ್ ಮಾಡುವುದು?", "ಇನ್ನಷ್ಟು → ಭದ್ರತೆ ಮತ್ತು ಗೌಪ್ಯತೆಯಲ್ಲಿ 'ಬಯೋಮೆಟ್ರಿಕ್ ಲಾಕ್' ಆನ್/ಆಫ್ ಮಾಡಿ. ನಿಮ್ಮ ಫೋನ್‌ನಲ್ಲಿ ಫಿಂಗರ್‌ಪ್ರಿಂಟ್ ಅಥವಾ ಫೇಸ್ ಅನ್‌ಲಾಕ್ ಹೊಂದಿಸಿರಬೇಕು."),
        FaqItem("ಡೇಟಾ ಬ್ಯಾಕಪ್ ಹೇಗೆ ತೆಗೆದುಕೊಳ್ಳುವುದು?", "ಇನ್ನಷ್ಟು → ಬ್ಯಾಕಪ್ ಮತ್ತು ರಿಸ್ಟೋರ್‌ನಲ್ಲಿ 'ಈಗಲೇ ಬ್ಯಾಕಪ್ ತೆಗೆದುಕೊಳ್ಳಿ' ಒತ್ತಿ. ಇದು ಒಂದು JSON ಫೈಲ್ ರಚಿಸುತ್ತದೆ; ಅದನ್ನು ಫೋನ್ ಅಥವಾ ಕ್ಲೌಡ್‌ನಲ್ಲಿ ಉಳಿಸಬಹುದು."),
        FaqItem("ಬ್ಯಾಕಪ್‌ನಿಂದ ಮರುಸ್ಥಾಪಿಸುವುದು ಹೇಗೆ?", "ಇನ್ನಷ್ಟು → ಬ್ಯಾಕಪ್ ಮತ್ತು ರಿಸ್ಟೋರ್‌ನಲ್ಲಿ 'ಬ್ಯಾಕಪ್‌ನಿಂದ ರಿಸ್ಟೋರ್ ಮಾಡಿ' ಒತ್ತಿ ನಿಮ್ಮ JSON ಫೈಲ್ ಆರಿಸಿ. ಇದು ಈಗಿನ ಎಲ್ಲಾ ಡೇಟಾವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಎಚ್ಚರಿಕೆ."),
        FaqItem("ಅಂಗಡಿಯನ್ನು ಅಳಿಸಿದರೆ ಮರಳಿ ಪಡೆಯಬಹುದೇ?", "ಆರ್ಕೈವ್ ಮಾಡಿದರೆ ಅದು ಇತಿಹಾಸದಲ್ಲಿ ಇರುತ್ತದೆ, ನಂತರ ಮರಳಿ ತರಬಹುದು. ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಿದರೆ ಮರಳಿ ಬರುವುದಿಲ್ಲ."),
        FaqItem("PDF ವರದಿಯನ್ನು ಹೇಗೆ ರಚಿಸುವುದು?", "'ಇನ್ನಷ್ಟು' ಪುಟದಲ್ಲಿ ಬ್ಯಾಕಪ್ ಮತ್ತು ರಿಸ್ಟೋರ್ ಪಕ್ಕದಲ್ಲಿ ರಫ್ತು ಆಯ್ಕೆ ಇದೆ; ಅಂಗಡಿ ಮತ್ತು ದಿನಾಂಕದ ಶ್ರೇಣಿ ಆರಿಸಿ PDF ಹಂಚಿಕೊಳ್ಳಿ."),
        FaqItem("ಆ್ಯಪ್‌ನ ಭಾಷೆಯನ್ನು ಹೇಗೆ ಬದಲಿಸುವುದು?", "ಇನ್ನಷ್ಟು → ಭಾಷೆಯಲ್ಲಿ ನಿಮ್ಮ ಭಾಷೆ ಆರಿಸಿ 'ಉಳಿಸಿ' ಒತ್ತಿ.")
    )
    override val privacyPolicyBody = """ಉಧಾರ್ ಹಿಸಾಬ್ ಒಂದು ವೈಯಕ್ತಿಕ ಆರ್ಥಿಕ/ಖಾತೆ ಪುಸ್ತಕ ಆ್ಯಪ್ ಆಗಿದ್ದು, ಅಂಗಡಿಯ ಸಾಲ, ಬಾಕಿ ಮತ್ತು ವ್ಯವಹಾರಗಳನ್ನು ಸುಲಭವಾಗಿ ನಿರ್ವಹಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ. ನಿಮ್ಮ ಗೌಪ್ಯತೆ ನಮಗೆ ಮುಖ್ಯ.

1. ನಾವು ಸಂಗ್ರಹಿಸುವ ಮಾಹಿತಿ

ಉಧಾರ್ ಹಿಸಾಬ್ ಬಳಸುವಾಗ ನೀವೇ ಆ್ಯಪ್‌ನಲ್ಲಿ ನಮೂದಿಸುವ ಮಾಹಿತಿ, ಉದಾಹರಣೆಗೆ:
• ಅಂಗಡಿಯ ಹೆಸರು
• ಮೊಬೈಲ್ ಸಂಖ್ಯೆ
• ಅಂಗಡಿಯ ವಿಳಾಸ ಅಥವಾ ಇತರ ವಿವರಗಳು
• ಸಾಲ ಮತ್ತು ಜಮಾ ಮೊತ್ತಗಳು
• ವ್ಯವಹಾರದ ದಿನಾಂಕ, ಸಮಯ ಮತ್ತು ಟಿಪ್ಪಣಿ

2. ಮಾಹಿತಿಯ ಬಳಕೆ

ಈ ಮಾಹಿತಿಯನ್ನು ನಿಮ್ಮ ಲೆಕ್ಕಗಳನ್ನು ಉಳಿಸಲು, ತೋರಿಸಲು ಮತ್ತು ನಿರ್ವಹಿಸಲು ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ. ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಖಾತೆ ಪುಸ್ತಕದ ಡೇಟಾವನ್ನು ನಿಮ್ಮ ಅನುಮತಿಯಿಲ್ಲದೆ ಯಾವುದೇ ಜಾಹೀರಾತುದಾರರಿಗೆ ಅಥವಾ ಮೂರನೇ ಪಕ್ಷಕ್ಕೆ ಮಾರಾಟ ಮಾಡುವುದಿಲ್ಲ ಅಥವಾ ಹಂಚಿಕೊಳ್ಳುವುದಿಲ್ಲ.

3. ಡೇಟಾ ಸಂಗ್ರಹಣೆ

ಆ್ಯಪ್‌ನ ಅಗತ್ಯಕ್ಕೆ ತಕ್ಕಂತೆ ನಿಮ್ಮ ಲೆಕ್ಕದ ಡೇಟಾ ನಿಮ್ಮ ಸಾಧನದಲ್ಲಿ ಸಂಗ್ರಹವಾಗಬಹುದು. ನೀವು ಬ್ಯಾಕಪ್ ಮತ್ತು ರಿಸ್ಟೋರ್ ಸೌಲಭ್ಯ ಬಳಸಿದರೆ, ನೀವು ಆರಿಸಿದ ಸ್ಟೋರೇಜ್/ಕ್ಲೌಡ್ ಸೇವೆಯಲ್ಲಿ ಬ್ಯಾಕಪ್ ಡೇಟಾ ಸಂಗ್ರಹವಾಗಬಹುದು.

4. ಆ್ಯಪ್ ಭದ್ರತೆ

ನಿಮ್ಮ ಲೆಕ್ಕದ ಡೇಟಾವನ್ನು ಸುರಕ್ಷಿತವಾಗಿಡಲು ಆ್ಯಪ್ ಲಾಕ್, PIN ಮತ್ತು ಬಯೋಮೆಟ್ರಿಕ್ ದೃಢೀಕರಣದಂತಹ ಭದ್ರತಾ ಸೌಲಭ್ಯಗಳನ್ನು ನೀಡಬಹುದು.

5. ಮಾಹಿತಿ ಹಂಚಿಕೆ

ಕಾನೂನಿನ ಪ್ರಕಾರ ಅಗತ್ಯವಿದ್ದರೆ ಹೊರತು, ನಿಮ್ಮ ವೈಯಕ್ತಿಕ ಖಾತೆ ಪುಸ್ತಕದ ಡೇಟಾವನ್ನು ನಾವು ಮೂರನೇ ಪಕ್ಷಗಳಿಗೆ ಮಾರುವುದಿಲ್ಲ, ಬಾಡಿಗೆಗೆ ಕೊಡುವುದಿಲ್ಲ ಅಥವಾ ವಾಣಿಜ್ಯ ಉದ್ದೇಶಕ್ಕೆ ಹಂಚಿಕೊಳ್ಳುವುದಿಲ್ಲ.

6. ನಿಮ್ಮ ನಿಯಂತ್ರಣ

ಆ್ಯಪ್‌ನಲ್ಲಿ ಉಳಿಸಿದ ನಿಮ್ಮ ಡೇಟಾವನ್ನು ನೀವು ಯಾವಾಗ ಬೇಕಾದರೂ ನೋಡಬಹುದು, ಬದಲಿಸಬಹುದು ಅಥವಾ ಅಳಿಸಬಹುದು.

7. ಮೂರನೇ ಪಕ್ಷದ ಸೇವೆಗಳು

ಆ್ಯಪ್‌ನ ಕೆಲವು ಸೌಲಭ್ಯಗಳಿಗೆ ಮೂರನೇ ಪಕ್ಷದ ಸೇವೆಗಳನ್ನು ಬಳಸಿದರೆ, ಅವುಗಳ ಸ್ವಂತ ಗೌಪ್ಯತಾ ನೀತಿ ಅನ್ವಯಿಸಬಹುದು.

8. ಮಕ್ಕಳ ಗೌಪ್ಯತೆ

ಉಧಾರ್ ಹಿಸಾಬ್ ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಮಕ್ಕಳಿಂದ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿ ಸಂಗ್ರಹಿಸಲು ರೂಪಿಸಲಾಗಿಲ್ಲ.

9. ಈ ಗೌಪ್ಯತಾ ನೀತಿಯಲ್ಲಿ ಬದಲಾವಣೆಗಳು

ಅಗತ್ಯಕ್ಕೆ ತಕ್ಕಂತೆ ಈ ಗೌಪ್ಯತಾ ನೀತಿಯನ್ನು ನಾವು ಬದಲಿಸಬಹುದು ಅಥವಾ ನವೀಕರಿಸಬಹುದು. ಹೊಸ ನೀತಿ ಈ ಪುಟದಲ್ಲಿ ಪ್ರಕಟಿಸಲಾಗುತ್ತದೆ.

10. ಸಂಪರ್ಕ

ಈ ಗೌಪ್ಯತಾ ನೀತಿ ಅಥವಾ ನಿಮ್ಮ ಡೇಟಾ ಬಗ್ಗೆ ಯಾವುದೇ ಪ್ರಶ್ನೆಗಳಿದ್ದರೆ ದಯವಿಟ್ಟು ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ.

ಉಧಾರ್ ಹಿಸಾಬ್
ಸುಲಭ ಲೆಕ್ಕ, ನಿಶ್ಚಿಂತೆಯಿಂದಿರಿ."""
}

/** Malayalam (മലയാളം) */
object MalayalamStrings : AppStrings {
    override val code = "ml"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "പരസ്യങ്ങൾ നീക്കുക"
    override val moreHintAdFree = "ഒരിക്കൽ വാങ്ങൂ, ഇനി പരസ്യമില്ല"
    override val adFreeDialogTitle = "പരസ്യരഹിത ആപ്പ്"
    override val adFreeDialogMessage = "ഒരിക്കൽ പണം നൽകിയാൽ എല്ലാ പരസ്യങ്ങളും എന്നെന്നേക്കുമായി നിലയ്ക്കും. ആപ്പിനെ പിന്തുണച്ചതിന് നന്ദി!"
    override val adFreeBuyButton = "വാങ്ങുക"
    override val adFreeRestoreButton = "മുമ്പത്തെ വാങ്ങൽ തിരികെ കൊണ്ടുവരിക"
    override val adFreeActiveLabel = "നിങ്ങളുടെ ആപ്പ് പരസ്യരഹിതമാണ് ✓"
    override val adFreeUnavailable = "ഇപ്പോൾ വാങ്ങാനാവില്ല — പിന്നീട് ശ്രമിക്കുക"
    override val adSponsoredLabel = "പരസ്യം"
    override val moreAdPrivacy = "പരസ്യ മുൻഗണനകൾ"
    override val moreHintAdPrivacy = "നിങ്ങൾ കാണേണ്ട പരസ്യത്തിന്റെ തരം തിരഞ്ഞെടുക്കുക"
    override val helpCenterTitle = "സഹായ കേന്ദ്രം"
    override val helpSearchPlaceholder = "ചോദ്യങ്ങൾ തിരയുക..."
    override val noFaqResultsMessage = "ഒന്നും കണ്ടെത്തിയില്ല"
    override val homeHeadline = "ഉധാർ ഹിസാബ്"
    override val history = "ചരിത്രം"
    override val settings = "ക്രമീകരണങ്ങൾ"
    override val totalDueLabel = "ആകെ കുടിശ്ശിക"
    override val thisMonthCreditLabel = "ഈ മാസത്തെ കുടിശ്ശിക"
    override val thisMonthPaymentLabel = "ഈ മാസം കിട്ടിയത്"
    override val searchPlaceholder = "കട/ഫോൺ തിരയുക..."
    override val filterAll = "എല്ലാം"
    override val settledLabel = "തീർന്നു"
    override val noShopsYetTitle = "ഇതുവരെ കടകളില്ല"
    override val noShopsYetSubtitle = "അക്കൗണ്ട് തുടങ്ങാൻ ആദ്യത്തെ കട ചേർക്കുക"
    override val addFirstShopButton = "ആദ്യത്തെ കട ചേർക്കുക"
    override val newShop = "പുതിയ കട"
    override val shopTypeTea = "ചായക്കട"
    override val shopTypeHardwareElectric = "ഹാർഡ്‌വെയർ & ഇലക്ട്രിക്"
    override val shopTypeKirana = "പലചരക്ക് കട"
    override val shopTypeVegetable = "പച്ചക്കറിക്കട"
    override val shopTypeFishMeat = "മീൻ & ഇറച്ചി"
    override val shopTypeBakerySweets = "ബേക്കറി & മധുരം"
    override val shopTypePharmacy = "മരുന്നുകട"
    override val shopTypeCosmetics = "സൗന്ദര്യവർധക വസ്തുക്കൾ"
    override val shopTypeStationery = "സ്റ്റേഷനറി"
    override val shopTypeXeroxPrinting = "സീറോക്സ് & പ്രിന്റിംഗ്"
    override val shopTypeWood = "തടിക്കട"
    override val shopTypeGarments = "തുണിക്കട"
    override val shopTypeOther = "മറ്റുള്ളവ"
    override val back = "പിന്നോട്ട്"
    override val cancel = "റദ്ദാക്കുക"
    override val save = "സേവ് ചെയ്യുക"
    override val shopNameLabel = "കടയുടെ പേര് *"
    override val shopNamePlaceholder = "ഉദാ. തടി മഹൽ"
    override val phoneLabel = "ഫോൺ നമ്പർ (ഓപ്ഷണൽ)"
    override val shopTypeLabel = "കടയുടെ തരം *"
    override val saveShopButton = "കട സേവ് ചെയ്യുക"
    override val errorNameRequired = "കടയുടെ പേര് എഴുതുക"
    override val errorTypeRequired = "കടയുടെ തരം തിരഞ്ഞെടുക്കുക"
    override val dueLabel = "കുടിശ്ശിക"
    override val noTransactionsYet = "ഇതുവരെ ഇടപാടുകളില്ല"
    override val creditButton = "കടം വാങ്ങി"
    override val paymentButton = "പണം നൽകി"
    override val pdfExport = "PDF എക്സ്പോർട്ട്"
    override val archive = "ആർക്കൈവ്"
    override val deleteShopAction = "കട ഇല്ലാതാക്കുക"
    override val archiveConfirmTitle = "ഈ കട ആർക്കൈവ് ചെയ്യണോ?"
    override val archiveConfirmText = "ഇത് ഹോം പട്ടികയിൽ നിന്ന് മാറും — ചരിത്രത്തിൽ ഇപ്പോഴും കാണും."
    override val deleteConfirmTitle = "ഈ കട എന്നെന്നേക്കുമായി ഇല്ലാതാക്കണോ?"
    override val deleteConfirmText = "ഈ കടയും അതിന്റെ എല്ലാ ഇടപാടുകളും എന്നെന്നേക്കുമായി ഇല്ലാതാകും, തിരികെ ലഭിക്കില്ല. ആർക്കൈവ് ചെയ്താൽ ചരിത്രത്തിൽ നിലനിൽക്കും — തുടരുന്നതിന് മുമ്പ് നന്നായി ആലോചിക്കുക."
    override val yesDelete = "അതെ, ഇല്ലാതാക്കുക"
    override val yesArchive = "ആർക്കൈവ് ചെയ്യുക"
    override val txnDeletedSnackbar = "ഇടപാട് ഇല്ലാതാക്കി"
    override val undo = "തിരികെ വയ്ക്കുക"
    override val pdfFailPrefix = "PDF ഉണ്ടാക്കാനായില്ല: "
    override val shareKhata = "അക്കൗണ്ട് പങ്കിടുക"
    override val creditFallback = "കടം"
    override val paymentFallback = "വരവ്"
    override val deleteTxnAction = "ഇല്ലാതാക്കുക"
    override val productNameLabel = "സാധനത്തിന്റെ പേര് (ഓപ്ഷണൽ)"
    override val quantityLabel = "അളവ്"
    override val unitLabel = "യൂണിറ്റ്"
    override val pricePerUnitLabel = "വില/യൂണിറ്റ്"
    override val totalPrefix = "ആകെ: "
    override val amountLabel = "നൽകിയ തുക"
    override val orEnterAmountLabel = "അല്ലെങ്കിൽ തുക നേരിട്ട് എഴുതുക"
    override val noteLabel = "കുറിപ്പ് (ഓപ്ഷണൽ)"
    override val cash = "പണം"
    override val bkash = "bKash"
    override val bank = "ബാങ്ക്"
    override val invalidAmountError = "ശരിയായ തുക എഴുതുക"
    override val cftCalculatorTitle = "CFT കാൽക്കുലേറ്റർ"
    override val lengthLabel = "നീളം (ഇഞ്ച്)"
    override val widthLabel = "വീതി"
    override val heightLabel = "ഉയരം"
    override val rateLabel = "നിരക്ക് /cft (₹)"
    override val applyToEntryButton = "എൻട്രിയിൽ ചേർക്കുക"
    override val settingsTitle = "ക്രമീകരണങ്ങൾ"
    override val security = "സുരക്ഷ"
    override val pinLockOn = "PIN ലോക്ക് ഓണാണ്"
    override val pinLockOff = "PIN ലോക്ക് ഓഫാണ്"
    override val changePin = "PIN മാറ്റുക"
    override val reminderTitle = "കുടിശ്ശിക ഓർമ്മപ്പെടുത്തൽ"
    override val reminderDesc = "എല്ലാ ദിവസവും കുടിശ്ശിക ഓർമ്മിപ്പിക്കും"
    override val about = "വിവരം"
    override val aboutLine = "ഉധാർ ഹിസാബ് — കടയിലെ കടം കണക്ക്"
    override val aboutDescription = "കടയിലെ കടം, കുടിശ്ശിക, ഇടപാടുകൾ എന്നിവ എളുപ്പത്തിലും വേഗത്തിലും ചിട്ടയായും കൈകാര്യം ചെയ്യാൻ സഹായിക്കുന്ന ഒരു സ്മാർട്ട് കണക്ക് ആപ്പാണ് ഉധാർ ഹിസാബ്. ഏത് കടയിൽ എത്ര കുടിശ്ശികയുണ്ട്, എവിടെ പണം നൽകി, ഏത് ഇടപാട് എപ്പോൾ നടന്നു — എല്ലാം ഒരിടത്ത് ഭംഗിയായി സൂക്ഷിക്കാം.\n\nഈ ആപ്പിൽ നിങ്ങൾക്ക് എളുപ്പത്തിൽ കടകൾ ചേർക്കാം, കടവും വരവും രേഖപ്പെടുത്താം, ഇടപാടുകളുടെ ചരിത്രം കാണാം, ആകെ കുടിശ്ശികയും വരവും പരിശോധിക്കാം, വിശദമായ റിപ്പോർട്ടുകൾ ഉണ്ടാക്കാം. തിരയൽ, ഫിൽട്ടർ, ബാക്കപ്പ് & റീസ്റ്റോർ, ആപ്പ് ലോക്ക്, ബയോമെട്രിക് സുരക്ഷ, ഡാർക്ക് മോഡ്, അറിയിപ്പുകൾ തുടങ്ങിയ സൗകര്യങ്ങൾ കണക്ക് സൂക്ഷിക്കൽ കൂടുതൽ എളുപ്പവും സുരക്ഷിതവുമാക്കുന്നു.\n\nകടലാസ് പുസ്തകത്തിലെ ബുദ്ധിമുട്ടുകളെ ലളിതവും ആധുനികവും വിശ്വസനീയവുമായ ഡിജിറ്റൽ രീതിയിലേക്ക് കൊണ്ടുവരിക എന്നതാണ് ഉധാർ ഹിസാബിന്റെ ലക്ഷ്യം."
    override val aboutTagline = "ഉധാർ ഹിസാബ് — എളുപ്പമുള്ള കണക്ക്, ആശങ്കയില്ലാതെ ഇരിക്കൂ."
    override val versionLine = "പതിപ്പ് 1.0"
    override val setPinTitle = "PIN സജ്ജമാക്കുക"
    override val newPinLabel = "പുതിയ PIN"
    override val confirmPinLabel = "PIN വീണ്ടും എഴുതുക"
    override val pinSetupError = "PIN പൊരുത്തപ്പെടുന്നില്ല (കുറഞ്ഞത് 4 അക്കങ്ങൾ)"
    override val removePinTitle = "PIN ലോക്ക് ഓഫാക്കണോ?"
    override val removePinText = "ഇനി ആപ്പ് തുറക്കുമ്പോൾ PIN ചോദിക്കില്ല."
    override val yesTurnOff = "അതെ, ഓഫാക്കുക"
    override val no = "വേണ്ട"
    override val languageTitle = "ഭാഷ"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "അറിയിപ്പുകൾ"
    override val notifSheetSubtitle = "നിങ്ങൾക്ക് ഏത് ഓർമ്മപ്പെടുത്തലുകൾ വേണം?"
    override val notifDueReminderOption = "കുടിശ്ശിക അടയ്ക്കൽ ഓർമ്മപ്പെടുത്തൽ"
    override val notifWeeklySummaryOption = "ആഴ്ചത്തെ സംഗ്രഹം"
    override val notifAppNewsOption = "ആപ്പ് വാർത്തകളും അപ്‌ഡേറ്റുകളും"
    override val langSheetSubtitle = "ആപ്പ് ഏത് ഭാഷയിൽ ഉപയോഗിക്കണം?"
    override val themeSheetSubtitle = "നിങ്ങൾക്ക് ഏത് തീം ഇഷ്ടം?"
    override val securityPrivacyTitle = "സുരക്ഷയും സ്വകാര്യതയും"
    override val pinSectionTitle = "PIN ലോക്ക്"
    override val pinSectionDesc = "ആപ്പ് തുറക്കുമ്പോൾ PIN ചോദിക്കുക"
    override val fingerprintTitle = "ഫിംഗർപ്രിന്റ് ലോക്ക്"
    override val fingerprintDesc = "PIN-ന് പകരം ഫിംഗർപ്രിന്റ് ഉപയോഗിച്ച് തുറക്കുക"
    override val fingerprintUnavailable = "ഈ ഫോണിൽ ഫിംഗർപ്രിന്റ് സെൻസർ കണ്ടില്ല"
    override val lockImmediatelyTitle = "ഉടനെ ലോക്ക് ചെയ്യുക"
    override val lockImmediatelyDesc = "ആപ്പിലേക്ക് തിരിച്ചെത്തിയാൽ ഉടനെ വീണ്ടും ലോക്ക് ആകും"
    override val rateTitle = "റേറ്റിംഗും അഭിപ്രായവും"
    override val rateSubtitle = "ഉധാർ ഹിസാബ് നിങ്ങൾക്ക് എങ്ങനെ തോന്നുന്നു?"
    override val rateStarsPrompt = "റേറ്റ് ചെയ്യാൻ തൊടുക"
    override val rateThanksMessage = "നന്ദി! നിങ്ങളെ Play Store-ലേക്ക് കൊണ്ടുപോകുന്നു…"
    override val feedbackPromptLow = "നിങ്ങൾക്ക് എന്താണ് ഇഷ്ടപ്പെടാതിരുന്നത്? ഞങ്ങളോട് പറയൂ"
    override val feedbackPlaceholder = "നിങ്ങളുടെ അഭിപ്രായം എഴുതുക…"
    override val feedbackSubmit = "അയയ്ക്കുക"
    override val feedbackThanks = "നന്ദി, നിങ്ങളുടെ അഭിപ്രായം അയച്ചു"
    override val aboutPageTitle = "ഉധാർ ഹിസാബിനെക്കുറിച്ച്"
    override val aboutVersionPrefix = "പതിപ്പ്"
    override val aboutDeveloperLabel = "ഡെവലപ്പർ"
    override val aboutDeveloperName = "ഉധാർ ഹിസാബ് ടീം"
    override val aboutPrivacyPolicy = "സ്വകാര്യതാ നയം"
    override val privacyPolicyEffectiveDate = "പ്രാബല്യ തീയതി: 13 സെപ്റ്റംബർ 2026"
    override val aboutShareApp = "പങ്കിടുക"
    override val aboutShareText = "ഉധാർ ഹിസാബ് — കടയിലെ കടം കണക്ക് ആപ്പ് പരീക്ഷിച്ചു നോക്കൂ!"
    override val noArchivedShops = "ആർക്കൈവ് ചെയ്ത കടകളില്ല"
    override val noSettledShops = "തീർന്ന കടകളില്ല"
    override val setupPinTitle = "4 അക്ക PIN സജ്ജമാക്കുക"
    override val unlockPinTitle = "PIN ഉപയോഗിച്ച് തുറക്കുക"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 അക്കങ്ങൾ എഴുതുക"
    override val pinsDontMatchError = "PIN പൊരുത്തപ്പെടുന്നില്ല"
    override val wrongPinError = "PIN തെറ്റാണ് — വീണ്ടും ശ്രമിക്കുക"
    override val savePinButton = "PIN സേവ് ചെയ്യുക"
    override val unlockButton = "തുറക്കുക"
    override val pdfHeaderTitle = "അക്കൗണ്ട് — ഉധാർ ഹിസാബ്"
    override val pdfFullKhataSuffix = "പൂർണ്ണ അക്കൗണ്ട്"
    override val pdfShopLabel = "കട: "
    override val pdfPhoneLabel = "ഫോൺ: "
    override val pdfCreatedLabel = "തയ്യാറാക്കിയത്: "
    override val pdfColDate = "തീയതി/സമയം"
    override val pdfColDesc = "വിവരണം"
    override val pdfTotalCredit = "ആകെ കടം:"
    override val pdfTotalPayment = "ആകെ വരവ്:"
    override val pdfCurrentDue = "ഇപ്പോഴത്തെ കുടിശ്ശിക:"
    override val pdfFooter = "ഉധാർ ഹിസാബ് ആപ്പ് ഉണ്ടാക്കിയത്"
    override val navHome = "ഹോം"
    override val navHistory = "ചരിത്രം"
    override val navReports = "റിപ്പോർട്ട്"
    override val navMore = "കൂടുതൽ"
    override val historyFilterAllShops = "എല്ലാ കടകളും"
    override val historyFilterAllTypes = "എല്ലാം"
    override val historyFilterCreditOnly = "കടം മാത്രം"
    override val historyFilterPaymentOnly = "വരവ് മാത്രം"
    override val historyNoTxnsFound = "ഇടപാടുകളൊന്നും കണ്ടില്ല"
    override val viewArchivedAction = "ആർക്കൈവ് ചെയ്ത കടകൾ കാണുക"
    override val reportsTitle = "റിപ്പോർട്ട്"
    override val periodLabel = "കാലയളവ്"
    override val period7d = "കഴിഞ്ഞ 7 ദിവസം"
    override val period15d = "കഴിഞ്ഞ 15 ദിവസം"
    override val period30d = "കഴിഞ്ഞ 30 ദിവസം"
    override val period3m = "കഴിഞ്ഞ 3 മാസം"
    override val period1y = "ഈ വർഷം"
    override val reportTotalCredit = "ആകെ കടം"
    override val reportTotalPayment = "ആകെ വരവ്"
    override val reportCurrentDue = "ഇപ്പോഴത്തെ ആകെ കുടിശ്ശിക"
    override val reportTxnCount = "ഇടപാടുകൾ"
    override val reportChartTitle = "കടം vs വരവ്"
    override val reportShopWiseTitle = "കട തിരിച്ചുള്ള കുടിശ്ശിക"
    override val reportAgingTitle = "കുടിശ്ശികയുടെ പഴക്കം"
    override val reportAging0to7 = "0–7 ദിവസം"
    override val reportAging7to15 = "7–15 ദിവസം"
    override val reportAging15to30 = "15–30 ദിവസം"
    override val reportAging30plus = "30+ ദിവസം"
    override val reportRecentPaymentsTitle = "സമീപകാല വരവുകൾ"
    override val reportNoData = "ഈ കാലയളവിൽ വിവരമില്ല"
    override val reportSmartSummaryPrefix = "ഈ കാലയളവിൽ നിങ്ങൾ"
    override val moreTitle = "കൂടുതൽ"
    override val moreBackupRestore = "ബാക്കപ്പ് & റീസ്റ്റോർ"
    override val moreHintBackupRestore = "നിങ്ങളുടെ ഡാറ്റ സുരക്ഷിതമായി സൂക്ഷിക്കുക"
    override val notesTitle = "കുറിപ്പുകൾ"
    override val notesSearchPlaceholder = "കുറിപ്പുകൾ തിരയുക..."
    override val addNoteButton = "പുതിയ കുറിപ്പ്"
    override val noNotesYetTitle = "ഇതുവരെ കുറിപ്പുകളില്ല"
    override val noNotesYetSubtitle = "സാധനങ്ങളുടെ പട്ടിക, ഓർമ്മകൾ — എന്തും എഴുതിവയ്ക്കൂ"
    override val deleteNoteConfirmTitle = "ഈ കുറിപ്പ് ഇല്ലാതാക്കണോ?"
    override val deleteNoteConfirmMessage = "ഈ കുറിപ്പ് എന്നെന്നേക്കുമായി ഇല്ലാതാകും."
    override val noteTitlePlaceholder = "തലക്കെട്ട്"
    override val noteContentPlaceholder = "എന്തെങ്കിലും എഴുതൂ..."
    override val untitledNote = "തലക്കെട്ടില്ലാത്ത കുറിപ്പ്"
    override val notificationInboxTitle = "അറിയിപ്പുകൾ"
    override val moreNotificationHistory = "അറിയിപ്പ് ചരിത്രം"
    override val moreHintNotificationHistory = "സമീപകാല പ്രവർത്തനങ്ങൾ കാണുക"
    override val noNotificationsYetTitle = "ഇതുവരെ അറിയിപ്പുകളില്ല"
    override val noNotificationsYetSubtitle = "കടമോ വരവോ രേഖപ്പെടുത്തിയാൽ ഇവിടെ കാണാം"
    override val notifCreditMessage = "%1\$s-ൽ നിന്ന് %2\$s കടം വാങ്ങി"
    override val notifPaymentMessage = "%1\$s-ന് %2\$s നൽകി"
    override val moreQuickCalculator = "ക്വിക്ക് കാൽക്കുലേറ്റർ"
    override val moreHintQuickCalculator = "പെട്ടെന്ന് കണക്ക് കൂട്ടാം"
    override val calcGeneralTab = "പൊതുവായ"
    override val calcPercentTab = "ശതമാനം"
    override val calcConversionTab = "പരിവർത്തനം"
    override val calcComingSoonInTab = "ഉടൻ വരുന്നു"
    override val percentOfTitle = "ഒരു സംഖ്യയുടെ ശതമാനം"
    override val percentOfValueLabel = "സംഖ്യ"
    override val percentOfPercentLabel = "ശതമാനം (%)"
    override val percentIsWhatTitle = "ഒരു സംഖ്യ മറ്റൊന്നിന്റെ എത്ര ശതമാനം"
    override val percentIsWhatXLabel = "ഈ സംഖ്യ"
    override val percentIsWhatYLabel = "ഇതിന്റെ"
    override val percentChangeTitle = "ശതമാനം വർധന/കുറവ്"
    override val percentChangeBaseLabel = "അടിസ്ഥാന സംഖ്യ"
    override val percentChangePercentLabel = "ശതമാനം (%)"
    override val increaseOption = "വർധന"
    override val decreaseOption = "കുറവ്"
    override val resultLabel = "ഫലം"
    override val weightCategory = "ഭാരം"
    override val lengthCategory = "നീളം"
    override val volumeCategory = "വ്യാപ്തം"
    override val fromLabel = "മുതൽ"
    override val toLabel = "വരെ"
    override val enterValueHint = "മൂല്യം എഴുതുക"
    override val backupNowButton = "ഇപ്പോൾ ബാക്കപ്പ് എടുക്കുക"
    override val backupNowHint = "എല്ലാ കടകളും ഇടപാടുകളും JSON ഫയലിൽ സേവ് ചെയ്യുക"
    override val restoreButton = "ബാക്കപ്പിൽ നിന്ന് റീസ്റ്റോർ ചെയ്യുക"
    override val restoreShopAction = "റീസ്റ്റോർ"
    override val restoreHint = "പഴയ JSON ബാക്കപ്പ് ഫയലിൽ നിന്ന് ഡാറ്റ തിരികെ കൊണ്ടുവരിക"
    override val lastBackupLabel = "അവസാന ബാക്കപ്പ്"
    override val noBackupYetLabel = "ഇതുവരെ ബാക്കപ്പ് എടുത്തിട്ടില്ല"
    override val backupSuccessMessage = "ബാക്കപ്പ് ഉണ്ടാക്കി"
    override val backupFailPrefix = "ബാക്കപ്പ് പരാജയപ്പെട്ടു: "
    override val restoreConfirmTitle = "ബാക്കപ്പ് റീസ്റ്റോർ ചെയ്യണോ?"
    override val restoreConfirmMessage = "ഇത് നിലവിലെ എല്ലാ കടകളും ഇടപാടുകളും മായ്ച്ച് ബാക്കപ്പ് ഫയലിലെ ഡാറ്റ കൊണ്ട് മാറ്റും. ഇത് തിരിച്ചെടുക്കാൻ കഴിയില്ല."
    override val restoreSuccessMessage = "റീസ്റ്റോർ പൂർത്തിയായി"
    override val restoreFailPrefix = "റീസ്റ്റോർ പരാജയപ്പെട്ടു: "
    override val dataSafeNote = "നിങ്ങളുടെ ഡാറ്റ ഈ ഫോണിൽ മാത്രമാണ് — ബാക്കപ്പ് ഫയൽ നിങ്ങൾ തന്നെ സുരക്ഷിതമായി സൂക്ഷിക്കുക"
    override val moreExportShare = "എക്സ്പോർട്ട് & പങ്കിടൽ"
    override val moreHintExportShare = "PDF-ഉം ഫയലുകളും അയയ്ക്കുക"
    override val moreNotifications = "അറിയിപ്പുകൾ"
    override val moreHintNotifications = "ഓർമ്മപ്പെടുത്തലുകൾ ഓൺ/ഓഫ് ചെയ്യുക"
    override val moreLanguage = "ഭാഷ"
    override val moreHintLanguage = "നിങ്ങളുടെ ഭാഷ തിരഞ്ഞെടുക്കുക"
    override val moreUserMode = "ഞാൻ ആരാണ്"
    override val moreHintUserMode = "ഉപഭോക്താവ് അല്ലെങ്കിൽ കടക്കാരൻ"
    override val moreSecurityPrivacy = "സുരക്ഷയും സ്വകാര്യതയും"
    override val moreHintSecurityPrivacy = "PIN & ഫിംഗർപ്രിന്റ് ലോക്ക്"
    override val moreAppearance = "രൂപം"
    override val moreHintAppearance = "ലൈറ്റ്, ഡാർക്ക് അല്ലെങ്കിൽ സിസ്റ്റം"
    override val moreRateFeedback = "റേറ്റിംഗും അഭിപ്രായവും"
    override val moreHintRateFeedback = "നിങ്ങളുടെ അഭിപ്രായം പറയൂ"
    override val moreAbout = "ഉധാർ ഹിസാബിനെക്കുറിച്ച്"
    override val moreHintAbout = "പതിപ്പും ഡെവലപ്പറും"
    override val comingSoonMessage = "ഉടൻ വരുന്നു"
    override val appearanceTitle = "രൂപം"
    override val themeLight = "ലൈറ്റ്"
    override val themeDark = "ഡാർക്ക്"
    override val themeSystem = "സിസ്റ്റം ഡിഫോൾട്ട്"
    override val creditPageTitle = "കടം വാങ്ങുക"
    override val accountingTypeLabel = "എൻട്രിയുടെ തരം"
    override val directMoneyMode = "നേരിട്ടുള്ള തുക"
    override val productMode = "സാധനം അനുസരിച്ച്"
    override val directMoneyAmountLabel = "എത്ര കടം കൊടുത്തു?"
    override val previousDueLabel = "മുമ്പത്തെ കുടിശ്ശിക"
    override val newCreditLabel = "പുതിയ കടം"
    override val newTotalDueLabel = "പുതിയ ആകെ കുടിശ്ശിക"
    override val addCreditButton = "കടം ചേർക്കുക"
    override val addMoreProductButton = "+ മറ്റൊരു സാധനം ചേർക്കുക"
    override val totalNewCreditLabel = "ആകെ പുതിയ കടം"
    override val editAction = "മാറ്റുക"
    override val itemsCountSuffix = "സാധനങ്ങൾ"
    override val paymentPageTitle = "വരവ്"
    override val currentDueLabel = "ഇപ്പോഴത്തെ കുടിശ്ശിക"
    override val howMuchPaymentLabel = "എത്ര നൽകുന്നു?"
    override val fullPaymentButton = "മുഴുവൻ തുക"
    override val dueAfterPaymentLabel = "നൽകിയ ശേഷം കുടിശ്ശിക"
    override val addPaymentButton = "വരവ് ചേർക്കുക"
    override val overpaymentBlockedMessage = "ഇപ്പോഴത്തെ കുടിശ്ശികയേക്കാൾ കൂടുതൽ നൽകാനാവില്ല"
    override val fullyPaidCelebration = "ഇത് മുഴുവൻ കുടിശ്ശികയും തീർക്കും"
    override val woodCalculatorTitle = "തടി കാൽക്കുലേറ്റർ"
    override val woodTypeLabel = "തടിയുടെ തരം"
    override val sawnWoodOption = "അറുത്ത തടി"
    override val roundWoodOption = "ഉരുണ്ട തടി"
    override val lengthFtLabel = "നീളം (അടി)"
    override val widthInLabel = "വീതി (ഇഞ്ച്)"
    override val thicknessInLabel = "കനം (ഇഞ്ച്)"
    override val girthInLabel = "ചുറ്റളവ് (ഇഞ്ച്)"
    override val pieceCountLabel = "കഷണങ്ങളുടെ എണ്ണം"
    override val perPieceCftLabel = "ഒരു കഷണത്തിന്"
    override val totalWoodCftLabel = "ആകെ തടി"
    override val perCftPriceLabel = "ഒരു CFT വില (₹)"
    override val totalWoodValueLabel = "ആകെ മൂല്യം"
    override val addWoodCalcButton = "ഈ തടി കണക്ക് ചേർക്കുക"
    override val woodNameLabel = "സാധനത്തിന്റെ പേര്"
    override val addMoreWoodProductButton = "+ മറ്റൊരു തടി/സാധനം ചേർക്കുക"
    override val addedItemsHeader = "ചേർത്ത സാധനങ്ങൾ/തടി"
    override val pdfOptionsTitle = "PDF ഓപ്ഷനുകൾ"
    override val pdfPeriodLabel = "കാലയളവ്"
    override val pdfThisMonth = "ഈ മാസം"
    override val pdfLastMonth = "കഴിഞ്ഞ മാസം"
    override val pdfLast3Months = "കഴിഞ്ഞ 3 മാസം"
    override val pdfCustomRange = "സ്വന്തം തീയതികൾ"
    override val pdfShopLabelOption = "കട"
    override val pdfAllShopsOption = "എല്ലാ കടകളും"
    override val pdfContentLabel = "എന്ത് കാണിക്കണം"
    override val pdfContentFull = "എല്ലാം (ഇടപാടുകൾ + സംഗ്രഹം + ഒപ്പ്)"
    override val pdfContentSummaryOnly = "സംഗ്രഹം മാത്രം"
    override val pdfContentTxnsOnly = "ഇടപാടുകൾ മാത്രം"
    override val pdfFormatLabel = "ഫോർമാറ്റ്"
    override val pdfFormatA4 = "A4 റിപ്പോർട്ട്"
    override val pdfFormatReceipt = "രസീത് (58mm)"
    override val pdfGenerateButton = "PDF ഉണ്ടാക്കുക"
    override val pdfFromDateLabel = "തുടക്ക തീയതി"
    override val pdfToDateLabel = "അവസാന തീയതി"
    override val pdfReportNumberLabel = "റിപ്പോർട്ട് നമ്പർ"
    override val pdfShopBoxLabel = "കട"
    override val pdfDateBoxLabel = "തീയതി"
    override val pdfDaysOfRecordsSuffix = "ദിവസത്തെ രേഖ"
    override val pdfWeeklyChartTitle = "ആഴ്ചത്തെ കടം (ചുവപ്പ്) vs വരവ് (പച്ച)"
    override val pdfFinalDueLabel = "ഇപ്പോഴത്തെ കുടിശ്ശിക"
    override val pdfShopSignatureLabel = "കടക്കാരന്റെ ഒപ്പ്"
    override val pdfCustomerSignatureLabel = "ഉപഭോക്താവിന്റെ ഒപ്പ്"
    override val pdfAllShopsReportTitle = "എല്ലാ കടകളുടെയും സംഗ്രഹം — ഉധാർ ഹിസാബ്"
    override val pdfPageLabel = "പേജ്"
    override val moreShopProfile = "കടയുടെ പ്രൊഫൈൽ"
    override val moreHintShopProfile = "പേര്, ലോഗോ, വിലാസം, ഓർമ്മപ്പെടുത്തൽ"
    override val shopProfileTitle = "കടയുടെ പ്രൊഫൈൽ"
    override val shopProfileIntro = "ഈ വിവരങ്ങൾ PDF ഇൻവോയ്സുകളിലും ഉപഭോക്താവിന് അയയ്ക്കുന്ന സന്ദേശങ്ങളിലും ഉപയോഗിക്കും"
    override val shopBusinessNameLabel = "കടയുടെ പേര്"
    override val shopBusinessAddressLabel = "കടയുടെ വിലാസം"
    override val shopBusinessPhoneLabel = "കടയുടെ ഫോൺ നമ്പർ"
    override val countryCodeLabel = "രാജ്യ കോഡ് (ഉദാ. 91)"
    override val shopLogoLabel = "കടയുടെ ലോഗോ"
    override val shopLogoPick = "ലോഗോ തിരഞ്ഞെടുക്കുക"
    override val shopLogoRemove = "ലോഗോ നീക്കം ചെയ്യുക"
    override val promptAfterEntryLabel = "എൻട്രിക്ക് ശേഷം ഉപഭോക്താവിനെ അറിയിക്കാനുള്ള ഓപ്ഷൻ കാണിക്കുക"
    override val saveProfileButton = "പ്രൊഫൈൽ സേവ് ചെയ്യുക"
    override val profileSavedMessage = "പ്രൊഫൈൽ സേവ് ചെയ്തു"
    override val errorShopNameForPdf = "PDF-ൽ ഉപയോഗിക്കാൻ കടയുടെ പേര് നൽകുക"
    override val reminderSendAction = "ഓർമ്മപ്പെടുത്തൽ അയയ്ക്കുക"
    override val reminderDialogTitle = "ഉപഭോക്താവിനെ അറിയിക്കുക"
    override val reminderDialogSubtitle = "സന്ദേശം തിരുത്തി WhatsApp അല്ലെങ്കിൽ SMS വഴി അയയ്ക്കുക"
    override val reminderMessageLabel = "സന്ദേശം"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "ഇപ്പോൾ വേണ്ട"
    override val reminderNoPhone = "ഈ ഉപഭോക്താവിന് ഫോൺ നമ്പർ ഇല്ല"
    override val reminderAppMissing = "ആപ്പ് തുറക്കാനായില്ല"
    override val reminderShopFallback = "ഞങ്ങളുടെ കട"
    override val reminderMsgDue = "നമസ്കാരം %1\$s, %2\$s-ലെ അക്കൗണ്ടിൽ നിങ്ങളുടെ ആകെ കുടിശ്ശിക %3\$s ആണ്. ദയവായി സമയത്തിന് അടയ്ക്കുക. നന്ദി."
    override val reminderMsgCredit = "നമസ്കാരം %1\$s, %2\$s-ലെ അക്കൗണ്ടിൽ നിങ്ങളുടെ പുതിയ കടം ചേർത്തിട്ടുണ്ട്. ആകെ കുടിശ്ശിക: %3\$s."
    override val reminderMsgPayment = "നമസ്കാരം %1\$s, നിങ്ങളുടെ പണം കിട്ടി. നന്ദി! %2\$s-ലെ അക്കൗണ്ടിൽ ഇപ്പോഴത്തെ കുടിശ്ശിക: %3\$s."
    override val reminderMsgSettled = "നമസ്കാരം %1\$s, നിങ്ങളുടെ കുടിശ്ശിക മുഴുവൻ തീർന്നു. നന്ദി! — %2\$s"
    override val pdfActionLabel = "📤 എന്ത് ചെയ്യണം"
    override val pdfActionShare = "പങ്കിടുക"
    override val pdfActionSave = "സേവ്"
    override val pdfActionPrint = "പ്രിന്റ്"
    override val pdfBrandingOption = "എന്റെ കടയുടെ പേര്, ലോഗോ, വിലാസം ചേർക്കുക"
    override val pdfBrandingMissing = "കടയുടെ പേര് നൽകിയിട്ടില്ല — കൂടുതൽ → കടയുടെ പ്രൊഫൈലിൽ ചേർക്കുക"
    override val pdfSavedMessage = "PDF സേവ് ചെയ്തു"
    override val pdfSaveFailed = "PDF സേവ് ചെയ്യാനായില്ല"
    override val setupRoleTitle = "നിങ്ങൾ ആപ്പ് എങ്ങനെ ഉപയോഗിക്കും?"
    override val setupProfileTitle = "നിങ്ങളുടെ കടയുടെ വിവരങ്ങൾ"
    override val setupProfileSubtitle = "പിന്നീട് കൂടുതൽ → കടയുടെ പ്രൊഫൈലിൽ മാറ്റാം"
    override val setupContinue = "തുടരുക"
    override val setupSkip = "ഇപ്പോൾ വേണ്ട, പിന്നീട് ചെയ്യാം"
    override val setupFinish = "തുടങ്ങൂ"
    override val pickFromContacts = "കോൺടാക്റ്റുകളിൽ നിന്ന് നമ്പർ തിരഞ്ഞെടുക്കുക"
    override val pdfColQtyPrice = "അളവ് × വില"
    override val pdfColItemTotal = "സാധനത്തിന്റെ തുക"
    override val pdfWoodSawn = "അറുത്ത തടി"
    override val pdfWoodRound = "ഉരുണ്ട തടി"
    override val pdfWoodFormula = "സൂത്രവാക്യം"
    override val pdfWoodTotalWord = "ആകെ"
    override val pdfMemoTitle = "ക്യാഷ് മെമ്മോ"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "ബിൽ നമ്പർ / Bill No"
    override val pdfDateTitle = "തീയതി / Date"
    override val pdfPeriodTitle = "കാലയളവ് / Period"
    override val pdfSeller = "വിൽപ്പനക്കാരൻ / Seller"
    override val pdfBuyer = "വാങ്ങുന്നയാൾ / Buyer"
    override val pdfAddressLabel = "വിലാസം: "
    override val pdfColSl = "ക്രമം"
    override val pdfColPieces = "എണ്ണം"
    override val pdfColCft = "CFT"
    override val pdfColRate = "നിരക്ക് (₹/CFT)"
    override val pdfColAmountRs = "ആകെ (₹)"
    override val pdfColQty = "അളവ്"
    override val pdfColUnitPrice = "നിരക്ക് (₹)"
    override val pdfSecSawn = "അറുത്ത തടി / Sawn Timber"
    override val pdfSecRound = "ഉരുണ്ട തടി / Round Log"
    override val pdfSecOther = "മറ്റ് സാധനങ്ങൾ / Other Items"
    override val pdfSecCashCredit = "പണ കടം / Cash Credit"
    override val pdfSecPayments = "വരവ് / Payments"
    override val pdfBadgeSawn = "അറുത്തത്"
    override val pdfBadgeRound = "ഉരുണ്ടത്"
    override val pdfSawnTotal = "അറുത്ത തടി ആകെ:"
    override val pdfRoundTotal = "ഉരുണ്ട തടി ആകെ:"
    override val pdfTableTotal = "ആകെ:"
    override val pdfSumBill = "ആകെ ബിൽ"
    override val pdfSumPaid = "വരവ്"
    override val pdfSumDue = "കുടിശ്ശിക"
    override val pdfWordsTitle = "തുക അക്ഷരത്തിൽ / Amount in Words:"
    override val pdfSellerSign = "വിൽപ്പനക്കാരന്റെ ഒപ്പും മുദ്രയും"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "വാങ്ങുന്നയാളുടെ ഒപ്പ്"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "ഇത് കമ്പ്യൂട്ടർ നിർമ്മിത ബിൽ ആണ്. ഒപ്പില്ലാതെ സാധുവല്ല."
    override val pdfSummaryTitle = "സംഗ്രഹ റിപ്പോർട്ട്"
    override val moveShopAction = "മറ്റൊരു പട്ടികയിലേക്ക് മാറ്റുക"
    override val moveShopTitle = "മറ്റൊരു പട്ടികയിലേക്ക് മാറ്റണോ?"
    override val moveToShopkeeperMsg = "ഈ എൻട്രി \"ഞാൻ കടക്കാരൻ\" പട്ടികയിലേക്ക് (നിങ്ങളുടെ ഉപഭോക്താവായി) പോകും. തുകകൾ അതേപടി തുടരും, വാക്കുകൾ മാത്രം മാറും."
    override val moveToCustomerMsg = "ഈ എൻട്രി \"ഞാൻ ഉപഭോക്താവ്\" പട്ടികയിലേക്ക് (നിങ്ങൾ കടം വാങ്ങുന്ന കട) പോകും. തുകകൾ അതേപടി തുടരും, വാക്കുകൾ മാത്രം മാറും."
    override val moveShopConfirm = "മാറ്റുക"
    override val faqItems = listOf(
        FaqItem("പുതിയ കട എങ്ങനെ ചേർക്കാം?", "ഹോമിലെ '+' ബട്ടൺ അമർത്തി, കടയുടെ പേര്, ഫോൺ (ഓപ്ഷണൽ), തരം എന്നിവ എഴുതി 'സേവ് ചെയ്യുക' അമർത്തുക."),
        FaqItem("കടമോ വരവോ എങ്ങനെ രേഖപ്പെടുത്താം?", "കടയുടെ പേജ് തുറന്ന് 'കടം വാങ്ങി' അല്ലെങ്കിൽ 'പണം നൽകി' അമർത്തി, തുക എഴുതി സ്ഥിരീകരിക്കുക."),
        FaqItem("ബയോമെട്രിക് ലോക്ക് എങ്ങനെ ഓൺ/ഓഫ് ചെയ്യാം?", "കൂടുതൽ → സുരക്ഷയും സ്വകാര്യതയും എന്നതിൽ 'ബയോമെട്രിക് ലോക്ക്' ഓൺ/ഓഫ് ചെയ്യുക. നിങ്ങളുടെ ഫോണിൽ ഫിംഗർപ്രിന്റോ ഫേസ് അൺലോക്കോ സജ്ജമാക്കിയിരിക്കണം."),
        FaqItem("ഡാറ്റ ബാക്കപ്പ് എങ്ങനെ എടുക്കാം?", "കൂടുതൽ → ബാക്കപ്പ് & റീസ്റ്റോർ എന്നതിൽ 'ഇപ്പോൾ ബാക്കപ്പ് എടുക്കുക' അമർത്തുക. ഇത് ഒരു JSON ഫയൽ ഉണ്ടാക്കും; അത് ഫോണിലോ ക്ലൗഡിലോ സേവ് ചെയ്യാം."),
        FaqItem("ബാക്കപ്പിൽ നിന്ന് എങ്ങനെ റീസ്റ്റോർ ചെയ്യാം?", "കൂടുതൽ → ബാക്കപ്പ് & റീസ്റ്റോർ എന്നതിൽ 'ബാക്കപ്പിൽ നിന്ന് റീസ്റ്റോർ ചെയ്യുക' അമർത്തി നിങ്ങളുടെ JSON ഫയൽ തിരഞ്ഞെടുക്കുക. ഇത് നിലവിലെ ഡാറ്റ മുഴുവൻ മാറ്റും, അതിനാൽ ശ്രദ്ധിക്കുക."),
        FaqItem("കട ഇല്ലാതാക്കിയാൽ തിരികെ കിട്ടുമോ?", "ആർക്കൈവ് ചെയ്താൽ അത് ചരിത്രത്തിൽ നിലനിൽക്കും, പിന്നീട് തിരികെ കൊണ്ടുവരാം. എന്നെന്നേക്കുമായി ഇല്ലാതാക്കിയാൽ തിരികെ കിട്ടില്ല."),
        FaqItem("PDF റിപ്പോർട്ട് എങ്ങനെ ഉണ്ടാക്കാം?", "'കൂടുതൽ' പേജിൽ ബാക്കപ്പ് & റീസ്റ്റോറിനടുത്ത് എക്സ്പോർട്ട് ഓപ്ഷൻ ഉണ്ട്; കടയും തീയതി പരിധിയും തിരഞ്ഞെടുത്ത് PDF പങ്കിടുക."),
        FaqItem("ആപ്പിന്റെ ഭാഷ എങ്ങനെ മാറ്റാം?", "കൂടുതൽ → ഭാഷ എന്നതിൽ നിങ്ങളുടെ ഭാഷ തിരഞ്ഞെടുത്ത് 'സേവ് ചെയ്യുക' അമർത്തുക.")
    )
    override val privacyPolicyBody = """ഉധാർ ഹിസാബ് ഒരു വ്യക്തിഗത സാമ്പത്തിക/കണക്കുപുസ്തക ആപ്പാണ്; കടയിലെ കടം, കുടിശ്ശിക, ഇടപാടുകൾ എന്നിവ എളുപ്പത്തിൽ കൈകാര്യം ചെയ്യാൻ ഇത് സഹായിക്കുന്നു. നിങ്ങളുടെ സ്വകാര്യത ഞങ്ങൾക്ക് പ്രധാനമാണ്.

1. ഞങ്ങൾ ശേഖരിക്കുന്ന വിവരങ്ങൾ

ഉധാർ ഹിസാബ് ഉപയോഗിക്കുമ്പോൾ നിങ്ങൾ തന്നെ ആപ്പിൽ നൽകുന്ന വിവരങ്ങൾ, ഉദാഹരണത്തിന്:
• കടയുടെ പേര്
• മൊബൈൽ നമ്പർ
• കടയുടെ വിലാസം അല്ലെങ്കിൽ മറ്റ് വിവരങ്ങൾ
• കടത്തിന്റെയും വരവിന്റെയും തുകകൾ
• ഇടപാടിന്റെ തീയതി, സമയം, കുറിപ്പ്

2. വിവരങ്ങളുടെ ഉപയോഗം

ഈ വിവരങ്ങൾ നിങ്ങളുടെ കണക്കുകൾ സൂക്ഷിക്കാനും കാണിക്കാനും കൈകാര്യം ചെയ്യാനും മാത്രമാണ് ഉപയോഗിക്കുന്നത്. നിങ്ങളുടെ വ്യക്തിഗത കണക്കുപുസ്തക ഡാറ്റ നിങ്ങളുടെ അനുമതിയില്ലാതെ ഒരു പരസ്യദാതാവിനോ മൂന്നാം കക്ഷിക്കോ വിൽക്കുകയോ പങ്കിടുകയോ ചെയ്യില്ല.

3. ഡാറ്റ സംഭരണം

ആപ്പിന്റെ ആവശ്യമനുസരിച്ച് നിങ്ങളുടെ കണക്ക് ഡാറ്റ നിങ്ങളുടെ ഉപകരണത്തിൽ സൂക്ഷിക്കാം. ബാക്കപ്പ് & റീസ്റ്റോർ സൗകര്യം ഉപയോഗിച്ചാൽ, നിങ്ങൾ തിരഞ്ഞെടുത്ത സ്റ്റോറേജ്/ക്ലൗഡ് സേവനത്തിൽ ബാക്കപ്പ് ഡാറ്റ സൂക്ഷിക്കാം.

4. ആപ്പ് സുരക്ഷ

നിങ്ങളുടെ കണക്ക് ഡാറ്റ സുരക്ഷിതമാക്കാൻ ആപ്പ് ലോക്ക്, PIN, ബയോമെട്രിക് സ്ഥിരീകരണം തുടങ്ങിയ സുരക്ഷാ സൗകര്യങ്ങൾ നൽകിയേക്കാം.

5. വിവരങ്ങൾ പങ്കിടൽ

നിയമപ്രകാരം ആവശ്യമുള്ളപ്പോൾ ഒഴികെ, നിങ്ങളുടെ വ്യക്തിഗത കണക്കുപുസ്തക ഡാറ്റ ഞങ്ങൾ മൂന്നാം കക്ഷികൾക്ക് വിൽക്കുകയോ വാടകയ്ക്ക് നൽകുകയോ വാണിജ്യ ആവശ്യങ്ങൾക്ക് പങ്കിടുകയോ ചെയ്യില്ല.

6. നിങ്ങളുടെ നിയന്ത്രണം

ആപ്പിൽ സൂക്ഷിച്ച നിങ്ങളുടെ ഡാറ്റ നിങ്ങൾക്ക് എപ്പോൾ വേണമെങ്കിലും കാണാനും മാറ്റാനും ഇല്ലാതാക്കാനും കഴിയും.

7. മൂന്നാം കക്ഷി സേവനങ്ങൾ

ആപ്പിലെ ചില സൗകര്യങ്ങൾക്ക് മൂന്നാം കക്ഷി സേവനങ്ങൾ ഉപയോഗിച്ചാൽ, അവയുടെ സ്വന്തം സ്വകാര്യതാ നയം ബാധകമായേക്കാം.

8. കുട്ടികളുടെ സ്വകാര്യത

ഉധാർ ഹിസാബ് അറിഞ്ഞുകൊണ്ട് കുട്ടികളിൽ നിന്ന് വ്യക്തിഗത വിവരങ്ങൾ ശേഖരിക്കാൻ രൂപകൽപ്പന ചെയ്തതല്ല.

9. ഈ സ്വകാര്യതാ നയത്തിലെ മാറ്റങ്ങൾ

ആവശ്യാനുസരണം ഞങ്ങൾ ഈ സ്വകാര്യതാ നയം മാറ്റുകയോ പുതുക്കുകയോ ചെയ്തേക്കാം. പുതിയ നയം ഈ പേജിൽ പ്രസിദ്ധീകരിക്കും.

10. ബന്ധപ്പെടുക

ഈ സ്വകാര്യതാ നയത്തെക്കുറിച്ചോ നിങ്ങളുടെ ഡാറ്റയെക്കുറിച്ചോ എന്തെങ്കിലും ചോദ്യങ്ങളുണ്ടെങ്കിൽ ദയവായി ഞങ്ങളെ ബന്ധപ്പെടുക.

ഉധാർ ഹിസാബ്
എളുപ്പമുള്ള കണക്ക്, ആശങ്കയില്ലാതെ ഇരിക്കൂ."""
}

/** Punjabi (ਪੰਜਾਬੀ) */
object PunjabiStrings : AppStrings {
    override val code = "pa"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "ਇਸ਼ਤਿਹਾਰ ਹਟਾਓ"
    override val moreHintAdFree = "ਇੱਕ ਵਾਰ ਖਰੀਦੋ, ਫਿਰ ਇਸ਼ਤਿਹਾਰ ਨਹੀਂ"
    override val adFreeDialogTitle = "ਇਸ਼ਤਿਹਾਰ-ਮੁਕਤ ਐਪ"
    override val adFreeDialogMessage = "ਇੱਕ ਵਾਰ ਪੈਸੇ ਦੇਣ 'ਤੇ ਸਾਰੇ ਇਸ਼ਤਿਹਾਰ ਹਮੇਸ਼ਾ ਲਈ ਬੰਦ ਹੋ ਜਾਣਗੇ। ਐਪ ਦਾ ਸਾਥ ਦੇਣ ਲਈ ਧੰਨਵਾਦ!"
    override val adFreeBuyButton = "ਖਰੀਦੋ"
    override val adFreeRestoreButton = "ਪਿਛਲੀ ਖਰੀਦ ਵਾਪਸ ਲਿਆਓ"
    override val adFreeActiveLabel = "ਤੁਹਾਡੀ ਐਪ ਇਸ਼ਤਿਹਾਰ-ਮੁਕਤ ਹੈ ✓"
    override val adFreeUnavailable = "ਹੁਣ ਖਰੀਦਣਾ ਸੰਭਵ ਨਹੀਂ — ਬਾਅਦ ਵਿੱਚ ਕੋਸ਼ਿਸ਼ ਕਰੋ"
    override val adSponsoredLabel = "ਇਸ਼ਤਿਹਾਰ"
    override val moreAdPrivacy = "ਇਸ਼ਤਿਹਾਰ ਪਸੰਦ"
    override val moreHintAdPrivacy = "ਤੈਅ ਕਰੋ ਕਿ ਤੁਸੀਂ ਕਿਸ ਤਰ੍ਹਾਂ ਦੇ ਇਸ਼ਤਿਹਾਰ ਦੇਖੋ"
    override val helpCenterTitle = "ਮਦਦ ਕੇਂਦਰ"
    override val helpSearchPlaceholder = "ਸਵਾਲ ਲੱਭੋ..."
    override val noFaqResultsMessage = "ਕੁਝ ਨਹੀਂ ਮਿਲਿਆ"
    override val homeHeadline = "ਉਧਾਰ ਹਿਸਾਬ"
    override val history = "ਇਤਿਹਾਸ"
    override val settings = "ਸੈਟਿੰਗਾਂ"
    override val totalDueLabel = "ਕੁੱਲ ਬਕਾਇਆ"
    override val thisMonthCreditLabel = "ਇਸ ਮਹੀਨੇ ਦਾ ਬਕਾਇਆ"
    override val thisMonthPaymentLabel = "ਇਸ ਮਹੀਨੇ ਮਿਲਿਆ"
    override val searchPlaceholder = "ਦੁਕਾਨ/ਫ਼ੋਨ ਲੱਭੋ..."
    override val filterAll = "ਸਾਰੇ"
    override val settledLabel = "ਚੁਕਤਾ"
    override val noShopsYetTitle = "ਹਾਲੇ ਕੋਈ ਦੁਕਾਨ ਨਹੀਂ"
    override val noShopsYetSubtitle = "ਖਾਤਾ ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਪਹਿਲੀ ਦੁਕਾਨ ਜੋੜੋ"
    override val addFirstShopButton = "ਪਹਿਲੀ ਦੁਕਾਨ ਜੋੜੋ"
    override val newShop = "ਨਵੀਂ ਦੁਕਾਨ"
    override val shopTypeTea = "ਚਾਹ ਦੀ ਦੁਕਾਨ"
    override val shopTypeHardwareElectric = "ਹਾਰਡਵੇਅਰ ਅਤੇ ਇਲੈਕਟ੍ਰਿਕ"
    override val shopTypeKirana = "ਕਰਿਆਨੇ ਦੀ ਦੁਕਾਨ"
    override val shopTypeVegetable = "ਸਬਜ਼ੀ ਦੀ ਦੁਕਾਨ"
    override val shopTypeFishMeat = "ਮੱਛੀ ਅਤੇ ਮੀਟ"
    override val shopTypeBakerySweets = "ਬੇਕਰੀ ਅਤੇ ਮਿਠਾਈ"
    override val shopTypePharmacy = "ਦਵਾਈਆਂ ਦੀ ਦੁਕਾਨ"
    override val shopTypeCosmetics = "ਸ਼ਿੰਗਾਰ ਸਮਾਨ"
    override val shopTypeStationery = "ਸਟੇਸ਼ਨਰੀ"
    override val shopTypeXeroxPrinting = "ਜ਼ੀਰੌਕਸ ਅਤੇ ਪ੍ਰਿੰਟਿੰਗ"
    override val shopTypeWood = "ਲੱਕੜ ਦੀ ਦੁਕਾਨ"
    override val shopTypeGarments = "ਕੱਪੜਿਆਂ ਦੀ ਦੁਕਾਨ"
    override val shopTypeOther = "ਹੋਰ"
    override val back = "ਪਿੱਛੇ"
    override val cancel = "ਰੱਦ ਕਰੋ"
    override val save = "ਸੇਵ ਕਰੋ"
    override val shopNameLabel = "ਦੁਕਾਨ ਦਾ ਨਾਮ *"
    override val shopNamePlaceholder = "ਜਿਵੇਂ ਲੱਕੜ ਮਹਿਲ"
    override val phoneLabel = "ਫ਼ੋਨ ਨੰਬਰ (ਵਿਕਲਪਿਕ)"
    override val shopTypeLabel = "ਦੁਕਾਨ ਦੀ ਕਿਸਮ *"
    override val saveShopButton = "ਦੁਕਾਨ ਸੇਵ ਕਰੋ"
    override val errorNameRequired = "ਦੁਕਾਨ ਦਾ ਨਾਮ ਲਿਖੋ"
    override val errorTypeRequired = "ਦੁਕਾਨ ਦੀ ਕਿਸਮ ਚੁਣੋ"
    override val dueLabel = "ਬਕਾਇਆ"
    override val noTransactionsYet = "ਹਾਲੇ ਕੋਈ ਲੈਣ-ਦੇਣ ਨਹੀਂ"
    override val creditButton = "ਉਧਾਰ ਲਿਆ"
    override val paymentButton = "ਪੈਸੇ ਭਰੇ"
    override val pdfExport = "PDF ਐਕਸਪੋਰਟ"
    override val archive = "ਆਰਕਾਈਵ"
    override val deleteShopAction = "ਦੁਕਾਨ ਹਟਾਓ"
    override val archiveConfirmTitle = "ਇਹ ਦੁਕਾਨ ਆਰਕਾਈਵ ਕਰਨੀ ਹੈ?"
    override val archiveConfirmText = "ਇਹ ਹੋਮ ਦੀ ਸੂਚੀ ਵਿੱਚੋਂ ਹਟ ਜਾਵੇਗੀ — ਇਤਿਹਾਸ ਵਿੱਚ ਹਾਲੇ ਵੀ ਮਿਲੇਗੀ।"
    override val deleteConfirmTitle = "ਇਹ ਦੁਕਾਨ ਹਮੇਸ਼ਾ ਲਈ ਹਟਾਉਣੀ ਹੈ?"
    override val deleteConfirmText = "ਇਹ ਦੁਕਾਨ ਅਤੇ ਇਸਦੇ ਸਾਰੇ ਲੈਣ-ਦੇਣ ਹਮੇਸ਼ਾ ਲਈ ਮਿਟ ਜਾਣਗੇ ਅਤੇ ਵਾਪਸ ਨਹੀਂ ਆਉਣਗੇ। ਆਰਕਾਈਵ ਕਰਨ 'ਤੇ ਇਹ ਇਤਿਹਾਸ ਵਿੱਚ ਰਹੇਗੀ — ਅੱਗੇ ਵਧਣ ਤੋਂ ਪਹਿਲਾਂ ਚੰਗੀ ਤਰ੍ਹਾਂ ਸੋਚੋ।"
    override val yesDelete = "ਹਾਂ, ਹਟਾਓ"
    override val yesArchive = "ਆਰਕਾਈਵ ਕਰੋ"
    override val txnDeletedSnackbar = "ਲੈਣ-ਦੇਣ ਹਟਾਇਆ ਗਿਆ"
    override val undo = "ਵਾਪਸ ਲਿਆਓ"
    override val pdfFailPrefix = "PDF ਨਹੀਂ ਬਣ ਸਕੀ: "
    override val shareKhata = "ਖਾਤਾ ਸਾਂਝਾ ਕਰੋ"
    override val creditFallback = "ਉਧਾਰ"
    override val paymentFallback = "ਜਮ੍ਹਾਂ"
    override val deleteTxnAction = "ਹਟਾਓ"
    override val productNameLabel = "ਵਸਤੂ ਦਾ ਨਾਮ (ਵਿਕਲਪਿਕ)"
    override val quantityLabel = "ਮਾਤਰਾ"
    override val unitLabel = "ਇਕਾਈ"
    override val pricePerUnitLabel = "ਭਾਅ/ਇਕਾਈ"
    override val totalPrefix = "ਕੁੱਲ: "
    override val amountLabel = "ਭਰੀ ਹੋਈ ਰਕਮ"
    override val orEnterAmountLabel = "ਜਾਂ ਸਿੱਧੀ ਰਕਮ ਲਿਖੋ"
    override val noteLabel = "ਨੋਟ (ਵਿਕਲਪਿਕ)"
    override val cash = "ਨਕਦ"
    override val bkash = "bKash"
    override val bank = "ਬੈਂਕ"
    override val invalidAmountError = "ਸਹੀ ਰਕਮ ਲਿਖੋ"
    override val cftCalculatorTitle = "CFT ਕੈਲਕੁਲੇਟਰ"
    override val lengthLabel = "ਲੰਬਾਈ (ਇੰਚ)"
    override val widthLabel = "ਚੌੜਾਈ"
    override val heightLabel = "ਉਚਾਈ"
    override val rateLabel = "ਭਾਅ /cft (₹)"
    override val applyToEntryButton = "ਐਂਟਰੀ ਵਿੱਚ ਜੋੜੋ"
    override val settingsTitle = "ਸੈਟਿੰਗਾਂ"
    override val security = "ਸੁਰੱਖਿਆ"
    override val pinLockOn = "PIN ਲਾਕ ਚਾਲੂ ਹੈ"
    override val pinLockOff = "PIN ਲਾਕ ਬੰਦ ਹੈ"
    override val changePin = "PIN ਬਦਲੋ"
    override val reminderTitle = "ਬਕਾਏ ਦੀ ਯਾਦ"
    override val reminderDesc = "ਹਰ ਰੋਜ਼ ਬਕਾਏ ਦੀ ਯਾਦ ਦਿਵਾਉਂਦਾ ਹੈ"
    override val about = "ਜਾਣਕਾਰੀ"
    override val aboutLine = "ਉਧਾਰ ਹਿਸਾਬ — ਦੁਕਾਨ ਦਾ ਉਧਾਰ ਖਾਤਾ"
    override val aboutDescription = "ਉਧਾਰ ਹਿਸਾਬ ਇੱਕ ਸਮਾਰਟ ਹਿਸਾਬ ਐਪ ਹੈ ਜੋ ਦੁਕਾਨ ਦੇ ਉਧਾਰ, ਬਕਾਏ ਅਤੇ ਲੈਣ-ਦੇਣ ਨੂੰ ਆਸਾਨੀ ਨਾਲ, ਤੇਜ਼ੀ ਨਾਲ ਅਤੇ ਸਲੀਕੇ ਨਾਲ ਸੰਭਾਲਣ ਵਿੱਚ ਮਦਦ ਕਰਦੀ ਹੈ। ਕਿਸ ਦੁਕਾਨ ਵਿੱਚ ਕਿੰਨਾ ਬਕਾਇਆ ਹੈ, ਕਿੱਥੇ ਪੈਸੇ ਭਰੇ ਅਤੇ ਕਿਹੜਾ ਲੈਣ-ਦੇਣ ਕਦੋਂ ਹੋਇਆ — ਸਭ ਕੁਝ ਇੱਕੋ ਥਾਂ ਸੁਚੱਜੇ ਢੰਗ ਨਾਲ ਸੰਭਾਲਿਆ ਜਾ ਸਕਦਾ ਹੈ।\n\nਇਸ ਐਪ ਵਿੱਚ ਤੁਸੀਂ ਆਸਾਨੀ ਨਾਲ ਦੁਕਾਨਾਂ ਜੋੜ ਸਕਦੇ ਹੋ, ਉਧਾਰ ਅਤੇ ਜਮ੍ਹਾਂ ਦਰਜ ਕਰ ਸਕਦੇ ਹੋ, ਲੈਣ-ਦੇਣ ਦਾ ਇਤਿਹਾਸ ਦੇਖ ਸਕਦੇ ਹੋ, ਕੁੱਲ ਬਕਾਇਆ ਅਤੇ ਜਮ੍ਹਾਂ ਜਾਂਚ ਸਕਦੇ ਹੋ ਅਤੇ ਵਿਸਤ੍ਰਿਤ ਰਿਪੋਰਟਾਂ ਬਣਾ ਸਕਦੇ ਹੋ। ਖੋਜ, ਫਿਲਟਰ, ਬੈਕਅੱਪ ਅਤੇ ਰੀਸਟੋਰ, ਐਪ ਲਾਕ, ਬਾਇਓਮੈਟ੍ਰਿਕ ਸੁਰੱਖਿਆ, ਡਾਰਕ ਮੋਡ ਅਤੇ ਨੋਟੀਫਿਕੇਸ਼ਨ ਵਰਗੀਆਂ ਸਹੂਲਤਾਂ ਹਿਸਾਬ ਸੰਭਾਲਣਾ ਹੋਰ ਵੀ ਆਸਾਨ ਅਤੇ ਸੁਰੱਖਿਅਤ ਬਣਾਉਂਦੀਆਂ ਹਨ।\n\nਕਾਗਜ਼ੀ ਵਹੀ ਦੀਆਂ ਉਲਝਣਾਂ ਨੂੰ ਸਰਲ, ਆਧੁਨਿਕ ਅਤੇ ਭਰੋਸੇਮੰਦ ਡਿਜੀਟਲ ਤਰੀਕੇ ਵਿੱਚ ਲਿਆਉਣਾ ਹੀ ਉਧਾਰ ਹਿਸਾਬ ਦਾ ਮਕਸਦ ਹੈ।"
    override val aboutTagline = "ਉਧਾਰ ਹਿਸਾਬ — ਸੌਖਾ ਹਿਸਾਬ, ਬੇਫ਼ਿਕਰ ਰਹੋ।"
    override val versionLine = "ਵਰਜਨ 1.0"
    override val setPinTitle = "PIN ਸੈੱਟ ਕਰੋ"
    override val newPinLabel = "ਨਵਾਂ PIN"
    override val confirmPinLabel = "PIN ਦੁਬਾਰਾ ਲਿਖੋ"
    override val pinSetupError = "PIN ਮੇਲ ਨਹੀਂ ਖਾਂਦੇ (ਘੱਟੋ-ਘੱਟ 4 ਅੰਕ)"
    override val removePinTitle = "PIN ਲਾਕ ਬੰਦ ਕਰਨਾ ਹੈ?"
    override val removePinText = "ਹੁਣ ਐਪ ਖੋਲ੍ਹਣ ਵੇਲੇ PIN ਨਹੀਂ ਪੁੱਛਿਆ ਜਾਵੇਗਾ।"
    override val yesTurnOff = "ਹਾਂ, ਬੰਦ ਕਰੋ"
    override val no = "ਨਹੀਂ"
    override val languageTitle = "ਭਾਸ਼ਾ"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "ਨੋਟੀਫਿਕੇਸ਼ਨ"
    override val notifSheetSubtitle = "ਤੁਹਾਨੂੰ ਕਿਹੜੀਆਂ ਯਾਦਾਂ ਚਾਹੀਦੀਆਂ ਹਨ?"
    override val notifDueReminderOption = "ਬਕਾਇਆ ਭਰਨ ਦੀ ਯਾਦ"
    override val notifWeeklySummaryOption = "ਹਫ਼ਤਾਵਾਰੀ ਸਾਰ"
    override val notifAppNewsOption = "ਐਪ ਦੀਆਂ ਖ਼ਬਰਾਂ ਅਤੇ ਅੱਪਡੇਟ"
    override val langSheetSubtitle = "ਐਪ ਕਿਸ ਭਾਸ਼ਾ ਵਿੱਚ ਚਲਾਉਣੀ ਹੈ?"
    override val themeSheetSubtitle = "ਤੁਹਾਨੂੰ ਕਿਹੜੀ ਥੀਮ ਪਸੰਦ ਹੈ?"
    override val securityPrivacyTitle = "ਸੁਰੱਖਿਆ ਅਤੇ ਗੋਪਨੀਯਤਾ"
    override val pinSectionTitle = "PIN ਲਾਕ"
    override val pinSectionDesc = "ਐਪ ਖੋਲ੍ਹਣ ਵੇਲੇ PIN ਪੁੱਛੋ"
    override val fingerprintTitle = "ਫਿੰਗਰਪ੍ਰਿੰਟ ਲਾਕ"
    override val fingerprintDesc = "PIN ਦੀ ਥਾਂ ਫਿੰਗਰਪ੍ਰਿੰਟ ਨਾਲ ਖੋਲ੍ਹੋ"
    override val fingerprintUnavailable = "ਇਸ ਫ਼ੋਨ ਵਿੱਚ ਫਿੰਗਰਪ੍ਰਿੰਟ ਸੈਂਸਰ ਨਹੀਂ ਮਿਲਿਆ"
    override val lockImmediatelyTitle = "ਤੁਰੰਤ ਲਾਕ ਕਰੋ"
    override val lockImmediatelyDesc = "ਐਪ ਵਿੱਚ ਵਾਪਸ ਆਉਂਦੇ ਹੀ ਮੁੜ ਲਾਕ ਹੋ ਜਾਵੇਗੀ"
    override val rateTitle = "ਰੇਟਿੰਗ ਅਤੇ ਫੀਡਬੈਕ"
    override val rateSubtitle = "ਉਧਾਰ ਹਿਸਾਬ ਤੁਹਾਨੂੰ ਕਿਵੇਂ ਲੱਗ ਰਿਹਾ ਹੈ?"
    override val rateStarsPrompt = "ਰੇਟਿੰਗ ਦੇਣ ਲਈ ਟੈਪ ਕਰੋ"
    override val rateThanksMessage = "ਧੰਨਵਾਦ! ਤੁਹਾਨੂੰ Play Store ਲੈ ਜਾ ਰਹੇ ਹਾਂ…"
    override val feedbackPromptLow = "ਤੁਹਾਨੂੰ ਕੀ ਪਸੰਦ ਨਹੀਂ ਆਇਆ? ਸਾਨੂੰ ਦੱਸੋ"
    override val feedbackPlaceholder = "ਆਪਣੀ ਫੀਡਬੈਕ ਲਿਖੋ…"
    override val feedbackSubmit = "ਭੇਜੋ"
    override val feedbackThanks = "ਧੰਨਵਾਦ, ਤੁਹਾਡੀ ਫੀਡਬੈਕ ਭੇਜ ਦਿੱਤੀ ਗਈ"
    override val aboutPageTitle = "ਉਧਾਰ ਹਿਸਾਬ ਬਾਰੇ"
    override val aboutVersionPrefix = "ਵਰਜਨ"
    override val aboutDeveloperLabel = "ਡਿਵੈਲਪਰ"
    override val aboutDeveloperName = "ਉਧਾਰ ਹਿਸਾਬ ਟੀਮ"
    override val aboutPrivacyPolicy = "ਗੋਪਨੀਯਤਾ ਨੀਤੀ"
    override val privacyPolicyEffectiveDate = "ਲਾਗੂ ਹੋਣ ਦੀ ਮਿਤੀ: 13 ਸਤੰਬਰ 2026"
    override val aboutShareApp = "ਸਾਂਝਾ ਕਰੋ"
    override val aboutShareText = "ਉਧਾਰ ਹਿਸਾਬ — ਦੁਕਾਨ ਦੇ ਉਧਾਰ ਖਾਤੇ ਦੀ ਇਹ ਐਪ ਅਜ਼ਮਾ ਕੇ ਦੇਖੋ!"
    override val noArchivedShops = "ਕੋਈ ਆਰਕਾਈਵ ਕੀਤੀ ਦੁਕਾਨ ਨਹੀਂ"
    override val noSettledShops = "ਕੋਈ ਚੁਕਤਾ ਹੋਈ ਦੁਕਾਨ ਨਹੀਂ"
    override val setupPinTitle = "4 ਅੰਕਾਂ ਦਾ PIN ਸੈੱਟ ਕਰੋ"
    override val unlockPinTitle = "PIN ਨਾਲ ਖੋਲ੍ਹੋ"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 ਅੰਕ ਲਿਖੋ"
    override val pinsDontMatchError = "PIN ਮੇਲ ਨਹੀਂ ਖਾਂਦੇ"
    override val wrongPinError = "PIN ਗਲਤ ਹੈ — ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ"
    override val savePinButton = "PIN ਸੇਵ ਕਰੋ"
    override val unlockButton = "ਖੋਲ੍ਹੋ"
    override val pdfHeaderTitle = "ਖਾਤਾ — ਉਧਾਰ ਹਿਸਾਬ"
    override val pdfFullKhataSuffix = "ਪੂਰਾ ਖਾਤਾ"
    override val pdfShopLabel = "ਦੁਕਾਨ: "
    override val pdfPhoneLabel = "ਫ਼ੋਨ: "
    override val pdfCreatedLabel = "ਬਣਾਇਆ: "
    override val pdfColDate = "ਮਿਤੀ/ਸਮਾਂ"
    override val pdfColDesc = "ਵੇਰਵਾ"
    override val pdfTotalCredit = "ਕੁੱਲ ਉਧਾਰ:"
    override val pdfTotalPayment = "ਕੁੱਲ ਜਮ੍ਹਾਂ:"
    override val pdfCurrentDue = "ਮੌਜੂਦਾ ਬਕਾਇਆ:"
    override val pdfFooter = "ਉਧਾਰ ਹਿਸਾਬ ਐਪ ਤੋਂ ਬਣਾਇਆ"
    override val navHome = "ਹੋਮ"
    override val navHistory = "ਇਤਿਹਾਸ"
    override val navReports = "ਰਿਪੋਰਟ"
    override val navMore = "ਹੋਰ"
    override val historyFilterAllShops = "ਸਾਰੀਆਂ ਦੁਕਾਨਾਂ"
    override val historyFilterAllTypes = "ਸਾਰੇ"
    override val historyFilterCreditOnly = "ਸਿਰਫ਼ ਉਧਾਰ"
    override val historyFilterPaymentOnly = "ਸਿਰਫ਼ ਜਮ੍ਹਾਂ"
    override val historyNoTxnsFound = "ਕੋਈ ਲੈਣ-ਦੇਣ ਨਹੀਂ ਮਿਲਿਆ"
    override val viewArchivedAction = "ਆਰਕਾਈਵ ਕੀਤੀਆਂ ਦੁਕਾਨਾਂ ਦੇਖੋ"
    override val reportsTitle = "ਰਿਪੋਰਟ"
    override val periodLabel = "ਸਮਾਂ-ਸੀਮਾ"
    override val period7d = "ਪਿਛਲੇ 7 ਦਿਨ"
    override val period15d = "ਪਿਛਲੇ 15 ਦਿਨ"
    override val period30d = "ਪਿਛਲੇ 30 ਦਿਨ"
    override val period3m = "ਪਿਛਲੇ 3 ਮਹੀਨੇ"
    override val period1y = "ਇਹ ਸਾਲ"
    override val reportTotalCredit = "ਕੁੱਲ ਉਧਾਰ"
    override val reportTotalPayment = "ਕੁੱਲ ਜਮ੍ਹਾਂ"
    override val reportCurrentDue = "ਮੌਜੂਦਾ ਕੁੱਲ ਬਕਾਇਆ"
    override val reportTxnCount = "ਲੈਣ-ਦੇਣ"
    override val reportChartTitle = "ਉਧਾਰ ਬਨਾਮ ਜਮ੍ਹਾਂ"
    override val reportShopWiseTitle = "ਦੁਕਾਨ ਮੁਤਾਬਕ ਬਕਾਇਆ"
    override val reportAgingTitle = "ਬਕਾਏ ਦੀ ਉਮਰ"
    override val reportAging0to7 = "0–7 ਦਿਨ"
    override val reportAging7to15 = "7–15 ਦਿਨ"
    override val reportAging15to30 = "15–30 ਦਿਨ"
    override val reportAging30plus = "30+ ਦਿਨ"
    override val reportRecentPaymentsTitle = "ਹਾਲੀਆ ਜਮ੍ਹਾਂ"
    override val reportNoData = "ਇਸ ਸਮੇਂ ਦੀ ਕੋਈ ਜਾਣਕਾਰੀ ਨਹੀਂ"
    override val reportSmartSummaryPrefix = "ਇਸ ਸਮੇਂ ਵਿੱਚ ਤੁਸੀਂ"
    override val moreTitle = "ਹੋਰ"
    override val moreBackupRestore = "ਬੈਕਅੱਪ ਅਤੇ ਰੀਸਟੋਰ"
    override val moreHintBackupRestore = "ਆਪਣਾ ਡਾਟਾ ਸੁਰੱਖਿਅਤ ਰੱਖੋ"
    override val notesTitle = "ਨੋਟ"
    override val notesSearchPlaceholder = "ਨੋਟ ਲੱਭੋ..."
    override val addNoteButton = "ਨਵਾਂ ਨੋਟ"
    override val noNotesYetTitle = "ਹਾਲੇ ਕੋਈ ਨੋਟ ਨਹੀਂ"
    override val noNotesYetSubtitle = "ਖਰੀਦਦਾਰੀ ਦੀ ਸੂਚੀ, ਯਾਦਾਂ — ਕੁਝ ਵੀ ਲਿਖ ਕੇ ਰੱਖੋ"
    override val deleteNoteConfirmTitle = "ਇਹ ਨੋਟ ਹਟਾਉਣਾ ਹੈ?"
    override val deleteNoteConfirmMessage = "ਇਹ ਨੋਟ ਹਮੇਸ਼ਾ ਲਈ ਹਟਾ ਦਿੱਤਾ ਜਾਵੇਗਾ।"
    override val noteTitlePlaceholder = "ਸਿਰਲੇਖ"
    override val noteContentPlaceholder = "ਕੁਝ ਲਿਖੋ..."
    override val untitledNote = "ਬਿਨਾਂ ਸਿਰਲੇਖ ਵਾਲਾ ਨੋਟ"
    override val notificationInboxTitle = "ਨੋਟੀਫਿਕੇਸ਼ਨ"
    override val moreNotificationHistory = "ਨੋਟੀਫਿਕੇਸ਼ਨ ਇਤਿਹਾਸ"
    override val moreHintNotificationHistory = "ਹਾਲੀਆ ਗਤੀਵਿਧੀ ਦੇਖੋ"
    override val noNotificationsYetTitle = "ਹਾਲੇ ਕੋਈ ਨੋਟੀਫਿਕੇਸ਼ਨ ਨਹੀਂ"
    override val noNotificationsYetSubtitle = "ਉਧਾਰ ਜਾਂ ਜਮ੍ਹਾਂ ਦਰਜ ਕਰੋਗੇ ਤਾਂ ਇੱਥੇ ਦਿਖੇਗਾ"
    override val notifCreditMessage = "%1\$s ਤੋਂ %2\$s ਉਧਾਰ ਲਿਆ"
    override val notifPaymentMessage = "%1\$s ਨੂੰ %2\$s ਜਮ੍ਹਾਂ ਕੀਤੇ"
    override val moreQuickCalculator = "ਕਵਿੱਕ ਕੈਲਕੁਲੇਟਰ"
    override val moreHintQuickCalculator = "ਝੱਟਪਟ ਹਿਸਾਬ ਕਰੋ"
    override val calcGeneralTab = "ਆਮ"
    override val calcPercentTab = "ਫ਼ੀਸਦੀ"
    override val calcConversionTab = "ਬਦਲਾਅ"
    override val calcComingSoonInTab = "ਜਲਦੀ ਆ ਰਿਹਾ ਹੈ"
    override val percentOfTitle = "ਕਿਸੇ ਸੰਖਿਆ ਦਾ ਫ਼ੀਸਦੀ"
    override val percentOfValueLabel = "ਸੰਖਿਆ"
    override val percentOfPercentLabel = "ਫ਼ੀਸਦੀ (%)"
    override val percentIsWhatTitle = "ਇੱਕ ਸੰਖਿਆ ਦੂਜੀ ਦਾ ਕਿੰਨਾ ਫ਼ੀਸਦੀ ਹੈ"
    override val percentIsWhatXLabel = "ਇਹ ਸੰਖਿਆ"
    override val percentIsWhatYLabel = "ਇਸ ਦੇ"
    override val percentChangeTitle = "ਫ਼ੀਸਦੀ ਵਾਧਾ/ਘਾਟਾ"
    override val percentChangeBaseLabel = "ਮੂਲ ਸੰਖਿਆ"
    override val percentChangePercentLabel = "ਫ਼ੀਸਦੀ (%)"
    override val increaseOption = "ਵਾਧਾ"
    override val decreaseOption = "ਘਾਟਾ"
    override val resultLabel = "ਨਤੀਜਾ"
    override val weightCategory = "ਵਜ਼ਨ"
    override val lengthCategory = "ਲੰਬਾਈ"
    override val volumeCategory = "ਆਇਤਨ"
    override val fromLabel = "ਤੋਂ"
    override val toLabel = "ਤੱਕ"
    override val enterValueHint = "ਮੁੱਲ ਲਿਖੋ"
    override val backupNowButton = "ਹੁਣੇ ਬੈਕਅੱਪ ਲਓ"
    override val backupNowHint = "ਸਾਰੀਆਂ ਦੁਕਾਨਾਂ ਅਤੇ ਲੈਣ-ਦੇਣ JSON ਫ਼ਾਈਲ ਵਿੱਚ ਸੇਵ ਕਰੋ"
    override val restoreButton = "ਬੈਕਅੱਪ ਤੋਂ ਰੀਸਟੋਰ ਕਰੋ"
    override val restoreShopAction = "ਰੀਸਟੋਰ"
    override val restoreHint = "ਪੁਰਾਣੀ JSON ਬੈਕਅੱਪ ਫ਼ਾਈਲ ਤੋਂ ਡਾਟਾ ਵਾਪਸ ਲਿਆਓ"
    override val lastBackupLabel = "ਆਖ਼ਰੀ ਬੈਕਅੱਪ"
    override val noBackupYetLabel = "ਹਾਲੇ ਬੈਕਅੱਪ ਨਹੀਂ ਲਿਆ"
    override val backupSuccessMessage = "ਬੈਕਅੱਪ ਬਣ ਗਿਆ"
    override val backupFailPrefix = "ਬੈਕਅੱਪ ਅਸਫ਼ਲ: "
    override val restoreConfirmTitle = "ਬੈਕਅੱਪ ਰੀਸਟੋਰ ਕਰਨਾ ਹੈ?"
    override val restoreConfirmMessage = "ਇਸ ਨਾਲ ਮੌਜੂਦਾ ਸਾਰੀਆਂ ਦੁਕਾਨਾਂ ਅਤੇ ਲੈਣ-ਦੇਣ ਮਿਟ ਜਾਣਗੇ ਅਤੇ ਬੈਕਅੱਪ ਫ਼ਾਈਲ ਦਾ ਡਾਟਾ ਆ ਜਾਵੇਗਾ। ਇਸਨੂੰ ਵਾਪਸ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਦਾ।"
    override val restoreSuccessMessage = "ਰੀਸਟੋਰ ਪੂਰਾ ਹੋਇਆ"
    override val restoreFailPrefix = "ਰੀਸਟੋਰ ਅਸਫ਼ਲ: "
    override val dataSafeNote = "ਤੁਹਾਡਾ ਡਾਟਾ ਸਿਰਫ਼ ਇਸ ਫ਼ੋਨ ਵਿੱਚ ਹੀ ਰਹਿੰਦਾ ਹੈ — ਬੈਕਅੱਪ ਫ਼ਾਈਲ ਆਪ ਸੁਰੱਖਿਅਤ ਰੱਖੋ"
    override val moreExportShare = "ਐਕਸਪੋਰਟ ਅਤੇ ਸਾਂਝਾ ਕਰੋ"
    override val moreHintExportShare = "PDF ਅਤੇ ਫ਼ਾਈਲਾਂ ਭੇਜੋ"
    override val moreNotifications = "ਨੋਟੀਫਿਕੇਸ਼ਨ"
    override val moreHintNotifications = "ਯਾਦਾਂ ਚਾਲੂ/ਬੰਦ ਕਰੋ"
    override val moreLanguage = "ਭਾਸ਼ਾ"
    override val moreHintLanguage = "ਆਪਣੀ ਭਾਸ਼ਾ ਚੁਣੋ"
    override val moreUserMode = "ਮੈਂ ਕੌਣ ਹਾਂ"
    override val moreHintUserMode = "ਗਾਹਕ ਜਾਂ ਦੁਕਾਨਦਾਰ"
    override val moreSecurityPrivacy = "ਸੁਰੱਖਿਆ ਅਤੇ ਗੋਪਨੀਯਤਾ"
    override val moreHintSecurityPrivacy = "PIN ਅਤੇ ਫਿੰਗਰਪ੍ਰਿੰਟ ਲਾਕ"
    override val moreAppearance = "ਦਿੱਖ"
    override val moreHintAppearance = "ਲਾਈਟ, ਡਾਰਕ ਜਾਂ ਸਿਸਟਮ"
    override val moreRateFeedback = "ਰੇਟਿੰਗ ਅਤੇ ਫੀਡਬੈਕ"
    override val moreHintRateFeedback = "ਆਪਣੀ ਰਾਏ ਦੱਸੋ"
    override val moreAbout = "ਉਧਾਰ ਹਿਸਾਬ ਬਾਰੇ"
    override val moreHintAbout = "ਵਰਜਨ ਅਤੇ ਡਿਵੈਲਪਰ"
    override val comingSoonMessage = "ਜਲਦੀ ਆ ਰਿਹਾ ਹੈ"
    override val appearanceTitle = "ਦਿੱਖ"
    override val themeLight = "ਲਾਈਟ"
    override val themeDark = "ਡਾਰਕ"
    override val themeSystem = "ਸਿਸਟਮ ਡਿਫਾਲਟ"
    override val creditPageTitle = "ਉਧਾਰ ਲਓ"
    override val accountingTypeLabel = "ਐਂਟਰੀ ਦੀ ਕਿਸਮ"
    override val directMoneyMode = "ਸਿੱਧੀ ਰਕਮ"
    override val productMode = "ਵਸਤੂ ਮੁਤਾਬਕ"
    override val directMoneyAmountLabel = "ਕਿੰਨਾ ਉਧਾਰ ਦਿੱਤਾ?"
    override val previousDueLabel = "ਪਿਛਲਾ ਬਕਾਇਆ"
    override val newCreditLabel = "ਨਵਾਂ ਉਧਾਰ"
    override val newTotalDueLabel = "ਨਵਾਂ ਕੁੱਲ ਬਕਾਇਆ"
    override val addCreditButton = "ਉਧਾਰ ਜੋੜੋ"
    override val addMoreProductButton = "+ ਇੱਕ ਹੋਰ ਵਸਤੂ ਜੋੜੋ"
    override val totalNewCreditLabel = "ਕੁੱਲ ਨਵਾਂ ਉਧਾਰ"
    override val editAction = "ਬਦਲੋ"
    override val itemsCountSuffix = "ਵਸਤੂਆਂ"
    override val paymentPageTitle = "ਜਮ੍ਹਾਂ"
    override val currentDueLabel = "ਮੌਜੂਦਾ ਬਕਾਇਆ"
    override val howMuchPaymentLabel = "ਕਿੰਨਾ ਜਮ੍ਹਾਂ ਕਰ ਰਹੇ ਹੋ?"
    override val fullPaymentButton = "ਪੂਰੀ ਰਕਮ"
    override val dueAfterPaymentLabel = "ਜਮ੍ਹਾਂ ਤੋਂ ਬਾਅਦ ਬਕਾਇਆ"
    override val addPaymentButton = "ਜਮ੍ਹਾਂ ਜੋੜੋ"
    override val overpaymentBlockedMessage = "ਮੌਜੂਦਾ ਬਕਾਏ ਤੋਂ ਵੱਧ ਜਮ੍ਹਾਂ ਨਹੀਂ ਹੋ ਸਕਦਾ"
    override val fullyPaidCelebration = "ਇਸ ਨਾਲ ਪੂਰਾ ਬਕਾਇਆ ਚੁਕਤਾ ਹੋ ਜਾਵੇਗਾ"
    override val woodCalculatorTitle = "ਲੱਕੜ ਕੈਲਕੁਲੇਟਰ"
    override val woodTypeLabel = "ਲੱਕੜ ਦੀ ਕਿਸਮ"
    override val sawnWoodOption = "ਚੀਰੀ ਹੋਈ ਲੱਕੜ"
    override val roundWoodOption = "ਗੋਲ ਲੱਠ"
    override val lengthFtLabel = "ਲੰਬਾਈ (ਫੁੱਟ)"
    override val widthInLabel = "ਚੌੜਾਈ (ਇੰਚ)"
    override val thicknessInLabel = "ਮੋਟਾਈ (ਇੰਚ)"
    override val girthInLabel = "ਘੇਰਾ (ਇੰਚ)"
    override val pieceCountLabel = "ਟੁਕੜਿਆਂ ਦੀ ਗਿਣਤੀ"
    override val perPieceCftLabel = "ਪ੍ਰਤੀ ਟੁਕੜਾ"
    override val totalWoodCftLabel = "ਕੁੱਲ ਲੱਕੜ"
    override val perCftPriceLabel = "ਪ੍ਰਤੀ CFT ਭਾਅ (₹)"
    override val totalWoodValueLabel = "ਕੁੱਲ ਕੀਮਤ"
    override val addWoodCalcButton = "ਇਹ ਲੱਕੜ ਦਾ ਹਿਸਾਬ ਜੋੜੋ"
    override val woodNameLabel = "ਵਸਤੂ ਦਾ ਨਾਮ"
    override val addMoreWoodProductButton = "+ ਇੱਕ ਹੋਰ ਲੱਕੜ/ਵਸਤੂ ਜੋੜੋ"
    override val addedItemsHeader = "ਜੋੜੀਆਂ ਵਸਤੂਆਂ/ਲੱਕੜ"
    override val pdfOptionsTitle = "PDF ਵਿਕਲਪ"
    override val pdfPeriodLabel = "ਸਮਾਂ-ਸੀਮਾ"
    override val pdfThisMonth = "ਇਹ ਮਹੀਨਾ"
    override val pdfLastMonth = "ਪਿਛਲਾ ਮਹੀਨਾ"
    override val pdfLast3Months = "ਪਿਛਲੇ 3 ਮਹੀਨੇ"
    override val pdfCustomRange = "ਆਪਣੀਆਂ ਤਾਰੀਖਾਂ"
    override val pdfShopLabelOption = "ਦੁਕਾਨ"
    override val pdfAllShopsOption = "ਸਾਰੀਆਂ ਦੁਕਾਨਾਂ"
    override val pdfContentLabel = "ਕੀ ਦਿਖਾਉਣਾ ਹੈ"
    override val pdfContentFull = "ਸਭ ਕੁਝ (ਲੈਣ-ਦੇਣ + ਸਾਰ + ਦਸਤਖ਼ਤ)"
    override val pdfContentSummaryOnly = "ਸਿਰਫ਼ ਸਾਰ"
    override val pdfContentTxnsOnly = "ਸਿਰਫ਼ ਲੈਣ-ਦੇਣ"
    override val pdfFormatLabel = "ਫਾਰਮੈਟ"
    override val pdfFormatA4 = "A4 ਰਿਪੋਰਟ"
    override val pdfFormatReceipt = "ਰਸੀਦ (58mm)"
    override val pdfGenerateButton = "PDF ਬਣਾਓ"
    override val pdfFromDateLabel = "ਸ਼ੁਰੂ ਦੀ ਤਾਰੀਖ"
    override val pdfToDateLabel = "ਆਖ਼ਰੀ ਤਾਰੀਖ"
    override val pdfReportNumberLabel = "ਰਿਪੋਰਟ ਨੰ."
    override val pdfShopBoxLabel = "ਦੁਕਾਨ"
    override val pdfDateBoxLabel = "ਤਾਰੀਖ"
    override val pdfDaysOfRecordsSuffix = "ਦਿਨਾਂ ਦਾ ਰਿਕਾਰਡ"
    override val pdfWeeklyChartTitle = "ਹਫ਼ਤਾਵਾਰੀ ਉਧਾਰ (ਲਾਲ) ਬਨਾਮ ਜਮ੍ਹਾਂ (ਹਰਾ)"
    override val pdfFinalDueLabel = "ਮੌਜੂਦਾ ਬਕਾਇਆ"
    override val pdfShopSignatureLabel = "ਦੁਕਾਨਦਾਰ ਦੇ ਦਸਤਖ਼ਤ"
    override val pdfCustomerSignatureLabel = "ਗਾਹਕ ਦੇ ਦਸਤਖ਼ਤ"
    override val pdfAllShopsReportTitle = "ਸਾਰੀਆਂ ਦੁਕਾਨਾਂ ਦਾ ਸਾਰ — ਉਧਾਰ ਹਿਸਾਬ"
    override val pdfPageLabel = "ਸਫ਼ਾ"
    override val moreShopProfile = "ਦੁਕਾਨ ਦੀ ਪ੍ਰੋਫਾਈਲ"
    override val moreHintShopProfile = "ਨਾਮ, ਲੋਗੋ, ਪਤਾ, ਯਾਦ"
    override val shopProfileTitle = "ਦੁਕਾਨ ਦੀ ਪ੍ਰੋਫਾਈਲ"
    override val shopProfileIntro = "ਇਹ ਜਾਣਕਾਰੀ PDF ਇਨਵੌਇਸ ਅਤੇ ਗਾਹਕ ਨੂੰ ਭੇਜੇ ਸੁਨੇਹਿਆਂ ਵਿੱਚ ਵਰਤੀ ਜਾਵੇਗੀ"
    override val shopBusinessNameLabel = "ਦੁਕਾਨ ਦਾ ਨਾਮ"
    override val shopBusinessAddressLabel = "ਦੁਕਾਨ ਦਾ ਪਤਾ"
    override val shopBusinessPhoneLabel = "ਦੁਕਾਨ ਦਾ ਫ਼ੋਨ ਨੰਬਰ"
    override val countryCodeLabel = "ਦੇਸ਼ ਦਾ ਕੋਡ (ਜਿਵੇਂ 91)"
    override val shopLogoLabel = "ਦੁਕਾਨ ਦਾ ਲੋਗੋ"
    override val shopLogoPick = "ਲੋਗੋ ਚੁਣੋ"
    override val shopLogoRemove = "ਲੋਗੋ ਹਟਾਓ"
    override val promptAfterEntryLabel = "ਐਂਟਰੀ ਤੋਂ ਬਾਅਦ ਗਾਹਕ ਨੂੰ ਦੱਸਣ ਦਾ ਵਿਕਲਪ ਦਿਖਾਓ"
    override val saveProfileButton = "ਪ੍ਰੋਫਾਈਲ ਸੇਵ ਕਰੋ"
    override val profileSavedMessage = "ਪ੍ਰੋਫਾਈਲ ਸੇਵ ਹੋ ਗਈ"
    override val errorShopNameForPdf = "PDF ਵਿੱਚ ਵਰਤਣ ਲਈ ਦੁਕਾਨ ਦਾ ਨਾਮ ਦਿਓ"
    override val reminderSendAction = "ਯਾਦ ਭੇਜੋ"
    override val reminderDialogTitle = "ਗਾਹਕ ਨੂੰ ਦੱਸੋ"
    override val reminderDialogSubtitle = "ਸੁਨੇਹਾ ਬਦਲ ਕੇ WhatsApp ਜਾਂ SMS ਰਾਹੀਂ ਭੇਜੋ"
    override val reminderMessageLabel = "ਸੁਨੇਹਾ"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "ਹੁਣੇ ਨਹੀਂ"
    override val reminderNoPhone = "ਇਸ ਗਾਹਕ ਦਾ ਫ਼ੋਨ ਨੰਬਰ ਨਹੀਂ ਹੈ"
    override val reminderAppMissing = "ਐਪ ਖੁੱਲ੍ਹ ਨਹੀਂ ਸਕੀ"
    override val reminderShopFallback = "ਸਾਡੀ ਦੁਕਾਨ"
    override val reminderMsgDue = "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ %1\$s ਜੀ, %2\$s ਦੇ ਖਾਤੇ ਵਿੱਚ ਤੁਹਾਡਾ ਕੁੱਲ ਬਕਾਇਆ %3\$s ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਸਮੇਂ ਸਿਰ ਭਰ ਦਿਓ। ਧੰਨਵਾਦ।"
    override val reminderMsgCredit = "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ %1\$s ਜੀ, %2\$s ਦੇ ਖਾਤੇ ਵਿੱਚ ਤੁਹਾਡਾ ਨਵਾਂ ਉਧਾਰ ਜੋੜਿਆ ਗਿਆ ਹੈ। ਕੁੱਲ ਬਕਾਇਆ: %3\$s।"
    override val reminderMsgPayment = "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ %1\$s ਜੀ, ਤੁਹਾਡੇ ਪੈਸੇ ਮਿਲ ਗਏ। ਧੰਨਵਾਦ! %2\$s ਦੇ ਖਾਤੇ ਵਿੱਚ ਮੌਜੂਦਾ ਬਕਾਇਆ: %3\$s।"
    override val reminderMsgSettled = "ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ %1\$s ਜੀ, ਤੁਹਾਡਾ ਸਾਰਾ ਬਕਾਇਆ ਚੁਕਤਾ ਹੋ ਗਿਆ ਹੈ। ਧੰਨਵਾਦ! — %2\$s"
    override val pdfActionLabel = "📤 ਕੀ ਕਰਨਾ ਹੈ"
    override val pdfActionShare = "ਸਾਂਝਾ ਕਰੋ"
    override val pdfActionSave = "ਸੇਵ"
    override val pdfActionPrint = "ਪ੍ਰਿੰਟ"
    override val pdfBrandingOption = "ਮੇਰੀ ਦੁਕਾਨ ਦਾ ਨਾਮ, ਲੋਗੋ ਅਤੇ ਪਤਾ ਜੋੜੋ"
    override val pdfBrandingMissing = "ਦੁਕਾਨ ਦਾ ਨਾਮ ਨਹੀਂ ਦਿੱਤਾ — ਹੋਰ → ਦੁਕਾਨ ਦੀ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ ਜਾ ਕੇ ਜੋੜੋ"
    override val pdfSavedMessage = "PDF ਸੇਵ ਹੋ ਗਈ"
    override val pdfSaveFailed = "PDF ਸੇਵ ਨਹੀਂ ਹੋ ਸਕੀ"
    override val setupRoleTitle = "ਤੁਸੀਂ ਐਪ ਕਿਵੇਂ ਵਰਤੋਗੇ?"
    override val setupProfileTitle = "ਤੁਹਾਡੀ ਦੁਕਾਨ ਦੀ ਜਾਣਕਾਰੀ"
    override val setupProfileSubtitle = "ਬਾਅਦ ਵਿੱਚ ਹੋਰ → ਦੁਕਾਨ ਦੀ ਪ੍ਰੋਫਾਈਲ ਤੋਂ ਬਦਲ ਸਕਦੇ ਹੋ"
    override val setupContinue = "ਅੱਗੇ ਵਧੋ"
    override val setupSkip = "ਹੁਣੇ ਨਹੀਂ, ਬਾਅਦ ਵਿੱਚ ਕਰਾਂਗਾ"
    override val setupFinish = "ਸ਼ੁਰੂ ਕਰੋ"
    override val pickFromContacts = "ਸੰਪਰਕਾਂ ਵਿੱਚੋਂ ਨੰਬਰ ਚੁਣੋ"
    override val pdfColQtyPrice = "ਮਾਤਰਾ × ਭਾਅ"
    override val pdfColItemTotal = "ਵਸਤੂ ਦੀ ਰਕਮ"
    override val pdfWoodSawn = "ਚੀਰੀ ਹੋਈ ਲੱਕੜ"
    override val pdfWoodRound = "ਗੋਲ ਲੱਠ"
    override val pdfWoodFormula = "ਸੂਤਰ"
    override val pdfWoodTotalWord = "ਕੁੱਲ"
    override val pdfMemoTitle = "ਕੈਸ਼ ਮੀਮੋ"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "ਬਿੱਲ ਨੰ. / Bill No"
    override val pdfDateTitle = "ਤਾਰੀਖ / Date"
    override val pdfPeriodTitle = "ਸਮਾਂ-ਸੀਮਾ / Period"
    override val pdfSeller = "ਵੇਚਣ ਵਾਲਾ / Seller"
    override val pdfBuyer = "ਖਰੀਦਦਾਰ / Buyer"
    override val pdfAddressLabel = "ਪਤਾ: "
    override val pdfColSl = "ਲੜੀ ਨੰ."
    override val pdfColPieces = "ਨਗ"
    override val pdfColCft = "CFT"
    override val pdfColRate = "ਭਾਅ (₹/CFT)"
    override val pdfColAmountRs = "ਕੁੱਲ (₹)"
    override val pdfColQty = "ਮਾਤਰਾ"
    override val pdfColUnitPrice = "ਭਾਅ (₹)"
    override val pdfSecSawn = "ਚੀਰੀ ਹੋਈ ਲੱਕੜ / Sawn Timber"
    override val pdfSecRound = "ਗੋਲ ਲੱਠ / Round Log"
    override val pdfSecOther = "ਹੋਰ ਵਸਤੂਆਂ / Other Items"
    override val pdfSecCashCredit = "ਨਕਦ ਉਧਾਰ / Cash Credit"
    override val pdfSecPayments = "ਜਮ੍ਹਾਂ / Payments"
    override val pdfBadgeSawn = "ਚੀਰੀ"
    override val pdfBadgeRound = "ਗੋਲ"
    override val pdfSawnTotal = "ਚੀਰੀ ਲੱਕੜ ਦਾ ਕੁੱਲ:"
    override val pdfRoundTotal = "ਗੋਲ ਲੱਠ ਦਾ ਕੁੱਲ:"
    override val pdfTableTotal = "ਕੁੱਲ:"
    override val pdfSumBill = "ਕੁੱਲ ਬਿੱਲ"
    override val pdfSumPaid = "ਜਮ੍ਹਾਂ"
    override val pdfSumDue = "ਬਕਾਇਆ"
    override val pdfWordsTitle = "ਰਕਮ ਅੱਖਰਾਂ ਵਿੱਚ / Amount in Words:"
    override val pdfSellerSign = "ਵੇਚਣ ਵਾਲੇ ਦੇ ਦਸਤਖ਼ਤ ਅਤੇ ਮੋਹਰ"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "ਖਰੀਦਦਾਰ ਦੇ ਦਸਤਖ਼ਤ"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "ਇਹ ਕੰਪਿਊਟਰ ਦੁਆਰਾ ਬਣਾਇਆ ਬਿੱਲ ਹੈ। ਦਸਤਖ਼ਤ ਤੋਂ ਬਿਨਾਂ ਮਾਨਤਾ ਨਹੀਂ।"
    override val pdfSummaryTitle = "ਸਾਰ ਰਿਪੋਰਟ"
    override val moveShopAction = "ਦੂਜੀ ਸੂਚੀ ਵਿੱਚ ਭੇਜੋ"
    override val moveShopTitle = "ਦੂਜੀ ਸੂਚੀ ਵਿੱਚ ਭੇਜਣਾ ਹੈ?"
    override val moveToShopkeeperMsg = "ਇਹ ਐਂਟਰੀ \"ਮੈਂ ਦੁਕਾਨਦਾਰ ਹਾਂ\" ਸੂਚੀ ਵਿੱਚ (ਤੁਹਾਡੇ ਗਾਹਕ ਵਜੋਂ) ਚਲੀ ਜਾਵੇਗੀ। ਰਕਮਾਂ ਉਹੀ ਰਹਿਣਗੀਆਂ, ਸਿਰਫ਼ ਸ਼ਬਦ ਬਦਲਣਗੇ।"
    override val moveToCustomerMsg = "ਇਹ ਐਂਟਰੀ \"ਮੈਂ ਗਾਹਕ ਹਾਂ\" ਸੂਚੀ ਵਿੱਚ (ਜਿਸ ਦੁਕਾਨ ਤੋਂ ਤੁਸੀਂ ਉਧਾਰ ਲੈਂਦੇ ਹੋ) ਚਲੀ ਜਾਵੇਗੀ। ਰਕਮਾਂ ਉਹੀ ਰਹਿਣਗੀਆਂ, ਸਿਰਫ਼ ਸ਼ਬਦ ਬਦਲਣਗੇ।"
    override val moveShopConfirm = "ਭੇਜੋ"
    override val faqItems = listOf(
        FaqItem("ਨਵੀਂ ਦੁਕਾਨ ਕਿਵੇਂ ਜੋੜੀਏ?", "ਹੋਮ 'ਤੇ '+' ਬਟਨ ਦਬਾਓ, ਦੁਕਾਨ ਦਾ ਨਾਮ, ਫ਼ੋਨ (ਵਿਕਲਪਿਕ) ਅਤੇ ਕਿਸਮ ਲਿਖੋ, ਫਿਰ 'ਸੇਵ ਕਰੋ' ਦਬਾਓ।"),
        FaqItem("ਉਧਾਰ ਜਾਂ ਜਮ੍ਹਾਂ ਕਿਵੇਂ ਦਰਜ ਕਰੀਏ?", "ਦੁਕਾਨ ਦਾ ਪੰਨਾ ਖੋਲ੍ਹੋ ਅਤੇ 'ਉਧਾਰ ਲਿਆ' ਜਾਂ 'ਪੈਸੇ ਭਰੇ' ਦਬਾਓ, ਰਕਮ ਲਿਖੋ ਅਤੇ ਪੁਸ਼ਟੀ ਕਰੋ।"),
        FaqItem("ਬਾਇਓਮੈਟ੍ਰਿਕ ਲਾਕ ਕਿਵੇਂ ਚਾਲੂ/ਬੰਦ ਕਰੀਏ?", "ਹੋਰ → ਸੁਰੱਖਿਆ ਅਤੇ ਗੋਪਨੀਯਤਾ ਵਿੱਚ ਜਾ ਕੇ 'ਬਾਇਓਮੈਟ੍ਰਿਕ ਲਾਕ' ਚਾਲੂ/ਬੰਦ ਕਰੋ। ਤੁਹਾਡੇ ਫ਼ੋਨ ਵਿੱਚ ਫਿੰਗਰਪ੍ਰਿੰਟ ਜਾਂ ਫੇਸ ਅਨਲਾਕ ਸੈੱਟ ਹੋਣਾ ਜ਼ਰੂਰੀ ਹੈ।"),
        FaqItem("ਡਾਟੇ ਦਾ ਬੈਕਅੱਪ ਕਿਵੇਂ ਲਈਏ?", "ਹੋਰ → ਬੈਕਅੱਪ ਅਤੇ ਰੀਸਟੋਰ ਵਿੱਚ ਜਾ ਕੇ 'ਹੁਣੇ ਬੈਕਅੱਪ ਲਓ' ਦਬਾਓ। ਇਸ ਨਾਲ ਇੱਕ JSON ਫ਼ਾਈਲ ਬਣਦੀ ਹੈ, ਜੋ ਤੁਸੀਂ ਫ਼ੋਨ ਜਾਂ ਕਲਾਊਡ ਵਿੱਚ ਸੇਵ ਕਰ ਸਕਦੇ ਹੋ।"),
        FaqItem("ਬੈਕਅੱਪ ਤੋਂ ਡਾਟਾ ਵਾਪਸ ਕਿਵੇਂ ਲਿਆਈਏ?", "ਹੋਰ → ਬੈਕਅੱਪ ਅਤੇ ਰੀਸਟੋਰ ਵਿੱਚ ਜਾ ਕੇ 'ਬੈਕਅੱਪ ਤੋਂ ਰੀਸਟੋਰ ਕਰੋ' ਦਬਾਓ ਅਤੇ ਆਪਣੀ JSON ਫ਼ਾਈਲ ਚੁਣੋ। ਇਸ ਨਾਲ ਮੌਜੂਦਾ ਸਾਰਾ ਡਾਟਾ ਬਦਲ ਜਾਂਦਾ ਹੈ, ਇਸ ਲਈ ਸਾਵਧਾਨ ਰਹੋ।"),
        FaqItem("ਦੁਕਾਨ ਹਟਾ ਦਿੱਤੀ ਤਾਂ ਵਾਪਸ ਮਿਲੇਗੀ?", "ਆਰਕਾਈਵ ਕਰਨ 'ਤੇ ਇਹ ਇਤਿਹਾਸ ਵਿੱਚ ਰਹਿੰਦੀ ਹੈ ਅਤੇ ਬਾਅਦ ਵਿੱਚ ਵਾਪਸ ਲਿਆਂਦੀ ਜਾ ਸਕਦੀ ਹੈ। ਹਮੇਸ਼ਾ ਲਈ ਹਟਾਉਣ 'ਤੇ ਵਾਪਸ ਨਹੀਂ ਮਿਲਦੀ।"),
        FaqItem("PDF ਰਿਪੋਰਟ ਕਿਵੇਂ ਬਣਾਈਏ?", "'ਹੋਰ' ਪੰਨੇ 'ਤੇ ਬੈਕਅੱਪ ਅਤੇ ਰੀਸਟੋਰ ਦੇ ਕੋਲ ਐਕਸਪੋਰਟ ਦਾ ਵਿਕਲਪ ਹੈ, ਦੁਕਾਨ ਅਤੇ ਮਿਤੀ ਦੀ ਸੀਮਾ ਚੁਣੋ ਅਤੇ PDF ਸਾਂਝਾ ਕਰੋ।"),
        FaqItem("ਐਪ ਦੀ ਭਾਸ਼ਾ ਕਿਵੇਂ ਬਦਲੀਏ?", "ਹੋਰ → ਭਾਸ਼ਾ ਵਿੱਚ ਜਾ ਕੇ ਆਪਣੀ ਭਾਸ਼ਾ ਚੁਣੋ ਅਤੇ 'ਸੇਵ ਕਰੋ' ਦਬਾਓ।")
    )
    override val privacyPolicyBody = """ਉਧਾਰ ਹਿਸਾਬ ਇੱਕ ਨਿੱਜੀ ਵਿੱਤੀ/ਖਾਤਾ ਵਹੀ ਐਪ ਹੈ, ਜੋ ਤੁਹਾਨੂੰ ਦੁਕਾਨ ਦੇ ਉਧਾਰ, ਬਕਾਏ ਅਤੇ ਲੈਣ-ਦੇਣ ਆਸਾਨੀ ਨਾਲ ਸੰਭਾਲਣ ਵਿੱਚ ਮਦਦ ਕਰਦੀ ਹੈ। ਤੁਹਾਡੀ ਗੋਪਨੀਯਤਾ ਸਾਡੇ ਲਈ ਮਹੱਤਵਪੂਰਨ ਹੈ।

1. ਅਸੀਂ ਕਿਹੜੀ ਜਾਣਕਾਰੀ ਇਕੱਠੀ ਕਰਦੇ ਹਾਂ

ਉਧਾਰ ਹਿਸਾਬ ਵਰਤਦੇ ਸਮੇਂ ਤੁਸੀਂ ਆਪ ਐਪ ਵਿੱਚ ਜੋ ਜਾਣਕਾਰੀ ਭਰਦੇ ਹੋ, ਜਿਵੇਂ:
• ਦੁਕਾਨ ਦਾ ਨਾਮ
• ਮੋਬਾਈਲ ਨੰਬਰ
• ਦੁਕਾਨ ਦਾ ਪਤਾ ਜਾਂ ਹੋਰ ਵੇਰਵੇ
• ਉਧਾਰ ਅਤੇ ਜਮ੍ਹਾਂ ਰਕਮਾਂ
• ਲੈਣ-ਦੇਣ ਦੀ ਮਿਤੀ, ਸਮਾਂ ਅਤੇ ਨੋਟ

2. ਜਾਣਕਾਰੀ ਦੀ ਵਰਤੋਂ

ਇਹ ਜਾਣਕਾਰੀ ਸਿਰਫ਼ ਤੁਹਾਡੇ ਹਿਸਾਬ ਸੰਭਾਲਣ, ਦਿਖਾਉਣ ਅਤੇ ਚਲਾਉਣ ਲਈ ਵਰਤੀ ਜਾਂਦੀ ਹੈ। ਤੁਹਾਡਾ ਨਿੱਜੀ ਖਾਤਾ ਵਹੀ ਡਾਟਾ ਤੁਹਾਡੀ ਇਜਾਜ਼ਤ ਤੋਂ ਬਿਨਾਂ ਕਿਸੇ ਇਸ਼ਤਿਹਾਰਦਾਤਾ ਜਾਂ ਤੀਜੀ ਧਿਰ ਨੂੰ ਵੇਚਿਆ ਜਾਂ ਸਾਂਝਾ ਨਹੀਂ ਕੀਤਾ ਜਾਵੇਗਾ।

3. ਡਾਟਾ ਸਟੋਰੇਜ

ਐਪ ਦੀ ਲੋੜ ਮੁਤਾਬਕ ਤੁਹਾਡਾ ਹਿਸਾਬ ਡਾਟਾ ਤੁਹਾਡੇ ਡਿਵਾਈਸ 'ਤੇ ਸੰਭਾਲਿਆ ਜਾ ਸਕਦਾ ਹੈ। ਜੇ ਤੁਸੀਂ ਬੈਕਅੱਪ ਅਤੇ ਰੀਸਟੋਰ ਸਹੂਲਤ ਵਰਤਦੇ ਹੋ, ਤਾਂ ਤੁਹਾਡਾ ਬੈਕਅੱਪ ਡਾਟਾ ਤੁਹਾਡੇ ਚੁਣੇ ਸਟੋਰੇਜ/ਕਲਾਊਡ ਰਾਹੀਂ ਸੰਭਾਲਿਆ ਜਾ ਸਕਦਾ ਹੈ।

4. ਐਪ ਸੁਰੱਖਿਆ

ਤੁਹਾਡੇ ਹਿਸਾਬ ਡਾਟੇ ਨੂੰ ਸੁਰੱਖਿਅਤ ਰੱਖਣ ਲਈ ਐਪ ਲਾਕ, PIN ਅਤੇ ਬਾਇਓਮੈਟ੍ਰਿਕ ਪ੍ਰਮਾਣਿਕਤਾ ਵਰਗੀਆਂ ਸੁਰੱਖਿਆ ਸਹੂਲਤਾਂ ਦਿੱਤੀਆਂ ਜਾ ਸਕਦੀਆਂ ਹਨ।

5. ਜਾਣਕਾਰੀ ਸਾਂਝੀ ਕਰਨਾ

ਕਾਨੂੰਨ ਮੁਤਾਬਕ ਲੋੜ ਹੋਣ ਤੋਂ ਸਿਵਾ, ਅਸੀਂ ਤੁਹਾਡਾ ਨਿੱਜੀ ਖਾਤਾ ਵਹੀ ਡਾਟਾ ਤੀਜੀਆਂ ਧਿਰਾਂ ਨੂੰ ਨਹੀਂ ਵੇਚਦੇ, ਕਿਰਾਏ 'ਤੇ ਨਹੀਂ ਦਿੰਦੇ ਜਾਂ ਵਪਾਰਕ ਮਕਸਦ ਲਈ ਸਾਂਝਾ ਨਹੀਂ ਕਰਦੇ।

6. ਤੁਹਾਡਾ ਕੰਟਰੋਲ

ਐਪ ਵਿੱਚ ਸੰਭਾਲਿਆ ਤੁਹਾਡਾ ਡਾਟਾ ਤੁਸੀਂ ਜਦੋਂ ਚਾਹੋ ਦੇਖ, ਬਦਲ ਜਾਂ ਹਟਾ ਸਕਦੇ ਹੋ।

7. ਤੀਜੀ ਧਿਰ ਦੀਆਂ ਸੇਵਾਵਾਂ

ਐਪ ਦੀਆਂ ਕੁਝ ਸਹੂਲਤਾਂ ਲਈ ਤੀਜੀ ਧਿਰ ਦੀਆਂ ਸੇਵਾਵਾਂ ਵਰਤੀਆਂ ਜਾਣ ਤਾਂ ਉਨ੍ਹਾਂ ਦੀ ਆਪਣੀ ਗੋਪਨੀਯਤਾ ਨੀਤੀ ਲਾਗੂ ਹੋ ਸਕਦੀ ਹੈ।

8. ਬੱਚਿਆਂ ਦੀ ਗੋਪਨੀਯਤਾ

ਉਧਾਰ ਹਿਸਾਬ ਜਾਣ-ਬੁੱਝ ਕੇ ਬੱਚਿਆਂ ਤੋਂ ਨਿੱਜੀ ਜਾਣਕਾਰੀ ਇਕੱਠੀ ਕਰਨ ਲਈ ਨਹੀਂ ਬਣਾਈ ਗਈ।

9. ਇਸ ਗੋਪਨੀਯਤਾ ਨੀਤੀ ਵਿੱਚ ਤਬਦੀਲੀਆਂ

ਅਸੀਂ ਲੋੜ ਮੁਤਾਬਕ ਇਸ ਗੋਪਨੀਯਤਾ ਨੀਤੀ ਨੂੰ ਬਦਲ ਜਾਂ ਅੱਪਡੇਟ ਕਰ ਸਕਦੇ ਹਾਂ। ਕੋਈ ਵੀ ਨਵੀਂ ਨੀਤੀ ਇਸ ਸਫ਼ੇ 'ਤੇ ਪ੍ਰਕਾਸ਼ਿਤ ਕੀਤੀ ਜਾਵੇਗੀ।

10. ਸੰਪਰਕ

ਇਸ ਗੋਪਨੀਯਤਾ ਨੀਤੀ ਜਾਂ ਤੁਹਾਡੇ ਡਾਟੇ ਬਾਰੇ ਕੋਈ ਸਵਾਲ ਹੋਵੇ ਤਾਂ ਕਿਰਪਾ ਕਰਕੇ ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ।

ਉਧਾਰ ਹਿਸਾਬ
ਸੌਖਾ ਹਿਸਾਬ, ਬੇਫ਼ਿਕਰ ਰਹੋ।"""
}

/** Odia (ଓଡ଼ିଆ) */
object OdiaStrings : AppStrings {
    override val code = "or"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "ବିଜ୍ଞାପନ ହଟାନ୍ତୁ"
    override val moreHintAdFree = "ଥରେ କିଣନ୍ତୁ, ଆଉ ବିଜ୍ଞାପନ ନାହିଁ"
    override val adFreeDialogTitle = "ବିଜ୍ଞାପନମୁକ୍ତ ଆପ୍"
    override val adFreeDialogMessage = "ଥରେ ଟଙ୍କା ଦେଲେ ସମସ୍ତ ବିଜ୍ଞାପନ ସଦାପାଇଁ ବନ୍ଦ ହେବ। ଆପ୍‌କୁ ସହଯୋଗ ପାଇଁ ଧନ୍ୟବାଦ!"
    override val adFreeBuyButton = "କିଣନ୍ତୁ"
    override val adFreeRestoreButton = "ପୂର୍ବ କିଣାକିଣି ଫେରାନ୍ତୁ"
    override val adFreeActiveLabel = "ଆପଣଙ୍କ ଆପ୍ ବିଜ୍ଞାପନମୁକ୍ତ ✓"
    override val adFreeUnavailable = "ଏବେ କିଣିହେବ ନାହିଁ — ପରେ ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ"
    override val adSponsoredLabel = "ବିଜ୍ଞାପନ"
    override val moreAdPrivacy = "ବିଜ୍ଞାପନ ପସନ୍ଦ"
    override val moreHintAdPrivacy = "ଆପଣ କେଉଁ ପ୍ରକାରର ବିଜ୍ଞାପନ ଦେଖିବେ ତାହା ବାଛନ୍ତୁ"
    override val helpCenterTitle = "ସହାୟତା କେନ୍ଦ୍ର"
    override val helpSearchPlaceholder = "ପ୍ରଶ୍ନ ଖୋଜନ୍ତୁ..."
    override val noFaqResultsMessage = "କିଛି ମିଳିଲା ନାହିଁ"
    override val homeHeadline = "ଉଧାର ହିସାବ"
    override val history = "ଇତିହାସ"
    override val settings = "ସେଟିଂସ"
    override val totalDueLabel = "ମୋଟ ବାକି"
    override val thisMonthCreditLabel = "ଏହି ମାସର ବାକି"
    override val thisMonthPaymentLabel = "ଏହି ମାସରେ ମିଳିଲା"
    override val searchPlaceholder = "ଦୋକାନ/ଫୋନ୍ ଖୋଜନ୍ତୁ..."
    override val filterAll = "ସବୁ"
    override val settledLabel = "ଶୁଝାଗଲା"
    override val noShopsYetTitle = "ଏଯାବତ୍ କୌଣସି ଦୋକାନ ନାହିଁ"
    override val noShopsYetSubtitle = "ଖାତା ଆରମ୍ଭ କରିବାକୁ ପ୍ରଥମ ଦୋକାନ ଯୋଡନ୍ତୁ"
    override val addFirstShopButton = "ପ୍ରଥମ ଦୋକାନ ଯୋଡନ୍ତୁ"
    override val newShop = "ନୂଆ ଦୋକାନ"
    override val shopTypeTea = "ଚାହା ଦୋକାନ"
    override val shopTypeHardwareElectric = "ହାର୍ଡୱେର୍ ଓ ଇଲେକ୍ଟ୍ରିକ୍"
    override val shopTypeKirana = "କିରାଣା ଦୋକାନ"
    override val shopTypeVegetable = "ପନିପରିବା ଦୋକାନ"
    override val shopTypeFishMeat = "ମାଛ ଓ ମାଂସ"
    override val shopTypeBakerySweets = "ବେକେରୀ ଓ ମିଠା"
    override val shopTypePharmacy = "ଔଷଧ ଦୋକାନ"
    override val shopTypeCosmetics = "ପ୍ରସାଧନ ସାମଗ୍ରୀ"
    override val shopTypeStationery = "ଷ୍ଟେସନରୀ"
    override val shopTypeXeroxPrinting = "ଜେରକ୍ସ ଓ ପ୍ରିଣ୍ଟିଂ"
    override val shopTypeWood = "କାଠ ଦୋକାନ"
    override val shopTypeGarments = "ପୋଷାକ ଦୋକାନ"
    override val shopTypeOther = "ଅନ୍ୟାନ୍ୟ"
    override val back = "ପଛକୁ"
    override val cancel = "ବାତିଲ୍"
    override val save = "ସେଭ୍ କରନ୍ତୁ"
    override val shopNameLabel = "ଦୋକାନର ନାମ *"
    override val shopNamePlaceholder = "ଯେପରି କାଠ ମହଲ"
    override val phoneLabel = "ଫୋନ୍ ନମ୍ବର (ଇଚ୍ଛାଧୀନ)"
    override val shopTypeLabel = "ଦୋକାନର ପ୍ରକାର *"
    override val saveShopButton = "ଦୋକାନ ସେଭ୍ କରନ୍ତୁ"
    override val errorNameRequired = "ଦୋକାନର ନାମ ଲେଖନ୍ତୁ"
    override val errorTypeRequired = "ଦୋକାନର ପ୍ରକାର ବାଛନ୍ତୁ"
    override val dueLabel = "ବାକି"
    override val noTransactionsYet = "ଏଯାବତ୍ କୌଣସି କାରବାର ନାହିଁ"
    override val creditButton = "ଉଧାର ନେଲି"
    override val paymentButton = "ଟଙ୍କା ଦେଲି"
    override val pdfExport = "PDF ଏକ୍ସପୋର୍ଟ"
    override val archive = "ଆର୍କାଇଭ୍"
    override val deleteShopAction = "ଦୋକାନ ମାଛନ୍ତୁ"
    override val archiveConfirmTitle = "ଏହି ଦୋକାନକୁ ଆର୍କାଇଭ୍ କରିବେ?"
    override val archiveConfirmText = "ଏହା ହୋମ୍ ତାଲିକାରୁ ହଟିଯିବ — ଇତିହାସରେ ତଥାପି ମିଳିବ।"
    override val deleteConfirmTitle = "ଏହି ଦୋକାନକୁ ସଦାପାଇଁ ମାଛିବେ?"
    override val deleteConfirmText = "ଏହି ଦୋକାନ ଓ ଏହାର ସମସ୍ତ କାରବାର ସଦାପାଇଁ ମାଛିଯିବ ଏବଂ ଫେରିବ ନାହିଁ। ଆର୍କାଇଭ୍ କଲେ ଏହା ଇତିହାସରେ ରହିବ — ଆଗକୁ ବଢ଼ିବା ପୂର୍ବରୁ ଭଲ ଭାବେ ଚିନ୍ତା କରନ୍ତୁ।"
    override val yesDelete = "ହଁ, ମାଛନ୍ତୁ"
    override val yesArchive = "ଆର୍କାଇଭ୍ କରନ୍ତୁ"
    override val txnDeletedSnackbar = "କାରବାର ମାଛାଗଲା"
    override val undo = "ଫେରାନ୍ତୁ"
    override val pdfFailPrefix = "PDF ତିଆରି ହେଲା ନାହିଁ: "
    override val shareKhata = "ଖାତା ସେୟାର୍ କରନ୍ତୁ"
    override val creditFallback = "ଉଧାର"
    override val paymentFallback = "ଜମା"
    override val deleteTxnAction = "ମାଛନ୍ତୁ"
    override val productNameLabel = "ଜିନିଷର ନାମ (ଇଚ୍ଛାଧୀନ)"
    override val quantityLabel = "ପରିମାଣ"
    override val unitLabel = "ଏକକ"
    override val pricePerUnitLabel = "ଦର/ଏକକ"
    override val totalPrefix = "ମୋଟ: "
    override val amountLabel = "ଦେଇଥିବା ଟଙ୍କା"
    override val orEnterAmountLabel = "କିମ୍ବା ସିଧାସଳଖ ଟଙ୍କା ଲେଖନ୍ତୁ"
    override val noteLabel = "ଟିପ୍ପଣୀ (ଇଚ୍ଛାଧୀନ)"
    override val cash = "ନଗଦ"
    override val bkash = "bKash"
    override val bank = "ବ୍ୟାଙ୍କ"
    override val invalidAmountError = "ସଠିକ୍ ଟଙ୍କା ଲେଖନ୍ତୁ"
    override val cftCalculatorTitle = "CFT କ୍ୟାଲକୁଲେଟର୍"
    override val lengthLabel = "ଲମ୍ବ (ଇଞ୍ଚ)"
    override val widthLabel = "ଓସାର"
    override val heightLabel = "ଉଚ୍ଚତା"
    override val rateLabel = "ଦର /cft (₹)"
    override val applyToEntryButton = "ଏଣ୍ଟ୍ରିରେ ଯୋଡନ୍ତୁ"
    override val settingsTitle = "ସେଟିଂସ"
    override val security = "ସୁରକ୍ଷା"
    override val pinLockOn = "PIN ଲକ୍ ଚାଲୁ ଅଛି"
    override val pinLockOff = "PIN ଲକ୍ ବନ୍ଦ ଅଛି"
    override val changePin = "PIN ବଦଳାନ୍ତୁ"
    override val reminderTitle = "ବାକି ସ୍ମରଣ"
    override val reminderDesc = "ପ୍ରତିଦିନ ବାକି ମନେ ପକାଏ"
    override val about = "ବିବରଣୀ"
    override val aboutLine = "ଉଧାର ହିସାବ — ଦୋକାନର ଉଧାର ଖାତା"
    override val aboutDescription = "ଉଧାର ହିସାବ ଏକ ସ୍ମାର୍ଟ ହିସାବ ଆପ୍, ଯାହା ଦୋକାନର ଉଧାର, ବାକି ଓ କାରବାରକୁ ସହଜରେ, ଦ୍ରୁତ ଓ ସୁବ୍ୟବସ୍ଥିତ ଭାବେ ସମ୍ଭାଳିବାରେ ସାହାଯ୍ୟ କରେ। କେଉଁ ଦୋକାନରେ କେତେ ବାକି ଅଛି, କେଉଁଠି ଟଙ୍କା ଦିଆଗଲା ଏବଂ କେଉଁ କାରବାର କେବେ ହେଲା — ସବୁ ଗୋଟିଏ ସ୍ଥାନରେ ସୁନ୍ଦର ଭାବେ ସାଇତି ରଖିହେବ।\n\nଏହି ଆପ୍‌ରେ ଆପଣ ସହଜରେ ଦୋକାନ ଯୋଡିପାରିବେ, ଉଧାର ଓ ଜମା ଲେଖିପାରିବେ, କାରବାରର ଇତିହାସ ଦେଖିପାରିବେ, ମୋଟ ବାକି ଓ ଜମା ଯାଞ୍ଚ କରିପାରିବେ ଏବଂ ବିସ୍ତୃତ ରିପୋର୍ଟ ତିଆରି କରିପାରିବେ। ସନ୍ଧାନ, ଫିଲ୍ଟର, ବ୍ୟାକଅପ୍ ଓ ରିଷ୍ଟୋର, ଆପ୍ ଲକ୍, ବାୟୋମେଟ୍ରିକ୍ ସୁରକ୍ଷା, ଡାର୍କ ମୋଡ୍ ଓ ବିଜ୍ଞପ୍ତି ପରି ସୁବିଧା ହିସାବ ରଖିବାକୁ ଆହୁରି ସହଜ ଓ ସୁରକ୍ଷିତ କରେ।\n\nକାଗଜ ଖାତାର ଜଟିଳତାକୁ ସରଳ, ଆଧୁନିକ ଓ ଭରସାଯୋଗ୍ୟ ଡିଜିଟାଲ୍ ପଦ୍ଧତିକୁ ଆଣିବା ହିଁ ଉଧାର ହିସାବର ଲକ୍ଷ୍ୟ।"
    override val aboutTagline = "ଉଧାର ହିସାବ — ସହଜ ହିସାବ, ନିଶ୍ଚିନ୍ତ ରୁହନ୍ତୁ।"
    override val versionLine = "ସଂସ୍କରଣ 1.0"
    override val setPinTitle = "PIN ସେଟ୍ କରନ୍ତୁ"
    override val newPinLabel = "ନୂଆ PIN"
    override val confirmPinLabel = "PIN ପୁଣି ଲେଖନ୍ତୁ"
    override val pinSetupError = "PIN ମେଳ ଖାଉନାହିଁ (ଅତି କମରେ 4 ଅଙ୍କ)"
    override val removePinTitle = "PIN ଲକ୍ ବନ୍ଦ କରିବେ?"
    override val removePinText = "ଏବେ ଆପ୍ ଖୋଲିବା ବେଳେ PIN ପଚରାଯିବ ନାହିଁ।"
    override val yesTurnOff = "ହଁ, ବନ୍ଦ କରନ୍ତୁ"
    override val no = "ନା"
    override val languageTitle = "ଭାଷା"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "ବିଜ୍ଞପ୍ତି"
    override val notifSheetSubtitle = "ଆପଣଙ୍କୁ କେଉଁ ସ୍ମରଣ ଦରକାର?"
    override val notifDueReminderOption = "ବାକି ଦେବାର ସ୍ମରଣ"
    override val notifWeeklySummaryOption = "ସାପ୍ତାହିକ ସାରାଂଶ"
    override val notifAppNewsOption = "ଆପ୍ ଖବର ଓ ଅପଡେଟ୍"
    override val langSheetSubtitle = "ଆପ୍ କେଉଁ ଭାଷାରେ ଚଳାଇବେ?"
    override val themeSheetSubtitle = "ଆପଣଙ୍କୁ କେଉଁ ଥିମ୍ ପସନ୍ଦ?"
    override val securityPrivacyTitle = "ସୁରକ୍ଷା ଓ ଗୋପନୀୟତା"
    override val pinSectionTitle = "PIN ଲକ୍"
    override val pinSectionDesc = "ଆପ୍ ଖୋଲିବା ବେଳେ PIN ପଚାରନ୍ତୁ"
    override val fingerprintTitle = "ଫିଙ୍ଗରପ୍ରିଣ୍ଟ ଲକ୍"
    override val fingerprintDesc = "PIN ବଦଳରେ ଫିଙ୍ଗରପ୍ରିଣ୍ଟରେ ଖୋଲନ୍ତୁ"
    override val fingerprintUnavailable = "ଏହି ଫୋନ୍‌ରେ ଫିଙ୍ଗରପ୍ରିଣ୍ଟ ସେନ୍ସର ମିଳିଲା ନାହିଁ"
    override val lockImmediatelyTitle = "ତୁରନ୍ତ ଲକ୍ କରନ୍ତୁ"
    override val lockImmediatelyDesc = "ଆପ୍‌କୁ ଫେରିବା କ୍ଷଣି ପୁଣି ଲକ୍ ହେବ"
    override val rateTitle = "ରେଟିଂ ଓ ମତାମତ"
    override val rateSubtitle = "ଉଧାର ହିସାବ ଆପଣଙ୍କୁ କେମିତି ଲାଗୁଛି?"
    override val rateStarsPrompt = "ରେଟିଂ ଦେବାକୁ ଟ୍ୟାପ୍ କରନ୍ତୁ"
    override val rateThanksMessage = "ଧନ୍ୟବାଦ! ଆପଣଙ୍କୁ Play Store କୁ ନେଉଛୁ…"
    override val feedbackPromptLow = "ଆପଣଙ୍କୁ କଣ ପସନ୍ଦ ହେଲା ନାହିଁ? ଆମକୁ କୁହନ୍ତୁ"
    override val feedbackPlaceholder = "ଆପଣଙ୍କ ମତାମତ ଲେଖନ୍ତୁ…"
    override val feedbackSubmit = "ପଠାନ୍ତୁ"
    override val feedbackThanks = "ଧନ୍ୟବାଦ, ଆପଣଙ୍କ ମତାମତ ପଠାଗଲା"
    override val aboutPageTitle = "ଉଧାର ହିସାବ ବିଷୟରେ"
    override val aboutVersionPrefix = "ସଂସ୍କରଣ"
    override val aboutDeveloperLabel = "ଡେଭଲପର୍"
    override val aboutDeveloperName = "ଉଧାର ହିସାବ ଟିମ୍"
    override val aboutPrivacyPolicy = "ଗୋପନୀୟତା ନୀତି"
    override val privacyPolicyEffectiveDate = "ଲାଗୁ ତାରିଖ: 13 ସେପ୍ଟେମ୍ବର 2026"
    override val aboutShareApp = "ସେୟାର୍ କରନ୍ତୁ"
    override val aboutShareText = "ଉଧାର ହିସାବ — ଦୋକାନର ଉଧାର ଖାତାର ଏହି ଆପ୍ ଚେଷ୍ଟା କରନ୍ତୁ!"
    override val noArchivedShops = "କୌଣସି ଆର୍କାଇଭ୍ ଦୋକାନ ନାହିଁ"
    override val noSettledShops = "କୌଣସି ଶୁଝାଯାଇଥିବା ଦୋକାନ ନାହିଁ"
    override val setupPinTitle = "4 ଅଙ୍କର PIN ସେଟ୍ କରନ୍ତୁ"
    override val unlockPinTitle = "PIN ରେ ଖୋଲନ୍ତୁ"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 ଅଙ୍କ ଲେଖନ୍ତୁ"
    override val pinsDontMatchError = "PIN ମେଳ ଖାଉନାହିଁ"
    override val wrongPinError = "PIN ଭୁଲ — ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ"
    override val savePinButton = "PIN ସେଭ୍ କରନ୍ତୁ"
    override val unlockButton = "ଖୋଲନ୍ତୁ"
    override val pdfHeaderTitle = "ଖାତା — ଉଧାର ହିସାବ"
    override val pdfFullKhataSuffix = "ପୂର୍ଣ୍ଣ ଖାତା"
    override val pdfShopLabel = "ଦୋକାନ: "
    override val pdfPhoneLabel = "ଫୋନ୍: "
    override val pdfCreatedLabel = "ତିଆରି: "
    override val pdfColDate = "ତାରିଖ/ସମୟ"
    override val pdfColDesc = "ବିବରଣୀ"
    override val pdfTotalCredit = "ମୋଟ ଉଧାର:"
    override val pdfTotalPayment = "ମୋଟ ଜମା:"
    override val pdfCurrentDue = "ବର୍ତ୍ତମାନ ବାକି:"
    override val pdfFooter = "ଉଧାର ହିସାବ ଆପ୍‌ରୁ ତିଆରି"
    override val navHome = "ହୋମ୍"
    override val navHistory = "ଇତିହାସ"
    override val navReports = "ରିପୋର୍ଟ"
    override val navMore = "ଅଧିକ"
    override val historyFilterAllShops = "ସବୁ ଦୋକାନ"
    override val historyFilterAllTypes = "ସବୁ"
    override val historyFilterCreditOnly = "କେବଳ ଉଧାର"
    override val historyFilterPaymentOnly = "କେବଳ ଜମା"
    override val historyNoTxnsFound = "କୌଣସି କାରବାର ମିଳିଲା ନାହିଁ"
    override val viewArchivedAction = "ଆର୍କାଇଭ୍ ଦୋକାନ ଦେଖନ୍ତୁ"
    override val reportsTitle = "ରିପୋର୍ଟ"
    override val periodLabel = "ସମୟସୀମା"
    override val period7d = "ଗତ 7 ଦିନ"
    override val period15d = "ଗତ 15 ଦିନ"
    override val period30d = "ଗତ 30 ଦିନ"
    override val period3m = "ଗତ 3 ମାସ"
    override val period1y = "ଏହି ବର୍ଷ"
    override val reportTotalCredit = "ମୋଟ ଉଧାର"
    override val reportTotalPayment = "ମୋଟ ଜମା"
    override val reportCurrentDue = "ବର୍ତ୍ତମାନ ମୋଟ ବାକି"
    override val reportTxnCount = "କାରବାର"
    override val reportChartTitle = "ଉଧାର ବନାମ ଜମା"
    override val reportShopWiseTitle = "ଦୋକାନ ଅନୁସାରେ ବାକି"
    override val reportAgingTitle = "ବାକିର ବୟସ"
    override val reportAging0to7 = "0–7 ଦିନ"
    override val reportAging7to15 = "7–15 ଦିନ"
    override val reportAging15to30 = "15–30 ଦିନ"
    override val reportAging30plus = "30+ ଦିନ"
    override val reportRecentPaymentsTitle = "ସାମ୍ପ୍ରତିକ ଜମା"
    override val reportNoData = "ଏହି ସମୟର ତଥ୍ୟ ନାହିଁ"
    override val reportSmartSummaryPrefix = "ଏହି ସମୟରେ ଆପଣ"
    override val moreTitle = "ଅଧିକ"
    override val moreBackupRestore = "ବ୍ୟାକଅପ୍ ଓ ରିଷ୍ଟୋର"
    override val moreHintBackupRestore = "ଆପଣଙ୍କ ଡାଟା ସୁରକ୍ଷିତ ରଖନ୍ତୁ"
    override val notesTitle = "ଟିପ୍ପଣୀ"
    override val notesSearchPlaceholder = "ଟିପ୍ପଣୀ ଖୋଜନ୍ତୁ..."
    override val addNoteButton = "ନୂଆ ଟିପ୍ପଣୀ"
    override val noNotesYetTitle = "ଏଯାବତ୍ କୌଣସି ଟିପ୍ପଣୀ ନାହିଁ"
    override val noNotesYetSubtitle = "କିଣାକିଣି ତାଲିକା, ସ୍ମରଣ — ଯାହା ଇଚ୍ଛା ଲେଖି ରଖନ୍ତୁ"
    override val deleteNoteConfirmTitle = "ଏହି ଟିପ୍ପଣୀ ମାଛିବେ?"
    override val deleteNoteConfirmMessage = "ଏହି ଟିପ୍ପଣୀ ସଦାପାଇଁ ମାଛିଯିବ।"
    override val noteTitlePlaceholder = "ଶିରୋନାମା"
    override val noteContentPlaceholder = "କିଛି ଲେଖନ୍ତୁ..."
    override val untitledNote = "ଶିରୋନାମାହୀନ ଟିପ୍ପଣୀ"
    override val notificationInboxTitle = "ବିଜ୍ଞପ୍ତି"
    override val moreNotificationHistory = "ବିଜ୍ଞପ୍ତି ଇତିହାସ"
    override val moreHintNotificationHistory = "ସାମ୍ପ୍ରତିକ କାର୍ଯ୍ୟକଳାପ ଦେଖନ୍ତୁ"
    override val noNotificationsYetTitle = "ଏଯାବତ୍ କୌଣସି ବିଜ୍ଞପ୍ତି ନାହିଁ"
    override val noNotificationsYetSubtitle = "ଉଧାର କିମ୍ବା ଜମା ଲେଖିଲେ ଏଠାରେ ଦେଖାଯିବ"
    override val notifCreditMessage = "%1\$s ଠାରୁ %2\$s ଉଧାର ନିଆଗଲା"
    override val notifPaymentMessage = "%1\$s କୁ %2\$s ଜମା କରାଗଲା"
    override val moreQuickCalculator = "କ୍ୱିକ୍ କ୍ୟାଲକୁଲେଟର୍"
    override val moreHintQuickCalculator = "ତୁରନ୍ତ ହିସାବ କରନ୍ତୁ"
    override val calcGeneralTab = "ସାଧାରଣ"
    override val calcPercentTab = "ପ୍ରତିଶତ"
    override val calcConversionTab = "ରୂପାନ୍ତର"
    override val calcComingSoonInTab = "ଶୀଘ୍ର ଆସୁଛି"
    override val percentOfTitle = "ଏକ ସଂଖ୍ୟାର ପ୍ରତିଶତ"
    override val percentOfValueLabel = "ସଂଖ୍ୟା"
    override val percentOfPercentLabel = "ପ୍ରତିଶତ (%)"
    override val percentIsWhatTitle = "ଏକ ସଂଖ୍ୟା ଅନ୍ୟଟିର କେତେ ପ୍ରତିଶତ"
    override val percentIsWhatXLabel = "ଏହି ସଂଖ୍ୟା"
    override val percentIsWhatYLabel = "ଏହାର"
    override val percentChangeTitle = "ପ୍ରତିଶତ ବୃଦ୍ଧି/ହ୍ରାସ"
    override val percentChangeBaseLabel = "ମୂଳ ସଂଖ୍ୟା"
    override val percentChangePercentLabel = "ପ୍ରତିଶତ (%)"
    override val increaseOption = "ବୃଦ୍ଧି"
    override val decreaseOption = "ହ୍ରାସ"
    override val resultLabel = "ଫଳାଫଳ"
    override val weightCategory = "ଓଜନ"
    override val lengthCategory = "ଲମ୍ବ"
    override val volumeCategory = "ଆୟତନ"
    override val fromLabel = "ଠାରୁ"
    override val toLabel = "ପର୍ଯ୍ୟନ୍ତ"
    override val enterValueHint = "ମୂଲ୍ୟ ଲେଖନ୍ତୁ"
    override val backupNowButton = "ଏବେ ବ୍ୟାକଅପ୍ ନିଅନ୍ତୁ"
    override val backupNowHint = "ସମସ୍ତ ଦୋକାନ ଓ କାରବାର JSON ଫାଇଲ୍‌ରେ ସେଭ୍ କରନ୍ତୁ"
    override val restoreButton = "ବ୍ୟାକଅପ୍‌ରୁ ରିଷ୍ଟୋର୍ କରନ୍ତୁ"
    override val restoreShopAction = "ରିଷ୍ଟୋର୍"
    override val restoreHint = "ପୁରୁଣା JSON ବ୍ୟାକଅପ୍ ଫାଇଲ୍‌ରୁ ଡାଟା ଫେରାଇ ଆଣନ୍ତୁ"
    override val lastBackupLabel = "ଶେଷ ବ୍ୟାକଅପ୍"
    override val noBackupYetLabel = "ଏଯାବତ୍ ବ୍ୟାକଅପ୍ ନିଆଯାଇ ନାହିଁ"
    override val backupSuccessMessage = "ବ୍ୟାକଅପ୍ ତିଆରି ହେଲା"
    override val backupFailPrefix = "ବ୍ୟାକଅପ୍ ବିଫଳ: "
    override val restoreConfirmTitle = "ବ୍ୟାକଅପ୍ ରିଷ୍ଟୋର୍ କରିବେ?"
    override val restoreConfirmMessage = "ଏହା ବର୍ତ୍ତମାନର ସମସ୍ତ ଦୋକାନ ଓ କାରବାର ଲିଭାଇ ବ୍ୟାକଅପ୍ ଫାଇଲ୍‌ର ଡାଟା ଆଣିବ। ଏହାକୁ ଫେରାଇ ହେବ ନାହିଁ।"
    override val restoreSuccessMessage = "ରିଷ୍ଟୋର୍ ସମ୍ପୂର୍ଣ୍ଣ ହେଲା"
    override val restoreFailPrefix = "ରିଷ୍ଟୋର୍ ବିଫଳ: "
    override val dataSafeNote = "ଆପଣଙ୍କ ଡାଟା କେବଳ ଏହି ଫୋନ୍‌ରେ ରହେ — ବ୍ୟାକଅପ୍ ଫାଇଲ୍ ନିଜେ ସୁରକ୍ଷିତ ରଖନ୍ତୁ"
    override val moreExportShare = "ଏକ୍ସପୋର୍ଟ ଓ ସେୟାର୍"
    override val moreHintExportShare = "PDF ଓ ଫାଇଲ୍ ପଠାନ୍ତୁ"
    override val moreNotifications = "ବିଜ୍ଞପ୍ତି"
    override val moreHintNotifications = "ସ୍ମରଣ ଚାଲୁ/ବନ୍ଦ କରନ୍ତୁ"
    override val moreLanguage = "ଭାଷା"
    override val moreHintLanguage = "ଆପଣଙ୍କ ଭାଷା ବାଛନ୍ତୁ"
    override val moreUserMode = "ମୁଁ କିଏ"
    override val moreHintUserMode = "ଗ୍ରାହକ କିମ୍ବା ଦୋକାନୀ"
    override val moreSecurityPrivacy = "ସୁରକ୍ଷା ଓ ଗୋପନୀୟତା"
    override val moreHintSecurityPrivacy = "PIN ଓ ଫିଙ୍ଗରପ୍ରିଣ୍ଟ ଲକ୍"
    override val moreAppearance = "ଦୃଶ୍ୟ"
    override val moreHintAppearance = "ଲାଇଟ୍, ଡାର୍କ କିମ୍ବା ସିଷ୍ଟମ୍"
    override val moreRateFeedback = "ରେଟିଂ ଓ ମତାମତ"
    override val moreHintRateFeedback = "ଆପଣଙ୍କ ମତ ଜଣାନ୍ତୁ"
    override val moreAbout = "ଉଧାର ହିସାବ ବିଷୟରେ"
    override val moreHintAbout = "ସଂସ୍କରଣ ଓ ଡେଭଲପର୍"
    override val comingSoonMessage = "ଶୀଘ୍ର ଆସୁଛି"
    override val appearanceTitle = "ଦୃଶ୍ୟ"
    override val themeLight = "ଲାଇଟ୍"
    override val themeDark = "ଡାର୍କ"
    override val themeSystem = "ସିଷ୍ଟମ୍ ଡିଫଲ୍ଟ"
    override val creditPageTitle = "ଉଧାର ନିଅନ୍ତୁ"
    override val accountingTypeLabel = "ଏଣ୍ଟ୍ରିର ପ୍ରକାର"
    override val directMoneyMode = "ସିଧାସଳଖ ଟଙ୍କା"
    override val productMode = "ଜିନିଷ ଅନୁସାରେ"
    override val directMoneyAmountLabel = "କେତେ ଉଧାର ଦେଲେ?"
    override val previousDueLabel = "ପୂର୍ବ ବାକି"
    override val newCreditLabel = "ନୂଆ ଉଧାର"
    override val newTotalDueLabel = "ନୂଆ ମୋଟ ବାକି"
    override val addCreditButton = "ଉଧାର ଯୋଡନ୍ତୁ"
    override val addMoreProductButton = "+ ଆଉ ଏକ ଜିନିଷ ଯୋଡନ୍ତୁ"
    override val totalNewCreditLabel = "ମୋଟ ନୂଆ ଉଧାର"
    override val editAction = "ବଦଳାନ୍ତୁ"
    override val itemsCountSuffix = "ଜିନିଷ"
    override val paymentPageTitle = "ଜମା"
    override val currentDueLabel = "ବର୍ତ୍ତମାନ ବାକି"
    override val howMuchPaymentLabel = "କେତେ ଜମା କରୁଛନ୍ତି?"
    override val fullPaymentButton = "ପୂରା ଟଙ୍କା"
    override val dueAfterPaymentLabel = "ଜମା ପରେ ବାକି"
    override val addPaymentButton = "ଜମା ଯୋଡନ୍ତୁ"
    override val overpaymentBlockedMessage = "ବର୍ତ୍ତମାନ ବାକିରୁ ଅଧିକ ଜମା କରାଯାଇପାରିବ ନାହିଁ"
    override val fullyPaidCelebration = "ଏହା ଦ୍ୱାରା ପୂରା ବାକି ଶୁଝିଯିବ"
    override val woodCalculatorTitle = "କାଠ କ୍ୟାଲକୁଲେଟର୍"
    override val woodTypeLabel = "କାଠର ପ୍ରକାର"
    override val sawnWoodOption = "କଟା କାଠ"
    override val roundWoodOption = "ଗୋଲ ଖୁଣ୍ଟ"
    override val lengthFtLabel = "ଲମ୍ବ (ଫୁଟ)"
    override val widthInLabel = "ଓସାର (ଇଞ୍ଚ)"
    override val thicknessInLabel = "ମୋଟେଇ (ଇଞ୍ଚ)"
    override val girthInLabel = "ଘେର (ଇଞ୍ଚ)"
    override val pieceCountLabel = "ଖଣ୍ଡର ସଂଖ୍ୟା"
    override val perPieceCftLabel = "ପ୍ରତି ଖଣ୍ଡ"
    override val totalWoodCftLabel = "ମୋଟ କାଠ"
    override val perCftPriceLabel = "ପ୍ରତି CFT ଦର (₹)"
    override val totalWoodValueLabel = "ମୋଟ ମୂଲ୍ୟ"
    override val addWoodCalcButton = "ଏହି କାଠ ହିସାବ ଯୋଡନ୍ତୁ"
    override val woodNameLabel = "ଜିନିଷର ନାମ"
    override val addMoreWoodProductButton = "+ ଆଉ ଏକ କାଠ/ଜିନିଷ ଯୋଡନ୍ତୁ"
    override val addedItemsHeader = "ଯୋଡାଯାଇଥିବା ଜିନିଷ/କାଠ"
    override val pdfOptionsTitle = "PDF ବିକଳ୍ପ"
    override val pdfPeriodLabel = "ସମୟସୀମା"
    override val pdfThisMonth = "ଏହି ମାସ"
    override val pdfLastMonth = "ଗତ ମାସ"
    override val pdfLast3Months = "ଗତ 3 ମାସ"
    override val pdfCustomRange = "ନିଜର ତାରିଖ"
    override val pdfShopLabelOption = "ଦୋକାନ"
    override val pdfAllShopsOption = "ସବୁ ଦୋକାନ"
    override val pdfContentLabel = "କଣ ଦେଖାଇବେ"
    override val pdfContentFull = "ସବୁକିଛି (କାରବାର + ସାରାଂଶ + ସ୍ୱାକ୍ଷର)"
    override val pdfContentSummaryOnly = "କେବଳ ସାରାଂଶ"
    override val pdfContentTxnsOnly = "କେବଳ କାରବାର"
    override val pdfFormatLabel = "ଫର୍ମାଟ୍"
    override val pdfFormatA4 = "A4 ରିପୋର୍ଟ"
    override val pdfFormatReceipt = "ରସିଦ (58mm)"
    override val pdfGenerateButton = "PDF ତିଆରି କରନ୍ତୁ"
    override val pdfFromDateLabel = "ଆରମ୍ଭ ତାରିଖ"
    override val pdfToDateLabel = "ଶେଷ ତାରିଖ"
    override val pdfReportNumberLabel = "ରିପୋର୍ଟ ନଂ."
    override val pdfShopBoxLabel = "ଦୋକାନ"
    override val pdfDateBoxLabel = "ତାରିଖ"
    override val pdfDaysOfRecordsSuffix = "ଦିନର ରେକର୍ଡ"
    override val pdfWeeklyChartTitle = "ସାପ୍ତାହିକ ଉଧାର (ନାଲି) ବନାମ ଜମା (ସବୁଜ)"
    override val pdfFinalDueLabel = "ବର୍ତ୍ତମାନ ବାକି"
    override val pdfShopSignatureLabel = "ଦୋକାନୀଙ୍କ ସ୍ୱାକ୍ଷର"
    override val pdfCustomerSignatureLabel = "ଗ୍ରାହକଙ୍କ ସ୍ୱାକ୍ଷର"
    override val pdfAllShopsReportTitle = "ସବୁ ଦୋକାନର ସାରାଂଶ — ଉଧାର ହିସାବ"
    override val pdfPageLabel = "ପୃଷ୍ଠା"
    override val moreShopProfile = "ଦୋକାନ ପ୍ରୋଫାଇଲ୍"
    override val moreHintShopProfile = "ନାମ, ଲୋଗୋ, ଠିକଣା, ସ୍ମରଣ"
    override val shopProfileTitle = "ଦୋକାନ ପ୍ରୋଫାଇଲ୍"
    override val shopProfileIntro = "ଏହି ସୂଚନା PDF ଇନଭଏସ୍ ଓ ଗ୍ରାହକକୁ ପଠାଯାଉଥିବା ବାର୍ତ୍ତାରେ ବ୍ୟବହାର ହେବ"
    override val shopBusinessNameLabel = "ଦୋକାନର ନାମ"
    override val shopBusinessAddressLabel = "ଦୋକାନର ଠିକଣା"
    override val shopBusinessPhoneLabel = "ଦୋକାନର ଫୋନ୍ ନମ୍ବର"
    override val countryCodeLabel = "ଦେଶ କୋଡ୍ (ଯଥା 91)"
    override val shopLogoLabel = "ଦୋକାନର ଲୋଗୋ"
    override val shopLogoPick = "ଲୋଗୋ ବାଛନ୍ତୁ"
    override val shopLogoRemove = "ଲୋଗୋ ହଟାନ୍ତୁ"
    override val promptAfterEntryLabel = "ଏଣ୍ଟ୍ରି ପରେ ଗ୍ରାହକକୁ ଜଣାଇବାର ବିକଳ୍ପ ଦେଖାନ୍ତୁ"
    override val saveProfileButton = "ପ୍ରୋଫାଇଲ୍ ସେଭ୍ କରନ୍ତୁ"
    override val profileSavedMessage = "ପ୍ରୋଫାଇଲ୍ ସେଭ୍ ହେଲା"
    override val errorShopNameForPdf = "PDF ରେ ବ୍ୟବହାର ପାଇଁ ଦୋକାନର ନାମ ଦିଅନ୍ତୁ"
    override val reminderSendAction = "ସ୍ମରଣ ପଠାନ୍ତୁ"
    override val reminderDialogTitle = "ଗ୍ରାହକକୁ ଜଣାନ୍ତୁ"
    override val reminderDialogSubtitle = "ବାର୍ତ୍ତା ବଦଳାଇ WhatsApp କିମ୍ବା SMS ରେ ପଠାନ୍ତୁ"
    override val reminderMessageLabel = "ବାର୍ତ୍ତା"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "ଏବେ ନୁହେଁ"
    override val reminderNoPhone = "ଏହି ଗ୍ରାହକଙ୍କ ଫୋନ୍ ନମ୍ବର ନାହିଁ"
    override val reminderAppMissing = "ଆପ୍ ଖୋଲିପାରିଲୁ ନାହିଁ"
    override val reminderShopFallback = "ଆମ ଦୋକାନ"
    override val reminderMsgDue = "ନମସ୍କାର %1\$s, %2\$s ଖାତାରେ ଆପଣଙ୍କ ମୋଟ ବାକି %3\$s। ଦୟାକରି ସମୟରେ ଦିଅନ୍ତୁ। ଧନ୍ୟବାଦ।"
    override val reminderMsgCredit = "ନମସ୍କାର %1\$s, %2\$s ଖାତାରେ ଆପଣଙ୍କ ନୂଆ ଉଧାର ଯୋଡାଗଲା। ମୋଟ ବାକି: %3\$s।"
    override val reminderMsgPayment = "ନମସ୍କାର %1\$s, ଆପଣଙ୍କ ଟଙ୍କା ମିଳିଲା। ଧନ୍ୟବାଦ! %2\$s ଖାତାରେ ବର୍ତ୍ତମାନ ବାକି: %3\$s।"
    override val reminderMsgSettled = "ନମସ୍କାର %1\$s, ଆପଣଙ୍କ ସମସ୍ତ ବାକି ଶୁଝିଗଲା। ଧନ୍ୟବାଦ! — %2\$s"
    override val pdfActionLabel = "📤 କଣ କରିବେ"
    override val pdfActionShare = "ସେୟାର୍"
    override val pdfActionSave = "ସେଭ୍"
    override val pdfActionPrint = "ପ୍ରିଣ୍ଟ୍"
    override val pdfBrandingOption = "ମୋ ଦୋକାନର ନାମ, ଲୋଗୋ ଓ ଠିକଣା ଯୋଡନ୍ତୁ"
    override val pdfBrandingMissing = "ଦୋକାନର ନାମ ଦିଆଯାଇ ନାହିଁ — ଅଧିକ → ଦୋକାନ ପ୍ରୋଫାଇଲ୍‌ରେ ଯୋଡନ୍ତୁ"
    override val pdfSavedMessage = "PDF ସେଭ୍ ହେଲା"
    override val pdfSaveFailed = "PDF ସେଭ୍ ହେଲା ନାହିଁ"
    override val setupRoleTitle = "ଆପଣ ଆପ୍ କିପରି ବ୍ୟବହାର କରିବେ?"
    override val setupProfileTitle = "ଆପଣଙ୍କ ଦୋକାନର ବିବରଣୀ"
    override val setupProfileSubtitle = "ପରେ ଅଧିକ → ଦୋକାନ ପ୍ରୋଫାଇଲ୍‌ରୁ ବଦଳାଇପାରିବେ"
    override val setupContinue = "ଆଗକୁ ବଢ଼ନ୍ତୁ"
    override val setupSkip = "ଏବେ ନୁହେଁ, ପରେ କରିବି"
    override val setupFinish = "ଆରମ୍ଭ କରନ୍ତୁ"
    override val pickFromContacts = "କଣ୍ଟାକ୍ଟରୁ ନମ୍ବର ବାଛନ୍ତୁ"
    override val pdfColQtyPrice = "ପରିମାଣ × ଦର"
    override val pdfColItemTotal = "ଜିନିଷର ଟଙ୍କା"
    override val pdfWoodSawn = "କଟା କାଠ"
    override val pdfWoodRound = "ଗୋଲ ଖୁଣ୍ଟ"
    override val pdfWoodFormula = "ସୂତ୍ର"
    override val pdfWoodTotalWord = "ମୋଟ"
    override val pdfMemoTitle = "କ୍ୟାସ୍ ମେମୋ"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "ବିଲ୍ ନଂ. / Bill No"
    override val pdfDateTitle = "ତାରିଖ / Date"
    override val pdfPeriodTitle = "ସମୟସୀମା / Period"
    override val pdfSeller = "ବିକ୍ରେତା / Seller"
    override val pdfBuyer = "କ୍ରେତା / Buyer"
    override val pdfAddressLabel = "ଠିକଣା: "
    override val pdfColSl = "କ୍ରମ"
    override val pdfColPieces = "ଗୋଟି"
    override val pdfColCft = "CFT"
    override val pdfColRate = "ଦର (₹/CFT)"
    override val pdfColAmountRs = "ମୋଟ (₹)"
    override val pdfColQty = "ପରିମାଣ"
    override val pdfColUnitPrice = "ଦର (₹)"
    override val pdfSecSawn = "କଟା କାଠ / Sawn Timber"
    override val pdfSecRound = "ଗୋଲ ଖୁଣ୍ଟ / Round Log"
    override val pdfSecOther = "ଅନ୍ୟ ଜିନିଷ / Other Items"
    override val pdfSecCashCredit = "ନଗଦ ଉଧାର / Cash Credit"
    override val pdfSecPayments = "ଜମା / Payments"
    override val pdfBadgeSawn = "କଟା"
    override val pdfBadgeRound = "ଗୋଲ"
    override val pdfSawnTotal = "କଟା କାଠ ମୋଟ:"
    override val pdfRoundTotal = "ଗୋଲ ଖୁଣ୍ଟ ମୋଟ:"
    override val pdfTableTotal = "ମୋଟ:"
    override val pdfSumBill = "ମୋଟ ବିଲ୍"
    override val pdfSumPaid = "ଜମା"
    override val pdfSumDue = "ବାକି"
    override val pdfWordsTitle = "ଟଙ୍କା ଅକ୍ଷରରେ / Amount in Words:"
    override val pdfSellerSign = "ବିକ୍ରେତାଙ୍କ ସ୍ୱାକ୍ଷର ଓ ମୋହର"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "କ୍ରେତାଙ୍କ ସ୍ୱାକ୍ଷର"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "ଏହା କମ୍ପ୍ୟୁଟର ତିଆରି ବିଲ୍। ସ୍ୱାକ୍ଷର ବିନା ବୈଧ ନୁହେଁ।"
    override val pdfSummaryTitle = "ସାରାଂଶ ରିପୋର୍ଟ"
    override val moveShopAction = "ଅନ୍ୟ ତାଲିକାକୁ ନିଅନ୍ତୁ"
    override val moveShopTitle = "ଅନ୍ୟ ତାଲିକାକୁ ନେବେ?"
    override val moveToShopkeeperMsg = "ଏହି ଏଣ୍ଟ୍ରି \"ମୁଁ ଦୋକାନୀ\" ତାଲିକାକୁ (ଆପଣଙ୍କ ଗ୍ରାହକ ଭାବେ) ଯିବ। ଟଙ୍କା ସମାନ ରହିବ, କେବଳ ଶବ୍ଦ ବଦଳିବ।"
    override val moveToCustomerMsg = "ଏହି ଏଣ୍ଟ୍ରି \"ମୁଁ ଗ୍ରାହକ\" ତାଲିକାକୁ (ଯେଉଁ ଦୋକାନରୁ ଆପଣ ଉଧାର ନିଅନ୍ତି) ଯିବ। ଟଙ୍କା ସମାନ ରହିବ, କେବଳ ଶବ୍ଦ ବଦଳିବ।"
    override val moveShopConfirm = "ନିଅନ୍ତୁ"
    override val faqItems = listOf(
        FaqItem("ନୂଆ ଦୋକାନ କିପରି ଯୋଡିବେ?", "ହୋମ୍‌ର '+' ବଟନ୍ ଦବାନ୍ତୁ, ଦୋକାନର ନାମ, ଫୋନ୍ (ଇଚ୍ଛାଧୀନ) ଓ ପ୍ରକାର ଲେଖି 'ସେଭ୍ କରନ୍ତୁ' ଦବାନ୍ତୁ।"),
        FaqItem("ଉଧାର କିମ୍ବା ଜମା କିପରି ଲେଖିବେ?", "ଦୋକାନର ପୃଷ୍ଠା ଖୋଲି 'ଉଧାର ନେଲି' କିମ୍ବା 'ଟଙ୍କା ଦେଲି' ଦବାନ୍ତୁ, ଟଙ୍କା ଲେଖି ନିଶ୍ଚିତ କରନ୍ତୁ।"),
        FaqItem("ବାୟୋମେଟ୍ରିକ୍ ଲକ୍ କିପରି ଚାଲୁ/ବନ୍ଦ କରିବେ?", "ଅଧିକ → ସୁରକ୍ଷା ଓ ଗୋପନୀୟତାରେ 'ବାୟୋମେଟ୍ରିକ୍ ଲକ୍' ଚାଲୁ/ବନ୍ଦ କରନ୍ତୁ। ଆପଣଙ୍କ ଫୋନ୍‌ରେ ଫିଙ୍ଗରପ୍ରିଣ୍ଟ କିମ୍ବା ଫେସ୍ ଅନଲକ୍ ସେଟ୍ ଥିବା ଦରକାର।"),
        FaqItem("ଡାଟାର ବ୍ୟାକଅପ୍ କିପରି ନେବେ?", "ଅଧିକ → ବ୍ୟାକଅପ୍ ଓ ରିଷ୍ଟୋରରେ 'ଏବେ ବ୍ୟାକଅପ୍ ନିଅନ୍ତୁ' ଦବାନ୍ତୁ। ଏହା ଏକ JSON ଫାଇଲ୍ ତିଆରି କରେ, ଯାହାକୁ ଫୋନ୍ କିମ୍ବା କ୍ଲାଉଡ୍‌ରେ ସେଭ୍ କରିହେବ।"),
        FaqItem("ବ୍ୟାକଅପ୍‌ରୁ ଡାଟା କିପରି ଫେରାଇବେ?", "ଅଧିକ → ବ୍ୟାକଅପ୍ ଓ ରିଷ୍ଟୋରରେ 'ବ୍ୟାକଅପ୍‌ରୁ ରିଷ୍ଟୋର୍ କରନ୍ତୁ' ଦବାଇ ଆପଣଙ୍କ JSON ଫାଇଲ୍ ବାଛନ୍ତୁ। ଏହା ବର୍ତ୍ତମାନର ସମସ୍ତ ଡାଟା ବଦଳାଇଦିଏ, ତେଣୁ ସତର୍କ ରୁହନ୍ତୁ।"),
        FaqItem("ଦୋକାନ ମାଛିଦେଲେ ଫେରିବ କି?", "ଆର୍କାଇଭ୍ କଲେ ଏହା ଇତିହାସରେ ରହେ ଏବଂ ପରେ ଫେରାଇ ଆଣିହେବ। ସଦାପାଇଁ ମାଛିଲେ ଫେରେ ନାହିଁ।"),
        FaqItem("PDF ରିପୋର୍ଟ କିପରି ତିଆରି କରିବେ?", "'ଅଧିକ' ପୃଷ୍ଠାରେ ବ୍ୟାକଅପ୍ ଓ ରିଷ୍ଟୋର ପାଖରେ ଏକ୍ସପୋର୍ଟ ବିକଳ୍ପ ଅଛି, ଦୋକାନ ଓ ତାରିଖ ସୀମା ବାଛି PDF ସେୟାର୍ କରନ୍ତୁ।"),
        FaqItem("ଆପ୍‌ର ଭାଷା କିପରି ବଦଳାଇବେ?", "ଅଧିକ → ଭାଷାରେ ଆପଣଙ୍କ ଭାଷା ବାଛି 'ସେଭ୍ କରନ୍ତୁ' ଦବାନ୍ତୁ।")
    )
    override val privacyPolicyBody = """ଉଧାର ହିସାବ ଏକ ବ୍ୟକ୍ତିଗତ ଆର୍ଥିକ/ଖାତା ବହି ଆପ୍, ଯାହା ଦୋକାନର ଉଧାର, ବାକି ଓ କାରବାରକୁ ସହଜରେ ସମ୍ଭାଳିବାରେ ସାହାଯ୍ୟ କରେ। ଆପଣଙ୍କ ଗୋପନୀୟତା ଆମ ପାଇଁ ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ।

1. ଆମେ ସଂଗ୍ରହ କରୁଥିବା ସୂଚନା

ଉଧାର ହିସାବ ବ୍ୟବହାର କରିବା ବେଳେ ଆପଣ ନିଜେ ଆପ୍‌ରେ ଦେଉଥିବା ସୂଚନା, ଯେପରି:
• ଦୋକାନର ନାମ
• ମୋବାଇଲ୍ ନମ୍ବର
• ଦୋକାନର ଠିକଣା କିମ୍ବା ଅନ୍ୟ ବିବରଣୀ
• ଉଧାର ଓ ଜମା ଟଙ୍କା
• କାରବାରର ତାରିଖ, ସମୟ ଓ ଟିପ୍ପଣୀ

2. ସୂଚନାର ବ୍ୟବହାର

ଏହି ସୂଚନା କେବଳ ଆପଣଙ୍କ ହିସାବ ସାଇତିବା, ଦେଖାଇବା ଓ ସମ୍ଭାଳିବା ପାଇଁ ବ୍ୟବହୃତ ହୁଏ। ଆପଣଙ୍କ ବ୍ୟକ୍ତିଗତ ଖାତା ବହି ଡାଟା ଆପଣଙ୍କ ଅନୁମତି ବିନା କୌଣସି ବିଜ୍ଞାପନଦାତା କିମ୍ବା ତୃତୀୟ ପକ୍ଷକୁ ବିକ୍ରି ବା ସେୟାର୍ କରାଯିବ ନାହିଁ।

3. ଡାଟା ସଂରକ୍ଷଣ

ଆପ୍‌ର ଆବଶ୍ୟକତା ଅନୁସାରେ ଆପଣଙ୍କ ହିସାବ ଡାଟା ଆପଣଙ୍କ ଡିଭାଇସ୍‌ରେ ସାଇତାଯାଇପାରେ। ଆପଣ ବ୍ୟାକଅପ୍ ଓ ରିଷ୍ଟୋର ସୁବିଧା ବ୍ୟବହାର କଲେ, ଆପଣ ବାଛିଥିବା ଷ୍ଟୋରେଜ୍/କ୍ଲାଉଡ୍ ସେବାରେ ବ୍ୟାକଅପ୍ ଡାଟା ସାଇତାଯାଇପାରେ।

4. ଆପ୍ ସୁରକ୍ଷା

ଆପଣଙ୍କ ହିସାବ ଡାଟା ସୁରକ୍ଷିତ ରଖିବା ପାଇଁ ଆପ୍ ଲକ୍, PIN ଓ ବାୟୋମେଟ୍ରିକ୍ ପ୍ରମାଣୀକରଣ ପରି ସୁରକ୍ଷା ସୁବିଧା ଦିଆଯାଇପାରେ।

5. ସୂଚନା ସେୟାର୍ କରିବା

ଆଇନ ଅନୁସାରେ ଆବଶ୍ୟକ ହେଲେ ବ୍ୟତୀତ, ଆମେ ଆପଣଙ୍କ ବ୍ୟକ୍ତିଗତ ଖାତା ବହି ଡାଟା ତୃତୀୟ ପକ୍ଷକୁ ବିକ୍ରି କରୁନାହୁଁ, ଭଡ଼ାରେ ଦେଉନାହୁଁ କିମ୍ବା ବ୍ୟବସାୟିକ ଉଦ୍ଦେଶ୍ୟରେ ସେୟାର୍ କରୁନାହୁଁ।

6. ଆପଣଙ୍କ ନିୟନ୍ତ୍ରଣ

ଆପ୍‌ରେ ସାଇତା ଆପଣଙ୍କ ଡାଟା ଆପଣ ଯେକୌଣସି ସମୟରେ ଦେଖିପାରିବେ, ବଦଳାଇପାରିବେ କିମ୍ବା ମାଛିପାରିବେ।

7. ତୃତୀୟ ପକ୍ଷର ସେବା

ଆପ୍‌ର କିଛି ସୁବିଧା ପାଇଁ ତୃତୀୟ ପକ୍ଷର ସେବା ବ୍ୟବହୃତ ହେଲେ, ସେମାନଙ୍କ ନିଜସ୍ୱ ଗୋପନୀୟତା ନୀତି ଲାଗୁ ହୋଇପାରେ।

8. ପିଲାମାନଙ୍କ ଗୋପନୀୟତା

ଉଧାର ହିସାବ ଜାଣିଶୁଣି ପିଲାମାନଙ୍କଠାରୁ ବ୍ୟକ୍ତିଗତ ସୂଚନା ସଂଗ୍ରହ ପାଇଁ ତିଆରି ହୋଇନାହିଁ।

9. ଏହି ଗୋପନୀୟତା ନୀତିରେ ପରିବର୍ତ୍ତନ

ଆବଶ୍ୟକ ଅନୁସାରେ ଆମେ ଏହି ଗୋପନୀୟତା ନୀତି ବଦଳାଇପାରୁ କିମ୍ବା ଅପଡେଟ୍ କରିପାରୁ। ନୂଆ ନୀତି ଏହି ପୃଷ୍ଠାରେ ପ୍ରକାଶିତ ହେବ।

10. ଯୋଗାଯୋଗ

ଏହି ଗୋପନୀୟତା ନୀତି କିମ୍ବା ଆପଣଙ୍କ ଡାଟା ବିଷୟରେ କୌଣସି ପ୍ରଶ୍ନ ଥିଲେ ଦୟାକରି ଆମ ସହ ଯୋଗାଯୋଗ କରନ୍ତୁ।

ଉଧାର ହିସାବ
ସହଜ ହିସାବ, ନିଶ୍ଚିନ୍ତ ରୁହନ୍ତୁ।"""
}

/** Assamese (অসমীয়া) */
object AssameseStrings : AppStrings {
    override val code = "as"
    // ── বিজ্ঞাপনমুক্ত / বিজ্ঞাপনের পছন্দ ──
    override val moreAdFree = "বিজ্ঞাপন আঁতৰাওক"
    override val moreHintAdFree = "এবাৰ কিনক, আৰু বিজ্ঞাপন নাথাকিব"
    override val adFreeDialogTitle = "বিজ্ঞাপনমুক্ত এপ"
    override val adFreeDialogMessage = "এবাৰ ধন দিলে সকলো বিজ্ঞাপন চিৰদিনৰ বাবে বন্ধ হ'ব। এপটোক সহায় কৰাৰ বাবে ধন্যবাদ!"
    override val adFreeBuyButton = "কিনক"
    override val adFreeRestoreButton = "আগৰ ক্ৰয় ঘূৰাই আনক"
    override val adFreeActiveLabel = "আপোনাৰ এপ বিজ্ঞাপনমুক্ত ✓"
    override val adFreeUnavailable = "এতিয়া কিনিব নোৱাৰি — পিছত আকৌ চেষ্টা কৰক"
    override val adSponsoredLabel = "বিজ্ঞাপন"
    override val moreAdPrivacy = "বিজ্ঞাপনৰ পছন্দ"
    override val moreHintAdPrivacy = "আপুনি কেনেকুৱা বিজ্ঞাপন চাব সেয়া বাছনি কৰক"
    override val helpCenterTitle = "সহায় কেন্দ্ৰ"
    override val helpSearchPlaceholder = "প্ৰশ্ন বিচাৰক..."
    override val noFaqResultsMessage = "একো পোৱা নগ'ল"
    override val homeHeadline = "উধাৰ হিচাপ"
    override val history = "ইতিহাস"
    override val settings = "ছেটিংছ"
    override val totalDueLabel = "মুঠ বাকী"
    override val thisMonthCreditLabel = "এই মাহৰ বাকী"
    override val thisMonthPaymentLabel = "এই মাহত পোৱা"
    override val searchPlaceholder = "দোকান/ফোন বিচাৰক..."
    override val filterAll = "সকলো"
    override val settledLabel = "শুজি দিয়া হ'ল"
    override val noShopsYetTitle = "এতিয়াও কোনো দোকান নাই"
    override val noShopsYetSubtitle = "খাতা আৰম্ভ কৰিবলৈ প্ৰথম দোকান যোগ কৰক"
    override val addFirstShopButton = "প্ৰথম দোকান যোগ কৰক"
    override val newShop = "নতুন দোকান"
    override val shopTypeTea = "চাহৰ দোকান"
    override val shopTypeHardwareElectric = "হাৰ্ডৱেৰ আৰু ইলেক্ট্ৰিক"
    override val shopTypeKirana = "কিৰাণা দোকান"
    override val shopTypeVegetable = "পাচলিৰ দোকান"
    override val shopTypeFishMeat = "মাছ আৰু মাংস"
    override val shopTypeBakerySweets = "বেকাৰী আৰু মিঠাই"
    override val shopTypePharmacy = "দৰবৰ দোকান"
    override val shopTypeCosmetics = "প্ৰসাধন সামগ্ৰী"
    override val shopTypeStationery = "ষ্টেচনাৰী"
    override val shopTypeXeroxPrinting = "জেৰক্স আৰু প্ৰিণ্টিং"
    override val shopTypeWood = "কাঠৰ দোকান"
    override val shopTypeGarments = "কাপোৰৰ দোকান"
    override val shopTypeOther = "আন"
    override val back = "উভতি যাওক"
    override val cancel = "বাতিল"
    override val save = "ছেভ কৰক"
    override val shopNameLabel = "দোকানৰ নাম *"
    override val shopNamePlaceholder = "যেনে কাঠ মহল"
    override val phoneLabel = "ফোন নম্বৰ (ঐচ্ছিক)"
    override val shopTypeLabel = "দোকানৰ প্ৰকাৰ *"
    override val saveShopButton = "দোকান ছেভ কৰক"
    override val errorNameRequired = "দোকানৰ নাম লিখক"
    override val errorTypeRequired = "দোকানৰ প্ৰকাৰ বাছনি কৰক"
    override val dueLabel = "বাকী"
    override val noTransactionsYet = "এতিয়াও কোনো লেনদেন নাই"
    override val creditButton = "উধাৰ ল'লোঁ"
    override val paymentButton = "ধন দিলোঁ"
    override val pdfExport = "PDF এক্সপৰ্ট"
    override val archive = "আৰ্কাইভ"
    override val deleteShopAction = "দোকান মচি পেলাওক"
    override val archiveConfirmTitle = "এই দোকান আৰ্কাইভ কৰিব নেকি?"
    override val archiveConfirmText = "ই হোমৰ তালিকাৰ পৰা আঁতৰি যাব — ইতিহাসত তথাপিও থাকিব।"
    override val deleteConfirmTitle = "এই দোকান চিৰদিনৰ বাবে মচিব নেকি?"
    override val deleteConfirmText = "এই দোকান আৰু ইয়াৰ সকলো লেনদেন চিৰদিনৰ বাবে মচি যাব আৰু উভতাই আনিব নোৱাৰি। আৰ্কাইভ কৰিলে ইতিহাসত থাকিব — আগবঢ়াৰ আগতে ভালকৈ ভাবি লওক।"
    override val yesDelete = "হয়, মচক"
    override val yesArchive = "আৰ্কাইভ কৰক"
    override val txnDeletedSnackbar = "লেনদেন মচা হ'ল"
    override val undo = "পূৰ্বাৱস্থাত ঘূৰাওক"
    override val pdfFailPrefix = "PDF বনাব পৰা নগ'ল: "
    override val shareKhata = "খাতা শ্বেয়াৰ কৰক"
    override val creditFallback = "উধাৰ"
    override val paymentFallback = "জমা"
    override val deleteTxnAction = "মচক"
    override val productNameLabel = "বস্তুৰ নাম (ঐচ্ছিক)"
    override val quantityLabel = "পৰিমাণ"
    override val unitLabel = "এককৰ"
    override val pricePerUnitLabel = "দৰ/একক"
    override val totalPrefix = "মুঠ: "
    override val amountLabel = "দিয়া ধন"
    override val orEnterAmountLabel = "বা পোনপটীয়াকৈ ধন লিখক"
    override val noteLabel = "টোকা (ঐচ্ছিক)"
    override val cash = "নগদ"
    override val bkash = "bKash"
    override val bank = "বেংক"
    override val invalidAmountError = "শুদ্ধ ধন লিখক"
    override val cftCalculatorTitle = "CFT কেলকুলেটৰ"
    override val lengthLabel = "দৈৰ্ঘ্য (ইঞ্চি)"
    override val widthLabel = "প্ৰস্থ"
    override val heightLabel = "উচ্চতা"
    override val rateLabel = "দৰ /cft (₹)"
    override val applyToEntryButton = "এণ্ট্ৰিত যোগ কৰক"
    override val settingsTitle = "ছেটিংছ"
    override val security = "সুৰক্ষা"
    override val pinLockOn = "PIN লক চলি আছে"
    override val pinLockOff = "PIN লক বন্ধ আছে"
    override val changePin = "PIN সলনি কৰক"
    override val reminderTitle = "বাকীৰ সোঁৱৰণী"
    override val reminderDesc = "প্ৰতিদিনে বাকীৰ কথা মনত পেলাই দিয়ে"
    override val about = "বিষয়ে"
    override val aboutLine = "উধাৰ হিচাপ — দোকানৰ উধাৰ খাতা"
    override val aboutDescription = "উধাৰ হিচাপ এটা স্মাৰ্ট হিচাপ এপ্, যিয়ে দোকানৰ উধাৰ, বাকী আৰু লেনদেন সহজে, দ্ৰুতভাৱে আৰু শৃংখলাবদ্ধভাৱে চম্ভালিবলৈ সহায় কৰে। কোনখন দোকানত কিমান বাকী আছে, ক'ত ধন দিয়া হ'ল আৰু কোনটো লেনদেন কেতিয়া হ'ল — সকলো এঠাইতে সুন্দৰকৈ সুৰক্ষিত কৰি ৰাখিব পাৰি।\n\nএই এপত আপুনি সহজে দোকান যোগ কৰিব পাৰে, উধাৰ আৰু জমা লিখিব পাৰে, লেনদেনৰ ইতিহাস চাব পাৰে, মুঠ বাকী আৰু জমা পৰীক্ষা কৰিব পাৰে আৰু বিতং প্ৰতিবেদন বনাব পাৰে। সন্ধান, ফিল্টাৰ, বেকআপ আৰু ৰিষ্টৰ, এপ লক, বায়োমেট্ৰিক সুৰক্ষা, ডাৰ্ক মোড আৰু জাননীৰ দৰে সুবিধাই হিচাপ ৰখাটো আৰু সহজ আৰু সুৰক্ষিত কৰে।\n\nকাগজৰ খাতাৰ জটিলতাক সৰল, আধুনিক আৰু ভৰসাযোগ্য ডিজিটেল পদ্ধতিলৈ অনাটোৱেই উধাৰ হিচাপৰ লক্ষ্য।"
    override val aboutTagline = "উধাৰ হিচাপ — সহজ হিচাপ, নিশ্চিন্তে থাকক।"
    override val versionLine = "সংস্কৰণ 1.0"
    override val setPinTitle = "PIN ছেট কৰক"
    override val newPinLabel = "নতুন PIN"
    override val confirmPinLabel = "PIN আকৌ লিখক"
    override val pinSetupError = "PIN মিলা নাই (কমেও 4 অংক)"
    override val removePinTitle = "PIN লক বন্ধ কৰিব নেকি?"
    override val removePinText = "এতিয়াৰ পৰা এপ খোলোতে PIN সোধা নহ'ব।"
    override val yesTurnOff = "হয়, বন্ধ কৰক"
    override val no = "নহয়"
    override val languageTitle = "ভাষা"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"
    override val notifSheetTitle = "জাননী"
    override val notifSheetSubtitle = "আপুনি কোনবোৰ সোঁৱৰণী বিচাৰে?"
    override val notifDueReminderOption = "বাকী পৰিশোধৰ সোঁৱৰণী"
    override val notifWeeklySummaryOption = "সাপ্তাহিক সাৰাংশ"
    override val notifAppNewsOption = "এপৰ খবৰ আৰু আপডেট"
    override val langSheetSubtitle = "এপ কোনটো ভাষাত চলাব?"
    override val themeSheetSubtitle = "আপুনি কোনটো থীম ভাল পায়?"
    override val securityPrivacyTitle = "সুৰক্ষা আৰু গোপনীয়তা"
    override val pinSectionTitle = "PIN লক"
    override val pinSectionDesc = "এপ খোলোতে PIN সোধক"
    override val fingerprintTitle = "ফিংগাৰপ্ৰিণ্ট লক"
    override val fingerprintDesc = "PIN ৰ সলনি ফিংগাৰপ্ৰিণ্টেৰে খোলক"
    override val fingerprintUnavailable = "এই ফোনত ফিংগাৰপ্ৰিণ্ট ছেন্সৰ পোৱা নগ'ল"
    override val lockImmediatelyTitle = "তৎক্ষণাত লক কৰক"
    override val lockImmediatelyDesc = "এপলৈ উভতি অহাৰ লগে লগে পুনৰ লক হ'ব"
    override val rateTitle = "ৰেটিং আৰু মতামত"
    override val rateSubtitle = "উধাৰ হিচাপ আপোনাৰ কেনেকুৱা লাগিছে?"
    override val rateStarsPrompt = "ৰেটিং দিবলৈ টেপ কৰক"
    override val rateThanksMessage = "ধন্যবাদ! আপোনাক Play Store লৈ লৈ গৈ আছোঁ…"
    override val feedbackPromptLow = "আপোনাৰ কি ভাল লগা নাছিল? আমাক কওক"
    override val feedbackPlaceholder = "আপোনাৰ মতামত লিখক…"
    override val feedbackSubmit = "পঠিয়াওক"
    override val feedbackThanks = "ধন্যবাদ, আপোনাৰ মতামত পঠোৱা হ'ল"
    override val aboutPageTitle = "উধাৰ হিচাপৰ বিষয়ে"
    override val aboutVersionPrefix = "সংস্কৰণ"
    override val aboutDeveloperLabel = "ডেভেলপাৰ"
    override val aboutDeveloperName = "উধাৰ হিচাপ দল"
    override val aboutPrivacyPolicy = "গোপনীয়তা নীতি"
    override val privacyPolicyEffectiveDate = "কাৰ্যকৰী তাৰিখ: 13 ছেপ্টেম্বৰ 2026"
    override val aboutShareApp = "শ্বেয়াৰ কৰক"
    override val aboutShareText = "উধাৰ হিচাপ — দোকানৰ উধাৰ খাতাৰ এই এপ চেষ্টা কৰি চাওক!"
    override val noArchivedShops = "কোনো আৰ্কাইভ কৰা দোকান নাই"
    override val noSettledShops = "কোনো শুজি দিয়া দোকান নাই"
    override val setupPinTitle = "4 অংকৰ PIN ছেট কৰক"
    override val unlockPinTitle = "PIN ৰে খোলক"
    override val pinLabel = "PIN"
    override val pinDigitsError = "4 টা অংক লিখক"
    override val pinsDontMatchError = "PIN মিলা নাই"
    override val wrongPinError = "PIN ভুল — আকৌ চেষ্টা কৰক"
    override val savePinButton = "PIN ছেভ কৰক"
    override val unlockButton = "খোলক"
    override val pdfHeaderTitle = "খাতা — উধাৰ হিচাপ"
    override val pdfFullKhataSuffix = "সম্পূৰ্ণ খাতা"
    override val pdfShopLabel = "দোকান: "
    override val pdfPhoneLabel = "ফোন: "
    override val pdfCreatedLabel = "বনোৱা: "
    override val pdfColDate = "তাৰিখ/সময়"
    override val pdfColDesc = "বিৱৰণ"
    override val pdfTotalCredit = "মুঠ উধাৰ:"
    override val pdfTotalPayment = "মুঠ জমা:"
    override val pdfCurrentDue = "বৰ্তমান বাকী:"
    override val pdfFooter = "উধাৰ হিচাপ এপৰ দ্বাৰা বনোৱা"
    override val navHome = "হোম"
    override val navHistory = "ইতিহাস"
    override val navReports = "প্ৰতিবেদন"
    override val navMore = "অধিক"
    override val historyFilterAllShops = "সকলো দোকান"
    override val historyFilterAllTypes = "সকলো"
    override val historyFilterCreditOnly = "কেৱল উধাৰ"
    override val historyFilterPaymentOnly = "কেৱল জমা"
    override val historyNoTxnsFound = "কোনো লেনদেন পোৱা নগ'ল"
    override val viewArchivedAction = "আৰ্কাইভ কৰা দোকান চাওক"
    override val reportsTitle = "প্ৰতিবেদন"
    override val periodLabel = "সময়সীমা"
    override val period7d = "যোৱা 7 দিন"
    override val period15d = "যোৱা 15 দিন"
    override val period30d = "যোৱা 30 দিন"
    override val period3m = "যোৱা 3 মাহ"
    override val period1y = "এই বছৰ"
    override val reportTotalCredit = "মুঠ উধাৰ"
    override val reportTotalPayment = "মুঠ জমা"
    override val reportCurrentDue = "বৰ্তমান মুঠ বাকী"
    override val reportTxnCount = "লেনদেন"
    override val reportChartTitle = "উধাৰ বনাম জমা"
    override val reportShopWiseTitle = "দোকান অনুযায়ী বাকী"
    override val reportAgingTitle = "বাকীৰ বয়স"
    override val reportAging0to7 = "0–7 দিন"
    override val reportAging7to15 = "7–15 দিন"
    override val reportAging15to30 = "15–30 দিন"
    override val reportAging30plus = "30+ দিন"
    override val reportRecentPaymentsTitle = "শেহতীয়া জমা"
    override val reportNoData = "এই সময়ৰ কোনো তথ্য নাই"
    override val reportSmartSummaryPrefix = "এই সময়ছোৱাত আপুনি"
    override val moreTitle = "অধিক"
    override val moreBackupRestore = "বেকআপ আৰু ৰিষ্টৰ"
    override val moreHintBackupRestore = "আপোনাৰ ডাটা সুৰক্ষিত ৰাখক"
    override val notesTitle = "টোকা"
    override val notesSearchPlaceholder = "টোকা বিচাৰক..."
    override val addNoteButton = "নতুন টোকা"
    override val noNotesYetTitle = "এতিয়াও কোনো টোকা নাই"
    override val noNotesYetSubtitle = "কিনা-বেচাৰ তালিকা, সোঁৱৰণী — যিকোনো লিখি ৰাখক"
    override val deleteNoteConfirmTitle = "এই টোকা মচিব নেকি?"
    override val deleteNoteConfirmMessage = "এই টোকা চিৰদিনৰ বাবে মচি যাব।"
    override val noteTitlePlaceholder = "শিৰোনাম"
    override val noteContentPlaceholder = "কিবা লিখক..."
    override val untitledNote = "শিৰোনামবিহীন টোকা"
    override val notificationInboxTitle = "জাননী"
    override val moreNotificationHistory = "জাননীৰ ইতিহাস"
    override val moreHintNotificationHistory = "শেহতীয়া কাৰ্যকলাপ চাওক"
    override val noNotificationsYetTitle = "এতিয়াও কোনো জাননী নাই"
    override val noNotificationsYetSubtitle = "উধাৰ বা জমা লিখিলে ইয়াত দেখা যাব"
    override val notifCreditMessage = "%1\$s ৰ পৰা %2\$s উধাৰ লোৱা হ'ল"
    override val notifPaymentMessage = "%1\$s ক %2\$s জমা কৰা হ'ল"
    override val moreQuickCalculator = "কুইক কেলকুলেটৰ"
    override val moreHintQuickCalculator = "সোনকালে হিচাপ কৰক"
    override val calcGeneralTab = "সাধাৰণ"
    override val calcPercentTab = "শতাংশ"
    override val calcConversionTab = "ৰূপান্তৰ"
    override val calcComingSoonInTab = "সোনকালেই আহিব"
    override val percentOfTitle = "এটা সংখ্যাৰ শতাংশ"
    override val percentOfValueLabel = "সংখ্যা"
    override val percentOfPercentLabel = "শতাংশ (%)"
    override val percentIsWhatTitle = "এটা সংখ্যা আনটোৰ কিমান শতাংশ"
    override val percentIsWhatXLabel = "এই সংখ্যা"
    override val percentIsWhatYLabel = "ইয়াৰ"
    override val percentChangeTitle = "শতাংশ বৃদ্ধি/হ্ৰাস"
    override val percentChangeBaseLabel = "মূল সংখ্যা"
    override val percentChangePercentLabel = "শতাংশ (%)"
    override val increaseOption = "বৃদ্ধি"
    override val decreaseOption = "হ্ৰাস"
    override val resultLabel = "ফলাফল"
    override val weightCategory = "ওজন"
    override val lengthCategory = "দৈৰ্ঘ্য"
    override val volumeCategory = "আয়তন"
    override val fromLabel = "পৰা"
    override val toLabel = "লৈকে"
    override val enterValueHint = "মান লিখক"
    override val backupNowButton = "এতিয়াই বেকআপ লওক"
    override val backupNowHint = "সকলো দোকান আৰু লেনদেন JSON ফাইলত ছেভ কৰক"
    override val restoreButton = "বেকআপৰ পৰা ৰিষ্টৰ কৰক"
    override val restoreShopAction = "ৰিষ্টৰ"
    override val restoreHint = "পুৰণি JSON বেকআপ ফাইলৰ পৰা ডাটা ঘূৰাই আনক"
    override val lastBackupLabel = "শেষ বেকআপ"
    override val noBackupYetLabel = "এতিয়ালৈকে বেকআপ লোৱা হোৱা নাই"
    override val backupSuccessMessage = "বেকআপ বনোৱা হ'ল"
    override val backupFailPrefix = "বেকআপ ব্যৰ্থ: "
    override val restoreConfirmTitle = "বেকআপ ৰিষ্টৰ কৰিব নেকি?"
    override val restoreConfirmMessage = "ইয়াৰ ফলত বৰ্তমানৰ সকলো দোকান আৰু লেনদেন মচি যাব আৰু বেকআপ ফাইলৰ ডাটা আহিব। এইটো উভতাব নোৱাৰি।"
    override val restoreSuccessMessage = "ৰিষ্টৰ সম্পূৰ্ণ হ'ল"
    override val restoreFailPrefix = "ৰিষ্টৰ ব্যৰ্থ: "
    override val dataSafeNote = "আপোনাৰ ডাটা কেৱল এই ফোনতেই থাকে — বেকআপ ফাইল নিজে সুৰক্ষিত ৰাখক"
    override val moreExportShare = "এক্সপৰ্ট আৰু শ্বেয়াৰ"
    override val moreHintExportShare = "PDF আৰু ফাইল পঠিয়াওক"
    override val moreNotifications = "জাননী"
    override val moreHintNotifications = "সোঁৱৰণী অন/অফ কৰক"
    override val moreLanguage = "ভাষা"
    override val moreHintLanguage = "আপোনাৰ ভাষা বাছনি কৰক"
    override val moreUserMode = "মই কোন"
    override val moreHintUserMode = "গ্ৰাহক বা দোকানী"
    override val moreSecurityPrivacy = "সুৰক্ষা আৰু গোপনীয়তা"
    override val moreHintSecurityPrivacy = "PIN আৰু ফিংগাৰপ্ৰিণ্ট লক"
    override val moreAppearance = "ৰূপ"
    override val moreHintAppearance = "লাইট, ডাৰ্ক বা ছিষ্টেম"
    override val moreRateFeedback = "ৰেটিং আৰু মতামত"
    override val moreHintRateFeedback = "আপোনাৰ মত জনাওক"
    override val moreAbout = "উধাৰ হিচাপৰ বিষয়ে"
    override val moreHintAbout = "সংস্কৰণ আৰু ডেভেলপাৰ"
    override val comingSoonMessage = "সোনকালেই আহিব"
    override val appearanceTitle = "ৰূপ"
    override val themeLight = "লাইট"
    override val themeDark = "ডাৰ্ক"
    override val themeSystem = "ছিষ্টেম ডিফল্ট"
    override val creditPageTitle = "উধাৰ লওক"
    override val accountingTypeLabel = "এণ্ট্ৰিৰ প্ৰকাৰ"
    override val directMoneyMode = "পোনপটীয়া ধন"
    override val productMode = "বস্তু অনুযায়ী"
    override val directMoneyAmountLabel = "কিমান উধাৰ দিলে?"
    override val previousDueLabel = "আগৰ বাকী"
    override val newCreditLabel = "নতুন উধাৰ"
    override val newTotalDueLabel = "নতুন মুঠ বাকী"
    override val addCreditButton = "উধাৰ যোগ কৰক"
    override val addMoreProductButton = "+ আৰু এটা বস্তু যোগ কৰক"
    override val totalNewCreditLabel = "মুঠ নতুন উধাৰ"
    override val editAction = "সলনি কৰক"
    override val itemsCountSuffix = "বস্তু"
    override val paymentPageTitle = "জমা"
    override val currentDueLabel = "বৰ্তমান বাকী"
    override val howMuchPaymentLabel = "কিমান জমা কৰিছে?"
    override val fullPaymentButton = "সম্পূৰ্ণ ধন"
    override val dueAfterPaymentLabel = "জমাৰ পিছত বাকী"
    override val addPaymentButton = "জমা যোগ কৰক"
    override val overpaymentBlockedMessage = "বৰ্তমান বাকীতকৈ বেছি জমা কৰিব নোৱাৰি"
    override val fullyPaidCelebration = "ইয়াৰ দ্বাৰা সম্পূৰ্ণ বাকী শুজি যাব"
    override val woodCalculatorTitle = "কাঠ কেলকুলেটৰ"
    override val woodTypeLabel = "কাঠৰ প্ৰকাৰ"
    override val sawnWoodOption = "ফলা কাঠ"
    override val roundWoodOption = "গোল গুড়ি"
    override val lengthFtLabel = "দৈৰ্ঘ্য (ফুট)"
    override val widthInLabel = "প্ৰস্থ (ইঞ্চি)"
    override val thicknessInLabel = "ঘনত্ব (ইঞ্চি)"
    override val girthInLabel = "পৰিধি (ইঞ্চি)"
    override val pieceCountLabel = "টুকুৰাৰ সংখ্যা"
    override val perPieceCftLabel = "প্ৰতি টুকুৰা"
    override val totalWoodCftLabel = "মুঠ কাঠ"
    override val perCftPriceLabel = "প্ৰতি CFT দৰ (₹)"
    override val totalWoodValueLabel = "মুঠ মূল্য"
    override val addWoodCalcButton = "এই কাঠৰ হিচাপ যোগ কৰক"
    override val woodNameLabel = "বস্তুৰ নাম"
    override val addMoreWoodProductButton = "+ আৰু এটা কাঠ/বস্তু যোগ কৰক"
    override val addedItemsHeader = "যোগ কৰা বস্তু/কাঠ"
    override val pdfOptionsTitle = "PDF বিকল্প"
    override val pdfPeriodLabel = "সময়সীমা"
    override val pdfThisMonth = "এই মাহ"
    override val pdfLastMonth = "যোৱা মাহ"
    override val pdfLast3Months = "যোৱা 3 মাহ"
    override val pdfCustomRange = "নিজৰ তাৰিখ"
    override val pdfShopLabelOption = "দোকান"
    override val pdfAllShopsOption = "সকলো দোকান"
    override val pdfContentLabel = "কি দেখুৱাব"
    override val pdfContentFull = "সকলো (লেনদেন + সাৰাংশ + স্বাক্ষৰ)"
    override val pdfContentSummaryOnly = "কেৱল সাৰাংশ"
    override val pdfContentTxnsOnly = "কেৱল লেনদেন"
    override val pdfFormatLabel = "ফৰ্মেট"
    override val pdfFormatA4 = "A4 প্ৰতিবেদন"
    override val pdfFormatReceipt = "ৰচিদ (58mm)"
    override val pdfGenerateButton = "PDF বনাওক"
    override val pdfFromDateLabel = "আৰম্ভণিৰ তাৰিখ"
    override val pdfToDateLabel = "শেষৰ তাৰিখ"
    override val pdfReportNumberLabel = "প্ৰতিবেদন নং"
    override val pdfShopBoxLabel = "দোকান"
    override val pdfDateBoxLabel = "তাৰিখ"
    override val pdfDaysOfRecordsSuffix = "দিনৰ ৰেকৰ্ড"
    override val pdfWeeklyChartTitle = "সাপ্তাহিক উধাৰ (ৰঙা) বনাম জমা (সেউজীয়া)"
    override val pdfFinalDueLabel = "বৰ্তমান বাকী"
    override val pdfShopSignatureLabel = "দোকানীৰ স্বাক্ষৰ"
    override val pdfCustomerSignatureLabel = "গ্ৰাহকৰ স্বাক্ষৰ"
    override val pdfAllShopsReportTitle = "সকলো দোকানৰ সাৰাংশ — উধাৰ হিচাপ"
    override val pdfPageLabel = "পৃষ্ঠা"
    override val moreShopProfile = "দোকানৰ প্ৰফাইল"
    override val moreHintShopProfile = "নাম, লোগো, ঠিকনা, সোঁৱৰণী"
    override val shopProfileTitle = "দোকানৰ প্ৰফাইল"
    override val shopProfileIntro = "এই তথ্য PDF ইনভইচ আৰু গ্ৰাহকলৈ পঠোৱা বাৰ্তাত ব্যৱহাৰ হ'ব"
    override val shopBusinessNameLabel = "দোকানৰ নাম"
    override val shopBusinessAddressLabel = "দোকানৰ ঠিকনা"
    override val shopBusinessPhoneLabel = "দোকানৰ ফোন নম্বৰ"
    override val countryCodeLabel = "দেশৰ ক'ড (যেনে 91)"
    override val shopLogoLabel = "দোকানৰ লোগো"
    override val shopLogoPick = "লোগো বাছনি কৰক"
    override val shopLogoRemove = "লোগো আঁতৰাওক"
    override val promptAfterEntryLabel = "এণ্ট্ৰিৰ পিছত গ্ৰাহকক জনোৱাৰ বিকল্প দেখুৱাওক"
    override val saveProfileButton = "প্ৰফাইল ছেভ কৰক"
    override val profileSavedMessage = "প্ৰফাইল ছেভ হ'ল"
    override val errorShopNameForPdf = "PDF ত ব্যৱহাৰৰ বাবে দোকানৰ নাম দিয়ক"
    override val reminderSendAction = "সোঁৱৰণী পঠিয়াওক"
    override val reminderDialogTitle = "গ্ৰাহকক জনাওক"
    override val reminderDialogSubtitle = "বাৰ্তা সলনি কৰি WhatsApp বা SMS ৰে পঠিয়াওক"
    override val reminderMessageLabel = "বাৰ্তা"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "এতিয়া নহয়"
    override val reminderNoPhone = "এই গ্ৰাহকৰ ফোন নম্বৰ নাই"
    override val reminderAppMissing = "এপ খুলিব পৰা নগ'ল"
    override val reminderShopFallback = "আমাৰ দোকান"
    override val reminderMsgDue = "নমস্কাৰ %1\$s, %2\$s ৰ খাতাত আপোনাৰ মুঠ বাকী %3\$s। অনুগ্ৰহ কৰি সময়মতে শুজি দিয়ক। ধন্যবাদ।"
    override val reminderMsgCredit = "নমস্কাৰ %1\$s, %2\$s ৰ খাতাত আপোনাৰ নতুন উধাৰ যোগ কৰা হৈছে। মুঠ বাকী: %3\$s।"
    override val reminderMsgPayment = "নমস্কাৰ %1\$s, আপোনাৰ ধন পালোঁ। ধন্যবাদ! %2\$s ৰ খাতাত বৰ্তমান বাকী: %3\$s।"
    override val reminderMsgSettled = "নমস্কাৰ %1\$s, আপোনাৰ সকলো বাকী শুজি দিয়া হ'ল। ধন্যবাদ! — %2\$s"
    override val pdfActionLabel = "📤 কি কৰিব"
    override val pdfActionShare = "শ্বেয়াৰ"
    override val pdfActionSave = "ছেভ"
    override val pdfActionPrint = "প্ৰিণ্ট"
    override val pdfBrandingOption = "মোৰ দোকানৰ নাম, লোগো আৰু ঠিকনা যোগ কৰক"
    override val pdfBrandingMissing = "দোকানৰ নাম দিয়া হোৱা নাই — অধিক → দোকানৰ প্ৰফাইলত যোগ কৰক"
    override val pdfSavedMessage = "PDF ছেভ হ'ল"
    override val pdfSaveFailed = "PDF ছেভ কৰিব পৰা নগ'ল"
    override val setupRoleTitle = "আপুনি এপটো কেনেকৈ ব্যৱহাৰ কৰিব?"
    override val setupProfileTitle = "আপোনাৰ দোকানৰ বিৱৰণ"
    override val setupProfileSubtitle = "পিছত অধিক → দোকানৰ প্ৰফাইলৰ পৰা সলনি কৰিব পাৰিব"
    override val setupContinue = "আগবাঢ়ক"
    override val setupSkip = "এতিয়া নহয়, পিছত কৰিম"
    override val setupFinish = "আৰম্ভ কৰক"
    override val pickFromContacts = "যোগাযোগৰ পৰা নম্বৰ বাছনি কৰক"
    override val pdfColQtyPrice = "পৰিমাণ × দৰ"
    override val pdfColItemTotal = "বস্তুৰ ধন"
    override val pdfWoodSawn = "ফলা কাঠ"
    override val pdfWoodRound = "গোল গুড়ি"
    override val pdfWoodFormula = "সূত্ৰ"
    override val pdfWoodTotalWord = "মুঠ"
    override val pdfMemoTitle = "কেশ মেমো"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "বিল নং / Bill No"
    override val pdfDateTitle = "তাৰিখ / Date"
    override val pdfPeriodTitle = "সময়সীমা / Period"
    override val pdfSeller = "বিক্ৰেতা / Seller"
    override val pdfBuyer = "ক্ৰেতা / Buyer"
    override val pdfAddressLabel = "ঠিকনা: "
    override val pdfColSl = "ক্ৰম"
    override val pdfColPieces = "সংখ্যা"
    override val pdfColCft = "CFT"
    override val pdfColRate = "দৰ (₹/CFT)"
    override val pdfColAmountRs = "মুঠ (₹)"
    override val pdfColQty = "পৰিমাণ"
    override val pdfColUnitPrice = "দৰ (₹)"
    override val pdfSecSawn = "ফলা কাঠ / Sawn Timber"
    override val pdfSecRound = "গোল গুড়ি / Round Log"
    override val pdfSecOther = "আন বস্তু / Other Items"
    override val pdfSecCashCredit = "নগদ উধাৰ / Cash Credit"
    override val pdfSecPayments = "জমা / Payments"
    override val pdfBadgeSawn = "ফলা"
    override val pdfBadgeRound = "গোল"
    override val pdfSawnTotal = "ফলা কাঠৰ মুঠ:"
    override val pdfRoundTotal = "গোল গুড়িৰ মুঠ:"
    override val pdfTableTotal = "মুঠ:"
    override val pdfSumBill = "মুঠ বিল"
    override val pdfSumPaid = "জমা"
    override val pdfSumDue = "বাকী"
    override val pdfWordsTitle = "ধন আখৰত / Amount in Words:"
    override val pdfSellerSign = "বিক্ৰেতাৰ স্বাক্ষৰ আৰু মোহৰ"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "ক্ৰেতাৰ স্বাক্ষৰ"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "এইটো কম্পিউটাৰে বনোৱা বিল। স্বাক্ষৰ অবিহনে বৈধ নহয়।"
    override val pdfSummaryTitle = "সাৰাংশ প্ৰতিবেদন"
    override val moveShopAction = "আন তালিকালৈ স্থানান্তৰ কৰক"
    override val moveShopTitle = "আন তালিকালৈ স্থানান্তৰ কৰিব নেকি?"
    override val moveToShopkeeperMsg = "এই এণ্ট্ৰি \"মই দোকানী\" তালিকালৈ (আপোনাৰ গ্ৰাহক হিচাপে) যাব। ধনৰ পৰিমাণ একে থাকিব, কেৱল শব্দ সলনি হ'ব।"
    override val moveToCustomerMsg = "এই এণ্ট্ৰি \"মই গ্ৰাহক\" তালিকালৈ (যি দোকানৰ পৰা আপুনি উধাৰ লয়) যাব। ধনৰ পৰিমাণ একে থাকিব, কেৱল শব্দ সলনি হ'ব।"
    override val moveShopConfirm = "স্থানান্তৰ কৰক"
    override val faqItems = listOf(
        FaqItem("নতুন দোকান কেনেকৈ যোগ কৰিব?", "হোমৰ '+' বুটাম টিপক, দোকানৰ নাম, ফোন (ঐচ্ছিক) আৰু প্ৰকাৰ লিখি 'ছেভ কৰক' টিপক।"),
        FaqItem("উধাৰ বা জমা কেনেকৈ লিখিব?", "দোকানৰ পৃষ্ঠা খুলি 'উধাৰ ল'লোঁ' বা 'ধন দিলোঁ' টিপক, ধন লিখি নিশ্চিত কৰক।"),
        FaqItem("বায়োমেট্ৰিক লক কেনেকৈ অন/অফ কৰিব?", "অধিক → সুৰক্ষা আৰু গোপনীয়তাত 'বায়োমেট্ৰিক লক' অন/অফ কৰক। আপোনাৰ ফোনত ফিংগাৰপ্ৰিণ্ট বা ফেচ আনলক ছেট কৰা থাকিব লাগিব।"),
        FaqItem("ডাটাৰ বেকআপ কেনেকৈ ল'ব?", "অধিক → বেকআপ আৰু ৰিষ্টৰত 'এতিয়াই বেকআপ লওক' টিপক। ই এটা JSON ফাইল বনায়, যাক ফোন বা ক্লাউডত ছেভ কৰিব পাৰি।"),
        FaqItem("বেকআপৰ পৰা ডাটা কেনেকৈ ঘূৰাই আনিব?", "অধিক → বেকআপ আৰু ৰিষ্টৰত 'বেকআপৰ পৰা ৰিষ্টৰ কৰক' টিপি আপোনাৰ JSON ফাইল বাছনি কৰক। ই বৰ্তমানৰ সকলো ডাটা সলনি কৰে, গতিকে সাৱধান হওক।"),
        FaqItem("দোকান মচিলে উভতি পাব নেকি?", "আৰ্কাইভ কৰিলে ই ইতিহাসত থাকে আৰু পিছত উভতাই আনিব পাৰি। চিৰদিনৰ বাবে মচিলে উভতি নাহে।"),
        FaqItem("PDF প্ৰতিবেদন কেনেকৈ বনাব?", "'অধিক' পৃষ্ঠাত বেকআপ আৰু ৰিষ্টৰৰ কাষত এক্সপৰ্টৰ বিকল্প আছে, দোকান আৰু তাৰিখৰ সীমা বাছি PDF শ্বেয়াৰ কৰক।"),
        FaqItem("এপৰ ভাষা কেনেকৈ সলনি কৰিব?", "অধিক → ভাষাত আপোনাৰ ভাষা বাছি 'ছেভ কৰক' টিপক।")
    )
    override val privacyPolicyBody = """উধাৰ হিচাপ এটা ব্যক্তিগত আৰ্থিক/খাতা বহী এপ, যিয়ে আপোনাক দোকানৰ উধাৰ, বাকী আৰু লেনদেন সহজে চম্ভালিবলৈ সহায় কৰে। আপোনাৰ গোপনীয়তা আমাৰ বাবে গুৰুত্বপূৰ্ণ।

1. আমি সংগ্ৰহ কৰা তথ্য

উধাৰ হিচাপ ব্যৱহাৰ কৰোঁতে আপুনি নিজে এপত দিয়া তথ্য, যেনে:
• দোকানৰ নাম
• মোবাইল নম্বৰ
• দোকানৰ ঠিকনা বা আন বিৱৰণ
• উধাৰ আৰু জমা ধন
• লেনদেনৰ তাৰিখ, সময় আৰু টোকা

2. তথ্যৰ ব্যৱহাৰ

এই তথ্য কেৱল আপোনাৰ হিচাপ সঞ্চয় কৰিবলৈ, দেখুৱাবলৈ আৰু চম্ভালিবলৈ ব্যৱহাৰ কৰা হয়। আপোনাৰ ব্যক্তিগত খাতা বহীৰ ডাটা আপোনাৰ অনুমতি অবিহনে কোনো বিজ্ঞাপনদাতা বা তৃতীয় পক্ষক বিক্ৰী বা শ্বেয়াৰ কৰা নহয়।

3. ডাটা সংৰক্ষণ

এপৰ প্ৰয়োজন অনুসৰি আপোনাৰ হিচাপৰ ডাটা আপোনাৰ ডিভাইচত সংৰক্ষিত হ'ব পাৰে। আপুনি বেকআপ আৰু ৰিষ্টৰ সুবিধা ব্যৱহাৰ কৰিলে, আপুনি বাছনি কৰা ষ্টৰেজ/ক্লাউড সেৱাত বেকআপ ডাটা সংৰক্ষিত হ'ব পাৰে।

4. এপ সুৰক্ষা

আপোনাৰ হিচাপৰ ডাটা সুৰক্ষিত ৰাখিবলৈ এপ লক, PIN আৰু বায়োমেট্ৰিক প্ৰমাণীকৰণৰ দৰে সুৰক্ষা সুবিধা দিয়া হ'ব পাৰে।

5. তথ্য শ্বেয়াৰ কৰা

আইনে বাধ্যতামূলক কৰিলে বাদে, আমি আপোনাৰ ব্যক্তিগত খাতা বহীৰ ডাটা তৃতীয় পক্ষক বিক্ৰী নকৰোঁ, ভাড়ালৈ নিদিওঁ বা ব্যৱসায়িক উদ্দেশ্যে শ্বেয়াৰ নকৰোঁ।

6. আপোনাৰ নিয়ন্ত্ৰণ

এপত সংৰক্ষিত আপোনাৰ ডাটা আপুনি যিকোনো সময়তে চাব, সলনি কৰিব বা মচি পেলাব পাৰে।

7. তৃতীয় পক্ষৰ সেৱা

এপৰ কিছুমান সুবিধাৰ বাবে তৃতীয় পক্ষৰ সেৱা ব্যৱহাৰ হ'লে, সিহঁতৰ নিজা গোপনীয়তা নীতি প্ৰযোজ্য হ'ব পাৰে।

8. শিশুৰ গোপনীয়তা

উধাৰ হিচাপ জানিয়ে শুনিয়ে শিশুৰ পৰা ব্যক্তিগত তথ্য সংগ্ৰহ কৰিবলৈ বনোৱা হোৱা নাই।

9. এই গোপনীয়তা নীতিৰ পৰিৱৰ্তন

প্ৰয়োজন অনুসৰি আমি এই গোপনীয়তা নীতি সলনি বা আপডেট কৰিব পাৰোঁ। নতুন নীতি এই পৃষ্ঠাত প্ৰকাশ কৰা হ'ব।

10. যোগাযোগ

এই গোপনীয়তা নীতি বা আপোনাৰ ডাটাৰ বিষয়ে কোনো প্ৰশ্ন থাকিলে অনুগ্ৰহ কৰি আমাৰ সৈতে যোগাযোগ কৰক।

উধাৰ হিচাপ
সহজ হিচাপ, নিশ্চিন্তে থাকক।"""
}


/** ভাষা কোড ("bn"/"en"/"hi") → স্ট্রিং সেট */
fun stringsFor(languageCode: String): AppStrings = when (languageCode) {
    "en" -> EnglishStrings
    "hi" -> HindiStrings
    "mr" -> MarathiStrings
    "gu" -> GujaratiStrings
    "ta" -> TamilStrings
    "te" -> TeluguStrings
    "kn" -> KannadaStrings
    "ml" -> MalayalamStrings
    "pa" -> PunjabiStrings
    "or" -> OdiaStrings
    "as" -> AssameseStrings
    else -> BengaliStrings
}

val LocalStrings = staticCompositionLocalOf<AppStrings> { BengaliStrings }

/** ShopType-এর অনুবাদিত নাম */
fun ShopType.displayName(strings: AppStrings): String = when (this) {
    ShopType.TEA -> strings.shopTypeTea
    ShopType.HARDWARE_ELECTRIC -> strings.shopTypeHardwareElectric
    ShopType.KIRANA -> strings.shopTypeKirana
    ShopType.VEGETABLE -> strings.shopTypeVegetable
    ShopType.FISH_MEAT -> strings.shopTypeFishMeat
    ShopType.BAKERY_SWEETS -> strings.shopTypeBakerySweets
    ShopType.PHARMACY -> strings.shopTypePharmacy
    ShopType.COSMETICS -> strings.shopTypeCosmetics
    ShopType.STATIONERY -> strings.shopTypeStationery
    ShopType.XEROX_PRINTING -> strings.shopTypeXeroxPrinting
    ShopType.WOOD -> strings.shopTypeWood
    ShopType.GARMENTS -> strings.shopTypeGarments
    ShopType.OTHER -> strings.shopTypeOther
}
