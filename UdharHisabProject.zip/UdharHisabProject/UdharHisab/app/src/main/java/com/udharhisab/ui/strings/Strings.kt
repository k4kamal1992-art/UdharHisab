package com.udharhisab.ui.strings

import androidx.compose.runtime.staticCompositionLocalOf
import com.udharhisab.data.local.ShopType

/** হেল্প সেন্টারের একটা প্রশ্ন-উত্তর */
data class FaqItem(val question: String, val answer: String)

/**
 * ⭐ App-wide UI স্ট্রিং — ভাষা অনুযায়ী [BengaliStrings] / [EnglishStrings]
 * ব্যবহার করুন কম্পোজেবলে: LocalStrings.current.xxx
 */
interface AppStrings {
    // ── ভাষা কোড (UnitConverter.dateShort ইত্যাদি নন-কম্পোজেবল হেল্পারে পাস করার জন্য) ──
    val code: String
    val faqItems: List<FaqItem>
    val helpCenterTitle: String
    val helpSearchPlaceholder: String
    val noFaqResultsMessage: String

    // ── Home ──
    val homeHeadline: String
    val history: String
    val settings: String
    val totalDueLabel: String
    val thisMonthCreditLabel: String
    val thisMonthPaymentLabel: String
    val searchPlaceholder: String
    val filterAll: String
    val settledLabel: String
    val noShopsYetTitle: String
    val noShopsYetSubtitle: String
    val addFirstShopButton: String
    val newShop: String

    // ── Shop types ──
    val shopTypeTea: String
    val shopTypeHardwareElectric: String
    val shopTypeKirana: String
    val shopTypeVegetable: String
    val shopTypeFishMeat: String
    val shopTypeBakerySweets: String
    val shopTypePharmacy: String
    val shopTypeCosmetics: String
    val shopTypeStationery: String
    val shopTypeXeroxPrinting: String
    val shopTypeWood: String
    val shopTypeGarments: String
    val shopTypeOther: String

    // ── Common ──
    val back: String
    val cancel: String
    val save: String

    // ── Add shop ──
    val shopNameLabel: String
    val shopNamePlaceholder: String
    val phoneLabel: String
    val shopTypeLabel: String
    val saveShopButton: String
    val errorNameRequired: String
    val errorTypeRequired: String

    // ── Shop detail ──
    val dueLabel: String
    val noTransactionsYet: String
    val creditButton: String
    val paymentButton: String
    val pdfExport: String
    val archive: String
    val deleteShopAction: String
    val archiveConfirmTitle: String
    val archiveConfirmText: String
    val deleteConfirmTitle: String
    val deleteConfirmText: String
    val yesDelete: String
    val yesArchive: String
    val txnDeletedSnackbar: String
    val undo: String
    val pdfFailPrefix: String
    val shareKhata: String
    val creditFallback: String
    val paymentFallback: String
    val deleteTxnAction: String

    // ── Entry sheet ──
    val productNameLabel: String
    val quantityLabel: String
    val unitLabel: String
    val pricePerUnitLabel: String
    val totalPrefix: String
    val amountLabel: String
    val orEnterAmountLabel: String
    val noteLabel: String
    val cash: String
    val bkash: String
    val bank: String
    val invalidAmountError: String

    // ── CFT calculator ──
    val cftCalculatorTitle: String
    val lengthLabel: String
    val widthLabel: String
    val heightLabel: String
    val rateLabel: String
    val applyToEntryButton: String

    // ── Settings ──
    val settingsTitle: String
    val security: String
    val pinLockOn: String
    val pinLockOff: String
    val changePin: String
    val reminderTitle: String
    val reminderDesc: String
    val about: String
    val aboutLine: String
    val aboutDescription: String
    val aboutTagline: String
    val versionLine: String
    val setPinTitle: String
    val newPinLabel: String
    val confirmPinLabel: String
    val pinSetupError: String
    val removePinTitle: String
    val removePinText: String
    val yesTurnOff: String
    val no: String
    val languageTitle: String
    val languageBengaliOption: String
    val languageEnglishOption: String

    // ── More: Notification bottom sheet ──
    val notifSheetTitle: String
    val notifSheetSubtitle: String
    val notifDueReminderOption: String
    val notifWeeklySummaryOption: String
    val notifAppNewsOption: String

    // ── More: Language / Theme sheet subtitles ──
    val langSheetSubtitle: String
    val themeSheetSubtitle: String
    val moreHintBackupRestore: String
    val notesTitle: String
    val notesSearchPlaceholder: String
    val addNoteButton: String
    val noNotesYetTitle: String
    val noNotesYetSubtitle: String
    val deleteNoteConfirmTitle: String
    val deleteNoteConfirmMessage: String
    val noteTitlePlaceholder: String
    val noteContentPlaceholder: String
    val untitledNote: String
    val notificationInboxTitle: String
    val moreNotificationHistory: String
    val moreHintNotificationHistory: String
    val noNotificationsYetTitle: String
    val noNotificationsYetSubtitle: String
    val notifCreditMessage: String
    val notifPaymentMessage: String
    val moreQuickCalculator: String
    val moreHintQuickCalculator: String
    val calcGeneralTab: String
    val calcPercentTab: String
    val calcConversionTab: String
    val calcComingSoonInTab: String
    val percentOfTitle: String
    val percentOfValueLabel: String
    val percentOfPercentLabel: String
    val percentIsWhatTitle: String
    val percentIsWhatXLabel: String
    val percentIsWhatYLabel: String
    val percentChangeTitle: String
    val percentChangeBaseLabel: String
    val percentChangePercentLabel: String
    val increaseOption: String
    val decreaseOption: String
    val resultLabel: String
    val weightCategory: String
    val lengthCategory: String
    val volumeCategory: String
    val fromLabel: String
    val toLabel: String
    val enterValueHint: String
    val backupNowButton: String
    val backupNowHint: String
    val restoreButton: String
    val restoreShopAction: String
    val restoreHint: String
    val lastBackupLabel: String
    val noBackupYetLabel: String
    val backupSuccessMessage: String
    val backupFailPrefix: String
    val restoreConfirmTitle: String
    val restoreConfirmMessage: String
    val restoreSuccessMessage: String
    val restoreFailPrefix: String
    val dataSafeNote: String
    val moreHintExportShare: String
    val moreHintNotifications: String
    val moreHintLanguage: String
    val moreUserMode: String
    val moreHintUserMode: String
    val moreHintSecurityPrivacy: String
    val moreHintAppearance: String
    val moreHintRateFeedback: String
    val moreHintAbout: String

    // ── Security & Privacy page ──
    val securityPrivacyTitle: String
    val pinSectionTitle: String
    val pinSectionDesc: String
    val fingerprintTitle: String
    val fingerprintDesc: String
    val fingerprintUnavailable: String
    val lockImmediatelyTitle: String
    val lockImmediatelyDesc: String

    // ── Rating & Feedback page ──
    val rateTitle: String
    val rateSubtitle: String
    val rateStarsPrompt: String
    val rateThanksMessage: String
    val feedbackPromptLow: String
    val feedbackPlaceholder: String
    val feedbackSubmit: String
    val feedbackThanks: String

    // ── About page ──
    val aboutPageTitle: String
    val aboutVersionPrefix: String
    val aboutDeveloperLabel: String
    val aboutDeveloperName: String
    val aboutPrivacyPolicy: String
    val privacyPolicyEffectiveDate: String
    val privacyPolicyBody: String
    val aboutShareApp: String
    val aboutShareText: String

    // ── History ──
    val noArchivedShops: String
    val noSettledShops: String

    // ── Lock screen ──
    val setupPinTitle: String
    val unlockPinTitle: String
    val pinLabel: String
    val pinDigitsError: String
    val pinsDontMatchError: String
    val wrongPinError: String
    val savePinButton: String
    val unlockButton: String

    // ── PDF ──
    val pdfHeaderTitle: String
    val pdfFullKhataSuffix: String
    val pdfShopLabel: String
    val pdfPhoneLabel: String
    val pdfCreatedLabel: String
    val pdfColDate: String
    val pdfColDesc: String
    val pdfTotalCredit: String
    val pdfTotalPayment: String
    val pdfCurrentDue: String
    val pdfFooter: String

    // ── Bottom nav ──
    val navHome: String
    val navHistory: String
    val navReports: String
    val navMore: String

    // ── Transaction history (new History tab) ──
    val historyFilterAllShops: String
    val historyFilterAllTypes: String
    val historyFilterCreditOnly: String
    val historyFilterPaymentOnly: String
    val historyNoTxnsFound: String
    val viewArchivedAction: String

    // ── Reports ──
    val reportsTitle: String
    val periodLabel: String
    val period7d: String
    val period15d: String
    val period30d: String
    val period3m: String
    val period1y: String
    val reportTotalCredit: String
    val reportTotalPayment: String
    val reportCurrentDue: String
    val reportTxnCount: String
    val reportChartTitle: String
    val reportShopWiseTitle: String
    val reportAgingTitle: String
    val reportAging0to7: String
    val reportAging7to15: String
    val reportAging15to30: String
    val reportAging30plus: String
    val reportRecentPaymentsTitle: String
    val reportNoData: String
    val reportSmartSummaryPrefix: String

    // ── More ──
    val moreTitle: String
    val moreBackupRestore: String
    val moreExportShare: String
    val moreNotifications: String
    val moreLanguage: String
    val moreSecurityPrivacy: String
    val moreAppearance: String
    val moreRateFeedback: String
    val moreAbout: String
    val comingSoonMessage: String

    // ── Appearance (Settings) ──
    val appearanceTitle: String
    val themeLight: String
    val themeDark: String
    val themeSystem: String

    // ── Credit entry screen (নতুন পূর্ণ-স্ক্রিন) ──
    val creditPageTitle: String
    val accountingTypeLabel: String
    val directMoneyMode: String
    val productMode: String
    val directMoneyAmountLabel: String
    val previousDueLabel: String
    val newCreditLabel: String
    val newTotalDueLabel: String
    val addCreditButton: String
    val addMoreProductButton: String
    val totalNewCreditLabel: String
    val editAction: String
    val itemsCountSuffix: String

    // ── Payment entry screen (নতুন পূর্ণ-স্ক্রিন) ──
    val paymentPageTitle: String
    val currentDueLabel: String
    val howMuchPaymentLabel: String
    val fullPaymentButton: String
    val dueAfterPaymentLabel: String
    val addPaymentButton: String
    val overpaymentBlockedMessage: String
    val fullyPaidCelebration: String

    // ── Timber calculator (কাঠের হিসাব) ──
    val woodCalculatorTitle: String
    val woodTypeLabel: String
    val sawnWoodOption: String
    val roundWoodOption: String
    val lengthFtLabel: String
    val widthInLabel: String
    val thicknessInLabel: String
    val girthInLabel: String
    val pieceCountLabel: String
    val perPieceCftLabel: String
    val totalWoodCftLabel: String
    val perCftPriceLabel: String
    val totalWoodValueLabel: String
    val addWoodCalcButton: String
    val woodNameLabel: String
    val addMoreWoodProductButton: String
    val addedItemsHeader: String

    // ── PDF অপশন ডায়ালগ ──
    val pdfOptionsTitle: String
    val pdfPeriodLabel: String
    val pdfThisMonth: String
    val pdfLastMonth: String
    val pdfLast3Months: String
    val pdfCustomRange: String
    val pdfShopLabelOption: String
    val pdfAllShopsOption: String
    val pdfContentLabel: String
    val pdfContentFull: String
    val pdfContentSummaryOnly: String
    val pdfContentTxnsOnly: String
    val pdfFormatLabel: String
    val pdfFormatA4: String
    val pdfFormatReceipt: String
    val pdfGenerateButton: String
    val pdfFromDateLabel: String
    val pdfToDateLabel: String

    // ── PDF-এ আঁকা কনটেন্ট ──
    val pdfReportNumberLabel: String
    val pdfShopBoxLabel: String
    val pdfDateBoxLabel: String
    val pdfDaysOfRecordsSuffix: String
    val pdfWeeklyChartTitle: String
    val pdfFinalDueLabel: String
    val pdfShopSignatureLabel: String
    val pdfCustomerSignatureLabel: String
    val pdfAllShopsReportTitle: String
    val pdfPageLabel: String

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    val moreShopProfile: String
    val moreHintShopProfile: String
    val shopProfileTitle: String
    val shopProfileIntro: String
    val shopBusinessNameLabel: String
    val shopBusinessAddressLabel: String
    val shopBusinessPhoneLabel: String
    val countryCodeLabel: String
    val shopLogoLabel: String
    val shopLogoPick: String
    val shopLogoRemove: String
    val promptAfterEntryLabel: String
    val saveProfileButton: String
    val profileSavedMessage: String
    val errorShopNameForPdf: String
    val reminderSendAction: String
    val reminderDialogTitle: String
    val reminderDialogSubtitle: String
    val reminderMessageLabel: String
    val reminderWhatsapp: String
    val reminderSms: String
    val reminderSkip: String
    val reminderNoPhone: String
    val reminderAppMissing: String
    val reminderShopFallback: String
    val reminderMsgDue: String
    val reminderMsgCredit: String
    val reminderMsgPayment: String
    val reminderMsgSettled: String
    val pdfActionLabel: String
    val pdfActionShare: String
    val pdfActionSave: String
    val pdfActionPrint: String
    val pdfBrandingOption: String
    val pdfBrandingMissing: String
    val pdfSavedMessage: String
    val pdfSaveFailed: String

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    val setupRoleTitle: String
    val setupProfileTitle: String
    val setupProfileSubtitle: String
    val setupContinue: String
    val setupSkip: String
    val setupFinish: String

    val pickFromContacts: String

    val pdfColQtyPrice: String
    val pdfColItemTotal: String

    val pdfWoodSawn: String
    val pdfWoodRound: String
    val pdfWoodFormula: String
    val pdfWoodTotalWord: String

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    val pdfMemoTitle: String
    val pdfMemoSubtitle: String
    val pdfBillNo: String
    val pdfDateTitle: String
    val pdfPeriodTitle: String
    val pdfSeller: String
    val pdfBuyer: String
    val pdfAddressLabel: String
    val pdfColSl: String
    val pdfColPieces: String
    val pdfColCft: String
    val pdfColRate: String
    val pdfColAmountRs: String
    val pdfColQty: String
    val pdfColUnitPrice: String
    val pdfSecSawn: String
    val pdfSecRound: String
    val pdfSecOther: String
    val pdfSecCashCredit: String
    val pdfSecPayments: String
    val pdfBadgeSawn: String
    val pdfBadgeRound: String
    val pdfSawnTotal: String
    val pdfRoundTotal: String
    val pdfTableTotal: String
    val pdfSumBill: String
    val pdfSumPaid: String
    val pdfSumDue: String
    val pdfWordsTitle: String
    val pdfSellerSign: String
    val pdfSellerSignSub: String
    val pdfBuyerSign: String
    val pdfBuyerSignSub: String
    val pdfMemoFooter: String

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    val pdfSummaryTitle: String
    val moveShopAction: String
    val moveShopTitle: String
    val moveToShopkeeperMsg: String
    val moveToCustomerMsg: String
    val moveShopConfirm: String
}

object BengaliStrings : AppStrings {
    override val code = "bn"
    override val helpCenterTitle = "সাহায্য কেন্দ্র"
    override val helpSearchPlaceholder = "প্রশ্ন খুঁজুন..."
    override val noFaqResultsMessage = "কোনো মিল পাওয়া যায়নি"
    override val faqItems = listOf(
        FaqItem(
            "কিভাবে নতুন দোকান যোগ করব?",
            "হোম স্ক্রিনের নিচে '+' বাটনে ট্যাপ করুন, দোকানের নাম, ফোন নম্বর (ঐচ্ছিক) আর ধরন দিয়ে 'সংরক্ষণ করুন' চাপুন।"
        ),
        FaqItem(
            "কিভাবে ধার নেব বা পরিশোধ করব?",
            "দোকানের বিস্তারিত পেজে গিয়ে 'ধার নিন' বা 'পরিশোধ' বাটনে ট্যাপ করুন, টাকার পরিমাণ দিয়ে যোগ করুন।"
        ),
        FaqItem(
            "বায়োমেট্রিক লক কিভাবে চালু/বন্ধ করব?",
            "আরও → নিরাপত্তা ও গোপনীয়তা পেজে গিয়ে 'বায়োমেট্রিক লক' টগল করুন। ডিভাইসে ফিঙ্গারপ্রিন্ট/ফেস আনলক সেট করা থাকতে হবে।"
        ),
        FaqItem(
            "ডেটা ব্যাকআপ কিভাবে নেব?",
            "আরও → ব্যাকআপ ও রিস্টোর পেজে গিয়ে 'এখনই ব্যাকআপ নিন' চাপুন। একটা JSON ফাইল তৈরি হবে, যেটা আপনি ফোনে বা ক্লাউডে সংরক্ষণ করতে পারবেন।"
        ),
        FaqItem(
            "ব্যাকআপ থেকে ডেটা কিভাবে ফিরিয়ে আনব?",
            "আরও → ব্যাকআপ ও রিস্টোর পেজে 'ব্যাকআপ থেকে রিস্টোর করুন' চাপুন, আগের JSON ফাইল বেছে নিন। এটি বর্তমান সব ডেটা মুছে ব্যাকআপ দিয়ে replace করবে, তাই সাবধানে করুন।"
        ),
        FaqItem(
            "একটা দোকান মুছে ফেললে কি আবার ফিরে পাব?",
            "আর্কাইভ করলে দোকানটা হিস্ট্রিতে থেকে যায়, পরে চাইলে ফিরিয়ে আনতে পারবেন। কিন্তু স্থায়ীভাবে ডিলিট করলে আর ফেরানো যাবে না।"
        ),
        FaqItem(
            "রিপোর্ট PDF কিভাবে বানাব?",
            "আরও পেজে 'ব্যাকআপ ও এক্সপোর্ট'-এর পাশে থাকা এক্সপোর্ট অপশনে গিয়ে দোকান আর সময়সীমা বেছে PDF তৈরি করুন, তারপর শেয়ার করুন।"
        ),
        FaqItem(
            "অ্যাপের ভাষা কিভাবে বদলাব?",
            "আরও → ভাষা নির্বাচন পেজে গিয়ে বাংলা বা English বেছে 'সংরক্ষণ করুন' চাপুন।"
        )
    )
    override val homeHeadline = "উধার হিসাব"
    override val history = "হিস্ট্রি"
    override val settings = "সেটিংস"
    override val totalDueLabel = "মোট বাকি আছে"
    override val thisMonthCreditLabel = "এ মাসে বাকি"
    override val thisMonthPaymentLabel = "এ মাসে জমা"
    override val searchPlaceholder = "দোকান/ফোন খুঁজুন..."
    override val filterAll = "সব"
    override val settledLabel = "পরিশোধিত"
    override val noShopsYetTitle = "কোনো দোকান নেই এখনো"
    override val noShopsYetSubtitle = "প্রথম দোকান যোগ করে খাতা শুরু করুন"
    override val addFirstShopButton = "প্রথম দোকান যোগ করুন"
    override val newShop = "নতুন দোকান"

    override val shopTypeTea = "চায়ের দোকান"
    override val shopTypeHardwareElectric = "হার্ডওয়্যার ও ইলেকট্রিক"
    override val shopTypeKirana = "মুদি দোকান"
    override val shopTypeVegetable = "কাঁচাবাজার/সবজি"
    override val shopTypeFishMeat = "মাছ ও মাংস"
    override val shopTypeBakerySweets = "বেকারি ও মিষ্টি"
    override val shopTypePharmacy = "ওষুধের দোকান"
    override val shopTypeCosmetics = "প্রসাধন সামগ্রী"
    override val shopTypeStationery = "স্টেশনারি"
    override val shopTypeXeroxPrinting = "জেরক্স ও প্রিন্টিং"
    override val shopTypeWood = "কাঠের দোকান"
    override val shopTypeGarments = "পোশাক"
    override val shopTypeOther = "অন্যান্য"

    override val back = "ফিরে যান"
    override val cancel = "বাতিল"
    override val save = "সেভ করুন"

    override val shopNameLabel = "দোকানের নাম *"
    override val shopNamePlaceholder = "যেমন: কাঠ মহল"
    override val phoneLabel = "ফোন নম্বর (ঐচ্ছিক)"
    override val shopTypeLabel = "দোকানের ধরন *"
    override val saveShopButton = "দোকান সেভ করুন"
    override val errorNameRequired = "দোকানের নাম লিখুন"
    override val errorTypeRequired = "দোকানের ধরন বেছে নিন"

    override val dueLabel = "বাকি আছে"
    override val noTransactionsYet = "এখনো কোনো লেনদেন নেই"
    override val creditButton = "ধার নিলাম"
    override val paymentButton = "জমা দিলাম"
    override val pdfExport = "PDF এক্সপোর্ট"
    override val archive = "আর্কাইভ"
    override val deleteShopAction = "দোকান ডিলিট করুন"
    override val archiveConfirmTitle = "দোকান আর্কাইভ করবেন?"
    override val archiveConfirmText = "আর্কাইভ করলে হোম লিস্ট থেকে সরে যাবে — হিস্ট্রিতে পাবেন।"
    override val deleteConfirmTitle = "দোকান স্থায়ীভাবে ডিলিট করবেন?"
    override val deleteConfirmText = "এই দোকান আর এর সব লেনদেন চিরতরে মুছে যাবে। এটি আর ফিরে পাওয়া যাবে না। আর্কাইভ করলে বরং হিস্ট্রিতে থেকে যেত — নিশ্চিত হয়ে এগোন।"
    override val yesDelete = "হ্যাঁ, ডিলিট করুন"
    override val yesArchive = "আর্কাইভ"
    override val txnDeletedSnackbar = "লেনদেন মুছে ফেলা হয়েছে"
    override val undo = "আনডু"
    override val pdfFailPrefix = "PDF তৈরি ব্যর্থ: "
    override val shareKhata = "খাতা শেয়ার করুন"
    override val creditFallback = "ধার"
    override val paymentFallback = "জমা"
    override val deleteTxnAction = "মুছুন"

    override val productNameLabel = "পণ্যের নাম (ঐচ্ছিক)"
    override val quantityLabel = "পরিমাণ"
    override val unitLabel = "একক"
    override val pricePerUnitLabel = "দাম/একক"
    override val totalPrefix = "মোট: "
    override val amountLabel = "কত টাকা জমা দিলেন"
    override val orEnterAmountLabel = "অথবা সরাসরি টাকার পরিমাণ লিখুন"
    override val noteLabel = "নোট (ঐচ্ছিক)"
    override val cash = "নগদ"
    override val bkash = "বিকাশ"
    override val bank = "ব্যাংক"
    override val invalidAmountError = "সঠিক টাকার পরিমাণ দিন"

    override val cftCalculatorTitle = "CFT ক্যালকুলেটর"
    override val lengthLabel = "দৈর্ঘ্য (ইঞ্চি)"
    override val widthLabel = "প্রস্থ"
    override val heightLabel = "উচ্চতা"
    override val rateLabel = "রেট /cft (৳)"
    override val applyToEntryButton = "হিসাব এন্ট্রিতে বসাও"

    override val settingsTitle = "সেটিংস"
    override val security = "নিরাপত্তা"
    override val pinLockOn = "PIN লক চালু আছে"
    override val pinLockOff = "PIN লক বন্ধ আছে"
    override val changePin = "PIN পরিবর্তন করুন"
    override val reminderTitle = "বকেয়া রিমাইন্ডার"
    override val reminderDesc = "প্রতিদিন বকেয়ার কথা মনে করিয়ে দেবে"
    override val about = "সম্পর্কে"
    override val aboutLine = "উধার হিসাব — দোকানের বাকির খাতা"
    override val aboutDescription = "UdharHisab হলো দোকানের ধার-পাওনা ও লেনদেনের হিসাব সহজ, দ্রুত এবং সুশৃঙ্খলভাবে পরিচালনা করার জন্য তৈরি একটি স্মার্ট হিসাব অ্যাপ। বিভিন্ন দোকানে আপনার কত টাকা ধার আছে, কোথায় কত টাকা পরিশোধ করেছেন এবং কোন লেনদেন কখন হয়েছে—সবকিছু এক জায়গায় সুন্দরভাবে সংরক্ষণ ও পরিচালনা করতে পারবেন।\n\nঅ্যাপটির মাধ্যমে আপনি সহজেই দোকান যোগ করতে, ধার ও পরিশোধের হিসাব রাখতে, লেনদেনের ইতিহাস দেখতে, মোট বাকি ও পরিশোধের পরিমাণ জানতে এবং বিস্তারিত রিপোর্ট তৈরি করতে পারবেন। পাশাপাশি Search, Filter, Backup & Restore, App Lock, Biometric Security, Dark Mode ও Notification-এর মতো সুবিধা আপনার হিসাব ব্যবস্থাপনাকে আরও সহজ ও নিরাপদ করে।\n\nUdharHisab-এর লক্ষ্য হলো—জটিল খাতা বা কাগজের হিসাবকে একটি সহজ, আধুনিক ও নির্ভরযোগ্য ডিজিটাল ব্যবস্থায় নিয়ে আসা।"
    override val aboutTagline = "UdharHisab — সহজ হিসাব, নিশ্চিন্ত থাকুন।"
    override val versionLine = "সংস্করণ 1.0"
    override val setPinTitle = "PIN সেট করুন"
    override val newPinLabel = "নতুন PIN"
    override val confirmPinLabel = "PIN আবার লিখুন"
    override val pinSetupError = "PIN মিলছে না (কমপক্ষে 4 ডিজিট)"
    override val removePinTitle = "PIN লক বন্ধ করবেন?"
    override val removePinText = "অ্যাপ খোলার সময় আর PIN চাওয়া হবে না।"
    override val yesTurnOff = "হ্যাঁ, বন্ধ করুন"
    override val no = "না"
    override val languageTitle = "ভাষা"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "নোটিফিকেশন"
    override val notifSheetSubtitle = "কোন রিমাইন্ডার চান?"
    override val notifDueReminderOption = "বাকি পরিশোধ রিমাইন্ডার"
    override val notifWeeklySummaryOption = "সাপ্তাহিক হিসাব সারাংশ"
    override val notifAppNewsOption = "অ্যাপ নিউজ ও আপডেট"

    override val langSheetSubtitle = "অ্যাপ কোন ভাষায় চলবে?"
    override val themeSheetSubtitle = "কোন থিম পছন্দ?"

    override val securityPrivacyTitle = "নিরাপত্তা ও প্রাইভেসি"
    override val pinSectionTitle = "PIN লক"
    override val pinSectionDesc = "অ্যাপ খুললে PIN চাইবে"
    override val fingerprintTitle = "ফিঙ্গারপ্রিন্ট লক"
    override val fingerprintDesc = "PIN-এর বদলে আঙুলের ছাপ দিয়ে আনলক করুন"
    override val fingerprintUnavailable = "এই ফোনে ফিঙ্গারপ্রিন্ট সেন্সর পাওয়া যায়নি"
    override val lockImmediatelyTitle = "সাথে সাথে লক করুন"
    override val lockImmediatelyDesc = "অ্যাপ থেকে বের হয়ে আবার ঢুকলেই লক লাগবে"

    override val rateTitle = "রেটিং ও ফিডব্যাক"
    override val rateSubtitle = "উধার হিসাব আপনার কেমন লাগছে?"
    override val rateStarsPrompt = "তারা দিয়ে রেট করুন"
    override val rateThanksMessage = "ধন্যবাদ! Play Store-এ নিয়ে যাচ্ছি…"
    override val feedbackPromptLow = "কী ভালো লাগেনি? আমাদের জানান"
    override val feedbackPlaceholder = "আপনার মতামত লিখুন…"
    override val feedbackSubmit = "পাঠান"
    override val feedbackThanks = "ধন্যবাদ, আপনার মতামত পৌঁছে গেছে"

    override val aboutPageTitle = "উধার হিসাব সম্পর্কে"
    override val aboutVersionPrefix = "সংস্করণ"
    override val aboutDeveloperLabel = "ডেভেলপার"
    override val aboutDeveloperName = "উধার হিসাব টিম"
    override val aboutPrivacyPolicy = "প্রাইভেসি পলিসি"
    override val privacyPolicyEffectiveDate = "কার্যকর তারিখ: 13 সেপ্টেম্বর 2026"
    override val privacyPolicyBody = """UdharHisab আপনার দোকানের ধার-পাওনা ও লেনদেনের হিসাব সহজভাবে পরিচালনা করার জন্য তৈরি একটি personal finance/ledger application। আপনার গোপনীয়তা আমাদের কাছে গুরুত্বপূর্ণ।

1. আমরা কোন তথ্য সংগ্রহ করি

UdharHisab ব্যবহারের সময় আপনি যে তথ্যগুলো নিজে অ্যাপে প্রবেশ করান, যেমন:
• দোকানের নাম
• মোবাইল নম্বর
• দোকানের ঠিকানা বা অন্যান্য বিবরণ
• ধার ও পরিশোধের পরিমাণ
• লেনদেনের তারিখ, সময় ও নোট

2. আপনার তথ্য কীভাবে ব্যবহার করা হয়

এই তথ্যগুলো শুধুমাত্র আপনার হিসাব সংরক্ষণ, দেখানো এবং পরিচালনার উদ্দেশ্যে ব্যবহার করা হয়। আপনার অনুমতি ছাড়া আপনার ব্যক্তিগত হিসাবের তথ্য কোনো বিজ্ঞাপনদাতা বা তৃতীয় পক্ষের কাছে বিক্রি বা শেয়ার করা হবে না।

3. Data Storage

আপনার হিসাবের তথ্য অ্যাপের প্রয়োজন অনুযায়ী আপনার ডিভাইসে সংরক্ষিত হতে পারে। আপনি Backup & Restore সুবিধা ব্যবহার করলে backup-এর তথ্য নির্বাচিত storage/cloud service-এর মাধ্যমে সংরক্ষিত হতে পারে।

4. App Security

আপনার হিসাবের তথ্য সুরক্ষিত রাখতে App Lock, PIN এবং Biometric Authentication-এর মতো নিরাপত্তা সুবিধা প্রদান করা হতে পারে।

5. তথ্য শেয়ার করা

আইনগত প্রয়োজন ছাড়া আপনার ব্যক্তিগত হিসাবের তথ্য আমরা তৃতীয় পক্ষের কাছে বিক্রি, ভাড়া বা বাণিজ্যিকভাবে শেয়ার করি না।

6. আপনার নিয়ন্ত্রণ

আপনি অ্যাপের মধ্যে সংরক্ষিত আপনার তথ্য দেখতে, পরিবর্তন করতে বা প্রয়োজন অনুযায়ী মুছে ফেলতে পারবেন।

7. Third-Party Services

অ্যাপের কিছু সুবিধার জন্য তৃতীয় পক্ষের service ব্যবহার করা হলে তাদের নিজস্ব Privacy Policy প্রযোজ্য হতে পারে।

8. শিশুদের গোপনীয়তা

UdharHisab শিশুদের ব্যক্তিগত তথ্য সংগ্রহ করার উদ্দেশ্যে তৈরি নয়।

9. Privacy Policy পরিবর্তন

প্রয়োজনে আমরা এই Privacy Policy পরিবর্তন বা আপডেট করতে পারি। নতুন Policy এই পেজে প্রকাশ করা হবে।

10. যোগাযোগ

Privacy Policy বা আপনার তথ্য সম্পর্কিত কোনো প্রশ্ন থাকলে আমাদের সঙ্গে যোগাযোগ করুন।

UdharHisab
সহজ হিসাব, নিশ্চিন্ত থাকুন।"""
    override val aboutShareApp = "শেয়ার করুন"
    override val aboutShareText = "উধার হিসাব — দোকানের বাকির খাতা অ্যাপটা ব্যবহার করে দেখুন!"

    override val noArchivedShops = "আর্কাইভ করা দোকান নেই"
    override val noSettledShops = "পরিশোধিত দোকান নেই"

    override val setupPinTitle = "4-ডিজিটের পিন সেট করুন"
    override val unlockPinTitle = "পিন দিয়ে আনলক করুন"
    override val pinLabel = "পিন"
    override val pinDigitsError = "4 ডিজিট দিন"
    override val pinsDontMatchError = "দুটো পিন মিলছে না"
    override val wrongPinError = "ভুল পিন — আবার চেষ্টা করুন"
    override val savePinButton = "পিন সেভ করুন"
    override val unlockButton = "আনলক"

    override val pdfHeaderTitle = "খাতা — উধার হিসাব"
    override val pdfFullKhataSuffix = "পূর্ণ খাতা"
    override val pdfShopLabel = "দোকান: "
    override val pdfPhoneLabel = "ফোন: "
    override val pdfCreatedLabel = "তৈরি: "
    override val pdfColDate = "তারিখ/সময়"
    override val pdfColDesc = "বিবরণ"
    override val pdfTotalCredit = "মোট ধার:"
    override val pdfTotalPayment = "মোট জমা:"
    override val pdfCurrentDue = "বর্তমান বাকি:"
    override val pdfFooter = "ধার হিসাব অ্যাপ দিয়ে তৈরি"

    override val navHome = "হোম"
    override val navHistory = "হিস্ট্রি"
    override val navReports = "রিপোর্ট"
    override val navMore = "আরও"

    override val historyFilterAllShops = "সব দোকান"
    override val historyFilterAllTypes = "সব"
    override val historyFilterCreditOnly = "শুধু ধার"
    override val historyFilterPaymentOnly = "শুধু পরিশোধ"
    override val historyNoTxnsFound = "কোনো লেনদেন পাওয়া যায়নি"
    override val viewArchivedAction = "আর্কাইভ করা দোকান দেখুন"

    override val reportsTitle = "রিপোর্ট"
    override val periodLabel = "সময়"
    override val period7d = "গত 7 দিন"
    override val period15d = "গত 15 দিন"
    override val period30d = "গত 30 দিন"
    override val period3m = "গত 3 মাস"
    override val period1y = "এই বছর"
    override val reportTotalCredit = "মোট ধার"
    override val reportTotalPayment = "মোট পরিশোধ"
    override val reportCurrentDue = "বর্তমান মোট বাকি"
    override val reportTxnCount = "লেনদেনের সংখ্যা"
    override val reportChartTitle = "ধার বনাম পরিশোধ"
    override val reportShopWiseTitle = "দোকানভিত্তিক বাকি"
    override val reportAgingTitle = "পুরনো বাকি"
    override val reportAging0to7 = "0–7 দিন"
    override val reportAging7to15 = "7–15 দিন"
    override val reportAging15to30 = "15–30 দিন"
    override val reportAging30plus = "30+ দিন"
    override val reportRecentPaymentsTitle = "সাম্প্রতিক পরিশোধ"
    override val reportNoData = "এই সময়ে কোনো তথ্য নেই"
    override val reportSmartSummaryPrefix = "এই সময়ে আপনি"

    override val moreTitle = "আরও"
    override val moreBackupRestore = "ব্যাকআপ ও রিস্টোর"
    override val moreHintBackupRestore = "ডেটা নিরাপদ রাখুন"
    override val notesTitle = "নোট"
    override val notesSearchPlaceholder = "নোট খুঁজুন..."
    override val addNoteButton = "নতুন নোট"
    override val noNotesYetTitle = "এখনো কোনো নোট নেই"
    override val noNotesYetSubtitle = "বাজারের তালিকা, রিমাইন্ডার — যা খুশি লিখে রাখুন"
    override val deleteNoteConfirmTitle = "নোট মুছে ফেলবেন?"
    override val deleteNoteConfirmMessage = "এই নোটটি স্থায়ীভাবে মুছে যাবে।"
    override val noteTitlePlaceholder = "শিরোনাম"
    override val noteContentPlaceholder = "লিখুন..."
    override val untitledNote = "শিরোনামহীন নোট"
    override val notificationInboxTitle = "নোটিফিকেশন"
    override val moreNotificationHistory = "নোটিফিকেশন হিস্ট্রি"
    override val moreHintNotificationHistory = "সাম্প্রতিক কার্যকলাপ দেখুন"
    override val noNotificationsYetTitle = "এখনো কোনো নোটিফিকেশন নেই"
    override val noNotificationsYetSubtitle = "ধার/পরিশোধ করলে এখানে দেখতে পাবেন"
    override val notifCreditMessage = "%1\$s থেকে %2\$s ধার নেওয়া হয়েছে"
    override val notifPaymentMessage = "%1\$s-কে %2\$s পরিশোধ করা হয়েছে"
    override val moreQuickCalculator = "কুইক ক্যালকুলেটর"
    override val moreHintQuickCalculator = "দ্রুত হিসাব করুন"
    override val calcGeneralTab = "সাধারণ"
    override val calcPercentTab = "শতকরা"
    override val calcConversionTab = "রূপান্তর"
    override val calcComingSoonInTab = "শীঘ্রই আসছে"
    override val percentOfTitle = "সংখ্যার শতকরা কত"
    override val percentOfValueLabel = "সংখ্যা"
    override val percentOfPercentLabel = "শতকরা (%)"
    override val percentIsWhatTitle = "একটি সংখ্যা আরেকটির শতকরা কত"
    override val percentIsWhatXLabel = "এই সংখ্যা"
    override val percentIsWhatYLabel = "এর শতকরা"
    override val percentChangeTitle = "শতকরা বৃদ্ধি/হ্রাস"
    override val percentChangeBaseLabel = "মূল সংখ্যা"
    override val percentChangePercentLabel = "শতকরা (%)"
    override val increaseOption = "বৃদ্ধি"
    override val decreaseOption = "হ্রাস"
    override val resultLabel = "ফলাফল"
    override val weightCategory = "ওজন"
    override val lengthCategory = "দৈর্ঘ্য"
    override val volumeCategory = "আয়তন"
    override val fromLabel = "থেকে"
    override val toLabel = "এ"
    override val enterValueHint = "মান লিখুন"
    override val backupNowButton = "এখনই ব্যাকআপ নিন"
    override val backupNowHint = "JSON ফাইলে সব দোকান ও লেনদেন সংরক্ষণ করুন"
    override val restoreButton = "ব্যাকআপ থেকে রিস্টোর করুন"
    override val restoreShopAction = "ফিরিয়ে আনুন"
    override val restoreHint = "আগের JSON ব্যাকআপ ফাইল থেকে ডেটা ফিরিয়ে আনুন"
    override val lastBackupLabel = "শেষ ব্যাকআপ"
    override val noBackupYetLabel = "এখনো কোনো ব্যাকআপ নেওয়া হয়নি"
    override val backupSuccessMessage = "ব্যাকআপ তৈরি হয়েছে"
    override val backupFailPrefix = "ব্যাকআপ ব্যর্থ: "
    override val restoreConfirmTitle = "রিস্টোর করবেন?"
    override val restoreConfirmMessage = "এটি বর্তমান সব দোকান ও লেনদেন মুছে ফেলে ব্যাকআপ ফাইলের ডেটা দিয়ে replace করবে। এই কাজ ফেরানো যাবে না।"
    override val restoreSuccessMessage = "রিস্টোর সম্পন্ন হয়েছে"
    override val restoreFailPrefix = "রিস্টোর ব্যর্থ: "
    override val dataSafeNote = "আপনার ডেটা শুধু এই ফোনেই থাকে — ব্যাকআপ ফাইল আপনি নিজে সংরক্ষণ করুন"
    override val moreExportShare = "এক্সপোর্ট ও শেয়ার"
    override val moreHintExportShare = "PDF ও ফাইল পাঠান"
    override val moreNotifications = "নোটিফিকেশন"
    override val moreHintNotifications = "রিমাইন্ডার চালু/বন্ধ করুন"
    override val moreLanguage = "ভাষা"
    override val moreHintLanguage = "বাংলা, English বা हिंदी"
    override val moreUserMode = "আমি কে"
    override val moreHintUserMode = "গ্রাহক নাকি দোকানদার"
    override val moreSecurityPrivacy = "নিরাপত্তা ও প্রাইভেসি"
    override val moreHintSecurityPrivacy = "PIN ও ফিঙ্গারপ্রিন্ট লক"
    override val moreAppearance = "অ্যাপের চেহারা"
    override val moreHintAppearance = "লাইট, ডার্ক বা সিস্টেম"
    override val moreRateFeedback = "রেটিং ও ফিডব্যাক"
    override val moreHintRateFeedback = "মতামত জানান"
    override val moreAbout = "উধার হিসাব সম্পর্কে"
    override val moreHintAbout = "ভার্সন ও ডেভেলপার"
    override val comingSoonMessage = "শীঘ্রই আসছে"

    override val appearanceTitle = "অ্যাপের চেহারা"
    override val themeLight = "লাইট"
    override val themeDark = "ডার্ক"
    override val themeSystem = "সিস্টেম ডিফল্ট"

    override val creditPageTitle = "ধার নিলাম"
    override val accountingTypeLabel = "হিসাবের ধরন"
    override val directMoneyMode = "সরাসরি টাকা"
    override val productMode = "পণ্য অনুযায়ী"
    override val directMoneyAmountLabel = "কত টাকা ধার নিলেন?"
    override val previousDueLabel = "আগের বাকি"
    override val newCreditLabel = "নতুন ধার"
    override val newTotalDueLabel = "নতুন মোট বাকি"
    override val addCreditButton = "ধার যোগ করুন"
    override val addMoreProductButton = "+ আরও পণ্য যোগ করুন"
    override val totalNewCreditLabel = "মোট নতুন ধার"
    override val editAction = "সম্পাদনা"
    override val itemsCountSuffix = "টি পণ্য"

    override val paymentPageTitle = "টাকা জমা"
    override val currentDueLabel = "বর্তমান বাকি"
    override val howMuchPaymentLabel = "কত টাকা জমা দেবেন?"
    override val fullPaymentButton = "সম্পূর্ণ পরিশোধ"
    override val dueAfterPaymentLabel = "জমা দেওয়ার পর বাকি"
    override val addPaymentButton = "জমা দিন"
    override val overpaymentBlockedMessage = "বর্তমান বাকির চেয়ে বেশি জমা দেওয়া যাবে না"
    override val fullyPaidCelebration = "সম্পূর্ণ পরিশোধ হয়ে যাবে"

    override val woodCalculatorTitle = "কাঠের হিসাব"
    override val woodTypeLabel = "কাঠের ধরন"
    override val sawnWoodOption = "চেরাই কাঠ"
    override val roundWoodOption = "গোল কাঠ"
    override val lengthFtLabel = "দৈর্ঘ্য (ফুট)"
    override val widthInLabel = "প্রস্থ (ইঞ্চি)"
    override val thicknessInLabel = "পুরত্ব (ইঞ্চি)"
    override val girthInLabel = "গোলবেড়ি (ইঞ্চি)"
    override val pieceCountLabel = "পিস সংখ্যা"
    override val perPieceCftLabel = "প্রতি পিস"
    override val totalWoodCftLabel = "মোট কাঠ"
    override val perCftPriceLabel = "প্রতি CFT দাম (₹)"
    override val totalWoodValueLabel = "মোট মূল্য"
    override val addWoodCalcButton = "এই কাঠের হিসাব যোগ করুন"
    override val woodNameLabel = "পণ্যের নাম"
    override val addMoreWoodProductButton = "+ আরও কাঠ/পণ্য যোগ করুন"
    override val addedItemsHeader = "যোগ করা পণ্য/কাঠ"

    override val pdfOptionsTitle = "PDF অপশন"
    override val pdfPeriodLabel = "সময়সীমা"
    override val pdfThisMonth = "এই মাস"
    override val pdfLastMonth = "গত মাস"
    override val pdfLast3Months = "গত 3 মাস"
    override val pdfCustomRange = "কাস্টম তারিখ"
    override val pdfShopLabelOption = "দোকান"
    override val pdfAllShopsOption = "সব দোকান"
    override val pdfContentLabel = "কী কী দেখাবে"
    override val pdfContentFull = "সব (লেনদেন + সারাংশ + সিগনেচার)"
    override val pdfContentSummaryOnly = "শুধু সারাংশ"
    override val pdfContentTxnsOnly = "শুধু লেনদেন"
    override val pdfFormatLabel = "ফরম্যাট"
    override val pdfFormatA4 = "A4 রিপোর্ট"
    override val pdfFormatReceipt = "রিসিট (58mm)"
    override val pdfGenerateButton = "PDF বানাও"
    override val pdfFromDateLabel = "শুরুর তারিখ"
    override val pdfToDateLabel = "শেষ তারিখ"

    override val pdfReportNumberLabel = "রিপোর্ট নং"
    override val pdfShopBoxLabel = "দোকান"
    override val pdfDateBoxLabel = "তারিখ"
    override val pdfDaysOfRecordsSuffix = "দিনের হিসাব"
    override val pdfWeeklyChartTitle = "সাপ্তাহিক ধার (লাল) ও পরিশোধ (সবুজ)"
    override val pdfFinalDueLabel = "বর্তমান বাকি"
    override val pdfShopSignatureLabel = "দোকানদারের স্বাক্ষর"
    override val pdfCustomerSignatureLabel = "ক্রেতার স্বাক্ষর"
    override val pdfAllShopsReportTitle = "সব দোকানের সারাংশ — উধার হিসাব"
    override val pdfPageLabel = "পৃষ্ঠা"

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    override val moreShopProfile = "দোকানের প্রোফাইল"
    override val moreHintShopProfile = "নাম, লোগো, ঠিকানা, রিমাইন্ডার"
    override val shopProfileTitle = "দোকানের প্রোফাইল"
    override val shopProfileIntro = "এই তথ্য PDF ইনভয়েসে আর গ্রাহককে পাঠানো বার্তায় ব্যবহার হবে"
    override val shopBusinessNameLabel = "দোকানের নাম"
    override val shopBusinessAddressLabel = "দোকানের ঠিকানা"
    override val shopBusinessPhoneLabel = "দোকানের ফোন নম্বর"
    override val countryCodeLabel = "দেশের কোড (যেমন 91)"
    override val shopLogoLabel = "দোকানের লোগো"
    override val shopLogoPick = "লোগো বাছুন"
    override val shopLogoRemove = "লোগো সরান"
    override val promptAfterEntryLabel = "এন্ট্রির পর গ্রাহককে জানানোর অপশন দেখান"
    override val saveProfileButton = "প্রোফাইল সেভ করুন"
    override val profileSavedMessage = "প্রোফাইল সেভ হয়েছে"
    override val errorShopNameForPdf = "PDF-এ ব্যবহারের জন্য দোকানের নাম দিন"
    override val reminderSendAction = "রিমাইন্ডার পাঠান"
    override val reminderDialogTitle = "গ্রাহককে জানান"
    override val reminderDialogSubtitle = "বার্তা এডিট করে WhatsApp বা SMS-এ পাঠান"
    override val reminderMessageLabel = "বার্তা"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "এখন না"
    override val reminderNoPhone = "গ্রাহকের ফোন নম্বর নেই"
    override val reminderAppMissing = "অ্যাপ খোলা যায়নি"
    override val reminderShopFallback = "আমাদের দোকান"
    override val reminderMsgDue = "নমস্কার %1\$s, %2\$s এর খাতায় আপনার মোট বাকি %3\$s। অনুগ্রহ করে সময়মতো পরিশোধ করবেন। ধন্যবাদ।"
    override val reminderMsgCredit = "নমস্কার %1\$s, %2\$s এর খাতায় আপনার নতুন বাকি যোগ হয়েছে। মোট বাকি: %3\$s।"
    override val reminderMsgPayment = "নমস্কার %1\$s, আপনার জমা পেয়েছি। ধন্যবাদ! %2\$s এর খাতায় বর্তমান বাকি: %3\$s।"
    override val reminderMsgSettled = "নমস্কার %1\$s, আপনার সব বাকি পরিশোধ হয়েছে। ধন্যবাদ! — %2\$s"
    override val pdfActionLabel = "📤 কী করবেন"
    override val pdfActionShare = "শেয়ার"
    override val pdfActionSave = "সেভ"
    override val pdfActionPrint = "প্রিন্ট"
    override val pdfBrandingOption = "আমার দোকানের নাম, লোগো ও ঠিকানা যোগ করুন"
    override val pdfBrandingMissing = "দোকানের নাম দেওয়া নেই — আরও → দোকানের প্রোফাইল-এ গিয়ে যোগ করুন"
    override val pdfSavedMessage = "PDF সেভ হয়েছে"
    override val pdfSaveFailed = "PDF সেভ করা যায়নি"

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    override val setupRoleTitle = "আপনি অ্যাপটা কীভাবে ব্যবহার করবেন?"
    override val setupProfileTitle = "আপনার দোকানের তথ্য"
    override val setupProfileSubtitle = "পরে আরও → দোকানের প্রোফাইল থেকে বদলাতে পারবেন"
    override val setupContinue = "চালিয়ে যান"
    override val setupSkip = "এখন না, পরে করব"
    override val setupFinish = "শুরু করুন"

    override val pickFromContacts = "কন্টাক্ট থেকে নম্বর নিন"

    // ── ⭐ PDF: পণ্যভিত্তিক হিসাবের কলাম ──
    override val pdfColQtyPrice = "পরিমাণ × দাম"
    override val pdfColItemTotal = "পণ্যের টাকা"

    // ── ⭐ PDF: কাঠের সম্পূর্ণ মাপ ──
    override val pdfWoodSawn = "চেরাই কাঠ"
    override val pdfWoodRound = "গোল কাঠ"
    override val pdfWoodFormula = "সূত্র"
    override val pdfWoodTotalWord = "মোট"

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    override val pdfMemoTitle = "ক্যাশ মেমো"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "বিল নং / Bill No"
    override val pdfDateTitle = "তারিখ / Date"
    override val pdfPeriodTitle = "সময়কাল / Period"
    override val pdfSeller = "বিক্রেতা / Seller"
    override val pdfBuyer = "ক্রেতা / Buyer"
    override val pdfAddressLabel = "ঠিকানা: "
    override val pdfColSl = "ক্রম"
    override val pdfColPieces = "পিস"
    override val pdfColCft = "CFT"
    override val pdfColRate = "রেট (₹/CFT)"
    override val pdfColAmountRs = "মোট (₹)"
    override val pdfColQty = "পরিমাণ"
    override val pdfColUnitPrice = "দর (₹)"
    override val pdfSecSawn = "চেরাই কাঠ / Sawn Timber"
    override val pdfSecRound = "গোল কাঠ / Round Log"
    override val pdfSecOther = "অন্যান্য পণ্য / Other Items"
    override val pdfSecCashCredit = "নগদ বাকি / Cash Credit"
    override val pdfSecPayments = "জমা / পরিশোধ / Payments"
    override val pdfBadgeSawn = "চেরাই"
    override val pdfBadgeRound = "গোল"
    override val pdfSawnTotal = "চেরাই কাঠ মোট:"
    override val pdfRoundTotal = "গোল কাঠ মোট:"
    override val pdfTableTotal = "মোট:"
    override val pdfSumBill = "মোট বিলের পরিমাণ"
    override val pdfSumPaid = "জমা / পরিশোধ"
    override val pdfSumDue = "বর্তমান বাকি"
    override val pdfWordsTitle = "টাকা কথায় / Amount in Words:"
    override val pdfSellerSign = "বিক্রেতার স্বাক্ষর ও সীল"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "ক্রেতার স্বাক্ষর"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "এটি কম্পিউটার তৈরি বিল। স্বাক্ষর ছাড়া বৈধ নয়।"

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    override val pdfSummaryTitle = "সারাংশ রিপোর্ট"
    override val moveShopAction = "অন্য তালিকায় সরান"
    override val moveShopTitle = "অন্য তালিকায় সরাবেন?"
    override val moveToShopkeeperMsg = "এই এন্ট্রি \"আমি দোকানদার\" তালিকায় (আপনার কাস্টমার হিসেবে) চলে যাবে। লেনদেনের অঙ্ক একই থাকবে, শুধু শব্দ বদলাবে — যেমন \"ধার নিলাম\" হবে \"বাকিতে দিলাম\"।"
    override val moveToCustomerMsg = "এই এন্ট্রি \"আমি গ্রাহক\" তালিকায় (যে দোকান থেকে আপনি ধার নেন) চলে যাবে। লেনদেনের অঙ্ক একই থাকবে, শুধু শব্দ বদলাবে — যেমন \"বাকিতে দিলাম\" হবে \"ধার নিলাম\"।"
    override val moveShopConfirm = "সরান"
}

object EnglishStrings : AppStrings {
    override val code = "en"
    override val helpCenterTitle = "Help Center"
    override val helpSearchPlaceholder = "Search questions..."
    override val noFaqResultsMessage = "No matches found"
    override val faqItems = listOf(
        FaqItem(
            "How do I add a new shop?",
            "Tap the '+' button on Home, enter the shop's name, phone (optional) and type, then tap Save."
        ),
        FaqItem(
            "How do I record a credit or a payment?",
            "Open the shop's detail page and tap 'Add credit' or 'Payment', enter the amount, and confirm."
        ),
        FaqItem(
            "How do I turn biometric lock on or off?",
            "Go to More → Security & Privacy and toggle 'Biometric lock'. Your device needs fingerprint or face unlock set up."
        ),
        FaqItem(
            "How do I back up my data?",
            "Go to More → Backup & Restore and tap 'Backup now'. This creates a JSON file you can save to your phone or the cloud."
        ),
        FaqItem(
            "How do I restore from a backup?",
            "Go to More → Backup & Restore and tap 'Restore from backup', then pick your JSON file. This replaces all current data, so be careful."
        ),
        FaqItem(
            "If I delete a shop, can I get it back?",
            "Archiving keeps it in History so you can bring it back later. Permanent deletion cannot be undone."
        ),
        FaqItem(
            "How do I generate a PDF report?",
            "From the More page, use the export option next to Backup & Restore, pick a shop and date range, then share the PDF."
        ),
        FaqItem(
            "How do I change the app's language?",
            "Go to More → Language, choose Bengali or English, and tap Save."
        )
    )
    override val homeHeadline = "Udhar Hisab"
    override val history = "History"
    override val settings = "Settings"
    override val totalDueLabel = "Total due"
    override val thisMonthCreditLabel = "This month's due"
    override val thisMonthPaymentLabel = "This month's received"
    override val searchPlaceholder = "Search shop/phone..."
    override val filterAll = "All"
    override val settledLabel = "Settled"
    override val noShopsYetTitle = "No shops yet"
    override val noShopsYetSubtitle = "Add your first shop to start your khata"
    override val addFirstShopButton = "Add first shop"
    override val newShop = "New shop"

    override val shopTypeTea = "Tea shop"
    override val shopTypeHardwareElectric = "Hardware & Electric"
    override val shopTypeKirana = "Grocery shop"
    override val shopTypeVegetable = "Vegetable market"
    override val shopTypeFishMeat = "Fish & meat"
    override val shopTypeBakerySweets = "Bakery & sweets"
    override val shopTypePharmacy = "Pharmacy"
    override val shopTypeCosmetics = "Cosmetics & toiletries"
    override val shopTypeStationery = "Stationery"
    override val shopTypeXeroxPrinting = "Xerox & printing"
    override val shopTypeWood = "Wood shop"
    override val shopTypeGarments = "Garments"
    override val shopTypeOther = "Other"

    override val back = "Back"
    override val cancel = "Cancel"
    override val save = "Save"

    override val shopNameLabel = "Shop name *"
    override val shopNamePlaceholder = "e.g. Wood Mahal"
    override val phoneLabel = "Phone number (optional)"
    override val shopTypeLabel = "Shop type *"
    override val saveShopButton = "Save shop"
    override val errorNameRequired = "Enter the shop name"
    override val errorTypeRequired = "Choose a shop type"

    override val dueLabel = "Due"
    override val noTransactionsYet = "No transactions yet"
    override val creditButton = "Credit taken"
    override val paymentButton = "Payment given"
    override val pdfExport = "Export PDF"
    override val archive = "Archive"
    override val deleteShopAction = "Delete shop"
    override val archiveConfirmTitle = "Archive this shop?"
    override val archiveConfirmText = "It'll be removed from the home list — you can still find it in History."
    override val deleteConfirmTitle = "Permanently delete this shop?"
    override val deleteConfirmText = "This shop and all its transactions will be deleted forever and cannot be recovered. Archiving instead would keep it in History — please confirm before continuing."
    override val yesDelete = "Yes, delete"
    override val yesArchive = "Archive"
    override val txnDeletedSnackbar = "Transaction deleted"
    override val undo = "Undo"
    override val pdfFailPrefix = "PDF generation failed: "
    override val shareKhata = "Share khata"
    override val creditFallback = "Credit"
    override val paymentFallback = "Payment"
    override val deleteTxnAction = "Delete"

    override val productNameLabel = "Product name (optional)"
    override val quantityLabel = "Quantity"
    override val unitLabel = "Unit"
    override val pricePerUnitLabel = "Price/unit"
    override val totalPrefix = "Total: "
    override val amountLabel = "Amount paid"
    override val orEnterAmountLabel = "Or enter the amount directly"
    override val noteLabel = "Note (optional)"
    override val cash = "Cash"
    override val bkash = "bKash"
    override val bank = "Bank"
    override val invalidAmountError = "Enter a valid amount"

    override val cftCalculatorTitle = "CFT calculator"
    override val lengthLabel = "Length (in)"
    override val widthLabel = "Width"
    override val heightLabel = "Height"
    override val rateLabel = "Rate /cft (৳)"
    override val applyToEntryButton = "Apply to entry"

    override val settingsTitle = "Settings"
    override val security = "Security"
    override val pinLockOn = "PIN lock is on"
    override val pinLockOff = "PIN lock is off"
    override val changePin = "Change PIN"
    override val reminderTitle = "Due reminders"
    override val reminderDesc = "Reminds you about dues every day"
    override val about = "About"
    override val aboutLine = "Udhar Hisab — a shop credit ledger"
    override val aboutDescription = "UdharHisab is a smart accounting app built to help you manage shop credit, dues, and transactions easily, quickly, and in an organized way. How much you owe at different shops, where you've made payments, and when each transaction happened — everything can be neatly stored and managed in one place.\n\nWith this app, you can easily add shops, keep track of credit and payments, view transaction history, check your total dues and payments, and generate detailed reports. Features like Search, Filter, Backup & Restore, App Lock, Biometric Security, Dark Mode, and Notifications make managing your accounts even easier and safer.\n\nUdharHisab's goal is to bring the complexity of paper ledgers into a simple, modern, and reliable digital system."
    override val aboutTagline = "UdharHisab — Simple accounting, stay worry-free."
    override val versionLine = "Version 1.0"
    override val setPinTitle = "Set PIN"
    override val newPinLabel = "New PIN"
    override val confirmPinLabel = "Re-enter PIN"
    override val pinSetupError = "PINs don't match (at least 4 digits)"
    override val removePinTitle = "Turn off PIN lock?"
    override val removePinText = "You won't be asked for a PIN when opening the app anymore."
    override val yesTurnOff = "Yes, turn off"
    override val no = "No"
    override val languageTitle = "Language"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "Notifications"
    override val notifSheetSubtitle = "Which reminders do you want?"
    override val notifDueReminderOption = "Due payment reminder"
    override val notifWeeklySummaryOption = "Weekly summary"
    override val notifAppNewsOption = "App news & updates"

    override val langSheetSubtitle = "Which language should the app use?"
    override val themeSheetSubtitle = "Which theme do you prefer?"

    override val securityPrivacyTitle = "Security & Privacy"
    override val pinSectionTitle = "PIN lock"
    override val pinSectionDesc = "Ask for a PIN when the app opens"
    override val fingerprintTitle = "Fingerprint lock"
    override val fingerprintDesc = "Unlock with your fingerprint instead of the PIN"
    override val fingerprintUnavailable = "No fingerprint sensor found on this phone"
    override val lockImmediatelyTitle = "Lock immediately"
    override val lockImmediatelyDesc = "Lock again as soon as you return to the app"

    override val rateTitle = "Rating & Feedback"
    override val rateSubtitle = "How's Udhar Hisab working for you?"
    override val rateStarsPrompt = "Tap to rate"
    override val rateThanksMessage = "Thanks! Taking you to the Play Store…"
    override val feedbackPromptLow = "What didn't you like? Let us know"
    override val feedbackPlaceholder = "Write your feedback…"
    override val feedbackSubmit = "Send"
    override val feedbackThanks = "Thanks, your feedback has been sent"

    override val aboutPageTitle = "About Udhar Hisab"
    override val aboutVersionPrefix = "Version"
    override val aboutDeveloperLabel = "Developer"
    override val aboutDeveloperName = "Udhar Hisab Team"
    override val aboutPrivacyPolicy = "Privacy Policy"
    override val privacyPolicyEffectiveDate = "Effective date: September 13, 2026"
    override val privacyPolicyBody = """UdharHisab is a personal finance/ledger application built to help you manage your shop credit, dues, and transactions simply and easily. Your privacy matters to us.

1. Information we collect

Information you enter into the app yourself while using UdharHisab, such as:
• Shop name
• Mobile number
• Shop address or other details
• Credit and payment amounts
• Transaction date, time, and notes

2. How your information is used

This information is used solely to store, display, and manage your accounts. Your personal ledger data will not be sold or shared with any advertiser or third party without your permission.

3. Data storage

Your account data may be stored on your device as needed by the app. If you use the Backup & Restore feature, your backup data may be stored via the storage/cloud service you choose.

4. App security

Security features such as App Lock, PIN, and Biometric Authentication may be provided to help keep your account data safe.

5. Sharing information

We do not sell, rent, or commercially share your personal ledger data with third parties, except where required by law.

6. Your control

You can view, change, or delete your data stored within the app whenever you need to.

7. Third-party services

If any third-party services are used for certain features of the app, their own Privacy Policy may apply.

8. Children's privacy

UdharHisab is not designed to knowingly collect personal information from children.

9. Changes to this Privacy Policy

We may change or update this Privacy Policy as needed. Any new policy will be posted on this page.

10. Contact

If you have any questions about this Privacy Policy or your data, please contact us.

UdharHisab
Simple accounting, stay worry-free."""
    override val aboutShareApp = "Share"
    override val aboutShareText = "Udhar Hisab — try this shop credit ledger app!"

    override val noArchivedShops = "No archived shops"
    override val noSettledShops = "No settled shops"

    override val setupPinTitle = "Set a 4-digit PIN"
    override val unlockPinTitle = "Unlock with PIN"
    override val pinLabel = "PIN"
    override val pinDigitsError = "Enter 4 digits"
    override val pinsDontMatchError = "PINs don't match"
    override val wrongPinError = "Wrong PIN — try again"
    override val savePinButton = "Save PIN"
    override val unlockButton = "Unlock"

    override val pdfHeaderTitle = "Khata — Udhar Hisab"
    override val pdfFullKhataSuffix = "Full khata"
    override val pdfShopLabel = "Shop: "
    override val pdfPhoneLabel = "Phone: "
    override val pdfCreatedLabel = "Created: "
    override val pdfColDate = "Date/Time"
    override val pdfColDesc = "Description"
    override val pdfTotalCredit = "Total credit:"
    override val pdfTotalPayment = "Total payment:"
    override val pdfCurrentDue = "Current due:"
    override val pdfFooter = "Made with Udhar Hisab app"

    override val navHome = "Home"
    override val navHistory = "History"
    override val navReports = "Reports"
    override val navMore = "More"

    override val historyFilterAllShops = "All shops"
    override val historyFilterAllTypes = "All"
    override val historyFilterCreditOnly = "Due only"
    override val historyFilterPaymentOnly = "Paid only"
    override val historyNoTxnsFound = "No transactions found"
    override val viewArchivedAction = "View archived shops"

    override val reportsTitle = "Reports"
    override val periodLabel = "Period"
    override val period7d = "Last 7 days"
    override val period15d = "Last 15 days"
    override val period30d = "Last 30 days"
    override val period3m = "Last 3 months"
    override val period1y = "This year"
    override val reportTotalCredit = "Total credit"
    override val reportTotalPayment = "Total payment"
    override val reportCurrentDue = "Current total due"
    override val reportTxnCount = "Transactions"
    override val reportChartTitle = "Credit vs Payment"
    override val reportShopWiseTitle = "Due by shop"
    override val reportAgingTitle = "Outstanding age"
    override val reportAging0to7 = "0–7 days"
    override val reportAging7to15 = "7–15 days"
    override val reportAging15to30 = "15–30 days"
    override val reportAging30plus = "30+ days"
    override val reportRecentPaymentsTitle = "Recent payments"
    override val reportNoData = "No data for this period"
    override val reportSmartSummaryPrefix = "In this period you"

    override val moreTitle = "More"
    override val moreBackupRestore = "Backup & Restore"
    override val moreHintBackupRestore = "Keep your data safe"
    override val notesTitle = "Notes"
    override val notesSearchPlaceholder = "Search notes..."
    override val addNoteButton = "New note"
    override val noNotesYetTitle = "No notes yet"
    override val noNotesYetSubtitle = "Shopping lists, reminders — jot down anything"
    override val deleteNoteConfirmTitle = "Delete this note?"
    override val deleteNoteConfirmMessage = "This note will be permanently deleted."
    override val noteTitlePlaceholder = "Title"
    override val noteContentPlaceholder = "Write something..."
    override val untitledNote = "Untitled note"
    override val notificationInboxTitle = "Notifications"
    override val moreNotificationHistory = "Notification history"
    override val moreHintNotificationHistory = "See recent activity"
    override val noNotificationsYetTitle = "No notifications yet"
    override val noNotificationsYetSubtitle = "Record a credit or payment and it'll show up here"
    override val notifCreditMessage = "Credit of %2\$s taken from %1\$s"
    override val notifPaymentMessage = "Payment of %2\$s made to %1\$s"
    override val moreQuickCalculator = "Quick calculator"
    override val moreHintQuickCalculator = "Do quick math"
    override val calcGeneralTab = "General"
    override val calcPercentTab = "Percent"
    override val calcConversionTab = "Convert"
    override val calcComingSoonInTab = "Coming soon"
    override val percentOfTitle = "Percentage of a number"
    override val percentOfValueLabel = "Number"
    override val percentOfPercentLabel = "Percent (%)"
    override val percentIsWhatTitle = "What percent is one number of another"
    override val percentIsWhatXLabel = "This number"
    override val percentIsWhatYLabel = "of this"
    override val percentChangeTitle = "Percentage increase/decrease"
    override val percentChangeBaseLabel = "Base number"
    override val percentChangePercentLabel = "Percent (%)"
    override val increaseOption = "Increase"
    override val decreaseOption = "Decrease"
    override val resultLabel = "Result"
    override val weightCategory = "Weight"
    override val lengthCategory = "Length"
    override val volumeCategory = "Volume"
    override val fromLabel = "From"
    override val toLabel = "To"
    override val enterValueHint = "Enter value"
    override val backupNowButton = "Backup now"
    override val backupNowHint = "Save all shops and transactions to a JSON file"
    override val restoreButton = "Restore from backup"
    override val restoreShopAction = "Restore"
    override val restoreHint = "Bring back data from a previous JSON backup file"
    override val lastBackupLabel = "Last backup"
    override val noBackupYetLabel = "No backup taken yet"
    override val backupSuccessMessage = "Backup created"
    override val backupFailPrefix = "Backup failed: "
    override val restoreConfirmTitle = "Restore backup?"
    override val restoreConfirmMessage = "This will erase all current shops and transactions and replace them with the backup file's data. This cannot be undone."
    override val restoreSuccessMessage = "Restore complete"
    override val restoreFailPrefix = "Restore failed: "
    override val dataSafeNote = "Your data stays on this phone only — keep the backup file safe yourself"
    override val moreExportShare = "Export & Share"
    override val moreHintExportShare = "Send PDF & files"
    override val moreNotifications = "Notifications"
    override val moreHintNotifications = "Turn reminders on/off"
    override val moreLanguage = "Language"
    override val moreHintLanguage = "Bengali, English or Hindi"
    override val moreUserMode = "Who am I"
    override val moreHintUserMode = "Customer or shopkeeper"
    override val moreSecurityPrivacy = "Security & Privacy"
    override val moreHintSecurityPrivacy = "PIN & fingerprint lock"
    override val moreAppearance = "Appearance"
    override val moreHintAppearance = "Light, dark or system"
    override val moreRateFeedback = "Rate & Feedback"
    override val moreHintRateFeedback = "Share your feedback"
    override val moreAbout = "About Udhar Hisab"
    override val moreHintAbout = "Version & developer"
    override val comingSoonMessage = "Coming soon"

    override val appearanceTitle = "Appearance"
    override val themeLight = "Light"
    override val themeDark = "Dark"
    override val themeSystem = "System default"

    override val creditPageTitle = "Take credit"
    override val accountingTypeLabel = "Entry type"
    override val directMoneyMode = "Direct amount"
    override val productMode = "By product"
    override val directMoneyAmountLabel = "How much credit did you give?"
    override val previousDueLabel = "Previous due"
    override val newCreditLabel = "New credit"
    override val newTotalDueLabel = "New total due"
    override val addCreditButton = "Add credit"
    override val addMoreProductButton = "+ Add another product"
    override val totalNewCreditLabel = "Total new credit"
    override val editAction = "Edit"
    override val itemsCountSuffix = "items"

    override val paymentPageTitle = "Payment"
    override val currentDueLabel = "Current due"
    override val howMuchPaymentLabel = "How much are they paying?"
    override val fullPaymentButton = "Full payment"
    override val dueAfterPaymentLabel = "Due after payment"
    override val addPaymentButton = "Add payment"
    override val overpaymentBlockedMessage = "Can't pay more than the current due"
    override val fullyPaidCelebration = "This will fully settle the due"

    override val woodCalculatorTitle = "Timber calculator"
    override val woodTypeLabel = "Wood type"
    override val sawnWoodOption = "Sawn timber"
    override val roundWoodOption = "Round log"
    override val lengthFtLabel = "Length (ft)"
    override val widthInLabel = "Width (in)"
    override val thicknessInLabel = "Thickness (in)"
    override val girthInLabel = "Girth (in)"
    override val pieceCountLabel = "Piece count"
    override val perPieceCftLabel = "Per piece"
    override val totalWoodCftLabel = "Total wood"
    override val perCftPriceLabel = "Price per CFT (₹)"
    override val totalWoodValueLabel = "Total value"
    override val addWoodCalcButton = "Add this wood calculation"
    override val woodNameLabel = "Product name"
    override val addMoreWoodProductButton = "+ Add another wood/product"
    override val addedItemsHeader = "Added products/wood"

    override val pdfOptionsTitle = "PDF options"
    override val pdfPeriodLabel = "Period"
    override val pdfThisMonth = "This month"
    override val pdfLastMonth = "Last month"
    override val pdfLast3Months = "Last 3 months"
    override val pdfCustomRange = "Custom range"
    override val pdfShopLabelOption = "Shop"
    override val pdfAllShopsOption = "All shops"
    override val pdfContentLabel = "What to show"
    override val pdfContentFull = "Everything (transactions + summary + signatures)"
    override val pdfContentSummaryOnly = "Summary only"
    override val pdfContentTxnsOnly = "Transactions only"
    override val pdfFormatLabel = "Format"
    override val pdfFormatA4 = "A4 report"
    override val pdfFormatReceipt = "Receipt (58mm)"
    override val pdfGenerateButton = "Generate PDF"
    override val pdfFromDateLabel = "Start date"
    override val pdfToDateLabel = "End date"

    override val pdfReportNumberLabel = "Report no."
    override val pdfShopBoxLabel = "Shop"
    override val pdfDateBoxLabel = "Date"
    override val pdfDaysOfRecordsSuffix = "days of records"
    override val pdfWeeklyChartTitle = "Weekly credit (red) vs payment (green)"
    override val pdfFinalDueLabel = "Current due"
    override val pdfShopSignatureLabel = "Shopkeeper's signature"
    override val pdfCustomerSignatureLabel = "Customer's signature"
    override val pdfAllShopsReportTitle = "All shops summary — Udhar Hisab"
    override val pdfPageLabel = "Page"

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    override val moreShopProfile = "Shop profile"
    override val moreHintShopProfile = "Name, logo, address, reminders"
    override val shopProfileTitle = "Shop profile"
    override val shopProfileIntro = "This is used on your PDF invoices and in messages sent to customers"
    override val shopBusinessNameLabel = "Shop name"
    override val shopBusinessAddressLabel = "Shop address"
    override val shopBusinessPhoneLabel = "Shop phone number"
    override val countryCodeLabel = "Country code (e.g. 91)"
    override val shopLogoLabel = "Shop logo"
    override val shopLogoPick = "Choose logo"
    override val shopLogoRemove = "Remove logo"
    override val promptAfterEntryLabel = "Offer to notify the customer after an entry"
    override val saveProfileButton = "Save profile"
    override val profileSavedMessage = "Profile saved"
    override val errorShopNameForPdf = "Enter your shop name to use it on PDFs"
    override val reminderSendAction = "Send reminder"
    override val reminderDialogTitle = "Notify the customer"
    override val reminderDialogSubtitle = "Edit the message and send it by WhatsApp or SMS"
    override val reminderMessageLabel = "Message"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "Not now"
    override val reminderNoPhone = "This customer has no phone number"
    override val reminderAppMissing = "Could not open the app"
    override val reminderShopFallback = "our shop"
    override val reminderMsgDue = "Hello %1\$s, your total balance due at %2\$s is %3\$s. Please pay on time. Thank you."
    override val reminderMsgCredit = "Hello %1\$s, a new credit entry was added to your account at %2\$s. Total due: %3\$s."
    override val reminderMsgPayment = "Hello %1\$s, we received your payment. Thank you! Current due at %2\$s: %3\$s."
    override val reminderMsgSettled = "Hello %1\$s, your dues are fully settled. Thank you! — %2\$s"
    override val pdfActionLabel = "📤 What to do"
    override val pdfActionShare = "Share"
    override val pdfActionSave = "Save"
    override val pdfActionPrint = "Print"
    override val pdfBrandingOption = "Add my shop name, logo and address"
    override val pdfBrandingMissing = "No shop name set — add it under More → Shop profile"
    override val pdfSavedMessage = "PDF saved"
    override val pdfSaveFailed = "Could not save the PDF"

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    override val setupRoleTitle = "How will you use the app?"
    override val setupProfileTitle = "Your shop details"
    override val setupProfileSubtitle = "You can change this later under More → Shop profile"
    override val setupContinue = "Continue"
    override val setupSkip = "Not now, I'll do it later"
    override val setupFinish = "Get started"

    override val pickFromContacts = "Pick from contacts"

    // ── ⭐ PDF: পণ্যভিত্তিক হিসাবের কলাম ──
    override val pdfColQtyPrice = "Qty × Price"
    override val pdfColItemTotal = "Item total"

    // ── ⭐ PDF: কাঠের সম্পূর্ণ মাপ ──
    override val pdfWoodSawn = "Sawn timber"
    override val pdfWoodRound = "Round timber"
    override val pdfWoodFormula = "Formula"
    override val pdfWoodTotalWord = "Total"

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    override val pdfMemoTitle = "Cash Memo"
    override val pdfMemoSubtitle = "Bill of Supply"
    override val pdfBillNo = "Bill No"
    override val pdfDateTitle = "Date"
    override val pdfPeriodTitle = "Period"
    override val pdfSeller = "Seller"
    override val pdfBuyer = "Buyer"
    override val pdfAddressLabel = "Address: "
    override val pdfColSl = "Sl"
    override val pdfColPieces = "Pcs"
    override val pdfColCft = "CFT"
    override val pdfColRate = "Rate (₹/CFT)"
    override val pdfColAmountRs = "Total (₹)"
    override val pdfColQty = "Quantity"
    override val pdfColUnitPrice = "Rate (₹)"
    override val pdfSecSawn = "Sawn Timber"
    override val pdfSecRound = "Round Log"
    override val pdfSecOther = "Other Items"
    override val pdfSecCashCredit = "Cash Credit"
    override val pdfSecPayments = "Payments"
    override val pdfBadgeSawn = "Sawn"
    override val pdfBadgeRound = "Round"
    override val pdfSawnTotal = "Sawn timber total:"
    override val pdfRoundTotal = "Round log total:"
    override val pdfTableTotal = "Total:"
    override val pdfSumBill = "Total Bill"
    override val pdfSumPaid = "Paid"
    override val pdfSumDue = "Balance Due"
    override val pdfWordsTitle = "Amount in Words:"
    override val pdfSellerSign = "Seller Signature & Seal"
    override val pdfSellerSignSub = ""
    override val pdfBuyerSign = "Buyer Signature"
    override val pdfBuyerSignSub = ""
    override val pdfMemoFooter = "This is a computer generated bill. Not valid without signature."

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    override val pdfSummaryTitle = "Summary Report"
    override val moveShopAction = "Move to the other list"
    override val moveShopTitle = "Move to the other list?"
    override val moveToShopkeeperMsg = "This entry will move to your \"I am a shopkeeper\" list (as your customer). Amounts stay the same; only the wording changes."
    override val moveToCustomerMsg = "This entry will move to your \"I am a customer\" list (a shop you buy from on credit). Amounts stay the same; only the wording changes."
    override val moveShopConfirm = "Move"
}

object HindiStrings : AppStrings {
    override val code = "hi"
    override val helpCenterTitle = "सहायता केंद्र"
    override val helpSearchPlaceholder = "सवाल खोजें..."
    override val noFaqResultsMessage = "कोई मेल नहीं मिला"
    override val faqItems = listOf(
        FaqItem(
            "नई दुकान कैसे जोड़ें?",
            "होम स्क्रीन पर '+' बटन दबाएं, दुकान का नाम, फ़ोन नंबर (वैकल्पिक) और प्रकार भरें, फिर 'सेव करें' दबाएं।"
        ),
        FaqItem(
            "उधार या भुगतान कैसे दर्ज करें?",
            "दुकान के विवरण पेज पर जाएं और 'उधार लें' या 'भुगतान' दबाएं, राशि डालें और पुष्टि करें।"
        ),
        FaqItem(
            "बायोमेट्रिक लॉक कैसे चालू/बंद करें?",
            "अधिक → सुरक्षा व गोपनीयता पेज पर जाकर 'बायोमेट्रिक लॉक' टॉगल करें। फ़ोन में फिंगरप्रिंट/फेस अनलॉक सेट होना ज़रूरी है।"
        ),
        FaqItem(
            "डेटा बैकअप कैसे लें?",
            "अधिक → बैकअप व रिस्टोर पेज पर जाकर 'अभी बैकअप लें' दबाएं। एक JSON फ़ाइल बनेगी जिसे आप फ़ोन या क्लाउड में सेव कर सकते हैं।"
        ),
        FaqItem(
            "बैकअप से डेटा कैसे वापस लाएं?",
            "अधिक → बैकअप व रिस्टोर पेज पर 'बैकअप से रिस्टोर करें' दबाएं, अपनी JSON फ़ाइल चुनें। इससे मौजूदा सारा डेटा मिटकर बैकअप से बदल जाएगा, इसलिए सावधानी बरतें।"
        ),
        FaqItem(
            "दुकान डिलीट करने पर क्या वापस मिल सकती है?",
            "आर्काइव करने पर दुकान History में रहती है, बाद में वापस लाई जा सकती है। स्थायी रूप से डिलीट करने पर यह हमेशा के लिए चली जाती है।"
        ),
        FaqItem(
            "PDF रिपोर्ट कैसे बनाएं?",
            "अधिक पेज पर बैकअप व रिस्टोर के पास एक्सपोर्ट विकल्प से दुकान और समय-सीमा चुनकर PDF बनाएं, फिर शेयर करें।"
        ),
        FaqItem(
            "ऐप की भाषा कैसे बदलें?",
            "अधिक → भाषा पेज पर जाकर बांग्ला, अंग्रेज़ी या हिंदी चुनें और 'सेव करें' दबाएं।"
        )
    )
    override val homeHeadline = "उधार हिसाब"
    override val history = "हिस्ट्री"
    override val settings = "सेटिंग्स"
    override val totalDueLabel = "कुल बकाया"
    override val thisMonthCreditLabel = "इस महीने का बकाया"
    override val thisMonthPaymentLabel = "इस महीने मिला भुगतान"
    override val searchPlaceholder = "दुकान/फ़ोन खोजें..."
    override val filterAll = "सभी"
    override val settledLabel = "चुकता"
    override val noShopsYetTitle = "अभी कोई दुकान नहीं"
    override val noShopsYetSubtitle = "अपना खाता शुरू करने के लिए पहली दुकान जोड़ें"
    override val addFirstShopButton = "पहली दुकान जोड़ें"
    override val newShop = "नई दुकान"

    override val shopTypeTea = "चाय की दुकान"
    override val shopTypeHardwareElectric = "हार्डवेयर व इलेक्ट्रिक"
    override val shopTypeKirana = "किराना दुकान"
    override val shopTypeVegetable = "सब्ज़ी बाज़ार"
    override val shopTypeFishMeat = "मछली व मांस"
    override val shopTypeBakerySweets = "बेकरी व मिठाई"
    override val shopTypePharmacy = "फार्मेसी"
    override val shopTypeCosmetics = "कॉस्मेटिक्स व टॉयलेटरीज़"
    override val shopTypeStationery = "स्टेशनरी"
    override val shopTypeXeroxPrinting = "ज़ेरॉक्स व प्रिंटिंग"
    override val shopTypeWood = "लकड़ी की दुकान"
    override val shopTypeGarments = "गारमेंट्स"
    override val shopTypeOther = "अन्य"

    override val back = "वापस"
    override val cancel = "रद्द करें"
    override val save = "सेव करें"

    override val shopNameLabel = "दुकान का नाम *"
    override val shopNamePlaceholder = "जैसे: वुड महल"
    override val phoneLabel = "फ़ोन नंबर (वैकल्पिक)"
    override val shopTypeLabel = "दुकान का प्रकार *"
    override val saveShopButton = "दुकान सेव करें"
    override val errorNameRequired = "दुकान का नाम भरें"
    override val errorTypeRequired = "दुकान का प्रकार चुनें"

    override val dueLabel = "बकाया"
    override val noTransactionsYet = "अभी कोई लेनदेन नहीं"
    override val creditButton = "उधार लिया"
    override val paymentButton = "भुगतान किया"
    override val pdfExport = "PDF एक्सपोर्ट करें"
    override val archive = "आर्काइव"
    override val deleteShopAction = "दुकान डिलीट करें"
    override val archiveConfirmTitle = "इस दुकान को आर्काइव करें?"
    override val archiveConfirmText = "यह होम लिस्ट से हट जाएगी — आप इसे History में पा सकते हैं।"
    override val deleteConfirmTitle = "दुकान स्थायी रूप से डिलीट करें?"
    override val deleteConfirmText = "यह दुकान और इसके सारे लेनदेन हमेशा के लिए मिट जाएंगे और वापस नहीं आएंगे। इसके बजाय आर्काइव करने पर यह History में रहेगी — आगे बढ़ने से पहले पुष्टि करें।"
    override val yesDelete = "हां, डिलीट करें"
    override val yesArchive = "आर्काइव करें"
    override val txnDeletedSnackbar = "लेनदेन डिलीट हुआ"
    override val undo = "वापस लाएं"
    override val pdfFailPrefix = "PDF बनाना असफल: "
    override val shareKhata = "खाता शेयर करें"
    override val creditFallback = "उधार"
    override val paymentFallback = "भुगतान"
    override val deleteTxnAction = "मिटाएं"

    override val productNameLabel = "उत्पाद का नाम (वैकल्पिक)"
    override val quantityLabel = "मात्रा"
    override val unitLabel = "इकाई"
    override val pricePerUnitLabel = "मूल्य/इकाई"
    override val totalPrefix = "कुल: "
    override val amountLabel = "भुगतान की गई राशि"
    override val orEnterAmountLabel = "या सीधे राशि डालें"
    override val noteLabel = "नोट (वैकल्पिक)"
    override val cash = "नकद"
    override val bkash = "बीकैश"
    override val bank = "बैंक"
    override val invalidAmountError = "सही राशि डालें"

    override val cftCalculatorTitle = "CFT कैलकुलेटर"
    override val lengthLabel = "लंबाई (इंच)"
    override val widthLabel = "चौड़ाई"
    override val heightLabel = "ऊंचाई"
    override val rateLabel = "दर /cft (৳)"
    override val applyToEntryButton = "एंट्री में लागू करें"

    override val settingsTitle = "सेटिंग्स"
    override val security = "सुरक्षा"
    override val pinLockOn = "पिन लॉक चालू है"
    override val pinLockOff = "पिन लॉक बंद है"
    override val changePin = "पिन बदलें"
    override val reminderTitle = "बकाया रिमाइंडर"
    override val reminderDesc = "हर दिन बकाया याद दिलाता है"
    override val about = "जानकारी"
    override val aboutLine = "उधार हिसाब — दुकान का उधार खाता"
    override val aboutDescription = "UdharHisab एक स्मार्ट अकाउंटिंग ऐप है जो दुकान के उधार, बकाया और लेनदेन को आसानी, तेज़ी और व्यवस्थित ढंग से संभालने के लिए बनाया गया है। अलग-अलग दुकानों में आपका कितना उधार बकाया है, कहां कितना भुगतान किया है, और कौन सा लेनदेन कब हुआ — सब कुछ एक ही जगह सुव्यवस्थित रूप से सेव और मैनेज किया जा सकता है।\n\nइस ऐप से आप आसानी से दुकान जोड़ सकते हैं, उधार व भुगतान का हिसाब रख सकते हैं, लेनदेन का इतिहास देख सकते हैं, कुल बकाया व भुगतान की जानकारी पा सकते हैं, और विस्तृत रिपोर्ट बना सकते हैं। साथ ही Search, Filter, Backup & Restore, App Lock, Biometric Security, Dark Mode और Notification जैसी सुविधाएं आपके हिसाब को और आसान व सुरक्षित बनाती हैं।\n\nUdharHisab का लक्ष्य है — जटिल कागज़ी बहीखाते को एक सरल, आधुनिक और भरोसेमंद डिजिटल व्यवस्था में लाना।"
    override val aboutTagline = "UdharHisab — आसान हिसाब, निश्चिंत रहें।"
    override val versionLine = "वर्शन 1.0"
    override val setPinTitle = "पिन सेट करें"
    override val newPinLabel = "नया पिन"
    override val confirmPinLabel = "पिन दोबारा डालें"
    override val pinSetupError = "पिन मेल नहीं खाते (कम से कम 4 अंक)"
    override val removePinTitle = "पिन लॉक बंद करें?"
    override val removePinText = "अब ऐप खोलते समय पिन नहीं मांगा जाएगा।"
    override val yesTurnOff = "हां, बंद करें"
    override val no = "नहीं"
    override val languageTitle = "भाषा"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "नोटिफिकेशन"
    override val notifSheetSubtitle = "आपको कौन से रिमाइंडर चाहिए?"
    override val notifDueReminderOption = "बकाया भुगतान रिमाइंडर"
    override val notifWeeklySummaryOption = "साप्ताहिक सारांश"
    override val notifAppNewsOption = "ऐप न्यूज़ व अपडेट्स"

    override val langSheetSubtitle = "ऐप किस भाषा में चलनी चाहिए?"
    override val themeSheetSubtitle = "आपको कौन-सी थीम पसंद है?"

    override val securityPrivacyTitle = "सुरक्षा व गोपनीयता"
    override val pinSectionTitle = "पिन लॉक"
    override val pinSectionDesc = "ऐप खुलते समय पिन मांगें"
    override val fingerprintTitle = "फिंगरप्रिंट लॉक"
    override val fingerprintDesc = "पिन की जगह फिंगरप्रिंट से अनलॉक करें"
    override val fingerprintUnavailable = "इस फ़ोन में फिंगरप्रिंट सेंसर नहीं मिला"
    override val lockImmediatelyTitle = "तुरंत लॉक करें"
    override val lockImmediatelyDesc = "ऐप पर वापस आते ही फिर से लॉक हो जाए"

    override val rateTitle = "रेटिंग व फीडबैक"
    override val rateSubtitle = "उधार हिसाब आपके लिए कैसा काम कर रहा है?"
    override val rateStarsPrompt = "रेट करने के लिए टैप करें"
    override val rateThanksMessage = "धन्यवाद! Play Store पर ले जा रहे हैं…"
    override val feedbackPromptLow = "आपको क्या पसंद नहीं आया? हमें बताएं"
    override val feedbackPlaceholder = "अपनी प्रतिक्रिया लिखें…"
    override val feedbackSubmit = "भेजें"
    override val feedbackThanks = "धन्यवाद, आपकी प्रतिक्रिया भेज दी गई है"

    override val aboutPageTitle = "उधार हिसाब के बारे में"
    override val aboutVersionPrefix = "वर्शन"
    override val aboutDeveloperLabel = "डेवलपर"
    override val aboutDeveloperName = "उधार हिसाब टीम"
    override val aboutPrivacyPolicy = "प्राइवेसी पॉलिसी"
    override val privacyPolicyEffectiveDate = "प्रभावी तिथि: 13 सितंबर 2026"
    override val privacyPolicyBody = """UdharHisab आपकी दुकान के उधार-बकाया और लेनदेन को आसानी से संभालने के लिए बनाया गया एक personal finance/ledger application है। आपकी गोपनीयता हमारे लिए महत्वपूर्ण है।

1. हम कौन-सी जानकारी लेते हैं

UdharHisab इस्तेमाल करते समय आप खुद जो जानकारी ऐप में डालते हैं, जैसे:
• दुकान का नाम
• मोबाइल नंबर
• दुकान का पता या अन्य विवरण
• उधार व भुगतान की राशि
• लेनदेन की तारीख, समय व नोट

2. आपकी जानकारी का उपयोग कैसे होता है

यह जानकारी केवल आपका हिसाब सेव करने, दिखाने और मैनेज करने के लिए इस्तेमाल होती है। आपकी अनुमति के बिना आपकी निजी हिसाब की जानकारी किसी विज्ञापनदाता या तीसरे पक्ष को नहीं बेची या साझा की जाएगी।

3. Data Storage

आपके हिसाब की जानकारी ऐप की ज़रूरत के अनुसार आपके डिवाइस में सेव हो सकती है। Backup & Restore सुविधा इस्तेमाल करने पर बैकअप की जानकारी आपके चुने गए storage/cloud service के ज़रिए सेव हो सकती है।

4. App Security

आपके हिसाब की जानकारी सुरक्षित रखने के लिए App Lock, PIN और Biometric Authentication जैसी सुरक्षा सुविधाएं दी जा सकती हैं।

5. जानकारी साझा करना

कानूनी ज़रूरत के अलावा हम आपकी निजी हिसाब की जानकारी किसी तीसरे पक्ष को न बेचते हैं, न किराए पर देते हैं, न व्यावसायिक रूप से साझा करते हैं।

6. आपका नियंत्रण

आप ऐप में सेव अपनी जानकारी कभी भी देख सकते हैं, बदल सकते हैं या ज़रूरत पड़ने पर मिटा सकते हैं।

7. Third-Party Services

ऐप की कुछ सुविधाओं के लिए तीसरे पक्ष की सेवा इस्तेमाल होने पर उनकी अपनी Privacy Policy लागू हो सकती है।

8. बच्चों की गोपनीयता

UdharHisab बच्चों की निजी जानकारी इकट्ठा करने के उद्देश्य से नहीं बनाया गया है।

9. Privacy Policy में बदलाव

ज़रूरत पड़ने पर हम इस Privacy Policy को बदल या अपडेट कर सकते हैं। नई Policy इसी पेज पर प्रकाशित की जाएगी।

10. संपर्क

Privacy Policy या अपनी जानकारी से जुड़ा कोई सवाल हो तो हमसे संपर्क करें।

UdharHisab
आसान हिसाब, निश्चिंत रहें।"""
    override val aboutShareApp = "शेयर करें"
    override val aboutShareText = "उधार हिसाब — यह दुकान उधार खाता ऐप आज़माएं!"

    override val noArchivedShops = "कोई आर्काइव की गई दुकान नहीं"
    override val noSettledShops = "कोई चुकता दुकान नहीं"

    override val setupPinTitle = "4 अंकों का पिन सेट करें"
    override val unlockPinTitle = "पिन से अनलॉक करें"
    override val pinLabel = "पिन"
    override val pinDigitsError = "4 अंक डालें"
    override val pinsDontMatchError = "पिन मेल नहीं खाते"
    override val wrongPinError = "गलत पिन — फिर कोशिश करें"
    override val savePinButton = "पिन सेव करें"
    override val unlockButton = "अनलॉक करें"

    override val pdfHeaderTitle = "खाता — उधार हिसाब"
    override val pdfFullKhataSuffix = "पूरा खाता"
    override val pdfShopLabel = "दुकान: "
    override val pdfPhoneLabel = "फ़ोन: "
    override val pdfCreatedLabel = "बनाया गया: "
    override val pdfColDate = "तारीख/समय"
    override val pdfColDesc = "विवरण"
    override val pdfTotalCredit = "कुल उधार:"
    override val pdfTotalPayment = "कुल भुगतान:"
    override val pdfCurrentDue = "मौजूदा बकाया:"
    override val pdfFooter = "उधार हिसाब ऐप से बनाया गया"

    override val navHome = "होम"
    override val navHistory = "हिस्ट्री"
    override val navReports = "रिपोर्ट"
    override val navMore = "अधिक"

    override val historyFilterAllShops = "सभी दुकानें"
    override val historyFilterAllTypes = "सभी"
    override val historyFilterCreditOnly = "सिर्फ़ बकाया"
    override val historyFilterPaymentOnly = "सिर्फ़ भुगतान"
    override val historyNoTxnsFound = "कोई लेनदेन नहीं मिला"
    override val viewArchivedAction = "आर्काइव दुकानें देखें"

    override val reportsTitle = "रिपोर्ट"
    override val periodLabel = "समय-सीमा"
    override val period7d = "पिछले 7 दिन"
    override val period15d = "पिछले 15 दिन"
    override val period30d = "पिछले 30 दिन"
    override val period3m = "पिछले 3 महीने"
    override val period1y = "इस साल"
    override val reportTotalCredit = "कुल उधार"
    override val reportTotalPayment = "कुल भुगतान"
    override val reportCurrentDue = "मौजूदा कुल बकाया"
    override val reportTxnCount = "लेनदेन"
    override val reportChartTitle = "उधार बनाम भुगतान"
    override val reportShopWiseTitle = "दुकान अनुसार बकाया"
    override val reportAgingTitle = "बकाया कितना पुराना"
    override val reportAging0to7 = "0–7 दिन"
    override val reportAging7to15 = "7–15 दिन"
    override val reportAging15to30 = "15–30 दिन"
    override val reportAging30plus = "30+ दिन"
    override val reportRecentPaymentsTitle = "हाल के भुगतान"
    override val reportNoData = "इस समय-सीमा में कोई डेटा नहीं"
    override val reportSmartSummaryPrefix = "इस समय-सीमा में आपने"

    override val moreTitle = "अधिक"
    override val moreBackupRestore = "बैकअप व रिस्टोर"
    override val moreHintBackupRestore = "अपना डेटा सुरक्षित रखें"
    override val notesTitle = "नोट्स"
    override val notesSearchPlaceholder = "नोट्स खोजें..."
    override val addNoteButton = "नया नोट"
    override val noNotesYetTitle = "अभी कोई नोट नहीं"
    override val noNotesYetSubtitle = "खरीदारी सूची, रिमाइंडर — कुछ भी लिख लें"
    override val deleteNoteConfirmTitle = "यह नोट डिलीट करें?"
    override val deleteNoteConfirmMessage = "यह नोट हमेशा के लिए मिट जाएगा।"
    override val noteTitlePlaceholder = "शीर्षक"
    override val noteContentPlaceholder = "कुछ लिखें..."
    override val untitledNote = "बिना शीर्षक का नोट"
    override val notificationInboxTitle = "नोटिफिकेशन"
    override val moreNotificationHistory = "नोटिफिकेशन हिस्ट्री"
    override val moreHintNotificationHistory = "हाल की गतिविधि देखें"
    override val noNotificationsYetTitle = "अभी कोई नोटिफिकेशन नहीं"
    override val noNotificationsYetSubtitle = "उधार या भुगतान दर्ज करें, यह यहां दिखेगा"
    override val notifCreditMessage = "%1\$s से %2\$s उधार लिया गया"
    override val notifPaymentMessage = "%1\$s को %2\$s भुगतान किया गया"
    override val moreQuickCalculator = "क्विक कैलकुलेटर"
    override val moreHintQuickCalculator = "तुरंत हिसाब करें"
    override val calcGeneralTab = "सामान्य"
    override val calcPercentTab = "प्रतिशत"
    override val calcConversionTab = "रूपांतरण"
    override val calcComingSoonInTab = "जल्द आ रहा है"
    override val percentOfTitle = "संख्या का प्रतिशत"
    override val percentOfValueLabel = "संख्या"
    override val percentOfPercentLabel = "प्रतिशत (%)"
    override val percentIsWhatTitle = "एक संख्या दूसरी की कितने प्रतिशत है"
    override val percentIsWhatXLabel = "यह संख्या"
    override val percentIsWhatYLabel = "इसका"
    override val percentChangeTitle = "प्रतिशत वृद्धि/कमी"
    override val percentChangeBaseLabel = "मूल संख्या"
    override val percentChangePercentLabel = "प्रतिशत (%)"
    override val increaseOption = "वृद्धि"
    override val decreaseOption = "कमी"
    override val resultLabel = "परिणाम"
    override val weightCategory = "वज़न"
    override val lengthCategory = "लंबाई"
    override val volumeCategory = "आयतन"
    override val fromLabel = "से"
    override val toLabel = "तक"
    override val enterValueHint = "मान डालें"
    override val backupNowButton = "अभी बैकअप लें"
    override val backupNowHint = "सभी दुकानें व लेनदेन JSON फ़ाइल में सेव करें"
    override val restoreButton = "बैकअप से रिस्टोर करें"
    override val restoreShopAction = "वापस लाएं"
    override val restoreHint = "पुरानी JSON बैकअप फ़ाइल से डेटा वापस लाएं"
    override val lastBackupLabel = "आख़िरी बैकअप"
    override val noBackupYetLabel = "अभी तक कोई बैकअप नहीं लिया गया"
    override val backupSuccessMessage = "बैकअप बन गया"
    override val backupFailPrefix = "बैकअप असफल: "
    override val restoreConfirmTitle = "रिस्टोर करें?"
    override val restoreConfirmMessage = "इससे मौजूदा सभी दुकानें व लेनदेन मिटकर बैकअप फ़ाइल के डेटा से बदल जाएंगे। यह वापस नहीं किया जा सकता।"
    override val restoreSuccessMessage = "रिस्टोर पूरा हुआ"
    override val restoreFailPrefix = "रिस्टोर असफल: "
    override val dataSafeNote = "आपका डेटा केवल इसी फ़ोन में रहता है — बैकअप फ़ाइल खुद सुरक्षित रखें"
    override val moreExportShare = "एक्सपोर्ट व शेयर"
    override val moreHintExportShare = "PDF व फ़ाइलें भेजें"
    override val moreNotifications = "नोटिफिकेशन"
    override val moreHintNotifications = "रिमाइंडर चालू/बंद करें"
    override val moreLanguage = "भाषा"
    override val moreHintLanguage = "बांग्ला, अंग्रेज़ी या हिंदी"
    override val moreUserMode = "मैं कौन हूं"
    override val moreHintUserMode = "ग्राहक या दुकानदार"
    override val moreSecurityPrivacy = "सुरक्षा व गोपनीयता"
    override val moreHintSecurityPrivacy = "पिन व फिंगरप्रिंट लॉक"
    override val moreAppearance = "थीम"
    override val moreHintAppearance = "लाइट, डार्क या सिस्टम"
    override val moreRateFeedback = "रेटिंग व फीडबैक"
    override val moreHintRateFeedback = "अपनी राय बताएं"
    override val moreAbout = "उधार हिसाब के बारे में"
    override val moreHintAbout = "वर्शन व डेवलपर"
    override val comingSoonMessage = "जल्द आ रहा है"

    override val appearanceTitle = "थीम"
    override val themeLight = "लाइट"
    override val themeDark = "डार्क"
    override val themeSystem = "सिस्टम डिफ़ॉल्ट"

    override val creditPageTitle = "उधार लें"
    override val accountingTypeLabel = "एंट्री का प्रकार"
    override val directMoneyMode = "सीधी राशि"
    override val productMode = "उत्पाद अनुसार"
    override val directMoneyAmountLabel = "कितना उधार दिया?"
    override val previousDueLabel = "पिछला बकाया"
    override val newCreditLabel = "नया उधार"
    override val newTotalDueLabel = "नया कुल बकाया"
    override val addCreditButton = "उधार जोड़ें"
    override val addMoreProductButton = "+ एक और उत्पाद जोड़ें"
    override val totalNewCreditLabel = "कुल नया उधार"
    override val editAction = "बदलें"
    override val itemsCountSuffix = "आइटम"

    override val paymentPageTitle = "भुगतान"
    override val currentDueLabel = "मौजूदा बकाया"
    override val howMuchPaymentLabel = "कितना भुगतान कर रहे हैं?"
    override val fullPaymentButton = "पूरा भुगतान"
    override val dueAfterPaymentLabel = "भुगतान के बाद बकाया"
    override val addPaymentButton = "भुगतान जोड़ें"
    override val overpaymentBlockedMessage = "मौजूदा बकाया से ज़्यादा भुगतान नहीं हो सकता"
    override val fullyPaidCelebration = "इससे बकाया पूरी तरह चुक जाएगा"

    override val woodCalculatorTitle = "लकड़ी कैलकुलेटर"
    override val woodTypeLabel = "लकड़ी का प्रकार"
    override val sawnWoodOption = "चिरी हुई लकड़ी"
    override val roundWoodOption = "गोल लट्ठा"
    override val lengthFtLabel = "लंबाई (फुट)"
    override val widthInLabel = "चौड़ाई (इंच)"
    override val thicknessInLabel = "मोटाई (इंच)"
    override val girthInLabel = "घेरा (इंच)"
    override val pieceCountLabel = "टुकड़ों की संख्या"
    override val perPieceCftLabel = "प्रति टुकड़ा"
    override val totalWoodCftLabel = "कुल लकड़ी"
    override val perCftPriceLabel = "मूल्य प्रति CFT (₹)"
    override val totalWoodValueLabel = "कुल मूल्य"
    override val addWoodCalcButton = "यह लकड़ी हिसाब जोड़ें"
    override val woodNameLabel = "उत्पाद का नाम"
    override val addMoreWoodProductButton = "+ एक और लकड़ी/उत्पाद जोड़ें"
    override val addedItemsHeader = "जोड़े गए उत्पाद/लकड़ी"

    override val pdfOptionsTitle = "PDF विकल्प"
    override val pdfPeriodLabel = "समय-सीमा"
    override val pdfThisMonth = "इस महीने"
    override val pdfLastMonth = "पिछले महीने"
    override val pdfLast3Months = "पिछले 3 महीने"
    override val pdfCustomRange = "कस्टम रेंज"
    override val pdfShopLabelOption = "दुकान"
    override val pdfAllShopsOption = "सभी दुकानें"
    override val pdfContentLabel = "क्या दिखाएं"
    override val pdfContentFull = "सब कुछ (लेनदेन + सारांश + हस्ताक्षर)"
    override val pdfContentSummaryOnly = "सिर्फ़ सारांश"
    override val pdfContentTxnsOnly = "सिर्फ़ लेनदेन"
    override val pdfFormatLabel = "फ़ॉर्मैट"
    override val pdfFormatA4 = "A4 रिपोर्ट"
    override val pdfFormatReceipt = "रसीद (58mm)"
    override val pdfGenerateButton = "PDF बनाएं"
    override val pdfFromDateLabel = "शुरुआत की तारीख"
    override val pdfToDateLabel = "अंतिम तारीख"

    override val pdfReportNumberLabel = "रिपोर्ट नं."
    override val pdfShopBoxLabel = "दुकान"
    override val pdfDateBoxLabel = "तारीख"
    override val pdfDaysOfRecordsSuffix = "दिनों का रिकॉर्ड"
    override val pdfWeeklyChartTitle = "साप्ताहिक उधार (लाल) बनाम भुगतान (हरा)"
    override val pdfFinalDueLabel = "मौजूदा बकाया"
    override val pdfShopSignatureLabel = "दुकानदार के हस्ताक्षर"
    override val pdfCustomerSignatureLabel = "ग्राहक के हस्ताक्षर"
    override val pdfAllShopsReportTitle = "सभी दुकानों का सारांश — उधार हिसाब"
    override val pdfPageLabel = "पेज"

    // ── ⭐ দোকানদার প্রোফাইল / রিমাইন্ডার / PDF কাস্টমাইজেশন ──
    override val moreShopProfile = "दुकान की प्रोफ़ाइल"
    override val moreHintShopProfile = "नाम, लोगो, पता, रिमाइंडर"
    override val shopProfileTitle = "दुकान की प्रोफ़ाइल"
    override val shopProfileIntro = "यह जानकारी PDF इनवॉइस और ग्राहक को भेजे संदेशों में इस्तेमाल होगी"
    override val shopBusinessNameLabel = "दुकान का नाम"
    override val shopBusinessAddressLabel = "दुकान का पता"
    override val shopBusinessPhoneLabel = "दुकान का फ़ोन नंबर"
    override val countryCodeLabel = "देश का कोड (जैसे 91)"
    override val shopLogoLabel = "दुकान का लोगो"
    override val shopLogoPick = "लोगो चुनें"
    override val shopLogoRemove = "लोगो हटाएँ"
    override val promptAfterEntryLabel = "एंट्री के बाद ग्राहक को सूचित करने का विकल्प दिखाएँ"
    override val saveProfileButton = "प्रोफ़ाइल सेव करें"
    override val profileSavedMessage = "प्रोफ़ाइल सेव हो गई"
    override val errorShopNameForPdf = "PDF में इस्तेमाल के लिए दुकान का नाम दें"
    override val reminderSendAction = "रिमाइंडर भेजें"
    override val reminderDialogTitle = "ग्राहक को सूचित करें"
    override val reminderDialogSubtitle = "संदेश एडिट करके WhatsApp या SMS से भेजें"
    override val reminderMessageLabel = "संदेश"
    override val reminderWhatsapp = "WhatsApp"
    override val reminderSms = "SMS"
    override val reminderSkip = "अभी नहीं"
    override val reminderNoPhone = "ग्राहक का फ़ोन नंबर नहीं है"
    override val reminderAppMissing = "ऐप नहीं खुल सका"
    override val reminderShopFallback = "हमारी दुकान"
    override val reminderMsgDue = "नमस्ते %1\$s, %2\$s के खाते में आपका कुल बकाया %3\$s है। कृपया समय पर भुगतान करें। धन्यवाद।"
    override val reminderMsgCredit = "नमस्ते %1\$s, %2\$s के खाते में आपका नया उधार जोड़ा गया है। कुल बकाया: %3\$s।"
    override val reminderMsgPayment = "नमस्ते %1\$s, आपका भुगतान मिल गया। धन्यवाद! %2\$s के खाते में वर्तमान बकाया: %3\$s।"
    override val reminderMsgSettled = "नमस्ते %1\$s, आपका पूरा बकाया चुकता हो गया है। धन्यवाद! — %2\$s"
    override val pdfActionLabel = "📤 क्या करना है"
    override val pdfActionShare = "शेयर"
    override val pdfActionSave = "सेव"
    override val pdfActionPrint = "प्रिंट"
    override val pdfBrandingOption = "मेरी दुकान का नाम, लोगो और पता जोड़ें"
    override val pdfBrandingMissing = "दुकान का नाम नहीं दिया गया — अधिक → दुकान की प्रोफ़ाइल में जाकर जोड़ें"
    override val pdfSavedMessage = "PDF सेव हो गई"
    override val pdfSaveFailed = "PDF सेव नहीं हो सकी"

    // ── ⭐ প্রথমবার সেটআপ (ভাষার পরে: আমি কে → দোকানের তথ্য) ──
    override val setupRoleTitle = "आप ऐप का उपयोग कैसे करेंगे?"
    override val setupProfileTitle = "आपकी दुकान की जानकारी"
    override val setupProfileSubtitle = "बाद में अधिक → दुकान की प्रोफ़ाइल से बदल सकते हैं"
    override val setupContinue = "आगे बढ़ें"
    override val setupSkip = "अभी नहीं, बाद में करूँगा"
    override val setupFinish = "शुरू करें"

    override val pickFromContacts = "संपर्कों से नंबर चुनें"

    // ── ⭐ PDF: পণ্যভিত্তিক হিসাবের কলাম ──
    override val pdfColQtyPrice = "मात्रा × दाम"
    override val pdfColItemTotal = "आइटम का कुल"

    // ── ⭐ PDF: কাঠের সম্পূর্ণ মাপ ──
    override val pdfWoodSawn = "चिरी लकड़ी"
    override val pdfWoodRound = "गोल लट्ठा"
    override val pdfWoodFormula = "सूत्र"
    override val pdfWoodTotalWord = "कुल"

    // ── ⭐ ক্যাশ মেমো ডিজাইনের PDF লেবেল ──
    override val pdfMemoTitle = "कैश मेमो"
    override val pdfMemoSubtitle = "Cash Memo / Bill of Supply"
    override val pdfBillNo = "बिल नं. / Bill No"
    override val pdfDateTitle = "दिनांक / Date"
    override val pdfPeriodTitle = "अवधि / Period"
    override val pdfSeller = "विक्रेता / Seller"
    override val pdfBuyer = "क्रेता / Buyer"
    override val pdfAddressLabel = "पता: "
    override val pdfColSl = "क्र."
    override val pdfColPieces = "पीस"
    override val pdfColCft = "CFT"
    override val pdfColRate = "रेट (₹/CFT)"
    override val pdfColAmountRs = "कुल (₹)"
    override val pdfColQty = "मात्रा"
    override val pdfColUnitPrice = "दर (₹)"
    override val pdfSecSawn = "चिरी लकड़ी / Sawn Timber"
    override val pdfSecRound = "गोल लट्ठा / Round Log"
    override val pdfSecOther = "अन्य सामान / Other Items"
    override val pdfSecCashCredit = "नकद उधार / Cash Credit"
    override val pdfSecPayments = "जमा / भुगतान / Payments"
    override val pdfBadgeSawn = "चिरी"
    override val pdfBadgeRound = "गोल"
    override val pdfSawnTotal = "चिरी लकड़ी कुल:"
    override val pdfRoundTotal = "गोल लट्ठा कुल:"
    override val pdfTableTotal = "कुल:"
    override val pdfSumBill = "कुल बिल"
    override val pdfSumPaid = "जमा / भुगतान"
    override val pdfSumDue = "बकाया"
    override val pdfWordsTitle = "राशि शब्दों में / Amount in Words:"
    override val pdfSellerSign = "विक्रेता के हस्ताक्षर व मुहर"
    override val pdfSellerSignSub = "Seller Signature & Seal"
    override val pdfBuyerSign = "क्रेता के हस्ताक्षर"
    override val pdfBuyerSignSub = "Buyer Signature"
    override val pdfMemoFooter = "यह कंप्यूटर निर्मित बिल है। हस्ताक्षर के बिना मान्य नहीं।"

    // ── ⭐ সারাংশ PDF শিরোনাম ও "অন্য তালিকায় সরান" ──
    override val pdfSummaryTitle = "सारांश रिपोर्ट"
    override val moveShopAction = "दूसरी सूची में ले जाएँ"
    override val moveShopTitle = "दूसरी सूची में ले जाएँ?"
    override val moveToShopkeeperMsg = "यह एंट्री \"मैं दुकानदार हूँ\" सूची में (आपके ग्राहक के रूप में) चली जाएगी। रकम वही रहेगी, केवल शब्द बदलेंगे।"
    override val moveToCustomerMsg = "यह एंट्री \"मैं ग्राहक हूँ\" सूची में (जिस दुकान से आप उधार लेते हैं) चली जाएगी। रकम वही रहेगी, केवल शब्द बदलेंगे।"
    override val moveShopConfirm = "ले जाएँ"
}

/** ভাষা কোড ("bn"/"en"/"hi") → স্ট্রিং সেট */
fun stringsFor(languageCode: String): AppStrings = when (languageCode) {
    "en" -> EnglishStrings
    "hi" -> HindiStrings
    else -> BengaliStrings
}

val LocalStrings = staticCompositionLocalOf<AppStrings> { BengaliStrings }

/** ShopType-এর অনুবাদিত নাম */
fun ShopType.displayName(strings: AppStrings): String = when (this) {
    ShopType.TEA -> strings.shopTypeTea
    ShopType.HARDWARE_ELECTRIC -> strings.shopTypeHardwareElectric
    ShopType.KIRANA -> strings.shopTypeKirana
    ShopType.VEGETABLE -> strings.shopTypeVegetable
    ShopType.FISH_MEAT -> strings.shopTypeFishMeat
    ShopType.BAKERY_SWEETS -> strings.shopTypeBakerySweets
    ShopType.PHARMACY -> strings.shopTypePharmacy
    ShopType.COSMETICS -> strings.shopTypeCosmetics
    ShopType.STATIONERY -> strings.shopTypeStationery
    ShopType.XEROX_PRINTING -> strings.shopTypeXeroxPrinting
    ShopType.WOOD -> strings.shopTypeWood
    ShopType.GARMENTS -> strings.shopTypeGarments
    ShopType.OTHER -> strings.shopTypeOther
}
