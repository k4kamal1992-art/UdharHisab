package com.udharhisab.ui.strings

import androidx.compose.runtime.staticCompositionLocalOf
import com.udharhisab.data.local.ShopType

/**
 * ⭐ App-wide UI স্ট্রিং — ভাষা অনুযায়ী [BengaliStrings] / [EnglishStrings]
 * ব্যবহার করুন কম্পোজেবলে: LocalStrings.current.xxx
 */
interface AppStrings {
    // ── ভাষা কোড (UnitConverter.dateShort ইত্যাদি নন-কম্পোজেবল হেল্পারে পাস করার জন্য) ──
    val code: String

    // ── Home ──
    val homeHeadline: String
    val history: String
    val settings: String
    val totalDueLabel: String
    val thisMonthCreditLabel: String
    val thisMonthPaymentLabel: String
    val searchPlaceholder: String
    val filterAll: String
    val settledLabel: String
    val noShopsYetTitle: String
    val noShopsYetSubtitle: String
    val addFirstShopButton: String
    val newShop: String

    // ── Shop types ──
    val shopTypeTea: String
    val shopTypeHardwareElectric: String
    val shopTypeKirana: String
    val shopTypeVegetable: String
    val shopTypeFishMeat: String
    val shopTypeBakerySweets: String
    val shopTypePharmacy: String
    val shopTypeCosmetics: String
    val shopTypeStationery: String
    val shopTypeXeroxPrinting: String
    val shopTypeWood: String
    val shopTypeGarments: String
    val shopTypeOther: String

    // ── Common ──
    val back: String
    val cancel: String
    val save: String

    // ── Add shop ──
    val shopNameLabel: String
    val shopNamePlaceholder: String
    val phoneLabel: String
    val shopTypeLabel: String
    val saveShopButton: String
    val errorNameRequired: String
    val errorTypeRequired: String

    // ── Shop detail ──
    val dueLabel: String
    val noTransactionsYet: String
    val creditButton: String
    val paymentButton: String
    val pdfExport: String
    val archive: String
    val deleteShopAction: String
    val archiveConfirmTitle: String
    val archiveConfirmText: String
    val deleteConfirmTitle: String
    val deleteConfirmText: String
    val yesDelete: String
    val yesArchive: String
    val txnDeletedSnackbar: String
    val undo: String
    val pdfFailPrefix: String
    val shareKhata: String
    val creditFallback: String
    val paymentFallback: String
    val deleteTxnAction: String

    // ── Entry sheet ──
    val productNameLabel: String
    val quantityLabel: String
    val unitLabel: String
    val pricePerUnitLabel: String
    val totalPrefix: String
    val amountLabel: String
    val orEnterAmountLabel: String
    val noteLabel: String
    val cash: String
    val bkash: String
    val bank: String
    val invalidAmountError: String

    // ── CFT calculator ──
    val cftCalculatorTitle: String
    val lengthLabel: String
    val widthLabel: String
    val heightLabel: String
    val rateLabel: String
    val applyToEntryButton: String

    // ── Settings ──
    val settingsTitle: String
    val security: String
    val pinLockOn: String
    val pinLockOff: String
    val changePin: String
    val reminderTitle: String
    val reminderDesc: String
    val about: String
    val aboutLine: String
    val versionLine: String
    val setPinTitle: String
    val newPinLabel: String
    val confirmPinLabel: String
    val pinSetupError: String
    val removePinTitle: String
    val removePinText: String
    val yesTurnOff: String
    val no: String
    val languageTitle: String
    val languageBengaliOption: String
    val languageEnglishOption: String

    // ── More: Notification bottom sheet ──
    val notifSheetTitle: String
    val notifSheetSubtitle: String
    val notifDueReminderOption: String
    val notifWeeklySummaryOption: String
    val notifAppNewsOption: String

    // ── More: Language / Theme sheet subtitles ──
    val langSheetSubtitle: String
    val themeSheetSubtitle: String
    val moreHintBackupRestore: String
    val notesTitle: String
    val notesSearchPlaceholder: String
    val addNoteButton: String
    val noNotesYetTitle: String
    val noNotesYetSubtitle: String
    val deleteNoteConfirmTitle: String
    val deleteNoteConfirmMessage: String
    val noteTitlePlaceholder: String
    val noteContentPlaceholder: String
    val untitledNote: String
    val moreQuickCalculator: String
    val moreHintQuickCalculator: String
    val calcGeneralTab: String
    val calcPercentTab: String
    val calcConversionTab: String
    val calcComingSoonInTab: String
    val backupNowButton: String
    val backupNowHint: String
    val restoreButton: String
    val restoreHint: String
    val lastBackupLabel: String
    val noBackupYetLabel: String
    val backupSuccessMessage: String
    val backupFailPrefix: String
    val restoreConfirmTitle: String
    val restoreConfirmMessage: String
    val restoreSuccessMessage: String
    val restoreFailPrefix: String
    val dataSafeNote: String
    val moreHintExportShare: String
    val moreHintNotifications: String
    val moreHintLanguage: String
    val moreHintSecurityPrivacy: String
    val moreHintAppearance: String
    val moreHintRateFeedback: String
    val moreHintAbout: String

    // ── Security & Privacy page ──
    val securityPrivacyTitle: String
    val pinSectionTitle: String
    val pinSectionDesc: String
    val fingerprintTitle: String
    val fingerprintDesc: String
    val fingerprintUnavailable: String
    val lockImmediatelyTitle: String
    val lockImmediatelyDesc: String

    // ── Rating & Feedback page ──
    val rateTitle: String
    val rateSubtitle: String
    val rateStarsPrompt: String
    val rateThanksMessage: String
    val feedbackPromptLow: String
    val feedbackPlaceholder: String
    val feedbackSubmit: String
    val feedbackThanks: String

    // ── About page ──
    val aboutPageTitle: String
    val aboutVersionPrefix: String
    val aboutDeveloperLabel: String
    val aboutDeveloperName: String
    val aboutPrivacyPolicy: String
    val aboutShareApp: String
    val aboutShareText: String

    // ── History ──
    val noArchivedShops: String
    val noSettledShops: String

    // ── Lock screen ──
    val setupPinTitle: String
    val unlockPinTitle: String
    val pinLabel: String
    val pinDigitsError: String
    val pinsDontMatchError: String
    val wrongPinError: String
    val savePinButton: String
    val unlockButton: String

    // ── PDF ──
    val pdfHeaderTitle: String
    val pdfFullKhataSuffix: String
    val pdfShopLabel: String
    val pdfPhoneLabel: String
    val pdfCreatedLabel: String
    val pdfColDate: String
    val pdfColDesc: String
    val pdfTotalCredit: String
    val pdfTotalPayment: String
    val pdfCurrentDue: String
    val pdfFooter: String

    // ── Bottom nav ──
    val navHome: String
    val navHistory: String
    val navReports: String
    val navMore: String

    // ── Transaction history (new History tab) ──
    val historyFilterAllShops: String
    val historyFilterAllTypes: String
    val historyFilterCreditOnly: String
    val historyFilterPaymentOnly: String
    val historyNoTxnsFound: String
    val viewArchivedAction: String

    // ── Reports ──
    val reportsTitle: String
    val periodLabel: String
    val period7d: String
    val period15d: String
    val period30d: String
    val period3m: String
    val period1y: String
    val reportTotalCredit: String
    val reportTotalPayment: String
    val reportCurrentDue: String
    val reportTxnCount: String
    val reportChartTitle: String
    val reportShopWiseTitle: String
    val reportAgingTitle: String
    val reportAging0to7: String
    val reportAging7to15: String
    val reportAging15to30: String
    val reportAging30plus: String
    val reportRecentPaymentsTitle: String
    val reportNoData: String
    val reportSmartSummaryPrefix: String

    // ── More ──
    val moreTitle: String
    val moreBackupRestore: String
    val moreExportShare: String
    val moreNotifications: String
    val moreLanguage: String
    val moreSecurityPrivacy: String
    val moreAppearance: String
    val moreRateFeedback: String
    val moreAbout: String
    val comingSoonMessage: String

    // ── Appearance (Settings) ──
    val appearanceTitle: String
    val themeLight: String
    val themeDark: String
    val themeSystem: String

    // ── Credit entry screen (নতুন পূর্ণ-স্ক্রিন) ──
    val creditPageTitle: String
    val accountingTypeLabel: String
    val directMoneyMode: String
    val productMode: String
    val directMoneyAmountLabel: String
    val previousDueLabel: String
    val newCreditLabel: String
    val newTotalDueLabel: String
    val addCreditButton: String
    val addMoreProductButton: String
    val totalNewCreditLabel: String
    val editAction: String
    val itemsCountSuffix: String

    // ── Payment entry screen (নতুন পূর্ণ-স্ক্রিন) ──
    val paymentPageTitle: String
    val currentDueLabel: String
    val howMuchPaymentLabel: String
    val fullPaymentButton: String
    val dueAfterPaymentLabel: String
    val addPaymentButton: String
    val overpaymentBlockedMessage: String
    val fullyPaidCelebration: String

    // ── Timber calculator (কাঠের হিসাব) ──
    val woodCalculatorTitle: String
    val woodTypeLabel: String
    val sawnWoodOption: String
    val roundWoodOption: String
    val lengthFtLabel: String
    val widthInLabel: String
    val thicknessInLabel: String
    val girthInLabel: String
    val pieceCountLabel: String
    val perPieceCftLabel: String
    val totalWoodCftLabel: String
    val perCftPriceLabel: String
    val totalWoodValueLabel: String
    val addWoodCalcButton: String
    val woodNameLabel: String
    val addMoreWoodProductButton: String
    val addedItemsHeader: String

    // ── PDF অপশন ডায়ালগ ──
    val pdfOptionsTitle: String
    val pdfPeriodLabel: String
    val pdfThisMonth: String
    val pdfLastMonth: String
    val pdfLast3Months: String
    val pdfCustomRange: String
    val pdfShopLabelOption: String
    val pdfAllShopsOption: String
    val pdfContentLabel: String
    val pdfContentFull: String
    val pdfContentSummaryOnly: String
    val pdfContentTxnsOnly: String
    val pdfFormatLabel: String
    val pdfFormatA4: String
    val pdfFormatReceipt: String
    val pdfGenerateButton: String
    val pdfFromDateLabel: String
    val pdfToDateLabel: String

    // ── PDF-এ আঁকা কনটেন্ট ──
    val pdfReportNumberLabel: String
    val pdfShopBoxLabel: String
    val pdfDateBoxLabel: String
    val pdfDaysOfRecordsSuffix: String
    val pdfWeeklyChartTitle: String
    val pdfFinalDueLabel: String
    val pdfShopSignatureLabel: String
    val pdfCustomerSignatureLabel: String
    val pdfAllShopsReportTitle: String
    val pdfPageLabel: String
}

object BengaliStrings : AppStrings {
    override val code = "bn"
    override val homeHeadline = "উধার হিসাব"
    override val history = "হিস্ট্রি"
    override val settings = "সেটিংস"
    override val totalDueLabel = "মোট বাকি আছে"
    override val thisMonthCreditLabel = "এ মাসে বাকি"
    override val thisMonthPaymentLabel = "এ মাসে জমা"
    override val searchPlaceholder = "দোকান/ফোন খুঁজুন..."
    override val filterAll = "সব"
    override val settledLabel = "পরিশোধিত"
    override val noShopsYetTitle = "কোনো দোকান নেই এখনো"
    override val noShopsYetSubtitle = "প্রথম দোকান যোগ করে খাতা শুরু করুন"
    override val addFirstShopButton = "প্রথম দোকান যোগ করুন"
    override val newShop = "নতুন দোকান"

    override val shopTypeTea = "চায়ের দোকান"
    override val shopTypeHardwareElectric = "হার্ডওয়্যার ও ইলেকট্রিক"
    override val shopTypeKirana = "মুদি দোকান"
    override val shopTypeVegetable = "কাঁচাবাজার/সবজি"
    override val shopTypeFishMeat = "মাছ ও মাংস"
    override val shopTypeBakerySweets = "বেকারি ও মিষ্টি"
    override val shopTypePharmacy = "ওষুধের দোকান"
    override val shopTypeCosmetics = "প্রসাধন সামগ্রী"
    override val shopTypeStationery = "স্টেশনারি"
    override val shopTypeXeroxPrinting = "জেরক্স ও প্রিন্টিং"
    override val shopTypeWood = "কাঠের দোকান"
    override val shopTypeGarments = "পোশাক"
    override val shopTypeOther = "অন্যান্য"

    override val back = "ফিরে যান"
    override val cancel = "বাতিল"
    override val save = "সেভ করুন"

    override val shopNameLabel = "দোকানের নাম *"
    override val shopNamePlaceholder = "যেমন: কাঠ মহল"
    override val phoneLabel = "ফোন নম্বর (ঐচ্ছিক)"
    override val shopTypeLabel = "দোকানের ধরন *"
    override val saveShopButton = "দোকান সেভ করুন"
    override val errorNameRequired = "দোকানের নাম লিখুন"
    override val errorTypeRequired = "দোকানের ধরন বেছে নিন"

    override val dueLabel = "বাকি আছে"
    override val noTransactionsYet = "এখনো কোনো লেনদেন নেই"
    override val creditButton = "ধার নিলাম"
    override val paymentButton = "জমা দিলাম"
    override val pdfExport = "PDF এক্সপোর্ট"
    override val archive = "আর্কাইভ"
    override val deleteShopAction = "দোকান ডিলিট করুন"
    override val archiveConfirmTitle = "দোকান আর্কাইভ করবেন?"
    override val archiveConfirmText = "আর্কাইভ করলে হোম লিস্ট থেকে সরে যাবে — হিস্ট্রিতে পাবেন।"
    override val deleteConfirmTitle = "দোকান স্থায়ীভাবে ডিলিট করবেন?"
    override val deleteConfirmText = "এই দোকান আর এর সব লেনদেন চিরতরে মুছে যাবে। এটি আর ফিরে পাওয়া যাবে না। আর্কাইভ করলে বরং হিস্ট্রিতে থেকে যেত — নিশ্চিত হয়ে এগোন।"
    override val yesDelete = "হ্যাঁ, ডিলিট করুন"
    override val yesArchive = "আর্কাইভ"
    override val txnDeletedSnackbar = "লেনদেন মুছে ফেলা হয়েছে"
    override val undo = "আনডু"
    override val pdfFailPrefix = "PDF তৈরি ব্যর্থ: "
    override val shareKhata = "খাতা শেয়ার করুন"
    override val creditFallback = "ধার"
    override val paymentFallback = "জমা"
    override val deleteTxnAction = "মুছুন"

    override val productNameLabel = "পণ্যের নাম (ঐচ্ছিক)"
    override val quantityLabel = "পরিমাণ"
    override val unitLabel = "একক"
    override val pricePerUnitLabel = "দাম/একক"
    override val totalPrefix = "মোট: "
    override val amountLabel = "কত টাকা জমা দিলেন"
    override val orEnterAmountLabel = "অথবা সরাসরি টাকার পরিমাণ লিখুন"
    override val noteLabel = "নোট (ঐচ্ছিক)"
    override val cash = "নগদ"
    override val bkash = "বিকাশ"
    override val bank = "ব্যাংক"
    override val invalidAmountError = "সঠিক টাকার পরিমাণ দিন"

    override val cftCalculatorTitle = "CFT ক্যালকুলেটর"
    override val lengthLabel = "দৈর্ঘ্য (ইঞ্চি)"
    override val widthLabel = "প্রস্থ"
    override val heightLabel = "উচ্চতা"
    override val rateLabel = "রেট /cft (৳)"
    override val applyToEntryButton = "হিসাব এন্ট্রিতে বসাও"

    override val settingsTitle = "সেটিংস"
    override val security = "নিরাপত্তা"
    override val pinLockOn = "PIN লক চালু আছে"
    override val pinLockOff = "PIN লক বন্ধ আছে"
    override val changePin = "PIN পরিবর্তন করুন"
    override val reminderTitle = "বকেয়া রিমাইন্ডার"
    override val reminderDesc = "প্রতিদিন বকেয়ার কথা মনে করিয়ে দেবে"
    override val about = "সম্পর্কে"
    override val aboutLine = "উধার হিসাব — দোকানের বাকির খাতা"
    override val versionLine = "সংস্করণ 1.0"
    override val setPinTitle = "PIN সেট করুন"
    override val newPinLabel = "নতুন PIN"
    override val confirmPinLabel = "PIN আবার লিখুন"
    override val pinSetupError = "PIN মিলছে না (কমপক্ষে ৪ ডিজিট)"
    override val removePinTitle = "PIN লক বন্ধ করবেন?"
    override val removePinText = "অ্যাপ খোলার সময় আর PIN চাওয়া হবে না।"
    override val yesTurnOff = "হ্যাঁ, বন্ধ করুন"
    override val no = "না"
    override val languageTitle = "ভাষা"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "নোটিফিকেশন"
    override val notifSheetSubtitle = "কোন রিমাইন্ডার চান?"
    override val notifDueReminderOption = "বাকি পরিশোধ রিমাইন্ডার"
    override val notifWeeklySummaryOption = "সাপ্তাহিক হিসাব সারাংশ"
    override val notifAppNewsOption = "অ্যাপ নিউজ ও আপডেট"

    override val langSheetSubtitle = "অ্যাপ কোন ভাষায় চলবে?"
    override val themeSheetSubtitle = "কোন থিম পছন্দ?"

    override val securityPrivacyTitle = "নিরাপত্তা ও প্রাইভেসি"
    override val pinSectionTitle = "PIN লক"
    override val pinSectionDesc = "অ্যাপ খুললে PIN চাইবে"
    override val fingerprintTitle = "ফিঙ্গারপ্রিন্ট লক"
    override val fingerprintDesc = "PIN-এর বদলে আঙুলের ছাপ দিয়ে আনলক করুন"
    override val fingerprintUnavailable = "এই ফোনে ফিঙ্গারপ্রিন্ট সেন্সর পাওয়া যায়নি"
    override val lockImmediatelyTitle = "সাথে সাথে লক করুন"
    override val lockImmediatelyDesc = "অ্যাপ থেকে বের হয়ে আবার ঢুকলেই লক লাগবে"

    override val rateTitle = "রেটিং ও ফিডব্যাক"
    override val rateSubtitle = "উধার হিসাব আপনার কেমন লাগছে?"
    override val rateStarsPrompt = "তারা দিয়ে রেট করুন"
    override val rateThanksMessage = "ধন্যবাদ! Play Store-এ নিয়ে যাচ্ছি…"
    override val feedbackPromptLow = "কী ভালো লাগেনি? আমাদের জানান"
    override val feedbackPlaceholder = "আপনার মতামত লিখুন…"
    override val feedbackSubmit = "পাঠান"
    override val feedbackThanks = "ধন্যবাদ, আপনার মতামত পৌঁছে গেছে"

    override val aboutPageTitle = "উধার হিসাব সম্পর্কে"
    override val aboutVersionPrefix = "সংস্করণ"
    override val aboutDeveloperLabel = "ডেভেলপার"
    override val aboutDeveloperName = "উধার হিসাব টিম"
    override val aboutPrivacyPolicy = "প্রাইভেসি পলিসি"
    override val aboutShareApp = "শেয়ার করুন"
    override val aboutShareText = "উধার হিসাব — দোকানের বাকির খাতা অ্যাপটা ব্যবহার করে দেখুন!"

    override val noArchivedShops = "আর্কাইভ করা দোকান নেই"
    override val noSettledShops = "পরিশোধিত দোকান নেই"

    override val setupPinTitle = "৪-ডিজিটের পিন সেট করুন"
    override val unlockPinTitle = "পিন দিয়ে আনলক করুন"
    override val pinLabel = "পিন"
    override val pinDigitsError = "৪ ডিজিট দিন"
    override val pinsDontMatchError = "দুটো পিন মিলছে না"
    override val wrongPinError = "ভুল পিন — আবার চেষ্টা করুন"
    override val savePinButton = "পিন সেভ করুন"
    override val unlockButton = "আনলক"

    override val pdfHeaderTitle = "খাতা — উধার হিসাব"
    override val pdfFullKhataSuffix = "পূর্ণ খাতা"
    override val pdfShopLabel = "দোকান: "
    override val pdfPhoneLabel = "ফোন: "
    override val pdfCreatedLabel = "তৈরি: "
    override val pdfColDate = "তারিখ"
    override val pdfColDesc = "বিবরণ"
    override val pdfTotalCredit = "মোট ধার:"
    override val pdfTotalPayment = "মোট জমা:"
    override val pdfCurrentDue = "বর্তমান বাকি:"
    override val pdfFooter = "ধার হিসাব অ্যাপ দিয়ে তৈরি"

    override val navHome = "হোম"
    override val navHistory = "হিস্ট্রি"
    override val navReports = "রিপোর্ট"
    override val navMore = "আরও"

    override val historyFilterAllShops = "সব দোকান"
    override val historyFilterAllTypes = "সব"
    override val historyFilterCreditOnly = "শুধু ধার"
    override val historyFilterPaymentOnly = "শুধু পরিশোধ"
    override val historyNoTxnsFound = "কোনো লেনদেন পাওয়া যায়নি"
    override val viewArchivedAction = "আর্কাইভ করা দোকান দেখুন"

    override val reportsTitle = "রিপোর্ট"
    override val periodLabel = "সময়"
    override val period7d = "গত ৭ দিন"
    override val period15d = "গত ১৫ দিন"
    override val period30d = "গত ৩০ দিন"
    override val period3m = "গত ৩ মাস"
    override val period1y = "এই বছর"
    override val reportTotalCredit = "মোট ধার"
    override val reportTotalPayment = "মোট পরিশোধ"
    override val reportCurrentDue = "বর্তমান মোট বাকি"
    override val reportTxnCount = "লেনদেনের সংখ্যা"
    override val reportChartTitle = "ধার বনাম পরিশোধ"
    override val reportShopWiseTitle = "দোকানভিত্তিক বাকি"
    override val reportAgingTitle = "পুরনো বাকি"
    override val reportAging0to7 = "০–৭ দিন"
    override val reportAging7to15 = "৭–১৫ দিন"
    override val reportAging15to30 = "১৫–৩০ দিন"
    override val reportAging30plus = "৩০+ দিন"
    override val reportRecentPaymentsTitle = "সাম্প্রতিক পরিশোধ"
    override val reportNoData = "এই সময়ে কোনো তথ্য নেই"
    override val reportSmartSummaryPrefix = "এই সময়ে আপনি"

    override val moreTitle = "আরও"
    override val moreBackupRestore = "ব্যাকআপ ও রিস্টোর"
    override val moreHintBackupRestore = "ডেটা নিরাপদ রাখুন"
    override val notesTitle = "নোট"
    override val notesSearchPlaceholder = "নোট খুঁজুন..."
    override val addNoteButton = "নতুন নোট"
    override val noNotesYetTitle = "এখনো কোনো নোট নেই"
    override val noNotesYetSubtitle = "বাজারের তালিকা, রিমাইন্ডার — যা খুশি লিখে রাখুন"
    override val deleteNoteConfirmTitle = "নোট মুছে ফেলবেন?"
    override val deleteNoteConfirmMessage = "এই নোটটি স্থায়ীভাবে মুছে যাবে।"
    override val noteTitlePlaceholder = "শিরোনাম"
    override val noteContentPlaceholder = "লিখুন..."
    override val untitledNote = "শিরোনামহীন নোট"
    override val moreQuickCalculator = "কুইক ক্যালকুলেটর"
    override val moreHintQuickCalculator = "দ্রুত হিসাব করুন"
    override val calcGeneralTab = "সাধারণ"
    override val calcPercentTab = "শতকরা"
    override val calcConversionTab = "রূপান্তর"
    override val calcComingSoonInTab = "শীঘ্রই আসছে"
    override val backupNowButton = "এখনই ব্যাকআপ নিন"
    override val backupNowHint = "JSON ফাইলে সব দোকান ও লেনদেন সংরক্ষণ করুন"
    override val restoreButton = "ব্যাকআপ থেকে রিস্টোর করুন"
    override val restoreHint = "আগের JSON ব্যাকআপ ফাইল থেকে ডেটা ফিরিয়ে আনুন"
    override val lastBackupLabel = "শেষ ব্যাকআপ"
    override val noBackupYetLabel = "এখনো কোনো ব্যাকআপ নেওয়া হয়নি"
    override val backupSuccessMessage = "ব্যাকআপ তৈরি হয়েছে"
    override val backupFailPrefix = "ব্যাকআপ ব্যর্থ: "
    override val restoreConfirmTitle = "রিস্টোর করবেন?"
    override val restoreConfirmMessage = "এটি বর্তমান সব দোকান ও লেনদেন মুছে ফেলে ব্যাকআপ ফাইলের ডেটা দিয়ে replace করবে। এই কাজ ফেরানো যাবে না।"
    override val restoreSuccessMessage = "রিস্টোর সম্পন্ন হয়েছে"
    override val restoreFailPrefix = "রিস্টোর ব্যর্থ: "
    override val dataSafeNote = "আপনার ডেটা শুধু এই ফোনেই থাকে — ব্যাকআপ ফাইল আপনি নিজে সংরক্ষণ করুন"
    override val moreExportShare = "এক্সপোর্ট ও শেয়ার"
    override val moreHintExportShare = "PDF ও ফাইল পাঠান"
    override val moreNotifications = "নোটিফিকেশন"
    override val moreHintNotifications = "রিমাইন্ডার চালু/বন্ধ করুন"
    override val moreLanguage = "ভাষা"
    override val moreHintLanguage = "বাংলা বা English"
    override val moreSecurityPrivacy = "নিরাপত্তা ও প্রাইভেসি"
    override val moreHintSecurityPrivacy = "PIN ও ফিঙ্গারপ্রিন্ট লক"
    override val moreAppearance = "অ্যাপের চেহারা"
    override val moreHintAppearance = "লাইট, ডার্ক বা সিস্টেম"
    override val moreRateFeedback = "রেটিং ও ফিডব্যাক"
    override val moreHintRateFeedback = "মতামত জানান"
    override val moreAbout = "উধার হিসাব সম্পর্কে"
    override val moreHintAbout = "ভার্সন ও ডেভেলপার"
    override val comingSoonMessage = "শীঘ্রই আসছে"

    override val appearanceTitle = "অ্যাপের চেহারা"
    override val themeLight = "লাইট"
    override val themeDark = "ডার্ক"
    override val themeSystem = "সিস্টেম ডিফল্ট"

    override val creditPageTitle = "ধার নিলাম"
    override val accountingTypeLabel = "হিসাবের ধরন"
    override val directMoneyMode = "সরাসরি টাকা"
    override val productMode = "পণ্য অনুযায়ী"
    override val directMoneyAmountLabel = "কত টাকা ধার নিলেন?"
    override val previousDueLabel = "আগের বাকি"
    override val newCreditLabel = "নতুন ধার"
    override val newTotalDueLabel = "নতুন মোট বাকি"
    override val addCreditButton = "ধার যোগ করুন"
    override val addMoreProductButton = "+ আরও পণ্য যোগ করুন"
    override val totalNewCreditLabel = "মোট নতুন ধার"
    override val editAction = "সম্পাদনা"
    override val itemsCountSuffix = "টি পণ্য"

    override val paymentPageTitle = "টাকা জমা"
    override val currentDueLabel = "বর্তমান বাকি"
    override val howMuchPaymentLabel = "কত টাকা জমা দেবেন?"
    override val fullPaymentButton = "সম্পূর্ণ পরিশোধ"
    override val dueAfterPaymentLabel = "জমা দেওয়ার পর বাকি"
    override val addPaymentButton = "জমা দিন"
    override val overpaymentBlockedMessage = "বর্তমান বাকির চেয়ে বেশি জমা দেওয়া যাবে না"
    override val fullyPaidCelebration = "সম্পূর্ণ পরিশোধ হয়ে যাবে"

    override val woodCalculatorTitle = "কাঠের হিসাব"
    override val woodTypeLabel = "কাঠের ধরন"
    override val sawnWoodOption = "চেরাই কাঠ"
    override val roundWoodOption = "গোল কাঠ"
    override val lengthFtLabel = "দৈর্ঘ্য (ফুট)"
    override val widthInLabel = "প্রস্থ (ইঞ্চি)"
    override val thicknessInLabel = "পুরত্ব (ইঞ্চি)"
    override val girthInLabel = "গোলবেড়ি (ইঞ্চি)"
    override val pieceCountLabel = "পিস সংখ্যা"
    override val perPieceCftLabel = "প্রতি পিস"
    override val totalWoodCftLabel = "মোট কাঠ"
    override val perCftPriceLabel = "প্রতি CFT দাম (₹)"
    override val totalWoodValueLabel = "মোট মূল্য"
    override val addWoodCalcButton = "এই কাঠের হিসাব যোগ করুন"
    override val woodNameLabel = "পণ্যের নাম"
    override val addMoreWoodProductButton = "+ আরও কাঠ/পণ্য যোগ করুন"
    override val addedItemsHeader = "যোগ করা পণ্য/কাঠ"

    override val pdfOptionsTitle = "PDF অপশন"
    override val pdfPeriodLabel = "সময়সীমা"
    override val pdfThisMonth = "এই মাস"
    override val pdfLastMonth = "গত মাস"
    override val pdfLast3Months = "গত ৩ মাস"
    override val pdfCustomRange = "কাস্টম তারিখ"
    override val pdfShopLabelOption = "দোকান"
    override val pdfAllShopsOption = "সব দোকান"
    override val pdfContentLabel = "কী কী দেখাবে"
    override val pdfContentFull = "সব (লেনদেন + সারাংশ + সিগনেচার)"
    override val pdfContentSummaryOnly = "শুধু সারাংশ"
    override val pdfContentTxnsOnly = "শুধু লেনদেন"
    override val pdfFormatLabel = "ফরম্যাট"
    override val pdfFormatA4 = "A4 রিপোর্ট"
    override val pdfFormatReceipt = "রিসিট (৫৮mm)"
    override val pdfGenerateButton = "PDF বানাও"
    override val pdfFromDateLabel = "শুরুর তারিখ"
    override val pdfToDateLabel = "শেষ তারিখ"

    override val pdfReportNumberLabel = "রিপোর্ট নং"
    override val pdfShopBoxLabel = "দোকান"
    override val pdfDateBoxLabel = "তারিখ"
    override val pdfDaysOfRecordsSuffix = "দিনের হিসাব"
    override val pdfWeeklyChartTitle = "সাপ্তাহিক ধার (লাল) ও পরিশোধ (সবুজ)"
    override val pdfFinalDueLabel = "বর্তমান বাকি"
    override val pdfShopSignatureLabel = "দোকানদারের স্বাক্ষর"
    override val pdfCustomerSignatureLabel = "ক্রেতার স্বাক্ষর"
    override val pdfAllShopsReportTitle = "সব দোকানের সারাংশ — উধার হিসাব"
    override val pdfPageLabel = "পৃষ্ঠা"
}

object EnglishStrings : AppStrings {
    override val code = "en"
    override val homeHeadline = "Udhar Hisab"
    override val history = "History"
    override val settings = "Settings"
    override val totalDueLabel = "Total due"
    override val thisMonthCreditLabel = "This month's due"
    override val thisMonthPaymentLabel = "This month's received"
    override val searchPlaceholder = "Search shop/phone..."
    override val filterAll = "All"
    override val settledLabel = "Settled"
    override val noShopsYetTitle = "No shops yet"
    override val noShopsYetSubtitle = "Add your first shop to start your khata"
    override val addFirstShopButton = "Add first shop"
    override val newShop = "New shop"

    override val shopTypeTea = "Tea shop"
    override val shopTypeHardwareElectric = "Hardware & Electric"
    override val shopTypeKirana = "Grocery shop"
    override val shopTypeVegetable = "Vegetable market"
    override val shopTypeFishMeat = "Fish & meat"
    override val shopTypeBakerySweets = "Bakery & sweets"
    override val shopTypePharmacy = "Pharmacy"
    override val shopTypeCosmetics = "Cosmetics & toiletries"
    override val shopTypeStationery = "Stationery"
    override val shopTypeXeroxPrinting = "Xerox & printing"
    override val shopTypeWood = "Wood shop"
    override val shopTypeGarments = "Garments"
    override val shopTypeOther = "Other"

    override val back = "Back"
    override val cancel = "Cancel"
    override val save = "Save"

    override val shopNameLabel = "Shop name *"
    override val shopNamePlaceholder = "e.g. Wood Mahal"
    override val phoneLabel = "Phone number (optional)"
    override val shopTypeLabel = "Shop type *"
    override val saveShopButton = "Save shop"
    override val errorNameRequired = "Enter the shop name"
    override val errorTypeRequired = "Choose a shop type"

    override val dueLabel = "Due"
    override val noTransactionsYet = "No transactions yet"
    override val creditButton = "Credit taken"
    override val paymentButton = "Payment given"
    override val pdfExport = "Export PDF"
    override val archive = "Archive"
    override val deleteShopAction = "Delete shop"
    override val archiveConfirmTitle = "Archive this shop?"
    override val archiveConfirmText = "It'll be removed from the home list — you can still find it in History."
    override val deleteConfirmTitle = "Permanently delete this shop?"
    override val deleteConfirmText = "This shop and all its transactions will be deleted forever and cannot be recovered. Archiving instead would keep it in History — please confirm before continuing."
    override val yesDelete = "Yes, delete"
    override val yesArchive = "Archive"
    override val txnDeletedSnackbar = "Transaction deleted"
    override val undo = "Undo"
    override val pdfFailPrefix = "PDF generation failed: "
    override val shareKhata = "Share khata"
    override val creditFallback = "Credit"
    override val paymentFallback = "Payment"
    override val deleteTxnAction = "Delete"

    override val productNameLabel = "Product name (optional)"
    override val quantityLabel = "Quantity"
    override val unitLabel = "Unit"
    override val pricePerUnitLabel = "Price/unit"
    override val totalPrefix = "Total: "
    override val amountLabel = "Amount paid"
    override val orEnterAmountLabel = "Or enter the amount directly"
    override val noteLabel = "Note (optional)"
    override val cash = "Cash"
    override val bkash = "bKash"
    override val bank = "Bank"
    override val invalidAmountError = "Enter a valid amount"

    override val cftCalculatorTitle = "CFT calculator"
    override val lengthLabel = "Length (in)"
    override val widthLabel = "Width"
    override val heightLabel = "Height"
    override val rateLabel = "Rate /cft (৳)"
    override val applyToEntryButton = "Apply to entry"

    override val settingsTitle = "Settings"
    override val security = "Security"
    override val pinLockOn = "PIN lock is on"
    override val pinLockOff = "PIN lock is off"
    override val changePin = "Change PIN"
    override val reminderTitle = "Due reminders"
    override val reminderDesc = "Reminds you about dues every day"
    override val about = "About"
    override val aboutLine = "Udhar Hisab — a shop credit ledger"
    override val versionLine = "Version 1.0"
    override val setPinTitle = "Set PIN"
    override val newPinLabel = "New PIN"
    override val confirmPinLabel = "Re-enter PIN"
    override val pinSetupError = "PINs don't match (at least 4 digits)"
    override val removePinTitle = "Turn off PIN lock?"
    override val removePinText = "You won't be asked for a PIN when opening the app anymore."
    override val yesTurnOff = "Yes, turn off"
    override val no = "No"
    override val languageTitle = "Language"
    override val languageBengaliOption = "বাংলা"
    override val languageEnglishOption = "English"

    override val notifSheetTitle = "Notifications"
    override val notifSheetSubtitle = "Which reminders do you want?"
    override val notifDueReminderOption = "Due payment reminder"
    override val notifWeeklySummaryOption = "Weekly summary"
    override val notifAppNewsOption = "App news & updates"

    override val langSheetSubtitle = "Which language should the app use?"
    override val themeSheetSubtitle = "Which theme do you prefer?"

    override val securityPrivacyTitle = "Security & Privacy"
    override val pinSectionTitle = "PIN lock"
    override val pinSectionDesc = "Ask for a PIN when the app opens"
    override val fingerprintTitle = "Fingerprint lock"
    override val fingerprintDesc = "Unlock with your fingerprint instead of the PIN"
    override val fingerprintUnavailable = "No fingerprint sensor found on this phone"
    override val lockImmediatelyTitle = "Lock immediately"
    override val lockImmediatelyDesc = "Lock again as soon as you return to the app"

    override val rateTitle = "Rating & Feedback"
    override val rateSubtitle = "How's Udhar Hisab working for you?"
    override val rateStarsPrompt = "Tap to rate"
    override val rateThanksMessage = "Thanks! Taking you to the Play Store…"
    override val feedbackPromptLow = "What didn't you like? Let us know"
    override val feedbackPlaceholder = "Write your feedback…"
    override val feedbackSubmit = "Send"
    override val feedbackThanks = "Thanks, your feedback has been sent"

    override val aboutPageTitle = "About Udhar Hisab"
    override val aboutVersionPrefix = "Version"
    override val aboutDeveloperLabel = "Developer"
    override val aboutDeveloperName = "Udhar Hisab Team"
    override val aboutPrivacyPolicy = "Privacy Policy"
    override val aboutShareApp = "Share"
    override val aboutShareText = "Udhar Hisab — try this shop credit ledger app!"

    override val noArchivedShops = "No archived shops"
    override val noSettledShops = "No settled shops"

    override val setupPinTitle = "Set a 4-digit PIN"
    override val unlockPinTitle = "Unlock with PIN"
    override val pinLabel = "PIN"
    override val pinDigitsError = "Enter 4 digits"
    override val pinsDontMatchError = "PINs don't match"
    override val wrongPinError = "Wrong PIN — try again"
    override val savePinButton = "Save PIN"
    override val unlockButton = "Unlock"

    override val pdfHeaderTitle = "Khata — Udhar Hisab"
    override val pdfFullKhataSuffix = "Full khata"
    override val pdfShopLabel = "Shop: "
    override val pdfPhoneLabel = "Phone: "
    override val pdfCreatedLabel = "Created: "
    override val pdfColDate = "Date"
    override val pdfColDesc = "Description"
    override val pdfTotalCredit = "Total credit:"
    override val pdfTotalPayment = "Total payment:"
    override val pdfCurrentDue = "Current due:"
    override val pdfFooter = "Made with Udhar Hisab app"

    override val navHome = "Home"
    override val navHistory = "History"
    override val navReports = "Reports"
    override val navMore = "More"

    override val historyFilterAllShops = "All shops"
    override val historyFilterAllTypes = "All"
    override val historyFilterCreditOnly = "Due only"
    override val historyFilterPaymentOnly = "Paid only"
    override val historyNoTxnsFound = "No transactions found"
    override val viewArchivedAction = "View archived shops"

    override val reportsTitle = "Reports"
    override val periodLabel = "Period"
    override val period7d = "Last 7 days"
    override val period15d = "Last 15 days"
    override val period30d = "Last 30 days"
    override val period3m = "Last 3 months"
    override val period1y = "This year"
    override val reportTotalCredit = "Total credit"
    override val reportTotalPayment = "Total payment"
    override val reportCurrentDue = "Current total due"
    override val reportTxnCount = "Transactions"
    override val reportChartTitle = "Credit vs Payment"
    override val reportShopWiseTitle = "Due by shop"
    override val reportAgingTitle = "Outstanding age"
    override val reportAging0to7 = "0–7 days"
    override val reportAging7to15 = "7–15 days"
    override val reportAging15to30 = "15–30 days"
    override val reportAging30plus = "30+ days"
    override val reportRecentPaymentsTitle = "Recent payments"
    override val reportNoData = "No data for this period"
    override val reportSmartSummaryPrefix = "In this period you"

    override val moreTitle = "More"
    override val moreBackupRestore = "Backup & Restore"
    override val moreHintBackupRestore = "Keep your data safe"
    override val notesTitle = "Notes"
    override val notesSearchPlaceholder = "Search notes..."
    override val addNoteButton = "New note"
    override val noNotesYetTitle = "No notes yet"
    override val noNotesYetSubtitle = "Shopping lists, reminders — jot down anything"
    override val deleteNoteConfirmTitle = "Delete this note?"
    override val deleteNoteConfirmMessage = "This note will be permanently deleted."
    override val noteTitlePlaceholder = "Title"
    override val noteContentPlaceholder = "Write something..."
    override val untitledNote = "Untitled note"
    override val moreQuickCalculator = "Quick calculator"
    override val moreHintQuickCalculator = "Do quick math"
    override val calcGeneralTab = "General"
    override val calcPercentTab = "Percent"
    override val calcConversionTab = "Convert"
    override val calcComingSoonInTab = "Coming soon"
    override val backupNowButton = "Backup now"
    override val backupNowHint = "Save all shops and transactions to a JSON file"
    override val restoreButton = "Restore from backup"
    override val restoreHint = "Bring back data from a previous JSON backup file"
    override val lastBackupLabel = "Last backup"
    override val noBackupYetLabel = "No backup taken yet"
    override val backupSuccessMessage = "Backup created"
    override val backupFailPrefix = "Backup failed: "
    override val restoreConfirmTitle = "Restore backup?"
    override val restoreConfirmMessage = "This will erase all current shops and transactions and replace them with the backup file's data. This cannot be undone."
    override val restoreSuccessMessage = "Restore complete"
    override val restoreFailPrefix = "Restore failed: "
    override val dataSafeNote = "Your data stays on this phone only — keep the backup file safe yourself"
    override val moreExportShare = "Export & Share"
    override val moreHintExportShare = "Send PDF & files"
    override val moreNotifications = "Notifications"
    override val moreHintNotifications = "Turn reminders on/off"
    override val moreLanguage = "Language"
    override val moreHintLanguage = "Bengali or English"
    override val moreSecurityPrivacy = "Security & Privacy"
    override val moreHintSecurityPrivacy = "PIN & fingerprint lock"
    override val moreAppearance = "Appearance"
    override val moreHintAppearance = "Light, dark or system"
    override val moreRateFeedback = "Rate & Feedback"
    override val moreHintRateFeedback = "Share your feedback"
    override val moreAbout = "About Udhar Hisab"
    override val moreHintAbout = "Version & developer"
    override val comingSoonMessage = "Coming soon"

    override val appearanceTitle = "Appearance"
    override val themeLight = "Light"
    override val themeDark = "Dark"
    override val themeSystem = "System default"

    override val creditPageTitle = "Take credit"
    override val accountingTypeLabel = "Entry type"
    override val directMoneyMode = "Direct amount"
    override val productMode = "By product"
    override val directMoneyAmountLabel = "How much credit did you give?"
    override val previousDueLabel = "Previous due"
    override val newCreditLabel = "New credit"
    override val newTotalDueLabel = "New total due"
    override val addCreditButton = "Add credit"
    override val addMoreProductButton = "+ Add another product"
    override val totalNewCreditLabel = "Total new credit"
    override val editAction = "Edit"
    override val itemsCountSuffix = "items"

    override val paymentPageTitle = "Payment"
    override val currentDueLabel = "Current due"
    override val howMuchPaymentLabel = "How much are they paying?"
    override val fullPaymentButton = "Full payment"
    override val dueAfterPaymentLabel = "Due after payment"
    override val addPaymentButton = "Add payment"
    override val overpaymentBlockedMessage = "Can't pay more than the current due"
    override val fullyPaidCelebration = "This will fully settle the due"

    override val woodCalculatorTitle = "Timber calculator"
    override val woodTypeLabel = "Wood type"
    override val sawnWoodOption = "Sawn timber"
    override val roundWoodOption = "Round log"
    override val lengthFtLabel = "Length (ft)"
    override val widthInLabel = "Width (in)"
    override val thicknessInLabel = "Thickness (in)"
    override val girthInLabel = "Girth (in)"
    override val pieceCountLabel = "Piece count"
    override val perPieceCftLabel = "Per piece"
    override val totalWoodCftLabel = "Total wood"
    override val perCftPriceLabel = "Price per CFT (₹)"
    override val totalWoodValueLabel = "Total value"
    override val addWoodCalcButton = "Add this wood calculation"
    override val woodNameLabel = "Product name"
    override val addMoreWoodProductButton = "+ Add another wood/product"
    override val addedItemsHeader = "Added products/wood"

    override val pdfOptionsTitle = "PDF options"
    override val pdfPeriodLabel = "Period"
    override val pdfThisMonth = "This month"
    override val pdfLastMonth = "Last month"
    override val pdfLast3Months = "Last 3 months"
    override val pdfCustomRange = "Custom range"
    override val pdfShopLabelOption = "Shop"
    override val pdfAllShopsOption = "All shops"
    override val pdfContentLabel = "What to show"
    override val pdfContentFull = "Everything (transactions + summary + signatures)"
    override val pdfContentSummaryOnly = "Summary only"
    override val pdfContentTxnsOnly = "Transactions only"
    override val pdfFormatLabel = "Format"
    override val pdfFormatA4 = "A4 report"
    override val pdfFormatReceipt = "Receipt (58mm)"
    override val pdfGenerateButton = "Generate PDF"
    override val pdfFromDateLabel = "Start date"
    override val pdfToDateLabel = "End date"

    override val pdfReportNumberLabel = "Report no."
    override val pdfShopBoxLabel = "Shop"
    override val pdfDateBoxLabel = "Date"
    override val pdfDaysOfRecordsSuffix = "days of records"
    override val pdfWeeklyChartTitle = "Weekly credit (red) vs payment (green)"
    override val pdfFinalDueLabel = "Current due"
    override val pdfShopSignatureLabel = "Shopkeeper's signature"
    override val pdfCustomerSignatureLabel = "Customer's signature"
    override val pdfAllShopsReportTitle = "All shops summary — Udhar Hisab"
    override val pdfPageLabel = "Page"
}

/** ভাষা কোড ("bn"/"en") → স্ট্রিং সেট */
fun stringsFor(languageCode: String): AppStrings =
    if (languageCode == "en") EnglishStrings else BengaliStrings

val LocalStrings = staticCompositionLocalOf<AppStrings> { BengaliStrings }

/** ShopType-এর অনুবাদিত নাম */
fun ShopType.displayName(strings: AppStrings): String = when (this) {
    ShopType.TEA -> strings.shopTypeTea
    ShopType.HARDWARE_ELECTRIC -> strings.shopTypeHardwareElectric
    ShopType.KIRANA -> strings.shopTypeKirana
    ShopType.VEGETABLE -> strings.shopTypeVegetable
    ShopType.FISH_MEAT -> strings.shopTypeFishMeat
    ShopType.BAKERY_SWEETS -> strings.shopTypeBakerySweets
    ShopType.PHARMACY -> strings.shopTypePharmacy
    ShopType.COSMETICS -> strings.shopTypeCosmetics
    ShopType.STATIONERY -> strings.shopTypeStationery
    ShopType.XEROX_PRINTING -> strings.shopTypeXeroxPrinting
    ShopType.WOOD -> strings.shopTypeWood
    ShopType.GARMENTS -> strings.shopTypeGarments
    ShopType.OTHER -> strings.shopTypeOther
}
