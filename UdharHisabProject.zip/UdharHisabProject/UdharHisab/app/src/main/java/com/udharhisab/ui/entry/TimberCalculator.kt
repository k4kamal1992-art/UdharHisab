package com.udharhisab.ui.entry

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

enum class WoodMeasureType { SAWN, ROUND }

/**
 * ⭐ প্রকৃত Timber Calculator — কাঠের ধরন অনুযায়ী সঠিক সূত্র, পিস সংখ্যা,
 * আর ফলাফল থেকে সরাসরি একটা সম্পূর্ণ পণ্য-সারি (নাম + CFT + রেট) তৈরি হয়।
 *
 * সূত্র:
 *  - চেরাই কাঠ: (দৈর্ঘ্য ফুট × প্রস্থ ইঞ্চি × পুরত্ব ইঞ্চি) ÷ 144
 *  - গোল কাঠ:   (দৈর্ঘ্য ফুট × গোলবেড়ি ইঞ্চি × গোলবেড়ি ইঞ্চি) ÷ 2304
 *
 * @param onAdd (পণ্যের নাম, মোট CFT, প্রতি CFT দাম) — যোগ করার পর ক্যালকুলেটর রিসেট হয়
 *              যাতে একই/অন্য কাঠের পরের হিসাবও সহজে করা যায়।
 */
@Composable
fun TimberCalculator(onAdd: (productName: String, totalCft: Double, ratePerCft: Double) -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    var woodType by remember { mutableStateOf(WoodMeasureType.SAWN) }
    var productName by remember { mutableStateOf("") }
    var length by remember { mutableStateOf("") }
    var width by remember { mutableStateOf("") }
    var thickness by remember { mutableStateOf("") }
    var girth by remember { mutableStateOf("") }
    var pieces by remember { mutableStateOf("1") }
    var rate by remember { mutableStateOf("") }

    val l = length.toDoubleOrNull() ?: 0.0
    val piecesNum = pieces.toIntOrNull() ?: 0
    val r = rate.toDoubleOrNull() ?: 0.0

    val perPieceCft = when (woodType) {
        WoodMeasureType.SAWN -> UnitConverter.sawnTimberCft(
            l, width.toDoubleOrNull() ?: 0.0, thickness.toDoubleOrNull() ?: 0.0
        )
        WoodMeasureType.ROUND -> UnitConverter.roundTimberCft(l, girth.toDoubleOrNull() ?: 0.0)
    }
    val totalCft = perPieceCft * piecesNum
    val totalValue = totalCft * r

    fun reset() {
        productName = ""; length = ""; width = ""; thickness = ""
        girth = ""; pieces = "1"; rate = ""
    }

    Column(Modifier.fillMaxWidth()) {
        Text(s.woodCalculatorTitle, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))

        // ── কাঠের ধরন ──
        Text(s.woodTypeLabel, style = MaterialTheme.typography.labelLarge, color = c.Muted)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = woodType == WoodMeasureType.SAWN,
                onClick = { woodType = WoodMeasureType.SAWN },
                label = { Text(s.sawnWoodOption) },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = woodType == WoodMeasureType.ROUND,
                onClick = { woodType = WoodMeasureType.ROUND },
                label = { Text(s.roundWoodOption) },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(10.dp))

        // ── পণ্যের নাম (আবশ্যক) ──
        OutlinedTextField(
            value = productName,
            onValueChange = { productName = it },
            label = { Text(s.woodNameLabel) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))

        // ── মাপ ──
        if (woodType == WoodMeasureType.SAWN) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = length, onValueChange = { length = it },
                    label = { Text(s.lengthFtLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = width, onValueChange = { width = it },
                    label = { Text(s.widthInLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = thickness, onValueChange = { thickness = it },
                    label = { Text(s.thicknessInLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = length, onValueChange = { length = it },
                    label = { Text(s.lengthFtLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = girth, onValueChange = { girth = it },
                    label = { Text(s.girthInLabel) }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = pieces, onValueChange = { pieces = it },
            label = { Text(s.pieceCountLabel) }, singleLine = true,
            modifier = Modifier.fillMaxWidth(0.5f)
        )
        Spacer(Modifier.height(14.dp))

        // ── ফলাফল কার্ড ──
        Card(colors = CardDefaults.cardColors(containerColor = c.ChipBg), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.perPieceCftLabel, color = c.Muted)
                    Text("${UnitConverter.amountInput(perPieceCft)} CFT")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.pieceCountLabel, color = c.Muted)
                    Text("$piecesNum")
                }
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.totalWoodCftLabel, style = MaterialTheme.typography.titleMedium)
                    Text("${UnitConverter.amountInput(totalCft)} CFT", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = rate, onValueChange = { rate = it },
            label = { Text(s.perCftPriceLabel) }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))

        Card(colors = CardDefaults.cardColors(containerColor = c.Primary), modifier = Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(14.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    s.totalWoodValueLabel,
                    color = androidx.compose.ui.graphics.Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    UnitConverter.rupees(totalValue),
                    color = androidx.compose.ui.graphics.Color.White,
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        Button(
            onClick = {
                onAdd(productName.trim(), totalCft, r)
                reset()
            },
            enabled = totalCft > 0 && r > 0 && productName.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(s.addWoodCalcButton)
        }
    }
}
