# Room entities
-keep class com.udharhisab.data.local.** { *; }

# WorkManager workers
-keepclassmembers class * extends androidx.work.CoroutineWorker { *; }

# বাংলা ফন্ট asset অটো থাকে, কিছু লাগে না
