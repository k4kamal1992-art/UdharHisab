package com.udharhisab.ui.reports

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.udharhisab.domain.UnitConverter

/** ⭐ প্রিমিয়াম গ্র্যাডিয়েন্ট বার চার্ট — গোলাকার টপ, সফট গ্লো */
@Composable
fun CreditPaymentBarChart(
    credit: Double,
    payment: Double,
    creditColor: Color,
    paymentColor: Color,
    creditLabel: String,
    paymentLabel: String
) {
    val maxVal = maxOf(credit, payment, 1.0)

    Column(Modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .padding(horizontal = 24.dp)
        ) {
            val barWidth = size.width / 4
            val chartHeight = size.height - 8
            val creditH = (credit / maxVal * chartHeight).toFloat().coerceAtLeast(4f)
            val paymentH = (payment / maxVal * chartHeight).toFloat().coerceAtLeast(4f)
            val radius = CornerRadius(barWidth / 2.6f, barWidth / 2.6f)

            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(creditColor, creditColor.copy(alpha = 0.55f))
                ),
                topLeft = Offset(barWidth * 0.5f, size.height - creditH),
                size = Size(barWidth, creditH),
                cornerRadius = radius
            )
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(paymentColor, paymentColor.copy(alpha = 0.55f))
                ),
                topLeft = Offset(barWidth * 2.5f, size.height - paymentH),
                size = Size(barWidth, paymentH),
                cornerRadius = radius
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(UnitConverter.rupees(credit), color = creditColor, style = MaterialTheme.typography.labelLarge)
                Text(creditLabel, style = MaterialTheme.typography.bodySmall)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(UnitConverter.rupees(payment), color = paymentColor, style = MaterialTheme.typography.labelLarge)
                Text(paymentLabel, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
