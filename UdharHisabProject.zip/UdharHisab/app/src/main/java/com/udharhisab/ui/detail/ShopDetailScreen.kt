package com.udharhisab.ui.detail

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithItems
import com.udharhisab.data.pdf.KhataPdfGenerator
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.components.GradientHeroCard
import com.udharhisab.ui.components.heroGradientFor
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopDetailScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onOpenCredit: () -> Unit,
    onOpenPayment: () -> Unit
) {
    val vm: ShopDetailViewModel = viewModel {
        ShopDetailViewModel(container.repo, shopId)
    }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val shop by vm.shop.collectAsState()
    val txns by vm.txns.collectAsState()
    val balance by vm.balance.collectAsState()
    val lastDeleted by vm.lastDeletedTxnId.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var showPermanentDeleteDialog by remember { mutableStateOf(false) }
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())

    val shopVal = shop
    if (shopVal == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = c.Primary)
        }
        return
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(shopVal.name, style = MaterialTheme.typography.titleLarge) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = c.TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { showPdfDialog = true }) {
                        Icon(Icons.Default.PictureAsPdf, s.pdfExport, tint = c.Primary)
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Archive, s.archive, tint = c.TextSecondary)
                    }
                    IconButton(onClick = { showPermanentDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, s.deleteShopAction, tint = c.Danger)
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = c.Background, shadowElevation = 0.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GradientActionButton(
                        label = s.creditButton,
                        icon = Icons.Default.Add,
                        gradient = KhataGradients.danger(c),
                        onClick = onOpenCredit,
                        modifier = Modifier.weight(1f)
                    )
                    GradientActionButton(
                        label = s.paymentButton,
                        icon = Icons.Default.Remove,
                        gradient = KhataGradients.success(c),
                        onClick = onOpenPayment,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // ── হিরো: বর্তমান বাকি — গ্র্যাডিয়েন্ট, ডাইনামিক (বাকি/মিটে গেছে) ──
            item {
                GradientHeroCard(gradient = c.heroGradientFor(isDue = balance > 0)) {
                    Column(Modifier.padding(24.dp)) {
                        Text(
                            if (balance > 0) s.dueLabel else "🎉 ${s.settledLabel}",
                            style = MaterialTheme.typography.displaySmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            UnitConverter.rupees(if (balance > 0) balance else 0.0),
                            style = MaterialTheme.typography.displayLarge,
                            color = Color.White
                        )
                        shopVal.phone?.let {
                            Spacer(Modifier.height(10.dp))
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(percent = 50))
                                    .background(Color.White.copy(alpha = 0.16f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("📞 $it", color = Color.White.copy(alpha = 0.9f),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            // ── লেনদেন লিস্ট ──
            if (txns.isEmpty()) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("📝", style = MaterialTheme.typography.displayLarge)
                        Text(s.noTransactionsYet,
                            style = MaterialTheme.typography.bodyLarge, color = c.Muted)
                    }
                }
            } else {
                item {
                    Text(
                        s.history,
                        style = MaterialTheme.typography.titleSmall,
                        color = c.TextSecondary,
                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    )
                }
                items(txns, key = { it.txn.id }) { tw ->
                    TxnRow(
                        tw = tw,
                        onDelete = { vm.deleteTxn(tw.txn.id) }
                    )
                }
            }
        }
    }

    // ── আনডু Snackbar ──
    LaunchedEffect(lastDeleted) {
        if (lastDeleted != null) {
            val result = snackbar.showSnackbar(
                message = s.txnDeletedSnackbar,
                actionLabel = s.undo,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) vm.undoDelete()
            else vm.lastDeletedTxnId.value = null
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(s.archiveConfirmTitle) },
            text = { Text(s.archiveConfirmText) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    vm.archiveShop { onBack() }
                }) { Text(s.yesArchive) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text(s.cancel) }
            }
        )
    }

    if (showPermanentDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showPermanentDeleteDialog = false },
            title = { Text(s.deleteConfirmTitle) },
            text = { Text(s.deleteConfirmText) },
            confirmButton = {
                TextButton(onClick = {
                    showPermanentDeleteDialog = false
                    vm.deleteShop { onBack() }
                }) { Text(s.yesDelete) }
            },
            dismissButton = {
                TextButton(onClick = { showPermanentDeleteDialog = false }) { Text(s.cancel) }
            }
        )
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = shopId,
            onDismiss = { showPdfDialog = false },
            onGenerate = { pdfShopId, fromTime, toTime, pdfScope, pdfFormat ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val reportNumber = container.store.nextReportNumber()
                        val file = if (pdfShopId != null) {
                            val targetShop = if (pdfShopId == shopId) shopVal
                                else container.repo.shopOnce(pdfShopId)
                            if (targetShop == null) {
                                snackbar.showSnackbar("${s.pdfFailPrefix}shop not found")
                                return@launch
                            }
                            val rangeTxns = container.repo.txnsWithItemsInRange(pdfShopId, fromTime, toTime)
                            KhataPdfGenerator(context, s).generateShopReport(
                                targetShop, rangeTxns, reportNumber, fromTime, toTime, pdfFormat, pdfScope
                            )
                        } else {
                            val rows = container.repo.shopReportRowsInRange(fromTime, toTime)
                            KhataPdfGenerator(context, s).generateAllShopsReport(
                                rows, reportNumber, fromTime, toTime
                            )
                        }
                        val uri = FileProvider.getUriForFile(
                            context, "${context.packageName}.fileprovider", file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, s.shareKhata))
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }
}

@Composable
private fun GradientActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    gradient: androidx.compose.ui.graphics.Brush,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalKhataColors.current
    Row(
        modifier
            .height(54.dp)
            .shadow(10.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
            .clip(RoundedCornerShape(percent = 50))
            .background(gradient)
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun TxnRow(tw: TransactionWithItems, onDelete: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val txn = tw.txn
    val isCredit = txn.type == TransactionEntity.TYPE_CREDIT
    val hasItems = tw.items.isNotEmpty()
    var showDetail by remember { mutableStateOf(false) }

    GlassCard(onClick = if (hasItems) ({ showDetail = true }) else null) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            // বাম পাশে রঙিন এক্সেন্ট বার — ক্রেডিট/পেমেন্ট নির্দেশক
            Box(
                Modifier
                    .width(4.dp)
                    .height(38.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (isCredit) c.Danger else c.Success)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        hasItems -> "${tw.items.size} ${s.itemsCountSuffix}"
                        isCredit -> s.creditFallback
                        else -> s.paymentFallback
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = c.TextPrimary
                )
                val details = buildString {
                    append(UnitConverter.dateShort(txn.date, s.code))
                    if (hasItems) {
                        append(" • " + tw.items.joinToString(", ") { it.productName.ifBlank { s.creditFallback } })
                    }
                    txn.paymentMethod?.let { append(" • $it") }
                    txn.note?.let { append(" • $it") }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(txn.amount),
                style = MaterialTheme.typography.titleMedium,
                color = if (isCredit) c.Danger else c.Success
            )
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete, s.deleteTxnAction,
                    tint = c.Muted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }

    if (showDetail) {
        AlertDialog(
            onDismissRequest = { showDetail = false },
            title = { Text(if (isCredit) s.creditButton else s.paymentButton) },
            text = {
                Column {
                    tw.items.forEach { itm ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(itm.productName.ifBlank { s.creditFallback })
                                if (itm.quantity != null && itm.unit != null) {
                                    Text(
                                        "${UnitConverter.amountInput(itm.quantity!!)} ${itm.unit} × ${itm.unitPrice?.let { UnitConverter.amountInput(it) } ?: ""}",
                                        style = MaterialTheme.typography.bodySmall, color = c.Muted
                                    )
                                }
                            }
                            Text(UnitConverter.rupees(itm.amount))
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    HorizontalDivider()
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.totalPrefix, style = MaterialTheme.typography.titleMedium)
                        Text(UnitConverter.rupees(txn.amount), style = MaterialTheme.typography.titleMedium)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetail = false }) { Text(s.cancel) }
            }
        )
    }
}
