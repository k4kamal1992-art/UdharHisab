package com.udharhisab.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.udharhisab.R
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.components.GradientAvatar
import com.udharhisab.ui.components.GradientHeroCard
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onAddShop: () -> Unit,
    onOpenShop: (Long) -> Unit
) {
    val vm: HomeViewModel = viewModel {
        HomeViewModel(container.repo)
    }
    val shops by vm.visibleShops.collectAsState()
    val totalDue by vm.totalDue.collectAsState()
    val search by vm.search.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    Scaffold(
        containerColor = c.Background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddShop,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                shape = RoundedCornerShape(percent = 50),
                modifier = Modifier
                    .shadow(16.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(KhataGradients.brand(c))
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(s.newShop, style = MaterialTheme.typography.labelLarge)
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 110.dp)
        ) {
            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    Spacer(Modifier.height(10.dp))

                    // ── টপ বার ──
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.logo),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            s.homeHeadline,
                            style = MaterialTheme.typography.headlineMedium,
                            color = c.TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(Modifier.height(18.dp))

                    // ── হিরো কার্ড: মোট বাকি — গ্র্যাডিয়েন্ট + গ্লাস শাইন + গ্লো ──
                    GradientHeroCard(gradient = KhataGradients.brandDeep(c)) {
                        Column(Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.9f))
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    s.totalDueLabel,
                                    style = MaterialTheme.typography.displaySmall,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                UnitConverter.rupees(totalDue),
                                style = MaterialTheme.typography.displayLarge,
                                color = Color.White
                            )
                            Spacer(Modifier.height(14.dp))
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(percent = 50))
                                    .background(Color.White.copy(alpha = 0.16f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "${shops.size} ${s.navHome}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    // ── সার্চ ──
                    OutlinedTextField(
                        value = search,
                        onValueChange = vm::setSearch,
                        placeholder = { Text(s.searchPlaceholder, color = c.Muted) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = c.Primary) },
                        singleLine = true,
                        shape = RoundedCornerShape(percent = 50),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = c.Surface,
                            unfocusedContainerColor = c.Surface,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(6.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
                    )

                    Spacer(Modifier.height(12.dp))

                    // ── ফিল্টার চিপ ──
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())
                    ) {
                        PremiumFilterChip(
                            selected = typeFilter == null,
                            label = s.filterAll,
                            onClick = { vm.setTypeFilter(null) }
                        )
                        ShopType.entries.forEach { t ->
                            PremiumFilterChip(
                                selected = typeFilter == t,
                                label = "${t.emoji} ${t.displayName(s)}",
                                onClick = { vm.setTypeFilter(if (typeFilter == t) null else t) }
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                }
            }

            // ── লিস্ট / এম্পটি ──
            if (shops.isEmpty()) {
                item { EmptyHome(onAddShop = onAddShop) }
            } else {
                items(shops, key = { it.shop.id }) { swb ->
                    Box(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                        ShopCard(swb, onClick = { onOpenShop(swb.shop.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumFilterChip(selected: Boolean, label: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Box(
        Modifier
            .clip(RoundedCornerShape(percent = 50))
            .let {
                if (selected) it.background(KhataGradients.brand(c))
                else it.background(c.Surface)
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) Color.White else c.TextSecondary
        )
    }
}

@Composable
private fun ShopCard(swb: com.udharhisab.data.local.ShopWithBalance, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val type = ShopType.fromKey(swb.shop.shopType)
    val balance = swb.balance
    val isSettled = balance <= 0.0

    GlassCard(onClick = onClick) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // gradient avatar রিং সহ ইমোজি
            GradientAvatar(
                size = 50.dp,
                gradient = if (isSettled) KhataGradients.success(c) else Brush.linearGradient(
                    listOf(c.ChipBg, c.ChipBg)
                )
            ) {
                Text(type.emoji, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(swb.shop.name, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                swb.shop.phone?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                }
                Text(type.displayName(s), style = MaterialTheme.typography.labelSmall, color = c.Muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    when {
                        isSettled -> "🎉 ${s.settledLabel}"
                        else -> UnitConverter.rupees(balance)
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isSettled) c.Success else c.Danger
                )
                Spacer(Modifier.height(2.dp))
                Icon(Icons.Default.ChevronRight, null, tint = c.Muted, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun EmptyHome(onAddShop: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 60.dp)
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(c.ChipBg, c.Surface))),
            contentAlignment = Alignment.Center
        ) {
            Text("🏪", style = MaterialTheme.typography.displayLarge)
        }
        Spacer(Modifier.height(16.dp))
        Text(s.noShopsYetTitle,
            style = MaterialTheme.typography.titleLarge, color = c.TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(s.noShopsYetSubtitle,
            style = MaterialTheme.typography.bodyMedium, color = c.Muted)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onAddShop,
            shape = RoundedCornerShape(percent = 50),
            colors = ButtonDefaults.buttonColors(containerColor = c.Primary),
            modifier = Modifier.height(48.dp)
        ) {
            Text(s.addFirstShopButton, style = MaterialTheme.typography.labelLarge)
        }
    }
}
