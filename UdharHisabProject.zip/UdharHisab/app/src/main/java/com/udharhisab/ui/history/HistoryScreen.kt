package com.udharhisab.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.TransactionEntity
import com.udharhisab.data.local.TransactionWithShop
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ বটম-ন্যাভের "History" ট্যাব — সব দোকানের সব লেনদেন এক জায়গায়,
 * দোকান আর ধার/পরিশোধ অনুযায়ী ফিল্টার করা যায়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    container: AppContainer,
    onOpenShop: (Long) -> Unit,
    onOpenArchived: () -> Unit
) {
    val vm: TransactionHistoryViewModel = viewModel { TransactionHistoryViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val txns by vm.filtered.collectAsState()
    val shopFilter by vm.shopFilter.collectAsState()
    val typeFilter by vm.typeFilter.collectAsState()
    val availableShops by vm.availableShops.collectAsState()

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.history, style = MaterialTheme.typography.headlineSmall) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                actions = {
                    IconButton(onClick = onOpenArchived) {
                        Icon(Icons.Default.Archive, s.viewArchivedAction, tint = c.Primary)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            // ── ধার/পরিশোধ ফিল্টার ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                HistoryChip(s.historyFilterAllTypes, typeFilter == null) { vm.setTypeFilter(null) }
                HistoryChip(s.historyFilterCreditOnly, typeFilter == TransactionEntity.TYPE_CREDIT) {
                    vm.setTypeFilter(TransactionEntity.TYPE_CREDIT)
                }
                HistoryChip(s.historyFilterPaymentOnly, typeFilter == TransactionEntity.TYPE_PAYMENT) {
                    vm.setTypeFilter(TransactionEntity.TYPE_PAYMENT)
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── দোকান ফিল্টার ──
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                HistoryChip(s.historyFilterAllShops, shopFilter == null) { vm.setShopFilter(null) }
                availableShops.forEach { (shopId, shopName) ->
                    HistoryChip(shopName, shopFilter == shopId) {
                        vm.setShopFilter(if (shopFilter == shopId) null else shopId)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            if (txns.isEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🧾", style = MaterialTheme.typography.displayLarge)
                    Text(s.historyNoTxnsFound, color = c.Muted)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 110.dp)
                ) {
                    items(txns, key = { it.txn.id }) { tws ->
                        TxnHistoryRow(tws, s.code, onClick = { onOpenShop(tws.txn.shopId) })
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Box(
        Modifier
            .clip(RoundedCornerShape(percent = 50))
            .let { if (selected) it.background(KhataGradients.brand(c)) else it.background(c.Surface) }
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) Color.White else c.TextSecondary
        )
    }
}

@Composable
private fun TxnHistoryRow(tws: TransactionWithShop, langCode: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val t = tws.txn
    val isCredit = t.type == TransactionEntity.TYPE_CREDIT

    GlassCard(onClick = onClick) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .width(4.dp)
                    .height(36.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (isCredit) c.Danger else c.Success)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tws.shopName, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                val details = buildString {
                    append(UnitConverter.dateShort(t.date, langCode))
                    (tws.items.firstOrNull()?.productName?.takeIf { tws.items.isNotEmpty() }
                        ?: if (isCredit) s.creditFallback else s.paymentFallback).let {
                        append(" • $it")
                        if (tws.items.size > 1) append(" +${tws.items.size - 1}")
                    }
                }
                Text(details, style = MaterialTheme.typography.bodySmall, color = c.Muted)
            }
            Text(
                (if (isCredit) "+" else "-") + UnitConverter.rupees(t.amount),
                style = MaterialTheme.typography.titleMedium,
                color = if (isCredit) c.Danger else c.Success
            )
        }
    }
}
