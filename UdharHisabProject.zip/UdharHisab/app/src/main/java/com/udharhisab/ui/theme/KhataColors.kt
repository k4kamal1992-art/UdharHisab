package com.udharhisab.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ── সেমান্টিক কালার (M3-এর বাইরে আমাদের নিজের) — Premium Fintech সিস্টেম ──
data class KhataColors(
    val Primary: Color,
    val PrimaryDark: Color,
    val PrimaryLight: Color,
    val Secondary: Color,           // গ্র্যাডিয়েন্টের দ্বিতীয় স্টপ / অ্যাকসেন্ট
    val Background: Color,
    val BackgroundElevated: Color,  // হেডার/হিরোর পেছনের গভীর টোন
    val Surface: Color,
    val SurfaceGlass: Color,        // গ্লাস কার্ডের বেস
    val GlassBorder: Color,
    val TextPrimary: Color,
    val TextSecondary: Color,
    val TextOnGradient: Color,
    val Success: Color,             // জমা/পরিশোধ
    val SuccessSoft: Color,
    val Danger: Color,              // বাকি/ধার
    val DangerSoft: Color,
    val Muted: Color,               // সেকেন্ডারি টেক্সট
    val ChipBg: Color,
    val Divider: Color,
    val Shadow: Color
)

// ── লাইট থিম — গভীর ইন্ডিগো/ভায়োলেট ব্র্যান্ড, ওয়ার্ম আইভরি ব্যাকগ্রাউন্ড ──
val LightKhataColors = KhataColors(
    Primary = Color(0xFF4F46E5),
    PrimaryDark = Color(0xFF3730A3),
    PrimaryLight = Color(0xFF818CF8),
    Secondary = Color(0xFF7C3AED),
    Background = Color(0xFFF4F5FB),
    BackgroundElevated = Color(0xFF1E1B4B),
    Surface = Color.White,
    SurfaceGlass = Color(0xF2FFFFFF),
    GlassBorder = Color(0x1F4F46E5),
    TextPrimary = Color(0xFF16162B),
    TextSecondary = Color(0xFF6B6B85),
    TextOnGradient = Color.White,
    Success = Color(0xFF0D9488),
    SuccessSoft = Color(0xFFE1F5F2),
    Danger = Color(0xFFE11D48),
    DangerSoft = Color(0xFFFCE4E9),
    Muted = Color(0xFF9797AC),
    ChipBg = Color(0xFFEDECFB),
    Divider = Color(0xFFE7E6F3),
    Shadow = Color(0x294F46E5)
)

// ── ডার্ক থিম — মিডনাইট গ্লাস ──
val DarkKhataColors = KhataColors(
    Primary = Color(0xFF818CF8),
    PrimaryDark = Color(0xFF4F46E5),
    PrimaryLight = Color(0xFFA5B4FC),
    Secondary = Color(0xFFC084FC),
    Background = Color(0xFF0B0B18),
    BackgroundElevated = Color(0xFF000000),
    Surface = Color(0xFF15152A),
    SurfaceGlass = Color(0xCC1D1D38),
    GlassBorder = Color(0x33A5B4FC),
    TextPrimary = Color(0xFFF1F1FA),
    TextSecondary = Color(0xFFA6A6C4),
    TextOnGradient = Color.White,
    Success = Color(0xFF2DD4BF),
    SuccessSoft = Color(0xFF16332F),
    Danger = Color(0xFFFB7185),
    DangerSoft = Color(0xFF3A1A24),
    Muted = Color(0xFF6E6E8C),
    ChipBg = Color(0xFF23233F),
    Divider = Color(0xFF262642),
    Shadow = Color(0x66000000)
)

val LocalKhataColors = staticCompositionLocalOf { LightKhataColors }

// ── গ্র্যাডিয়েন্ট টোকেন — প্রিমিয়াম ফিনটেক ফিল ──
object KhataGradients {
    fun brand(c: KhataColors) = Brush.linearGradient(listOf(c.Primary, c.Secondary))
    fun brandDeep(c: KhataColors) = Brush.linearGradient(
        listOf(c.PrimaryDark, c.Primary, c.Secondary)
    )
    fun danger(c: KhataColors) = Brush.linearGradient(
        listOf(Color(0xFFE11D48), Color(0xFFF43F5E), Color(0xFFFB7185))
    )
    fun success(c: KhataColors) = Brush.linearGradient(
        listOf(Color(0xFF0D9488), Color(0xFF14B8A6), Color(0xFF2DD4BF))
    )
    fun glassSheen(c: KhataColors) = Brush.linearGradient(
        listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.02f))
    )
    fun heroRadial(c: KhataColors) = Brush.radialGradient(
        listOf(c.Secondary.copy(alpha = 0.55f), Color.Transparent)
    )
}

// ── M3 ColorScheme সিঙ্ক ──
fun khataLightScheme(): ColorScheme = lightColorScheme(
    primary = LightKhataColors.Primary,
    onPrimary = Color.White,
    secondary = LightKhataColors.Secondary,
    background = LightKhataColors.Background,
    onBackground = LightKhataColors.TextPrimary,
    surface = LightKhataColors.Surface,
    onSurface = LightKhataColors.TextPrimary,
    surfaceVariant = LightKhataColors.ChipBg,
    outline = LightKhataColors.Divider,
    error = LightKhataColors.Danger
)

fun khataDarkScheme(): ColorScheme = darkColorScheme(
    primary = DarkKhataColors.Primary,
    onPrimary = Color(0xFF10102A),
    secondary = DarkKhataColors.Secondary,
    background = DarkKhataColors.Background,
    onBackground = DarkKhataColors.TextPrimary,
    surface = DarkKhataColors.Surface,
    onSurface = DarkKhataColors.TextPrimary,
    surfaceVariant = DarkKhataColors.ChipBg,
    outline = DarkKhataColors.Divider,
    error = DarkKhataColors.Danger
)
