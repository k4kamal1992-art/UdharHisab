package com.udharhisab.ui.more

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.udharhisab.data.pdf.KhataPdfGenerator
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.pdf.PdfOptionsDialog
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(container: AppContainer, onOpenSettings: () -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showPdfDialog by remember { mutableStateOf(false) }
    val allShops by container.repo.shopsWithBalance().collectAsState(initial = emptyList())

    fun comingSoon() {
        scope.launch { snackbar.showSnackbar(s.comingSoonMessage) }
    }

    Scaffold(
        containerColor = c.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(s.moreTitle, style = MaterialTheme.typography.headlineSmall) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(vertical = 8.dp)
        ) {
            MoreGroup {
                MoreRow(Icons.Default.CloudUpload, s.moreBackupRestore, onClick = ::comingSoon)
                MoreRow(Icons.Default.IosShare, s.moreExportShare, onClick = { showPdfDialog = true })
                MoreRow(Icons.Default.Notifications, s.moreNotifications, onClick = onOpenSettings)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(Icons.Default.Language, s.moreLanguage, onClick = onOpenSettings)
                MoreRow(Icons.Default.Lock, s.moreSecurityPrivacy, onClick = onOpenSettings)
                MoreRow(Icons.Default.Palette, s.moreAppearance, onClick = onOpenSettings)
            }
            Spacer(Modifier.height(12.dp))
            MoreGroup {
                MoreRow(Icons.Default.Star, s.moreRateFeedback, onClick = ::comingSoon)
                MoreRow(Icons.Default.Info, s.moreAbout, onClick = onOpenSettings)
            }
        }
    }

    if (showPdfDialog) {
        PdfOptionsDialog(
            shops = allShops.map { it.shop },
            preselectedShopId = null,
            onDismiss = { showPdfDialog = false },
            onGenerate = { pdfShopId, fromTime, toTime, pdfScope, pdfFormat ->
                showPdfDialog = false
                scope.launch {
                    try {
                        val reportNumber = container.store.nextReportNumber()
                        val file = if (pdfShopId != null) {
                            val targetShop = container.repo.shopOnce(pdfShopId)
                            if (targetShop == null) {
                                snackbar.showSnackbar("${s.pdfFailPrefix}shop not found")
                                return@launch
                            }
                            val rangeTxns = container.repo.txnsWithItemsInRange(pdfShopId, fromTime, toTime)
                            KhataPdfGenerator(context, s).generateShopReport(
                                targetShop, rangeTxns, reportNumber, fromTime, toTime, pdfFormat, pdfScope
                            )
                        } else {
                            val rows = container.repo.shopReportRowsInRange(fromTime, toTime)
                            KhataPdfGenerator(context, s).generateAllShopsReport(
                                rows, reportNumber, fromTime, toTime
                            )
                        }
                        val uri = FileProvider.getUriForFile(
                            context, "${context.packageName}.fileprovider", file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, s.shareKhata))
                    } catch (e: Exception) {
                        snackbar.showSnackbar("${s.pdfFailPrefix}${e.message}")
                    }
                }
            }
        )
    }
}

@Composable
private fun MoreGroup(content: @Composable ColumnScope.() -> Unit) {
    GlassCard(modifier = Modifier.padding(horizontal = 20.dp)) {
        Column(content = content)
    }
}

@Composable
private fun MoreRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(KhataGradients.brand(c)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = c.TextPrimary, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = c.Muted)
    }
}
