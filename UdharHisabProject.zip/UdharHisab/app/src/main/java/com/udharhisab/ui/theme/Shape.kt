package com.udharhisab.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val KhataShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),      // কার্ড
    large = RoundedCornerShape(28.dp),       // হিরো কার্ড
    extraLarge = RoundedCornerShape(36.dp)   // বটম শিট
)

// পিল-শেপ বাটন/চিপ/ন্যাভের জন্য
val KhataPillShape = RoundedCornerShape(percent = 50)
