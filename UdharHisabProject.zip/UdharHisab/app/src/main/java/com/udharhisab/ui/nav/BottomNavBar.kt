package com.udharhisab.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.udharhisab.navigation.Route
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors

/** ⭐ চারটা ট্যাব — Home | History | Reports | More — ফ্লোটিং গ্লাস পিল ন্যাভ */
private data class NavItem(val route: Route, val icon: ImageVector, val label: String)

@Composable
fun BottomNavBar(currentRoute: String?, onNavigate: (Route) -> Unit) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    val items = listOf(
        NavItem(Route.Home, Icons.Filled.Home, s.navHome),
        NavItem(Route.History, Icons.Filled.History, s.navHistory),
        NavItem(Route.Reports, Icons.Filled.Assessment, s.navReports),
        NavItem(Route.More, Icons.AutoMirrored.Filled.List, s.navMore)
    )

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .shadow(18.dp, RoundedCornerShape(28.dp), ambientColor = c.Shadow, spotColor = c.Shadow)
            .clip(RoundedCornerShape(28.dp))
            .background(c.SurfaceGlass)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route.route
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .let {
                        if (selected) it.background(KhataGradients.brand(c)) else it
                    }
                    .clickable { onNavigate(item.route) }
                    .padding(vertical = 10.dp)
            ) {
                Icon(
                    item.icon,
                    item.label,
                    tint = if (selected) Color.White else c.Muted,
                    modifier = Modifier.size(22.dp)
                )
                if (selected) {
                    Text(
                        item.label,
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }
    }
}
