package com.udharhisab.ui.lock

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.udharhisab.data.settings.SettingsDataStore
import com.udharhisab.domain.PinHasher
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors
import kotlinx.coroutines.launch

/**
 * ⭐ পিন সেট (প্রথমবার) + আনলক — দুই মোড এক স্ক্রিনে, প্রিমিয়াম গ্র্যাডিয়েন্ট ব্যাকগ্রাউন্ড
 */
@Composable
fun LockScreen(
    store: SettingsDataStore,
    storedPinHash: String?,      // null হলে = সেটআপ মোড
    onUnlocked: () -> Unit
) {
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val isSetupMode = storedPinHash == null

    Box(
        Modifier
            .fillMaxSize()
            .background(KhataGradients.brandDeep(c))
    ) {
        // কর্নার গ্লো
        Box(
            Modifier
                .size(260.dp)
                .align(Alignment.TopCenter)
                .offset(y = (-100).dp)
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.16f), Color.Transparent)
                    ),
                    CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .size(84.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Text("🔒", style = MaterialTheme.typography.displayMedium)
            }
            Spacer(Modifier.height(18.dp))

            Text(
                if (isSetupMode) s.setupPinTitle else s.unlockPinTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )
            Spacer(Modifier.height(24.dp))

            GlassCard(shape = MaterialTheme.shapes.large) {
                Column(Modifier.padding(20.dp)) {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = {
                            if (it.length <= 4 && it.all { ch -> ch.isDigit() }) pin = it
                            error = null
                        },
                        label = { Text(s.pinLabel) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        isError = error != null,
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (isSetupMode) {
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = confirmPin,
                            onValueChange = {
                                if (it.length <= 4 && it.all { ch -> ch.isDigit() }) confirmPin = it
                                error = null
                            },
                            label = { Text(s.confirmPinLabel) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            isError = error != null,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    error?.let {
                        Spacer(Modifier.height(8.dp))
                        Text(it, color = c.Danger,
                            style = MaterialTheme.typography.bodyMedium)
                    }

                    Spacer(Modifier.height(20.dp))

                    val enabled = pin.length == 4 && (!isSetupMode || confirmPin.length == 4)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .let { m ->
                                if (enabled) {
                                    m
                                        .shadow(10.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
                                        .clip(RoundedCornerShape(percent = 50))
                                        .background(KhataGradients.brand(c))
                                } else {
                                    m
                                        .clip(RoundedCornerShape(percent = 50))
                                        .background(c.Muted.copy(alpha = 0.3f))
                                }
                            }
                    ) {
                        TextButton(
                            onClick = {
                                scope.launch {
                                    if (isSetupMode) {
                                        when {
                                            pin.length != 4 -> error = s.pinDigitsError
                                            pin != confirmPin -> error = s.pinsDontMatchError
                                            else -> {
                                                store.setPin(PinHasher.hash(pin))
                                                onUnlocked()
                                            }
                                        }
                                    } else {
                                        if (PinHasher.verify(pin, storedPinHash!!)) {
                                            onUnlocked()
                                        } else {
                                            error = s.wrongPinError
                                            pin = ""
                                        }
                                    }
                                }
                            },
                            enabled = enabled,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                if (isSetupMode) s.savePinButton else s.unlockButton,
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }
}
