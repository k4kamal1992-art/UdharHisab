package com.udharhisab.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.reminder.ReminderWorker
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    container: AppContainer,
    onBack: () -> Unit
) {
    val viewModel: SettingsViewModel = viewModel { SettingsViewModel(container.store) }
    val s = LocalStrings.current
    val c = LocalKhataColors.current
    val context = LocalContext.current

    val settings by viewModel.settings.collectAsState()
    val pinEnabled = settings.pinEnabled
    val reminderEnabled = settings.remindersEnabled
    val language = settings.language
    val theme = settings.theme

    var showPinDialog by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }

    val chipColors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = c.Primary,
        selectedLabelColor = androidx.compose.ui.graphics.Color.White
    )
    val switchColors = SwitchDefaults.colors(
        checkedThumbColor = androidx.compose.ui.graphics.Color.White,
        checkedTrackColor = c.Primary
    )

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.settingsTitle, style = MaterialTheme.typography.headlineSmall) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back, tint = c.TextPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // নিরাপত্তা সেকশন
            GlassCard {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(s.security, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (pinEnabled) s.pinLockOn else s.pinLockOff, color = c.TextSecondary)
                        Switch(
                            checked = pinEnabled,
                            colors = switchColors,
                            onCheckedChange = { checked ->
                                if (checked) showPinDialog = true else showRemoveDialog = true
                            }
                        )
                    }
                    if (pinEnabled) {
                        TextButton(onClick = { showPinDialog = true }) {
                            Text(s.changePin, color = c.Primary)
                        }
                    }
                }
            }

            // রিমাইন্ডার সেকশন
            GlassCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(s.reminderTitle, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                        Text(
                            s.reminderDesc,
                            style = MaterialTheme.typography.bodySmall, color = c.Muted
                        )
                    }
                    Switch(
                        checked = reminderEnabled,
                        colors = switchColors,
                        onCheckedChange = { checked ->
                            viewModel.setReminder(checked)
                            if (checked) ReminderWorker.schedule(context)
                            else ReminderWorker.cancel(context)
                        }
                    )
                }
            }

            // ⭐ ভাষা সেকশন
            GlassCard {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(s.languageTitle, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = language == "bn",
                            onClick = { viewModel.setLanguage("bn") },
                            label = { Text(s.languageBengaliOption) },
                            colors = chipColors,
                            shape = RoundedCornerShape(percent = 50)
                        )
                        FilterChip(
                            selected = language == "en",
                            onClick = { viewModel.setLanguage("en") },
                            label = { Text(s.languageEnglishOption) },
                            colors = chipColors,
                            shape = RoundedCornerShape(percent = 50)
                        )
                    }
                }
            }

            // ⭐ অ্যাপের চেহারা
            GlassCard {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(s.appearanceTitle, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = theme == "light",
                            onClick = { viewModel.setTheme("light") },
                            label = { Text(s.themeLight) },
                            colors = chipColors,
                            shape = RoundedCornerShape(percent = 50)
                        )
                        FilterChip(
                            selected = theme == "dark",
                            onClick = { viewModel.setTheme("dark") },
                            label = { Text(s.themeDark) },
                            colors = chipColors,
                            shape = RoundedCornerShape(percent = 50)
                        )
                        FilterChip(
                            selected = theme == "system",
                            onClick = { viewModel.setTheme("system") },
                            label = { Text(s.themeSystem) },
                            colors = chipColors,
                            shape = RoundedCornerShape(percent = 50)
                        )
                    }
                }
            }

            // সম্পর্কে
            GlassCard {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(s.about, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                    Text(s.aboutLine, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                    Text(s.versionLine, style = MaterialTheme.typography.bodySmall, color = c.Muted)
                }
            }
        }
    }

    // PIN সেট করার ডায়ালগ
    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text(s.setPinTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.take(6) },
                        label = { Text(s.newPinLabel) },
                        isError = error
                    )
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it.take(6) },
                        label = { Text(s.confirmPinLabel) },
                        isError = error
                    )
                    if (error) {
                        Text(
                            s.pinSetupError,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pin.length >= 4 && pin == confirm) {
                            viewModel.savePin(pin)
                            showPinDialog = false
                        } else {
                            error = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = c.Primary)
                ) { Text(s.save) }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text(s.cancel) }
            }
        )
    }

    // PIN মুছার ডায়ালগ
    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            title = { Text(s.removePinTitle) },
            text = { Text(s.removePinText) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.removePin()
                    showRemoveDialog = false
                }) { Text(s.yesTurnOff) }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveDialog = false }) { Text(s.no) }
            }
        )
    }
}
