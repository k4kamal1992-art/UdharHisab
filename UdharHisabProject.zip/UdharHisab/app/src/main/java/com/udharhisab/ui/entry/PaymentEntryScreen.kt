package com.udharhisab.ui.entry

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.components.GradientHeroCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentEntryScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val shop by container.repo.shopByIdFlow(shopId).collectAsState(initial = null)

    val shopVal = shop
    if (shopVal == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = c.Primary) }
        return
    }
    val shopName = shopVal.name

    val vm: PaymentEntryViewModel = viewModel { PaymentEntryViewModel(container.repo, shopId) }
    val currentDue = vm.currentDue

    LaunchedEffect(vm.saved) { if (vm.saved) onSaved() }

    val quickAmounts = listOf(50.0, 100.0, 200.0, 500.0).filter { it <= currentDue && it > 0 }
    val dueAfter = vm.dueAfter()
    val amountEntered = vm.amount.toDoubleOrNull() ?: 0.0

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(shopName, style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = c.TextPrimary)
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = c.Background, shadowElevation = 0.dp) {
                Column(Modifier.padding(16.dp)) {
                    if (vm.error) {
                        Text(s.invalidAmountError, color = c.Danger,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (vm.overpaymentError) {
                        Text(s.overpaymentBlockedMessage, color = c.Danger,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .shadow(12.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
                            .clip(RoundedCornerShape(percent = 50))
                            .background(KhataGradients.success(c))
                    ) {
                        TextButton(
                            onClick = { vm.save(onSaved) },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                "${s.addPaymentButton} — ${UnitConverter.rupees(amountEntered)}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🟢", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.width(8.dp))
                Text(s.paymentPageTitle, style = MaterialTheme.typography.titleLarge, color = c.TextPrimary)
            }
            Spacer(Modifier.height(16.dp))

            GradientHeroCard(gradient = KhataGradients.brand(c)) {
                Column(Modifier.padding(18.dp)) {
                    Text(s.currentDueLabel, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.displaySmall)
                    Text(UnitConverter.rupees(currentDue), style = MaterialTheme.typography.displayMedium, color = Color.White)
                }
            }
            Spacer(Modifier.height(20.dp))

            Text(s.howMuchPaymentLabel, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = vm.amount,
                onValueChange = vm::updateAmount,
                singleLine = true,
                isError = vm.error || vm.overpaymentError,
                textStyle = MaterialTheme.typography.headlineSmall,
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Success,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                quickAmounts.forEach { qa ->
                    QuickAmountChip(UnitConverter.rupees(qa)) { vm.setQuickAmount(qa) }
                }
                QuickAmountChip(s.fullPaymentButton) { vm.setFullPayment() }
            }
            Spacer(Modifier.height(20.dp))

            GlassCard {
                Column(Modifier.padding(16.dp)) {
                    Text(s.dueAfterPaymentLabel, color = c.Muted)
                    Text(UnitConverter.rupees(dueAfter), style = MaterialTheme.typography.headlineMedium, color = c.Success)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${UnitConverter.rupees(currentDue)} − ${UnitConverter.rupees(amountEntered)} = ${UnitConverter.rupees(dueAfter)}",
                        style = MaterialTheme.typography.bodySmall, color = c.Muted
                    )
                    if (dueAfter == 0.0 && amountEntered > 0) {
                        Spacer(Modifier.height(6.dp))
                        Text(s.fullyPaidCelebration, color = c.Success, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = vm.note, onValueChange = vm::updateNote,
                label = { Text(s.noteLabel) },
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Success,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QuickAmountChip(label: String, onClick: () -> Unit) {
    val c = LocalKhataColors.current
    AssistChip(
        onClick = onClick,
        label = { Text(label) },
        shape = RoundedCornerShape(percent = 50),
        colors = AssistChipDefaults.assistChipColors(containerColor = c.ChipBg)
    )
}
