package com.udharhisab.ui.addshop

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.strings.displayName
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddShopScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val vm: AddShopViewModel = viewModel { AddShopViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current

    LaunchedEffect(vm.saved.value) {
        if (vm.saved.value) onSaved(vm.savedShopId.longValue)
    }

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.newShop) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = c.TextPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            // নাম
            OutlinedTextField(
                value = vm.name.value,
                onValueChange = vm::setName,
                label = { Text(s.shopNameLabel) },
                placeholder = { Text(s.shopNamePlaceholder) },
                singleLine = true,
                isError = vm.error.value != null,
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Primary,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))

            // ফোন
            OutlinedTextField(
                value = vm.phone.value,
                onValueChange = vm::setPhone,
                label = { Text(s.phoneLabel) },
                placeholder = { Text("01XXXXXXXXX") },
                singleLine = true,
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = c.Surface,
                    unfocusedContainerColor = c.Surface,
                    focusedIndicatorColor = c.Primary,
                    unfocusedIndicatorColor = c.Divider
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(22.dp))
            Text(s.shopTypeLabel, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)

            Spacer(Modifier.height(10.dp))

            // ⭐ ShopType গ্রিড (২ কলাম) — প্রিমিয়াম গ্লাস/গ্র্যাডিয়েন্ট সিলেকশন
            ShopType.entries.chunked(2).forEach { rowTypes ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    rowTypes.forEach { t ->
                        val selected = vm.selectedType.value == t
                        ShopTypeTile(
                            emoji = t.emoji,
                            label = t.displayName(s),
                            selected = selected,
                            onClick = { vm.setType(t) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowTypes.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
            }

            vm.error.value?.let { err ->
                val msg = when (err) {
                    AddShopError.NAME_REQUIRED -> s.errorNameRequired
                    AddShopError.TYPE_REQUIRED -> s.errorTypeRequired
                }
                Spacer(Modifier.height(8.dp))
                Text(msg, color = c.Danger,
                    style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(24.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(14.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(KhataGradients.brand(c))
            ) {
                TextButton(
                    onClick = { vm.save(s.code) },
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(s.saveShopButton, color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun ShopTypeTile(
    emoji: String,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalKhataColors.current
    GlassCard(shape = MaterialTheme.shapes.medium, onClick = onClick, modifier = modifier) {
        Column(
            Modifier
                .let { if (selected) it.background(c.ChipBg) else it }
                .padding(vertical = 16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) c.Primary else c.TextSecondary
            )
        }
    }
}
