package com.udharhisab.ui.entry

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopProductEntity
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.components.GradientHeroCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.KhataColors
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreditEntryScreen(
    container: AppContainer,
    shopId: Long,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val products by container.repo.shopProducts(shopId).collectAsState(initial = emptyList())
    val shop by container.repo.shopByIdFlow(shopId).collectAsState(initial = null)
    var currentDue by remember { mutableStateOf(0.0) }
    LaunchedEffect(shopId) { currentDue = container.repo.balanceOnce(shopId) }

    val shopVal = shop
    if (shopVal == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = c.Primary) }
        return
    }
    val shopName = shopVal.name
    val isWoodShop = ShopType.fromKey(shopVal.shopType) == ShopType.WOOD

    val vm: CreditEntryViewModel = viewModel { CreditEntryViewModel(container.repo, shopId, isWoodShop) }

    LaunchedEffect(vm.saved) { if (vm.saved) onSaved() }

    val total = vm.totalAmount()
    val newTotalDue = currentDue + total

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(shopName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${s.currentDueLabel}: ${UnitConverter.rupees(currentDue)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.Muted
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = c.TextPrimary)
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = c.Background, shadowElevation = 0.dp) {
                Column(Modifier.padding(16.dp)) {
                    if (vm.error) {
                        Text(s.invalidAmountError, color = c.Danger,
                            modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .shadow(12.dp, RoundedCornerShape(percent = 50), ambientColor = c.Shadow, spotColor = c.Shadow)
                            .clip(RoundedCornerShape(percent = 50))
                            .background(KhataGradients.danger(c))
                    ) {
                        TextButton(
                            onClick = { vm.save(onSaved) },
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                "${s.addCreditButton} — ${UnitConverter.rupees(total)}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            // ── হিসাবের ধরন ──
            Text(s.accountingTypeLabel, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeChip(
                    label = s.directMoneyMode,
                    selected = vm.mode == CreditMode.DIRECT,
                    onClick = { vm.selectMode(CreditMode.DIRECT) },
                    modifier = Modifier.weight(1f)
                )
                ModeChip(
                    label = s.productMode,
                    selected = vm.mode == CreditMode.PRODUCT,
                    onClick = { vm.selectMode(CreditMode.PRODUCT) },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(16.dp))

            if (vm.mode == CreditMode.DIRECT) {
                PremiumField(vm.directAmount, vm::updateDirectAmount, s.directMoneyAmountLabel, vm.error)
                Spacer(Modifier.height(16.dp))
                DueCalcBox(s.previousDueLabel, currentDue, s.newCreditLabel, total, s.newTotalDueLabel, newTotalDue, c)
                Spacer(Modifier.height(16.dp))
                NoteField(vm.note, vm::updateNote, s.noteLabel)
                Spacer(Modifier.height(24.dp))
            } else {
                if (isWoodShop) {
                    TimberCalculator { productName, totalCft, ratePerCft ->
                        vm.addProductRowFromTimber(productName, totalCft, ratePerCft)
                    }
                    Spacer(Modifier.height(16.dp))
                    if (vm.productRows.isNotEmpty()) {
                        Text(s.addedItemsHeader, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                        Spacer(Modifier.height(8.dp))
                    }
                }

                vm.productRows.forEachIndexed { index, row ->
                    ProductRowCard(
                        row = row,
                        suggestions = products,
                        canDelete = true,
                        onDelete = { vm.removeProductRow(row) }
                    )
                    Spacer(Modifier.height(10.dp))
                }

                OutlinedButton(
                    onClick = { vm.addProductRow() },
                    shape = MaterialTheme.shapes.small,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, c.Primary),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = c.Primary),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (isWoodShop) s.addMoreWoodProductButton else s.addMoreProductButton) }

                Spacer(Modifier.height(16.dp))

                // ⭐ সবসময় দৃশ্যমান টোটাল
                GlassCard {
                    Row(
                        Modifier.padding(14.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(s.totalNewCreditLabel, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                        Text(UnitConverter.rupees(total), style = MaterialTheme.typography.titleMedium, color = c.Danger)
                    }
                }
                Spacer(Modifier.height(12.dp))
                DueCalcBox(s.previousDueLabel, currentDue, s.newCreditLabel, total, s.newTotalDueLabel, newTotalDue, c)
                Spacer(Modifier.height(16.dp))
                NoteField(vm.note, vm::updateNote, s.noteLabel)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalKhataColors.current
    Box(
        modifier
            .clip(RoundedCornerShape(percent = 50))
            .let { if (selected) it.background(KhataGradients.brand(c)) else it.background(c.Surface) }
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color.White else c.TextSecondary,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun PremiumField(value: String, onChange: (String) -> Unit, label: String, isError: Boolean) {
    val c = LocalKhataColors.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        isError = isError,
        shape = MaterialTheme.shapes.small,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = c.Surface,
            unfocusedContainerColor = c.Surface,
            focusedIndicatorColor = c.Danger,
            unfocusedIndicatorColor = c.Divider
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun DueCalcBox(
    prevLabel: String, prev: Double,
    newLabel: String, added: Double,
    totalLabel: String, total: Double,
    c: KhataColors
) {
    GlassCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(prevLabel, color = c.Muted)
                Text(UnitConverter.rupees(prev), color = c.TextPrimary)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(newLabel, color = c.Muted)
                Text(UnitConverter.rupees(added), color = c.Danger)
            }
            HorizontalDivider(color = c.Divider)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(totalLabel, style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                Text(UnitConverter.rupees(total), style = MaterialTheme.typography.titleMedium, color = c.Danger)
            }
        }
    }
}

@Composable
private fun NoteField(value: String, onChange: (String) -> Unit, label: String) {
    val c = LocalKhataColors.current
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) },
        shape = MaterialTheme.shapes.small,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = c.Surface,
            unfocusedContainerColor = c.Surface,
            focusedIndicatorColor = c.Primary,
            unfocusedIndicatorColor = c.Divider
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductRowCard(
    row: ProductRow,
    suggestions: List<ShopProductEntity>,
    canDelete: Boolean,
    onDelete: () -> Unit
) {
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    var expanded by remember { mutableStateOf(false) }
    val filtered = remember(suggestions, row.productName) {
        val q = row.productName.trim()
        if (q.isEmpty()) suggestions else suggestions.filter { it.name.contains(q, ignoreCase = true) }
    }

    GlassCard {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ExposedDropdownMenuBox(
                    expanded = expanded && filtered.isNotEmpty(),
                    onExpandedChange = { expanded = it },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = row.productName,
                        onValueChange = { row.productName = it; expanded = true },
                        label = { Text(s.productNameLabel) },
                        singleLine = true,
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded && filtered.isNotEmpty(),
                        onDismissRequest = { expanded = false }
                    ) {
                        filtered.forEach { p ->
                            DropdownMenuItem(
                                text = {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                        p.lastUnitPrice?.let {
                                            Text(UnitConverter.rupees(it), color = c.Muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                },
                                onClick = {
                                    row.productName = p.name
                                    p.lastUnit?.let { row.unit = it }
                                    p.lastUnitPrice?.let { row.unitPrice = UnitConverter.amountInput(it) }
                                    expanded = false
                                }
                            )
                        }
                    }
                }
                if (canDelete) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, s.deleteTxnAction, tint = c.Muted)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = row.quantity, onValueChange = { row.quantity = it },
                    label = { Text(s.quantityLabel) }, singleLine = true,
                    shape = MaterialTheme.shapes.small, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = row.unit, onValueChange = { row.unit = it },
                    label = { Text(s.unitLabel) }, singleLine = true,
                    shape = MaterialTheme.shapes.small, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = row.unitPrice, onValueChange = { row.unitPrice = it },
                    label = { Text(s.pricePerUnitLabel) }, singleLine = true,
                    shape = MaterialTheme.shapes.small, modifier = Modifier.weight(1f)
                )
            }
            row.amount?.let {
                Spacer(Modifier.height(6.dp))
                Text(
                    "${row.productName.ifBlank { s.creditFallback }} — ${UnitConverter.rupees(it)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.Danger
                )
            }
        }
    }
}
