package com.udharhisab.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.udharhisab.data.local.ShopType
import com.udharhisab.di.AppContainer
import com.udharhisab.domain.UnitConverter
import com.udharhisab.ui.components.GlassCard
import com.udharhisab.ui.strings.LocalStrings
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ আর্কাইভ/পরিশোধিত দোকানের লিস্ট — History ট্যাবের টপ বার থেকে খোলা যায়।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchivedShopsScreen(
    container: AppContainer,
    onBack: () -> Unit,
    onOpenShop: (Long) -> Unit
) {
    val vm: HistoryViewModel = viewModel { HistoryViewModel(container.repo) }
    val c = LocalKhataColors.current
    val s = LocalStrings.current
    val shops by vm.shops.collectAsState()
    val tab by vm.tab.collectAsState()

    Scaffold(
        containerColor = c.Background,
        topBar = {
            TopAppBar(
                title = { Text(s.archive) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = c.Background),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, s.back, tint = c.TextPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                TabRow(
                    selectedTabIndex = tab.ordinal,
                    containerColor = c.Background,
                    contentColor = c.Primary
                ) {
                    Tab(
                        selected = tab == HistoryViewModel.Tab.ARCHIVED,
                        onClick = { vm.setTab(HistoryViewModel.Tab.ARCHIVED) },
                        text = { Text(s.archive) }
                    )
                    Tab(
                        selected = tab == HistoryViewModel.Tab.SETTLED,
                        onClick = { vm.setTab(HistoryViewModel.Tab.SETTLED) },
                        text = { Text(s.settledLabel) }
                    )
                }

                Spacer(Modifier.height(14.dp))

                if (shops.isEmpty()) {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🗂️", style = MaterialTheme.typography.displayLarge)
                        Text(
                            if (tab == HistoryViewModel.Tab.ARCHIVED)
                                s.noArchivedShops else s.noSettledShops,
                            color = c.Muted
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(shops, key = { it.shop.id }) { swb ->
                            GlassCard(onClick = { onOpenShop(swb.shop.id) }) {
                                Row(Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        ShopType.fromKey(swb.shop.shopType).emoji,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(swb.shop.name,
                                            style = MaterialTheme.typography.titleMedium, color = c.TextPrimary)
                                    }
                                    Text(
                                        if (swb.balance > 0) UnitConverter.rupees(swb.balance)
                                        else "✓",
                                        color = if (swb.balance > 0) c.Danger else c.Success,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
