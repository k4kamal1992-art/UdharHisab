package com.udharhisab.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.udharhisab.ui.theme.KhataColors
import com.udharhisab.ui.theme.KhataGradients
import com.udharhisab.ui.theme.LocalKhataColors

/**
 * ⭐ প্রিমিয়াম গ্র্যাডিয়েন্ট হিরো কার্ড — ডিপ শ্যাডো + সফট গ্লাস শাইন + কর্নার গ্লো
 * টাকার হিরো ব্যালেন্স, শপ ডিটেইল হিরো ইত্যাদির জন্য ব্যবহার করুন
 */
@Composable
fun GradientHeroCard(
    modifier: Modifier = Modifier,
    gradient: Brush,
    shape: Shape = MaterialTheme.shapes.large,
    shadowColor: Color = Color.Black.copy(alpha = 0.28f),
    content: @Composable BoxWithConstraints.() -> Unit
) {
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .shadow(
                elevation = 22.dp,
                shape = shape,
                ambientColor = shadowColor,
                spotColor = shadowColor
            )
            .clip(shape)
            .background(gradient)
    ) {
        // কর্নার গ্লো — উপরে-ডানে হালকা সাদা আভা, গভীরতার ফিল
        Box(
            Modifier
                .size(180.dp)
                .align(Alignment.TopEnd)
                .offset(x = 50.dp, y = (-60).dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.20f), Color.Transparent)
                    ),
                    CircleShape
                )
        )
        // গ্লাস শাইন স্ট্রাইপ — উপরের অংশে সূক্ষ্ম উজ্জ্বলতা
        Box(
            Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.10f), Color.Transparent)
                    )
                )
        )
        content()
    }
}

/**
 * ⭐ গ্লাসমরফিক কার্ড — সেমি-ট্রান্সপারেন্ট সারফেস + হালকা বর্ডার + সফট শ্যাডো
 * তালিকার আইটেম, সাধারণ কার্ডের জন্য
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = MaterialTheme.shapes.medium,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val c = LocalKhataColors.current
    var m = modifier
        .fillMaxWidth()
        .shadow(
            elevation = 8.dp,
            shape = shape,
            ambientColor = c.Shadow,
            spotColor = c.Shadow
        )
        .clip(shape)
        .background(c.SurfaceGlass)
        .border(1.dp, c.GlassBorder, shape)
    if (onClick != null) {
        m = m.clickable(onClick = onClick)
    }
    Box(modifier = m) {
        content()
    }
}

/** গ্র্যাডিয়েন্ট বৃত্তাকার অ্যাভাটার/আইকন বাজ — ইমোজি বা আইকনের ব্যাকগ্রাউন্ড */
@Composable
fun GradientAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 46.dp,
    gradient: Brush,
    content: @Composable () -> Unit
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

/** পিল আকৃতির গ্র্যাডিয়েন্ট ব্যাজ — স্ট্যাটাস/অ্যামাউন্ট চিপের জন্য */
@Composable
fun GradientPill(
    modifier: Modifier = Modifier,
    gradient: Brush,
    content: @Composable () -> Unit
) {
    Box(
        modifier
            .clip(RoundedCornerShape(percent = 50))
            .background(gradient),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

fun KhataColors.heroGradientFor(isDue: Boolean): Brush =
    if (isDue) KhataGradients.danger(this) else KhataGradients.success(this)
