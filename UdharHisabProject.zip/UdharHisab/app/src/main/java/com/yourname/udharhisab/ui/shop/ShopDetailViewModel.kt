package com.yourname.udharhisab.ui.shop

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.yourname.udharhisab.UdharHisabApp
import com.yourname.udharhisab.data.local.ShopTotals
import com.yourname.udharhisab.data.model.Shop
import com.yourname.udharhisab.data.model.Transaction
import com.yourname.udharhisab.data.repository.ShopRepository
import com.yourname.udharhisab.data.repository.TransactionRepository

class ShopDetailViewModel(
    application: Application,
    private val shopId: Long
) : AndroidViewModel(application) {

    private val shopRepository: ShopRepository = (application as UdharHisabApp).shopRepository
    private val transactionRepository: TransactionRepository = application.transactionRepository

    val shop: LiveData<Shop> = shopRepository.allShops.map { shops ->
        shops.find { it.id == shopId } ?: Shop(name = "", ownerName = "")
    } ?: TODO("Need to handle this properly")

    val transactions: LiveData<List<Transaction>> = transactionRepository.getTransactionsByShop(shopId)
    val balance: LiveData<Double> = transactionRepository.getShopBalance(shopId)
    val totals: LiveData<ShopTotals> = transactionRepository.getShopTotals(shopId)

    suspend fun deleteTransaction(transaction: Transaction) {
        transactionRepository.delete(transaction)
    }
}

@Suppress("UNCHECKED_CAST")
class ShopDetailViewModelFactory(
    private val application: Application,
    private val shopId: Long
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ShopDetailViewModel(application, shopId) as T
    }
}
