package com.yourname.udharhisab.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.yourname.udharhisab.R
import com.yourname.udharhisab.adapter.ShopAdapter
import com.yourname.udharhisab.adapter.TransactionAdapter
import com.yourname.udharhisab.databinding.ActivityHomeBinding
import com.yourname.udharhisab.ui.entry.NewEntryActivity
import com.yourname.udharhisab.ui.history.HistoryActivity
import com.yourname.udharhisab.ui.settings.SettingsActivity
import com.yourname.udharhisab.ui.shop.AddShopActivity
import com.yourname.udharhisab.ui.shop.ShopDetailActivity
import com.yourname.udharhisab.utils.Constants

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var viewModel: HomeViewModel
    private lateinit var shopAdapter: ShopAdapter
    private lateinit var transactionAdapter: TransactionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        )[HomeViewModel::class.java]

        setupUI()
        setupAds()
        observeData()
    }

    private fun setupUI() {
        // Shop list
        shopAdapter = ShopAdapter { shop ->
            val intent = Intent(this, ShopDetailActivity::class.java)
            intent.putExtra("shop_id", shop.id)
            startActivity(intent)
        }
        binding.recyclerShops.layoutManager = LinearLayoutManager(this)
        binding.recyclerShops.adapter = shopAdapter

        // Recent transactions
        transactionAdapter = TransactionAdapter { transaction ->
            // Handle transaction click
        }
        binding.recyclerRecent.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerRecent.adapter = transactionAdapter

        // FAB - New Entry
        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, NewEntryActivity::class.java))
        }

        // Add Shop button
        binding.btnAddShop.setOnClickListener {
            startActivity(Intent(this, AddShopActivity::class.java))
        }

        // Bottom navigation
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, NewEntryActivity::class.java))
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }
        binding.bottomNav.selectedItemId = R.id.nav_home
    }

    private fun setupAds() {
        val adRequest = AdRequest.Builder().build()
        binding.adView.loadAd(adRequest)
    }

    private fun observeData() {
        viewModel.allShops.observe(this) { shops ->
            shopAdapter.submitList(shops)
            binding.tvTotalShops.text = shops.size.toString()
        }

        viewModel.recentTransactions.observe(this) { transactions ->
            transactionAdapter.submitList(transactions)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshStats()
    }
}
